set define '^' verify off
prompt ...wwv_flows_release
create or replace function wwv_flows_release wrapped 
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
64 89
39XFlj5D6i1Z2n6ZYw9yctFAPDEwg8eZgcfLCNL+XhaWlm2u2fqWlkqW8tehLlbcXOfAsr2y
m17nx3TAM7h0ZQm4dIvmOdziuUE/cZ5nqcoOo3fwX4F0gVY9O75xc3HYiKaurR8f

/

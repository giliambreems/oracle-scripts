set define '^' verify off
prompt ...patch_35823778.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35823778.sql
--
--    DESCRIPTION
--      Bug 35823778 - SEARCH REGION WITH TWO OR MORE SEARCH SOURCES BREAKS APPLICATION SEARCH
--
--    MODIFIED   (MM/DD/YYYY)
--    cczarski    09/21/2023 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_dictionary_views
   set pk_column_name = 'SEARCH_SOURCE_ID'
 where view_name = 'APEX_APPL_PAGE_SEARCH_SOURCES'
/

commit
/

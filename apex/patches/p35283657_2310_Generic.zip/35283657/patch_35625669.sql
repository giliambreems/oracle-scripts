set define '^' verify off
prompt ...patch_35625669.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35625669.sql
--
--    DESCRIPTION
--      Bug 35625669 - APPROVAL COMPONENT: CREATED ON, CREATED BY, LAST UPDATED 
--                     ON AND LAST UPDATED BY IS OVERWRITTEN AT APP RE-IMPORT 
--                     WITH REPLACEMENT 
--
--    MODIFIED   (MM/DD/YYYY)
--      ralmuell    07/27/2023 - Created
--
--------------------------------------------------------------------------------

prompt ... trigger wwv_flow_tasks$_t1
create or replace trigger wwv_flow_tasks$_t1
    before insert or update or delete on wwv_flow_tasks$
    for each row
begin
    if inserting or updating then
        if inserting and :new.id is null then
            :new.id := wwv_flow_id.next_val;
        end if;

        -- vpd
        if :new.security_group_id is null then
           :new.security_group_id := wwv_flow_security.g_curr_flow_security_group_id;
        end if;
        if inserting and not wwv_flow.g_import_in_progress then
                :new.created_on := systimestamp;
                :new.created_by := wwv_flow.g_user;
        end if;
        --
        if not wwv_flow.g_import_in_progress then
            :new.last_updated_on := systimestamp;
            :new.last_updated_by := wwv_flow.g_user;
        end if;
    end if;
end;
/

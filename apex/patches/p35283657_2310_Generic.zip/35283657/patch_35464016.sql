set define '^' verify off
prompt ...patch_35464016.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35464016.sql
--
--    DESCRIPTION
--      Bug 35464016: Remove orphaned meta data in WWV_FLOW_IG_REPORTS, enable triggers and constraints
--
--    MODIFIED   (MM/DD/YYYY)
--      fgrassho    06/09/2023 - Created
--
--------------------------------------------------------------------------------
declare
    -- check if any trigger or constraint is disabled
    function check_trg_and_cons_state return number is
        v_cnt number;
    begin
        -- check trigger
        select count(*)
          into v_cnt
          from dba_triggers
         where table_name = 'WWV_FLOW_IG_REPORTS'
           and owner      = 'APEX_230100'
           and status     <> 'ENABLED'
           and rownum     <= 1;
    
        if v_cnt > 0 then
            return v_cnt;
        end if;
        
        -- check constraints
        select count(*)
          into v_cnt
          from dba_constraints
         where table_name = 'WWV_FLOW_IG_REPORTS'
           and owner      = 'APEX_230100'
           and status     <> 'ENABLED'
           and rownum     <= 1;
    
        return v_cnt;
    end check_trg_and_cons_state;
begin
    if check_trg_and_cons_state > 0 then

        -- remove orphaned data
        delete
          from WWV_FLOW_IG_REPORTS t1
         where t1.session_id is not null
           and not exists (select 1
                             from WWV_FLOW_SESSIONS$ t2
                            where t2.id = t1.session_id);

        delete
          from WWV_FLOW_IG_REPORTS t1
         where not exists (select 1
                             from WWV_FLOW_INTERACTIVE_GRIDS t2
                            where t2.id = t1.interactive_grid_id);
                
        delete
          from WWV_FLOW_IG_REPORTS t1
         where not exists (select 1
                             from WWV_FLOWS t2
                            where t2.id = t1.flow_id);

        -- enable triggers and constraints
        wwv_flow_upgrade.enable_cons_and_trg( p_owner_name  => 'APEX_230100', 
                                              p_object_name => 'WWV_FLOW_IG_REPORTS');

    end if;
end;
/

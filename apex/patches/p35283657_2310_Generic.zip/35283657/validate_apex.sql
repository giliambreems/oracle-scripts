set define '^' verify off
prompt ...validate_apex
create or replace procedure validate_apex as
--------------------------------------------------------------------------------
--
-- Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      validate_apex.sql
--
--    SYNOPSIS
--      @validate_apex x x APEX_050100
--
--    DESCRIPTION
--      This procedure checks that the objects in the APEX application schema
--      are valid.
--
--    NOTES
--      Assumes the SYS user is connected. Call with 3 parameters, the 3rd has
--      to be the APEX schema.
--
--    MODIFIED   (MM/DD/YYYY)
--      jstraub   06/21/2006 - Created, borrowed almost exclusively from CTXSYS, thanks gkaminag
--
--------------------------------------------------------------------------------
    c_apex_schema        constant varchar2(30) := '^3';
    l_reg_schema         varchar2(30);
    l_error_count        pls_integer := 0;
    c_key_apex_objects   constant sys.dbms_debug_vc2coll := sys.dbms_debug_vc2coll (
                                                                'WWV_FLOW_COLLECTIONS$',
                                                                'WWV_FLOW_COMPANIES',
                                                                'WWV_FLOW_FND_USER',
                                                                'WWV_FLOW_ITEMS',
                                                                'WWV_FLOW_LISTS',
                                                                'WWV_FLOW_MAIL_QUEUE',
                                                                'WWV_FLOW_PUSH_QUEUE',
                                                                'WWV_FLOW_MESSAGES$',
                                                                'WWV_FLOW_PAGE_PLUGS',
                                                                'WWV_FLOW_STEP_ITEMS',
                                                                'WWV_FLOW_STEP_PROCESSING',
                                                                'WWV_FLOW_STEP_VALIDATIONS',
                                                                'WWV_FLOW_STEPS',
                                                                'WWV_FLOW_SW_STMTS',
                                                                'WWV_FLOWS',
                                                                'WWV_FLOW_DML',
                                                                'WWV_FLOW_ITEM',
                                                                'WWV_FLOW_LANG',
                                                                'WWV_FLOW_LOG',
                                                                'WWV_FLOW_MAIL',
                                                                'WWV_FLOW_SVG',
                                                                'WWV_FLOW_SW_PARSER',
                                                                'WWV_FLOW_SW_UTIL',
                                                                'WWV_FLOW_UTILITIES',
                                                                'F',
                                                                'P',
                                                                'Z',
                                                                'V',
                                                                -- scheduler jobs
                                                                'ORACLE_APEX_DAILY_MAINTENANCE',
                                                                'ORACLE_APEX_MAIL_QUEUE',
                                                                'ORACLE_APEX_PURGE_SESSIONS',
                                                                'ORACLE_APEX_WS_NOTIFICATIONS' );
    c_key_file_objects   constant sys.dbms_debug_vc2coll := sys.dbms_debug_vc2coll (
                                                                'WWV_FLOW_FILE_OBJECTS$',
                                                                'WWV_BIU_FLOW_FILE_OBJECTS' );
    c_key_sys_objects    constant sys.dbms_debug_vc2coll := sys.dbms_debug_vc2coll (
                                                                'WWV_DBMS_SQL_'||c_apex_schema,
                                                                'WWV_FLOW_KEY',
                                                                'WWV_FLOW_VAL' );
    c_inherit_any_privs  constant varchar2(30)           := 'INHERIT ANY PRIVILEGES';
    type t_vc_map        is table of varchar2(30) index by varchar2(30);
    l_known_privs        t_vc_map;

    e_job_not_running    exception;
    pragma exception_init( e_job_not_running, -27366 );

    l_job_enabled_yn     t_vc_map;
--------------------------------------------------------------------------------
    procedure p (
        p_message in varchar2 )
    is
    begin
        sys.dbms_output.put_line (p_message);
    end p;
--------------------------------------------------------------------------------
    procedure error (
        p_message in varchar2 )
    is
    begin
        l_error_count := l_error_count + 1;
        if nvl(l_reg_schema,'x') = c_apex_schema then
            p('ORA-20001: '||p_message);
        else
            p('Current APEX schema is '||l_reg_schema||' and validate schema is '||c_apex_schema);
        end if;
    end error;
--------------------------------------------------------------------------------
    procedure log_action (
        p_message in varchar2 )
    is
    begin
        p('...('||to_char(sysdate,'HH24:MI:SS')||') '||p_message);
    end log_action;
--------------------------------------------------------------------------------
    procedure check_key_objects_exist (
        p_schema  in varchar2,
        p_objects in sys.dbms_debug_vc2coll )
    is
    begin
        for i in ( select p.column_value object_name,
                          o.status
                     from table(p_objects) p,
                          sys.dba_objects  o
                    where p.column_value = o.object_name (+)
                      and ( o.status is null or o.owner = p_schema ) )
        loop
            if i.status is null then
                error('FAILED Existence check for '||p_schema||'.'||i.object_name);
            elsif i.status <> 'VALID' then
                error('FAILED status check for '||p_schema||'.'||i.object_name||': '||i.status);
            end if;
        end loop;
    end check_key_objects_exist;
--------------------------------------------------------------------------------
    procedure ddl (
        p_ddl in varchar2 )
    is
    begin
        log_action(p_ddl);
        execute immediate p_ddl;
    exception when others then
        --
        -- during a database downgrade the object might not exist
        --
        log_action('DDL not successful: '||p_ddl);
    end ddl;
--------------------------------------------------------------------------------
    function is_runtime (
        p_schema  in varchar2 ) return boolean
    is
        l_is_dev_env number;
    begin
        execute immediate 'select 1 ' ||
                          'from ' || sys.dbms_assert.enquote_name( p_schema ) || '.wwv_flows ' ||
                          'where id = 4000'
                     into l_is_dev_env;
        return false;
    exception
        when NO_DATA_FOUND then
            return true;
    end is_runtime;
--------------------------------------------------------------------------------
    procedure disable_job( p_job_name in varchar2 )
    is
        l_enabled_job_cnt number;
    begin
        select count(1)
          into l_enabled_job_cnt
          from sys.dba_scheduler_jobs
         where owner     = c_apex_schema
           and job_name  = p_job_name
           and state    != 'DISABLED';

        if l_enabled_job_cnt > 0 then
            l_job_enabled_yn( p_job_name ) := 'Y';

            sys.dbms_scheduler.disable(
                name  => c_apex_schema || '.' || p_job_name,
                force => true );

            begin
                sys.dbms_scheduler.stop_job(
                    job_name => c_apex_schema || '.' || p_job_name,
                    force    => true );
            exception
                when e_job_not_running then
                    null;
            end;
        end if;
    end disable_job;
--------------------------------------------------------------------------------
    procedure enable_job( p_job_name in varchar2 )
    is
    begin
        if l_job_enabled_yn.exists( p_job_name ) then
            sys.dbms_scheduler.enable( name => c_apex_schema|| '.' || p_job_name );
        end if;
    end enable_job;
begin
    sys.dbms_registry.set_session_namespace (
        namespace   => 'DBTOOLS');
    l_reg_schema := sys.dbms_registry.schema('APEX');
    log_action('Starting validate_apex for '||c_apex_schema);
    if nvl(l_reg_schema,'x') <> c_apex_schema then
        log_action('DBMS registry schema for APEX is "'||l_reg_schema||'"');
    end if;
    --
    -- Missing direct grants for:
    --
    -- - Static dependencies.
    -- - Well known ORDS objects that are called with dynamic SQL, since APEX
    --   can be installed before ORDS.
    --
    -- Execute grant for known issues (e.g. object did not exist before DB
    -- upgrade or ords install), or log missing privilege.
    --
    l_known_privs('SYS.DBMS_MLE')                  := 'execute';
    l_known_privs('SYS.DBMS_XS_NSATTR')            := 'execute';
    l_known_privs('SYS.DBMS_XS_NSATTRLIST')        := 'execute';
    l_known_privs('SYS.DBMS_STATS_INTERNAL')       := 'execute';
    l_known_privs('SYS.DBMS_CRYPTO_INTERNAL')      := 'execute';
    l_known_privs('SYS.DBMS_CRYPTO_STATS_INT')     := 'execute';
    l_known_privs('SYS.DBMS_METADATA')             := 'execute';
    l_known_privs('SYS.DBMS_CRYPTO')               := 'execute';
    l_known_privs('SYS.DIANA')                     := 'execute';
    l_known_privs('SYS.DIUTIL')                    := 'execute';
    l_known_privs('SYS.GETLONG')                   := 'execute';
    l_known_privs('SYS.KU$_DDL')                   := 'execute';
    l_known_privs('SYS.KU$_DDLS')                  := 'execute';
    l_known_privs('SYS.UTL_CALL_STACK')            := 'execute';
    l_known_privs('SYS.XS$NAME_LIST')              := 'execute';
    l_known_privs('SYS.JSON_ARRAY_T')              := 'execute';
    l_known_privs('SYS.JSON_ELEMENT_T')            := 'execute';
    l_known_privs('SYS.JSON_KEY_LIST')             := 'execute';
    l_known_privs('SYS.JSON_OBJECT_T')             := 'execute';
    l_known_privs('SYS.JSON_DATAGUIDE')            := 'execute';
    l_known_privs('SYS.DBA_TAB_IDENTITY_COLS')     := 'select';
    l_known_privs('SYS.DBA_XS_DYNAMIC_ROLES')      := 'select';
    l_known_privs('SYS.V_$XS_SESSION_ROLES')       := 'select';
    l_known_privs('SYS.DBA_SCHEDULER_JOBS')        := 'select';
    l_known_privs('SYS.NLS_DATABASE_PARAMETERS')   := 'select';
    --
    -- Spatial objects
    --
    l_known_privs('MDSYS.SDO_GEOMETRY')            := 'execute';
    l_known_privs('MDSYS.SDO_ELEM_INFO_ARRAY')     := 'execute';
    l_known_privs('MDSYS.SDO_ORDINATE_ARRAY')      := 'execute';
    l_known_privs('MDSYS.SDO_POINT_TYPE')          := 'execute';
    l_known_privs('MDSYS.SDO_DIM_ARRAY')           := 'execute';
    l_known_privs('MDSYS.SDO_DIM_ELEMENT')         := 'execute';
    l_known_privs('MDSYS.MDERR')                   := 'execute';
    l_known_privs('MDSYS.SDO_META')                := 'execute';
    l_known_privs('MDSYS.SDO_GEOM')                := 'execute';
    l_known_privs('MDSYS.SDO_UTIL')                := 'execute';
    l_known_privs('MDSYS.SDO_CS')                  := 'execute';
    l_known_privs('MDSYS.CS_SRS')                  := 'select';
    l_known_privs('MDSYS.USER_SDO_INDEX_INFO')     := 'select';
    l_known_privs('MDSYS.SDO_GEOM_METADATA_TABLE') := 'select, insert, delete';

    for c1 in ( select d.owner,
                       d.referenced_owner,
                       d.referenced_name,
                       d.referenced_type
                  from  dba_dependencies d
                 where d.owner = c_apex_schema
                   and d.referenced_owner not in (d.owner, 'PUBLIC')
                   and d.referenced_name  not in ('STANDARD',
                                                'DBMS_STANDARD',
                                                'PLITBLM')
                   and not (    d.referenced_owner = 'XDB'
                            and d.referenced_name  like 'X$%' )
                   and not (    d.referenced_owner = 'SYS'
                            and d.referenced_name  = 'XMLSEQUENCETYPE' )
                   and not exists ( select null
                                      from dba_tab_privs p
                                     where d.referenced_owner = p.owner
                                       and d.referenced_name  = p.table_name
                                       and d.owner            = p.grantee )
                 order by 1, 2,3 )
    loop
        begin
            ddl('grant '||
                l_known_privs(c1.referenced_owner||'.'||c1.referenced_name)||
                ' on '||
                sys.dbms_assert.enquote_name(c1.referenced_owner)||'.'||
                sys.dbms_assert.enquote_name(c1.referenced_name)||' to '||
                c_apex_schema);
        exception when no_data_found then
            --
            -- Not a known priv: log it.
            --
            error('MISSING GRANT: grant '||
                case when c1.referenced_type in ('TABLE', 'VIEW') then 'select' else 'execute' end||
                ' on "'||c1.referenced_owner||'"."'||c1.referenced_name||
                '" to '||c_apex_schema);
        end;
    end loop;
    --
    -- check missing sys privileges.
    --
    -- ANY privileges consist of multiple words and must not be quoted!
    --
    log_action('Checking missing sys privileges');
    for i in ( select name
                 from sys.system_privilege_map m
                where name = c_inherit_any_privs
                  and not exists ( select null
                                     from sys.dba_sys_privs p
                                    where p.grantee = c_apex_schema
                                      and p.privilege = m.name ))
    loop
        ddl('grant '||c_inherit_any_privs||
            ' to '||c_apex_schema);
    end loop;
    --
    -- stop and disable the background execution coordinator job
    --
    disable_job( p_job_name => 'ORACLE_APEX_BG_PROCESSES' );
    --
    -- detect database environment (version and available features)
    --
    log_action('Re-generating '||c_apex_schema||'.wwv_flow_db_version');

    -- on a runtime environment, the APEX_XXXXXX schema does not have the CREATE PROCEDURE privilege. However,
    -- in order to run wwv_flow_db_env_detection.generate_wwv_flow_db_version correctly, this privilege is needed.
    -- So we temporarily grant the privilege here and revoke it after we're finished with wwv_flow_db_env_detection.
    --
    if is_runtime( c_apex_schema ) then
        log_action('temporarily grant CREATE PROCEDURE to '||c_apex_schema);
        execute immediate 'grant create procedure to '||c_apex_schema;
    end if;
    --
    -- now detect db version and capabilities; wwv_flow_db_version might be replaced ...
    --
    begin
        execute immediate 'begin ' ||
                          c_apex_schema||'.wwv_flow_db_env_detection.generate_wwv_flow_db_version;' ||
                          'end;';
    exception when others then
        error(sqlerrm);
    end;
    --
    -- revoke the create procedure privilege again, when runtime only
    --
    if is_runtime( c_apex_schema ) then
        log_action('revoke CREATE PROCEDURE from '||c_apex_schema);
        execute immediate 'revoke create procedure from '||c_apex_schema;
    end if;
    --
    -- recompile any invalid objects in schemas that we use
    --
    for l_schema in ( select owner, count(*)
                        from sys.dba_objects
                       where owner in ( c_apex_schema, 'FLOWS_FILES', 'SYS' )
                         and ( owner <> 'SYS' or object_name member of c_key_sys_objects )
                         and status <> 'VALID'
                       group by owner
                       order by case owner
                                when 'SYS'         then 1
                                when 'FLOWS_FILES' then 2
                                else 3
                                end )
    loop
        if l_schema.owner <> 'SYS' then
            log_action('Recompiling '||l_schema.owner||' ... with dbms_utility.compile_schema');
            sys.dbms_utility.compile_schema (
                schema         => l_schema.owner,
                compile_all    => false,
                reuse_settings => true );
        else
            --
            -- dbms_utility.compile_schema can not compile SYS, that raises
            -- ORA-20001: Cannot recompile SYS objects
            --
            for i in ( select object_type, object_name
                         from sys.dba_objects
                        where owner = l_schema.owner
                          and status <> 'VALID'
                          and object_name member of c_key_sys_objects
                        order by 1 )
            loop
                ddl (
                    'alter package sys.'||sys.dbms_assert.enquote_name(i.object_name)||
                    ' compile'||
                    case when i.object_type='PACKAGE BODY' then ' body' end||
                    ' reuse settings');
            end loop;
        end if;
        --
        -- check for objects that are still invalid
        --
        log_action('Checking for objects that are still invalid');
        for c1 in ( select object_name, object_type, status
                      from sys.dba_objects
                     where owner           = l_schema.owner
                       and ( owner <> 'SYS' or object_name member of c_key_sys_objects )
                       and object_type not in ( 'SYNONYM' )
                       and object_type not like 'LOB%'
                       and status <> 'VALID'
                     order by case object_type
                              when 'PACKAGE'      then 1
                              when 'PACKAGE BODY' then 3
                              when 'TYPE BODY'    then 3
                              else 2
                              end,
                              object_name )
        loop
            -- check if downgrade
            if nvl(l_reg_schema,'x') = c_apex_schema then -- registry matches, not a downgrade
                error('COMPILE FAILURE: '||c1.object_type||' '||l_schema.owner||'.'||c1.object_name);
                for l_err in ( select line, position, text
                                 from dba_errors
                                where owner = l_schema.owner
                                  and name  = c1.object_name
                                  and type  = c1.object_type
                                order by line, position )
                loop
                    p('...'||rpad(l_err.line||'/'||l_err.position, 8)||' '||l_err.text);
                end loop;
            else -- there are invalid objects but they exist in the schema downgraded from
                if l_schema.owner = c_apex_schema
                    and c1.object_name in ('APEX$_WS_ROWS_T1')
                then
                    ddl('drop '||
                        sys.dbms_assert.noop(c1.object_type)||' '||
                        sys.dbms_assert.enquote_name(c_apex_schema)||'.'||
                            sys.dbms_assert.enquote_name(c1.object_name));
                end if;
            end if;
        end loop;
    end loop;
    --
    -- recompile invalid public synonyms that reference APEX
    --
    log_action('Checking invalid public synonyms');
    for s in ( select s.synonym_name
                 from sys.dba_synonyms s, sys.dba_objects o
                where o.owner       = s.owner
                  and o.object_name = s.synonym_name
                   --
                  and s.table_owner = c_apex_schema
                  and o.status      = 'INVALID'
                  and s.owner       = 'PUBLIC'
                order by s.synonym_name )
    loop
        ddl('alter public synonym '||
            sys.dbms_assert.enquote_name(s.synonym_name)||
            ' compile');
    end loop;
    --
    -- check for the existence of key objects
    --
    log_action('Key object existence check');

    check_key_objects_exist (
        p_schema  => c_apex_schema,
        p_objects => c_key_apex_objects );
    check_key_objects_exist (
        p_schema  => 'FLOWS_FILES',
        p_objects => c_key_file_objects );
    check_key_objects_exist (
        p_schema  => 'SYS',
        p_objects => c_key_sys_objects );
    --
    -- enable the background execution coordinator job
    --
    enable_job( p_job_name => 'ORACLE_APEX_BG_PROCESSES' );
    --
    -- write summary and set registry status
    --
    if l_error_count > 0 then
        log_action('Setting DBMS registry for APEX to INVALID');
        sys.dbms_registry.invalid('APEX');
    else
        log_action('Setting DBMS Registry for APEX to valid');
        sys.dbms_registry.valid('APEX');
    end if;
    --
    log_action('Exiting validate_apex');
    sys.dbms_registry.set_session_namespace (
        namespace   => 'SERVER');
exception when others then
    sys.dbms_registry.invalid('APEX');
    sys.dbms_registry.set_session_namespace (
        namespace   => 'SERVER');
    error('Error in validate_apex: '||sqlerrm);
    p(sys.dbms_utility.format_error_backtrace);
end validate_apex;
/
show errors

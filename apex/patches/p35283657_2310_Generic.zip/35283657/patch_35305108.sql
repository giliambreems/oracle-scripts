set define '^' verify off
prompt ...patch_35305108.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35305108.sql
--
--    DESCRIPTION
--      Bug 35305108 - APEX_APPL_PAGE_SEARCH_SOURCES MISSING JOIN; RETURNS ROW FOR EVERY PAGE NAME
--
--    MODIFIED   (MM/DD/YYYY)
--    cczarski    09/21/2023 - Created
--
--------------------------------------------------------------------------------

prompt ...apex_appl_page_search_sources
create or replace view apex_appl_page_search_sources as
select s.id                                                    as search_source_id,
       f.workspace,
       f.workspace_display_name,
       f.application_id,
       f.application_name,
       s.page_id,
       p.name                                                  as page_name,
       s.search_region_id                                      as region_id,
       r.plug_name                                             as region_name,
       s.search_config_id                                      as search_config_id,
       case s.use_as_initial_result
           when 'Y'       then 'Yes'
           when 'N'       then 'No'
       end                                                     as use_as_initial_result,
       s.use_as_initial_result                                 as use_as_initial_result_code,
       ( select sc.label
           from wwv_flow_search_configs sc
          where sc.security_group_id = s.security_group_id
            and sc.flow_id           = s.flow_id
            and sc.id                = s.search_config_id )    as search_config_label,
       s.display_sequence,
       s.name                                                  as search_source_name,
       s.override_label                                        as search_source_label,
       s.override_icon                                         as search_source_icon,
       s.condition_type,
       s.condition_expr1,
       s.condition_expr2,
       s.build_option_id,
       (select case when s.build_option_id > 0
                   then pa.PATCH_NAME
                   else '{Not '||pa.PATCH_NAME||'}'
               end PATCH_NAME
          from wwv_flow_patches pa
         where pa.id                = abs(s.build_option_id)
           and pa.security_group_id = s.security_group_id)     as build_option,
       --
       s.source_comments,
       s.last_updated_by,
       s.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_steps p,
       wwv_flow_page_plugs r,
       wwv_flow_search_region_sources s
 where f.workspace_id      = s.security_group_id
   and f.application_id    = s.flow_id
    --
   and s.security_group_id = r.security_group_id
   and s.flow_id           = r.flow_id
   and s.page_id           = r.page_id
   and s.search_region_id  = r.id
    --
   and s.security_group_id = p.security_group_id
   and s.flow_id           = p.flow_id
   and s.page_id           = p.id
/
sho err

begin
  wwv_flow_upgrade.add_table_comments (
    p_table_name        => 'apex_appl_page_search_sources',
    p_table_comment     => 'Stores the meta data for Search Configuration usages within a search region.',
    p_column_comments   => wwv_flow_t_varchar2 (
                               'search_source_id'            , 'Primary Key of this Search Configuration Usage.',
                               'workspace'                   , 'A work area mapped to one or more database schemas',
                               'workspace_display_name'      , 'Display name for the workspace',
                               'application_id'              , 'Application Primary Key, Unique over all workspaces',
                               'application_name'            , 'Identifies the application',
                               'page_id'                     , 'Identifies the page where the component has been created.',
                               'page_name'                   , 'Name of the page where the component has been created.',
                               'region_id'                   , 'Internal ID of the region where the component has been created.',
                               'region_name'                 , 'Name of the region where the component has been created',
                               'search_config_id'            , 'Internal ID of the used search configuration.',
                               'search_config_label'         , 'Label of the used search configuration.',
                               'use_as_initial_result'       , 'Identifies whether this Source will be used to display initial results.',
                               'use_as_initial_result_code'  , 'Internal code for USE_AS_INITIAL_RESULT',
                               'display_sequence'            , 'Sequence in which results from multiple search configurations are displayed.',
                               'search_source_name'          , 'Name of the Search Configuration in this region.',
                               'search_source_label'         , 'Override Search Configuration label for result display.',
                               'search_source_icon'          , 'Override Search Configuration icon for result display',
                               'condition_type'              , 'Identifies a condition that must be met in order for this action to be displayed',
                               'condition_expr1'             , 'Specifies an expression based on the specific condition type selected.',
                               'condition_expr2'             , 'Specifies an expression based on the specific condition type selected.',
                               'build_option_id'             , 'Foreign key',
                               'build_option'                , 'Search Configuration will be used if the Build Option is enabled',
                               'source_comments'             , 'Developer comment.',
                               'last_updated_by'             , 'APEX developer who made the last update',
                               'last_updated_on'             , 'Date of last update' ));
end;
/
sho err

create or replace public synonym apex_appl_page_search_sources sharing=NONE for apex_230100.apex_appl_page_search_sources
/

grant read on apex_230100.apex_appl_page_search_sources to public
/

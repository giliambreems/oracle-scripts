set define '^' verify off
prompt ...patch_35378812.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35378812.sql
--
--    DESCRIPTION
--      Bug 35378812 - REST MODULE FULL URL INCORRECTLY INCLUDES MODULE NAME 
--
--    MODIFIED   (MM/DD/YYYY)
--    costrows    07/13/2023 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_step_items
set source = '&G_APEX_PATH.&G_SCHEMA_ALIAS.<font color="#EE0000">&P120_URI_PREFIX.</font>'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and flow_step_id      between 120 and 120.9999
           and id           between 521638629904366448 and 521638629904366448.9999
/
commit
/
# Oracle APEX Product Version #  : 23.1.9
#
# Patch Set Exception : Bug 35283657 - PSE BUNDLE FOR APEX 23.1 (PSES ON TOP OF 23.1.x)
#
# Platform Patch for  : Generic - Platform independent
#
# DATE : Mar 06, 2024
#
# This document describes how you can install the Patch Set Exception on your Oracle APEX 23.1.x instance.
#
#
# (I) Requirements:
# ----------------------------
# Before you install the patch, ensure that you meet the following requirement:
#
#    - You must be using Oracle APEX Product Version #  : 23.1.x
#
# If you do NOT meet this requirement, or are not certain that you meet
# the requirement, please log a Service Request and Support will make
# a determination about whether you should apply this patch.
#
#
# (II) Bugs Fixed by this patch:
# ------------------------------
# ----- PATCH_VERSION: 1 -----
# 35075104 - APP RE-IMPORT CHANGES OFFSETS WHEN EXPORTED WITH ORIGINAL IDS AND IMPORT OCCURS WITH SET_OFFSET()
# 35217899 - APEX EXPORT WITH -EXPORIGINALIDS DOES NOT SEEM TO PRESERVE THE ORIGINAL IDS
# 35354010 - REGRESSION: PAGE DESIGNER HANGS ON LOADING IF AN APP HAS MANY EMAIL TEMPLATES
# 35244986 - TEMPLATE COMPONENTS: MISSING LINK ATTRIBUTE GROUP AFTER CHANGING PAGES
# 35381042 - ORA-06502 WHEN THE APEX_MAIL PACKAGE IS EXECUTED (WORK AROUND PL/SQL BUG 35072180)
# 35418396 - BACKGROUND PROCESSING DOES NOT COPY SESSION CREDENTIALS TO WORKING SESSION
# 35410651 - REGRESSION: SQL WORKSHOP / SUPPORTING OBJECTS THROW ERROR WHEN SCRIPT CONTAINS COLONS
# 35354354 - REGRESSION: SQL WORKSHOP EDITORS SPLIT LONG LINES AT 4000 CHARACTERS
# 35396560 - REGRESSION: SWITCH CURRENT THEME FAILS WITH AN ERROR
# 35464016 - REGRESSION: CANNOT CREATE INTERACTIVE GRIDS AFTER APEX 23.1 UPGRADE
# 34844898 - CUSTOMERS ARE UNABLE TO UNLOCK INSTANCE ADMINISTRATOR ACCOUNT
# 35474788 - PUSH SUBCRIPTIONS ARE REMOVED AFTER REIMPORTING THE APP
# ----- PATCH_VERSION: 2 -----
# 35418916 - Fix for Bug 35418916
# ----- PATCH_VERSION: 3 -----
# 35504868 - REPLACING AN APP WITH BACKGROUND EXECS RAISES "ACCESS TO SESSION STATE IS DISABLED" ERROR
# 35510125 - FOOTER FROM EMAIL TEMPLATE IS NOT BEING DISPLAYED IN EMAIL
# 35526287 - FIX FOR BUG 35526287
# 35526692 - APPROVAL COMPONENT: TASK PARAMETER VALUE IS LIMITED TO 255 CHARACTERS IN APEX_TASK_PARAMETERS
# 35542652 - APEX_APP_BUILDER_API: MISC ERRORS LIKE ORA-01403 AND ORA-00060 IN OLD DATA REPORTER PACKAGED APP
# 35531933 - SAML AUTH: INVALID VALUE FOR PARAMETER: /RESPONSE/SIGNATURE (CANONICALIZATION)
# 35522369 - TEMPLATE COMPONENT REPORT: REMOVE PRE-FETCHING OF DATA
# 35482969 - WWV_FLOW.SHOW POST REQUESTS SHOULD ALWAYS CONTAIN P_CONTEXT QUERY PARAMETER
# 35536832 - AVATAR TEMPLATE PARTIAL RAISES ERROR IN INTERACTIVE REPORT
# 35501357 - APP_SAML_AUTH_METADATA NOT COMMITED IN POST-AUTHENTICATION PROCEDURE LOGIC
# 35579586 - MENU ENTRIES OF TEMPLATE COMPONENTS ARE DUPLICATED IF THE APP GETS TRANSLATED
# 35532402 - REGRESSION: INTERACTIVE GRID WITH RICH TEXT TYPE COLUMN ESCAPES OUTPUT IN HTML DOWNLOAD
# 35378812 - REST MODULE FULL URL INCORRECTLY INCLUDES MODULE NAME
# 35340435 - DB POOL NAME IS MISSING IN AUTOREST OBJECT URL
# 35381729 - REGRESSION: PERCENT GRAPH COLUMN IS ESCAPED IN HTML EXPRESSION OF INTERACTIVE REPORT 
# ----- PATCH_VERSION: 4 -----
# 35604620 - Fix for bug 35604620
# 35213251 - SQL COMMANDS CAN SHOW APEX INTERNAL PACKAGE IN STACK TRACE WHEN ERROR OCCURS
# 35619859 - UPGRADE TO 23.1 FAILS DUE TO BUG IN UNIQUE INDEX ON PLUGIN ATTRIBUTES
# 35598061 - Fix for bug 35598061
# 35625669 - APPROVAL COMPONENT: CREATED ON, CREATED BY, LAST UPDATED ON AND LAST UPDATED BY IS OVERWRITTEN AT APP RE-IMPORT WITH REPLACEMENT 
# 35527585 - P_CONTEXT PARAMETER IS MISSING IN WWV_FLOW.AJAX CALL IN F4750_P50.JS FILE
# 35679690 - TEMPLATE COMPONENT REGION ATTRIBUTES DO NOT GET TRANSLATED
# 35658705 - IMPORT PAGE FAILS WITH PARENT KEY NOT FOUND ERROR
# ----- PATCH_VERSION: 5 -----
# 35716957 - REGRESSION: DATA EXPORT AS PDF RAISES ERROR FOR UNSUPPORTED IMAGES
# 35509624 - PAGE DESIGNER: TEMPLATE COMPONENT ON THE GLOBAL PAGE BREAKS THE LOADING OF OTHER PAGES
# 35701019 - SIMPLE HTTP REST SOURCE TYPE: CHARACTER STRING BUFFER TOO SMALL IF "HAS MORE ROWS" JSON ATTRIBUTE IS LARGER THAN 255 BYTE
# 35734474 - SAML SIGN-OUT BEHAVES DIFFERENTLY WHEN CONFIGURED FOR THE BUILDER THAN FOR AN APP
# 35510011 - CARDS, INTERACTIVE GRID, AND TEMPLATE COMPONENT REPORT SCROLL PAGINATION REQUEST TOO MUCH DATA
# 35319758 - {WITH/}{APPLY/} CANNOT PASS &APEX$ITEM. INSIDE A {LOOP/}
# 35419252 - REGRESSION: CLOB SESSION STATE FAILS VALIDATIONS WHEN >32K
# 35554377 - SETTING EQ FILTER ON IG DATE COLUMN INTERPRETED AS UNSAVED CHANGE ON CLIENT SIDE
# 35796739 - SQL WORKSHOP LOAD DATA TO EXISTING TABLE: CANNOT LOAD VALUES WITH FRACTIONAL SECONDS TO DATE COLUMNS
# 35305108 - APEX_APPL_PAGE_SEARCH_SOURCES MISSING JOIN; RETURNS ROW FOR EVERY PAGE NAME 
# 35823778 - SEARCH REGION WITH TWO OR MORE SEARCH SOURCES BREAKS APPLICATION SEARCH
# 35815444 - OBJECT BROWSER: 'SAVE AND COMPILE' DOESN'T DISPLAY ALL ERRORS
# 35574855 - TEMPLATE COMPONENT: ACTIONS OF TYPE LINK DON'T SHOW TARGET PAGE PROPERTY
# 35568630 - LOG WORKSPACE CREATION FOR REPORTING OVER TIME
# 35711528 - JAVASCRIPT ERRORS OCCUR ON REGION DISPLAY SELECTOR
# ----- PATCH_VERSION: 6 -----
# 35832592 - BLANK PAGE AFTER TIMEOUT, WHEN SESSION SWITCHED TO SOCIAL SIGN-IN AUTH SCHEME
# 35527223 - IG SHOW NO DATA WHEN MAXIMIZED AFTER USING REGION DISPLAY SELECTOR
# 35857964 - INTERACTIVE REPORT SUBSCRIPTION FAILS WITH "SESSION ENDED ERROR" AFTER UPGRADE TO 23.1
# 35717714 - WHEN DISPLAY ZOOM IS LARGE, INTERACTIVE GRID DOES NOT SHOW THE 41ST ROW
# 35938522 - Fix for bug 35938522
# ----- PATCH_VERSION: 7 -----
# 35996877 - SAML AUTH: XML CANONICALIZATION SHOULD NORMALIZE LINE ENDINGS TO 0X0A (INVALID /RESPONSE/SIGNATURE)
# 36041971 - FORCE PASSWORD CHANGE PAGE DOES NOT REDIRECT BACK TO FRIENDLY URL 
# ----- PATCH_VERSION: 8 -----
# 36229358 - SAML AUTH: XML CANONICALIZATION SHOULD NORMALIZE ENTITY ENCODINGS (&#13; TO &#XD;)
# ----- NEW IN LATEST PATCH_VERSION: 9 -----
# 36250686 - SAML AUTH: XML CANONICALIZATION FOR ASSERTION CONTAINS SUPERFLUOUS XMLNS FROM ROOT NODE
#
#
# (III) Patch Installation Instructions:
# --------------------------------------
# To apply the patch
#
#  1. Download the p35283657_231_GENERIC.zip patch set installation archive to a directory that is not the Oracle home directory or under the Oracle home directory.
#
#  2. Unzip and extract the installation files by double-clicking p35283657_231_GENERIC.zip in a Microsoft Windows based system, or entering the following command to unzip on a UNIX or Linux based system:
#
#   $ unzip p35283657_231_GENERIC.zip
#
#  3. Preventing Access to Oracle REST Data Services
#
#     It is important that no developers or end users access Oracle APEX while you are applying the patch. This section describes how to prevent access to Oracle APEX.
#
#     Stopping Oracle REST Data Services:
#
#        To learn more about stopping the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#        http://docs.oracle.com/cd/E56351_01/doc.30/e56293/toc.htm
#
#
#  4. Set your current directory to the "" directory where you unzipped the p35283657_231_GENERIC.zip file.
#
#  5. Set the NLS_LANG environment variable, making sure that the character set is AL32UTF8. For example:
#
#     Bourne or Korn shell:
#
#       NLS_LANG=American_America.AL32UTF8
#       export NLS_LANG
#
#     C shell:
#
#       setenv NLS_LANG American_America.AL32UTF8
#
#     For Windows based systems:
#
#       set NLS_LANG=American_America.AL32UTF8
#
#  6. Connect to the database where Oracle APEX is installed as the SYS user and run catpatch.sql or catpatch_con.sql as in the following examples:
#
#     sqlplus "sys/ as sysdba" @catpatch.sql        -- for Oracle Database 12.1 and newer, for non-CDB, for CDB where Oracle APEX is not installed in the root, and for PDB where APEX is not installed in the root
#     sqlplus "sys/ as sysdba" @catpatch_con.sql    -- for CDB where Oracle APEX is installed in the root
#     sqlplus "sys/ as sysdba" @catpatch_appcon.sql -- for installations where Oracle APEX is installed in an application container
#
#  7. Install the Patch Set Exception's changes in the images directory
#
#       Copy the images directory of the patch to the /images folder of the Oracle APEX installation directory images sub directory.
#
#       Assuming the p35283657_231_GENERIC.zip file was unzipped to c:\temp on Windows and /tmp on Linux
#
#       On a Windows system, run a command from a command prompt similar to the following example:
#
#           xcopy /E /I c:\temp\images ORACLE_APEX_HOME\apex\images
#
#       On UNIX or Linux based systems, run a command similar to the following example:
#
#           cp -rf /tmp/images ORACLE_APEX_HOME/apex
#
#       In the preceding syntax examples, ORACLE_APEX_HOME is the existing Oracle APEX installation location. For example, c:\oracle\apex_23.1 on Windows and /oracle/apex_23.1 on Linux.
#
#  8. Starting Oracle APEX
#
#    - Starting Oracle REST Data Services
#
#       To learn more about starting the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#           http://docs.oracle.com/cd/E56351_01/doc.30/e56293/toc.htm
#
#
# (IV) New APEX 23.1 Content Delivery Network (CDN):
# --------------------------------------------------
# APEX 23.1 static resources are available on a CDN, https://static.oracle.com/cdn/apex/23.1.6/.
#   - The CDN contains the production APEX 23.1.6 static resources and the updated static resources included in this patch (23.1.6).
#
#    I. Instance using the APEX CDN
#
#       If your instance is currently using an APEX CDN, you are already availing of the updated static resources included in this patch.
#
#
#   II. Instance not yet using the APEX CDN
#
#       If you wish to convert your instance to use the static resources from the 23.1.6 CDN, you will need to reset the APEX images prefix for your instance. This should not be done on a live system.
#
#       To convert an instance to use the CDN:
#
#       - Set your current directory to the directory where the production APEX 23.1 zipfile was extracted. For example, c:\temp\apex_23.1_production on Windows and /tmp/apex_23.1_production on Linux.
#
#       - Navigate to the apex/utilities subdirectory of the production APEX 23.1 directory. For example, /tmp/apex_23.1_production/apex/utilities
#
#       - Connect to the database where Oracle APEX is installed as SYS and run reset_image_prefix.sql, as in the following example:
#
#         sqlplus "sys/syspass as sysdba" @reset_image_prefix.sql
#
#       - When prompted for the image prefix, enter the CDN path, as follows:
#
#         https://static.oracle.com/cdn/apex/23.1.6/
#
#       You will need to restart Oracle REST Data Services (ORDS) after resetting the image prefix.
#
#        1. Stopping Oracle REST Data Services
#
#           To learn more about stopping the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#           https://docs.oracle.com/en/database/oracle/oracle-rest-data-services/21.1/aelig/index.html
#
#        2. Starting Oracle REST Data Services
#
#            To learn more about starting the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#            https://docs.oracle.com/en/database/oracle/oracle-rest-data-services/21.1/aelig/index.html
#
#  III. Use the APEX CDN in a single APEX application
#
#       If you wish to use the APEX CDN in a single APEX application:
#
#       - In App Builder, edit your application and click 'Shared Components'
#
#       - Click 'User Interace Attributes'
#
#       - In the 'Image Prefix' attribute, enter as follows:
#
#         https://static.oracle.com/cdn/apex/23.1.6/
#
#       - Click 'Apply Changes'
#
#
# (V) To confirm the patch has been applied:
# -------------------------------------------
#
#    I. Review the Product Build number on your instance
#
#       - Log into your workspace.
#
#       - Review the Product Build number displayed in the lower right corner.
#
#         If your instance has been patched, the build number will be 23.1.x, where x is the PATCH_VERSION. For example, 23.1.9.
#         In your instance has not been patched, the build number will be 23.1.x.
#
#   II. Review the About dialog on your instance
#
#       - Log into your workspace.
#
#       - Click 'Help' > 'About'.
#
#       - Review the Details section:
#
#         'Patch Version' will display the version of the patch installed.
#         'Last Patch Time' will display the patch installation date and time.
#         These values will only be visible on a patched instance.
#
#
#  III. Start SQL*Plus and connect to the database where Oracle APEX is installed as SYS. For example:
#
#         - On Windows:
#
#                 SYSTEM_DRIVE:\> sqlplus /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password: SYS_password
#
#         - On UNIX and Linux:
#
#                 $ sqlplus /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password: SYS_password
#
#            Enter the following statement to verify the patch with patch_number 35283657 has been installed:
#
#                 select patch_version, installed_on
#                   from apex_patches
#                  where patch_number = 35283657;
#
#            If the parameter exists, its value is the timestamp for when the patch was applied.
#
#
# EOF README.txt

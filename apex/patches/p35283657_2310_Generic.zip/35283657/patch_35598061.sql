set define '^' verify off
prompt ...patch_35598061.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) 1999, 2023, Oracle and/or its affiliates.
-- 
-- NAME
--   patch_35598061.sql
--
-- DESCRIPTION
--   This is part of bug 35598061 fix.
--   This updates 4500:38, "Saved Queries" CR, TITLE column to HTML escape the link text.
--
-- MODIFIED   (MM/DD/YYYY)
-- cbcho       07/26/2023 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_region_report_column
   set column_linktext = '#TITLE!HTML#'
 where flow_id  between 4500 and 4509
   and region_id between 159940232617099966 and 159940232617099966.9999
   and security_group_id = 10
   and id between 159940904414099968 and 159940904414099968.9999
/

commit
/

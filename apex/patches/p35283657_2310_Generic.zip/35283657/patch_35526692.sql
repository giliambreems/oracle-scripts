set define '^' verify off
prompt ...patch_35526692.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35526692.sql
--
--    DESCRIPTION
--      Bug 35526692 - APPROVAL COMPONENT: TASK PARAMETER VALUE IS LIMITED TO 
--                     255 CHARACTERS IN APEX_TASK_PARAMETERS
--
--    MODIFIED   (MM/DD/YYYY)
--      ralmuell    06/26/2023 - Created
--
--------------------------------------------------------------------------------

prompt ...apex_task_parameters
create or replace view apex_task_parameters as
select t.id               as task_id,
       tdp.id             as task_def_param_id,
       f.workspace        as workspace,
       f.workspace_display_name,
       f.application_id   as application_id,
       f.application_name as application_name,
       --
       tdp.label          as param_label,
       tp.static_id       as param_static_id,
       tdp.is_required    as is_required,
       tdp.is_visible     as is_visible,
       --
       tp.string_value    as param_value
  from wwv_flow_authorized f,
       wwv_flow_tasks$     t,
       json_table( t.payload, '$.parameters[*]'
         columns (
           static_id    varchar2 (255)  path '$.name',
           string_value varchar2 (4000) path '$.value') ) tp,
       wwv_flow_task_defs       td,
       wwv_flow_task_def_params tdp
 where t.flow_id                 = f.application_id
   and t.security_group_id       = f.workspace_id
   and td.id                 (+) = t.task_def_id
   and td.security_group_id  (+) = t.security_group_id
   and tdp.task_def_id       (+) = td.id
   and tdp.security_group_id (+) = td.security_group_id
   and tdp.static_id         (+) = tp.static_id
/

begin
  wwv_flow_upgrade.add_table_comments (
    p_table_name        => 'apex_task_parameters',
    p_table_comment     => 'Stores the task instance parameters for applications in this workspace',
    p_column_comments   => wwv_flow_t_varchar2 (
      'task_id'                , 'Primary Key of this task instance',
      'task_def_param_id'      , 'ID of the task definition parameter corresponding to this task parameter',
      'workspace'              , 'A work area mapped to one or more database schemas',
      'workspace_display_name' , 'Display name for the workspace',
      'application_id'         , 'Application Primary Key, Unique over all workspaces',
      'application_name'       , 'Identifies the application',
      'param_label'            , 'Denotes the task parameter label',
      'param_static_id'        , 'Denotes the Static ID of the task parameter definition',
      'is_required'            , 'Denotes if the task parameter is a required parameter or not',
      'is_visible'             , 'Denotes if the task parameter is visible in the Task Details UI or not',
      'param_value'            , 'Denotes the actual value of the task parameter'
    )
  );
end;
/
set define '^' verify off
set concat on
set concat .
prompt ...devpatch.sql

Rem  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      devpatch.sql
Rem
Rem    DESCRIPTION
Rem      Oracle APEX patch for a full development installation.
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    hfarrell    10/13/2020 - Created

define APPUN    = 'APEX_230100'

alter session set current_schema = SYS;
--------------------------------------------------------------------------------
-- Grants
--------------------------------------------------------------------------------
grant select on sys.dba_external_tables to ^APPUN;

alter session set current_schema = ^APPUN;

---------------------------------------------------------------------------
-- Compilation of package specifications
-- @@foo.sql
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Compilation of views
-- @@dev_views.sql
---------------------------------------------------------------------------

-------------------------------------------------------------------
-- Compilation of package bodies
-- @@wwv_flow_property_dev.plb
-------------------------------------------------------------------
@@generate_ddl.plb
@@wwv_flow_theme_manager.plb
@@wwv_flow_f4000_plugins.plb
@@wwv_flow_query_builder.plb
@@wwv_flow_data_loader_dev.plb
@@wwv_flow_f4500_ob_dev.plb

--------------------------------------------------------------------------------
-- Grants and public synonyms
--------------------------------------------------------------------------------

-------------------------------------------------------------------
-- patch files
-- @@patch_123456.sql
-------------------------------------------------------------------
@@patch_35354010.sql
@@patch_35340435.sql
@@patch_35378812.sql
@@patch_35598061.sql
@@patch_35823778.sql
@@patch_35857964.sql


-- commit after dml changes to metadata
commit;

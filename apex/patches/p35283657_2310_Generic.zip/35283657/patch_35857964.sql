set define '^' verify off
prompt ...patch_35857964.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35857964.sql
--
--    DESCRIPTION
--      Bug 35857964: INTERACTIVE REPORT SUBSCRIPTION FAILS WITH "SESSION ENDED ERROR" AFTER UPGRADE TO 23.1 
--
--    MODIFIED   (MM/DD/YYYY)
--    cbcho       10/04/2023 - Created
--
--------------------------------------------------------------------------------

begin
    --
    -- set this global to avoid
    -- trigger updating timestamp for wwv_flow_worksheet_rpts table
    --
    wwv_flow.g_import_in_progress := true;

    update wwv_flow_worksheet_notify n
       set n.session_id = null
     where n.session_id is not null
       and not exists (select 1
                         from wwv_flow_sessions$ s
                        where s.id = n.session_id);
end;
/

commit
/

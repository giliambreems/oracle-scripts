set define '^' verify off
prompt ...patch_35340435.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35340435.sql
--
--    DESCRIPTION
--      Bug 35340435 - DB POOL NAME IS MISSING IN AUTOREST OBJECT URL 
--
--    MODIFIED   (MM/DD/YYYY)
--    costrows    07/13/2023 - Created
--
--------------------------------------------------------------------------------

update wwv_flow_page_da_actions
set attribute_05 = 'document.getElementById("P194_URL").value = ''&G_APEX_PATH.'' + ''&G_SCHEMA_ALIAS.'' + ''/'' + $v( "P194_DB_OBJECT_ALIAS" ) + ''/'';'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and page_id      between 194 and 194.9999
           and id           between 176008907259486214 and 176008907259486214.9999
/
update wwv_flow_page_da_actions
set attribute_05 = 'document.getElementById("P194_URL").value = ''&G_APEX_PATH.'' + ''&G_SCHEMA_ALIAS.'' + ''/'' + $v( "P194_DB_OBJECT_ALIAS" ) + ''/'';'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and page_id      between 194 and 194.9999
           and id           between 176007819760486203 and 176007819760486203.9999
/
update wwv_flow_page_da_actions
set attribute_05 = 'document.getElementById("P194_URL").value = ''&G_APEX_PATH.'' + ''&G_SCHEMA_ALIAS.'' + ''/'' + $v( "P194_DB_OBJECT_ALIAS" ) + ''/'';'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and page_id      between 194 and 194.9999
           and id           between 176008008118486205 and 176008008118486205.9999
/
update wwv_flow_page_da_actions
set attribute_05 = 'document.getElementById("P195_URL").value = ''&G_APEX_PATH.'' + ''&G_SCHEMA_ALIAS.'' + ''/'' + $v( "P195_DB_OBJECT_ALIAS" ) + ''/'';'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and page_id      between 195 and 195.9999
           and id           between 176008612449486211 and 176008612449486211.9999
/
update wwv_flow_page_da_actions
set attribute_05 = 'document.getElementById("P195_URL").value = ''&G_APEX_PATH.'' + ''&G_SCHEMA_ALIAS.'' + ''/'' + $v( "P195_DB_OBJECT_ALIAS" ) + ''/'';'
where security_group_id = 10
           and flow_id      between 4850 and 4859
           and page_id      between 195 and 195.9999
           and id           between 176008893952486213 and 176008893952486213.9999
/

commit
/
set define '^' verify off
prompt ...patch_35354010.sql
--------------------------------------------------------------------------------
--
-- Copyright (c) Oracle Corporation 1999 - 2023. All Rights Reserved.
--
-- NAME
--   patch_35354010.sql
--
-- DESCRIPTION
--   Bug 35354010 - REGRESSION: PAGE DESIGNER HANGS ON LOADING IF AN APP HAS MANY EMAIL TEMPLATES 
--
-- MODIFIED   (MM/DD/YYYY)
--   mhoogend  05/11/2023 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- view for email templates, including placeholder column
--==============================================================================
prompt ...wwv_flow_email_templates_dev
create or replace view wwv_flow_email_templates_dev
as
select t.*,
       --
       -- Page designer now uses an AJAX callback to fetch the placeholders. Bug 35354010.
       null placeholders
  from wwv_flow_email_templates t
 where t.security_group_id  = (select nv( 'WORKSPACE_ID' ) from sys.dual )
/
show err

declare
    c_id        constant number := 21976368989958503;
    l_id        number;
    l_step_id   number;
begin

    wwv_flow_security.g_security_group_id := 10;
    wwv_flow_api.g_mode := 'REPLACE';

    for l_flow in ( select id,
                      case id
                      when 4000 then 0
                      else id / 10000
                      end translation_id_offset
                 from wwv_flows
                where id between 4000 and 4009
                order by id )
    loop
        
        l_id        := c_id + l_flow.translation_id_offset;
        l_step_id   := 4500 + l_flow.translation_id_offset;
        
        wwv_flow_imp_page.create_page_process(
         p_id=>l_id
         ,p_flow_id=>l_flow.id
         ,p_flow_step_id=>l_step_id
        ,p_process_sequence=>170
        ,p_process_point=>'ON_DEMAND'
        ,p_process_type=>'NATIVE_PLSQL'
        ,p_process_name=>'getEmailPlaceholders'
        ,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
        'begin',
        '    wwv_flow_json.open_object;',
        '    wwv_flow_json.write( ',
        '        p_name          => ''placeholders'',',
        '        p_values        =>  wwv_flow_template_dev.email_template_placeholders(',
        '                                p_application_id    => :FB_FLOW_ID,',
        '                                p_email_template_id => wwv_flow.g_x01 ),',
        '        p_write_null    => true );',
        '    wwv_flow_json.close_object;',
        'end;'))
        ,p_process_clob_language=>'PLSQL'
        ,p_internal_uid=>l_id
        );
    end loop;
end;
/
commit;

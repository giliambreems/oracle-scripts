set define '^' verify off
prompt ...patch_35619859.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35619859.sql
--
--    DESCRIPTION
--      BUG 35619859 - UPGRADE TO 23.1 FAILS DUE TO BUG IN UNIQUE INDEX ON PLUGIN ATTRIBUTES
--
--    MODIFIED   (MM/DD/YYYY)
--      mhoogend    07/25/2023 - Created
--
--------------------------------------------------------------------------------
declare
    l_exp varchar2(4000);
begin

    select column_expression
      into l_exp
      from sys.dba_ind_expressions
     where index_name   = 'PLUGIN_ATTR_STATIC_UN'
       and index_owner  = 'APEX_230100';
         
    if l_exp like '%TO_CHAR%' then
        execute immediate 'drop index plugin_attr_static_un';
        execute immediate 'create unique index plugin_attr_static_un on wwv_flow_plugin_attributes (plugin_id, coalesce( static_id,  cast( standard_hash( id ) as varchar2( 40 ) ) ) ) compress';
    end if;
exception
    when no_data_found then
        null;
end;
/

set define '^' verify off
prompt ...patch_35568630.sql
--------------------------------------------------------------------------------
--
--  Copyright (c) 1999, 2023, Oracle and/or its affiliates.
--
--    NAME
--      patch_35568630.sql
--
--    DESCRIPTION
--      Bug 35568630 - LOG WORKSPACE CREATION FOR REPORTING OVER TIME
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    07/05/2023 - Created
--
--------------------------------------------------------------------------------

prompt ...apex_workspace_count
create or replace view apex_workspace_count as
    select log_day,
           created_workspaces_cnt,
           removed_workspaces_cnt
      from wwv_instance_aggr_metrics
/

begin
  wwv_flow_upgrade.add_table_comments (
    p_table_name        => 'apex_workspace_count',
    p_table_comment     => 'Instance workspace count',
    p_column_comments   => wwv_flow_t_varchar2 (
      'LOG_DAY'                  , 'Date of Workspace count',
      'CREATED_WORKSPACES_CNT'   , 'Count of workspaces created',
      'REMOVED_WORKSPACES_CNT'   , 'Count of workspaces removed'
    )
  );
end;
/

create or replace public synonym apex_workspace_count sharing=NONE for apex_230100.apex_workspace_count
/

grant read on apex_230100.apex_workspace_count to public
/

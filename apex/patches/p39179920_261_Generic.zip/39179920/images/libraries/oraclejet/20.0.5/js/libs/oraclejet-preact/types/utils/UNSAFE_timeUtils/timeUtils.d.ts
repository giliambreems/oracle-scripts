/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { OrderedTimeSegmentsArray } from "../../UNSAFE_InputTimeMask/types";
import { BCP47Locale } from "../../UNSAFE_IntlDateTime";
import { TimeISOStr } from "../../UNSAFE_IntlDateTime/types";
import { AmPmLocalizedValues, Hour, Time, TimeGranularity, TimePlaceholders, TimeWithValidIsoStrParts } from './types';
declare const AM_VALUE = 0;
declare const PM_VALUE = 12;
/**
 * Given an ISO 8601 time-only string without zulu or offset e.g., 'T01:00:00.000' or 'T01:00', this method returns a Time object
 * containing 'hour' and 'minute', with optional 'second' and 'millisecond'.
 *
 * If the input is invalid (empty, null, undefined, or incorrectly formatted), this function returns undefined.
 * @param {TimeISOStr} isoTime - The ISO 8601 time string that starts with 'T'. (e.g., "T12:30:45.123")
 * @returns  (TimeWithValidIsoStrParts | undefined)
 * Returns a Time object with hour and minute, and optionally second and millisecond if they are in the input ISO string.
 * If the input is invalid, return undefined.
 */
declare const getTimeObjFromTimeOnlyISOStr: (isoTime: TimeISOStr | undefined | null) => TimeWithValidIsoStrParts | undefined;
/**
 * Given a Time object with hour, minute, and optionally second and millisecond, return a time-only ISO string that starts with 'T'.
 * @param {Time | undefined} Time object or undefined. The hour and minute must be defined, otherwise this function returns undefined.
 * @returns {TimeISOStr | undefined} Time-only ISO string that starts with 'T'. If the time is undefined, or the hour or minute are undefined, returns undefined.
 * @throws {Error} throws an error if milliseconds is defined but its value is out of the valid range of 0-999. The allowed range is too large to express in Typescript.
 */
declare const getTimeOnlyISOStrFromTimeObj: (time: Time | undefined) => string | undefined;
/**
 * Returns a new array where the value in the masks array of type/value objects is replaced
 * with the string placeholders based on the locale.
 * For example, [{type='hour', value='hh'}, {type='minute', value='mm'} for 'en' locales,
 * or value='--' for non-'en' locales.
 * @param {BCP47Locale} locale - The locale.
 * @param {TimePlaceholders} masks - The TimePlaceholder masks
 * @returns A new array where the value in the masks array of type/value objects is replaced with
 * the string placeholders based on the locale.
 */
declare const replaceCustomMasksValuesWithPlaceholders: (locale: BCP47Locale, masks: TimePlaceholders) => TimePlaceholders;
/**
 * Retrieves the TimePlaceholders masks where value has the placeholder (e.g., 'hh' or '--')
 * by using a new instance of Intl.DateTimeFormat with the locale, granularity, and hour12.
 *
 * @param {BCP47Locale} locale - The locale
 * @param {TimeGranularity} granularity - The granularity of the desired time mask.
 * @param hour12 - passes through to Intl.DateTimeFormat's hour12, which indicates
 * if the hour is a 12-hour (as opposed to 24-hour) clock.
 * E.g., new Intl.DateTimeFormat('en-GB', {timeStyle: 'short', hour12: true}).format(date)
 * @returns Returns the TimePlaceholder masks where value has the placeholders (e.g., 'hh' or '--').
 */
declare const getTimeMasksFromLocaleAndOptions: (locale: BCP47Locale | undefined, granularity: TimeGranularity, hour12?: boolean) => TimePlaceholders;
/**
 * Gets the day period value strings for AM and PM.
 *
 * @param {BCP47Locale} locale - The locale to format the time.
 * @returns An object containing the AM and PM strings for the locale.
 */
declare const getAmPmStringsForLocale: (locale: BCP47Locale) => AmPmLocalizedValues;
/**
 * Retrieves the day period string for a specific locale and hour.
 * This uses a cache so a new instance of Intl.DateTimeFormat with hour12: true so even if the locale
 * does not have a 1-12 hour time by default, the hour12: true parameter will force it.
 * For example, for 'en-US' if the hour is 0, this returns 'AM'. If the hour is 13, this returns 'PM'.
 * For 'ms', if the hour is 0, this returns 'PG'.
 *
 * @param {BCP47Locale} locale - The locale to format the time.
 * @param {Hour} hour - The hour for which to get the day period (0-23).
 * @returns {string} The locale's day period value for the hour. All locales have a dayPeriod string, but
 * just in case we default to 'AM' and 'PM'.
 */
declare const getDayPeriodValueStr: (locale: BCP47Locale | undefined, hour: Hour) => string;
declare const getDayPeriodValueFromHour: (hour: Hour) => 0 | 12;
/**
 * Formats a Time object into a string based on the provided masks.
 * Handles hour conversion (12-hour/24-hour) since the Time object is in 24-hour format,
 * and the mask, if it has the dayPeriod, is in 12-hour format. Applies leading
 * zeros to hour if leadingZeroForHour is true. Pads zeros to minute, second, and millisecond so
 * that the digits equal two for minute/second and three for millisecond.
 * The timeMasks must have the correct segments to match the granularity before calling this function.
 * @param locale
 * @param time
 * @param granularity
 * @param timeMasks
 * @param leadingZeroForHour
 * @returns a formatted time string
 */
declare const formatTimeFromMasks: (locale: BCP47Locale, time: Time, granularity: TimeGranularity, timeMasks: TimePlaceholders, leadingZeroForHour: boolean) => string;
/**
 * Retrieves the hour string. If the display has a day period, then the hour string
 * will be 1-12, otherwise it will be 0-23.
 * @param hour
 * @param hasDayPeriod true if the time to display has a day period segment (e.g., a segment that shows AM or PM).
 * This means the time field has a 1-12 hour time.
 * @param leadingZeroForHour If true, the hour string will have length of 2, with leading zeros if necessary to pad it out.
 * @returns
 */
declare const getHourValueStr: (hour: Hour, hasDayPeriod: boolean, leadingZeroForHour: boolean) => string;
/**
 * Returns true if the locale's hour has a leading zero by default.
 *
 * This method uses a cached new Intl.DateTimeFormat(locale),
 * and uses formatToParts for hour
 * to figure out if the hour has a leading zero.
 *
 * @param {BCP47Locale} locale - the locale
 * @returns true if hour starts with 0 for the specific locale.
 */
declare const getLeadingZeroForHour: (locale: BCP47Locale) => boolean;
declare const padWithZero: (num: number | undefined, length: number) => string;
/**
 * Returns true if the time params represent two different times.
 * This is useful to call before we call onInput or onCommit.
 * @param t1
 * @param t2
 * @returns true if the time params represent two different times.
 */
declare const timesAreDifferent: (t1: Time | undefined, t2: Time | undefined) => boolean;
/**
 * Compares two TimeWithValidIsoStrParts objects and returns a number indicating their relative order.
 * @param {TimeWithValidIsoStrParts} time1 The first time to compare.
 * @param {TimeWithValidIsoStrParts} time2 The second time to compare.
 * @returns {number} A negative number if time1 is before time2, a positive number if time1 is after time2, or 0 if they are the same.
 */
declare const compareTimes: (time1: TimeWithValidIsoStrParts, time2: TimeWithValidIsoStrParts) => number;
/**
 * Determines whether the input string matches the start of the 'am' and/or 'pm' strings in the given am/pm object.
 *
 * The match is case-insensitive and ignores leading and trailing whitespace.
 *
 * If the input matches with only the start of the 'am' string, 'am' is returned.
 * If the input matches with only the start of the 'pm' string, 'pm' is returned.
 * If the input matches the start of both the 'am' and 'pm strings (e.g., the 'am'/'pm' strings have the same starting letter(s) and the input is too short to disambiguate),
 * 'both is returned.
 * If the input does not match the start of either string, 'none' is returned.
 * @param {AmPmLocalizedValues} amPmObj - An object containing the am and pm strings for the current locale.
 * @param {string} input - The user provided string to match against the am an pm strings.
 * @returns {('am' | 'pm' | 'none' | 'both')}
 */
declare const getAmPmMatchType: (amPmObj: AmPmLocalizedValues, input: string) => "none" | "both" | "am" | "pm";
/**
 * Check if the value has segments in it that are not displayed to the user.
 * E.g., originalValue: {hour: 1, minute: 30, second: 59, millisecond: 599}, and the segments are: ['hour', 'minute'], returns true.
 * originalValue: {millisecond: 599}, and the segments are: ['hour', 'minute'], returns true.
 * originalValue: {second: 599}, and the segments are: ['hour', 'minute'], returns true.
 * originalValue: {second: 599}, and the segments are: ['hour', 'minute'], returns true.
 * originalValue: {hour: 1, minute: 30, second: 599}, and the segments are: ['hour', 'minute', 'second'], returns false.
 * @param orderedSegments {OrderedTimeSegmentsArray} - The segments that are displayed to the user
 * @param originalValue {Time|undefined} - The original Time value.
 * @returns {boolean} returns true if the originalValue has segments that are not displayed to the user.
 */
declare const hasSegmentsNotDisplayed: (orderedSegments: OrderedTimeSegmentsArray, originalValue: Time | undefined) => boolean;
/**
 * Returns true if any one of the displayed time segments has a different value in initialTime vs updatedTime.
 * @param orderedSegments {OrderedTimeSegmentsArray} the time segments that are displayed to the user
 * @param initialTime {Time} The initial time.
 * @param updatedTime {Time} The updated time.
 * @returns true if the displayed time segments have different values
 */
declare const displayedTimeSegmentsAreDifferent: (orderedSegments: OrderedTimeSegmentsArray, initialTime: Time, updatedTime: Time) => boolean;
/**
 * Format an example TimeISOStr to show in an error message.
 */
declare const formatIsoTimeStrAsExample: (str: TimeISOStr, locale: BCP47Locale, granularity: TimeGranularity, leadingZeroForHour: boolean, masks: TimePlaceholders) => string;
declare const getTimePlaceholdersFromPattern: (pattern: string) => TimePlaceholders;
export { AM_VALUE, PM_VALUE, compareTimes, displayedTimeSegmentsAreDifferent, formatIsoTimeStrAsExample, formatTimeFromMasks, getAmPmMatchType, getAmPmStringsForLocale, getDayPeriodValueFromHour, getDayPeriodValueStr, getHourValueStr, getLeadingZeroForHour, getTimeOnlyISOStrFromTimeObj, getTimePlaceholdersFromPattern, getTimeObjFromTimeOnlyISOStr, getTimeMasksFromLocaleAndOptions, hasSegmentsNotDisplayed, padWithZero, replaceCustomMasksValuesWithPlaceholders, timesAreDifferent };

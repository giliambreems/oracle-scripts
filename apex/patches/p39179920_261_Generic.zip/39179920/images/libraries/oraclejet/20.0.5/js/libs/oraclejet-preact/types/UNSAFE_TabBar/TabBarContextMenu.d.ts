/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { ComponentProps } from 'preact';
import { Menu } from '../UNSAFE_Menu';
import { TabBarContextMenuConfig, TabBarItemContext } from '../UNSAFE_TabBarCommon';
import { TabBar } from './TabBar';
import { TabBarItemContextMenuContext } from '../UNSAFE_TabBarCommon/TabBar.types';
import { ReorderableTabBar } from '../UNSAFE_ReorderableTabBar';
export type Props<K extends string | number> = Omit<ComponentProps<typeof Menu>, 'children'> & {
    contextMenuConfig: TabBarContextMenuConfig<K>;
} & {
    contextMenuContext: TabBarItemContext<K>;
};
/**
 * The internal component used to render a custom or default context menu
 */
export declare function TabBarContextMenu<K extends string | number>({ contextMenuConfig, contextMenuContext, ...menuProps }: Props<K>): import("preact").JSX.Element;
/**
 * Optional props because we could have only remove feature or reorder feature.
 */
type StatusProps<K extends string | number> = {
    position?: 'before' | 'after';
    destinationKey?: K;
    removedKey?: K;
};
type AccInfo = {
    handleAccStatus: (statusDetail: StatusProps<string | number>) => void;
};
/**
 * Optional because we could have only remove feature or reorder feature.
 */
type RemoveItemProps = {
    handleRemove?: ComponentProps<typeof TabBar>['onRemove'];
    isRemovable?: boolean;
};
/**
 * Optional because we could have only remove feature or reorder feature.
 */
type ReorderItemProps<K> = {
    handleReorder?: ComponentProps<typeof ReorderableTabBar>['onReorder'];
    tabKeys?: K[];
    direction?: 'ltr' | 'rtl';
};
type TranslationLabels = {
    itemLabels: {
        labelRemove?: string;
        labelMoveLeft?: string;
        labelMoveRight?: string;
    };
};
/**
 * Creates the default context menu items
 */
export declare function getDefaultContextMenu<K extends string | number>({ isRemovable, handleReorder, handleRemove, itemKey, tabKeys, direction, itemLabels, handleAccStatus }: RemoveItemProps & ReorderItemProps<K> & TabBarItemContext<K> & TranslationLabels & AccInfo): TabBarItemContextMenuContext<K>;
export {};

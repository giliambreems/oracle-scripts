import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class NavigationListAdapter extends TestAdapter {
    /**
     * Select the NavigationListItem identified by a locator
     * @param key The key of the NavigationListItem to select
     * @returns Promise<void>
     */
    doSelect<K extends string | number>(key: K): Promise<void>;
    /**
     * Remove the item in the NavigationList
     * @param key The key of the NavigationListItem to remove
     * @returns Promise<void>
     */
    doRemove<K extends string | number>(key: K): Promise<void>;
}

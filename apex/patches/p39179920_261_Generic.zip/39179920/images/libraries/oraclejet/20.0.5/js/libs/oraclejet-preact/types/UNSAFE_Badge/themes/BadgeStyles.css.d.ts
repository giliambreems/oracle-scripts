import { badgeVars } from './BadgeContract.css';
import { ComponentThemeType, VariantOptions } from '../../UNSAFE_Theme';
type BadgeVariants = typeof variants;
type BadgeVariantOptions = VariantOptions<BadgeVariants>;
type BadgeStyles = typeof styles;
type BadgeTheme = ComponentThemeType<BadgeVariants, BadgeStyles>;
declare const styles: {
    base: string;
};
/*******************
 * Style Variants
 *******************/
declare const variants: {
    readonly edge: {
        readonly none: {};
        readonly end: {
            readonly borderTopRightRadius: "0";
            readonly borderBottomRightRadius: "0";
        };
    };
    readonly size: {
        readonly xs: {
            readonly vars: {
                readonly [badgeVars.height]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontSize]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontWeight]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.borderRadius]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.padding]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly sm: {
            readonly vars: {
                readonly [badgeVars.height]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontSize]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontWeight]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.borderRadius]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.padding]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly md: {
            readonly vars: {
                readonly [badgeVars.height]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontSize]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.fontWeight]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.borderRadius]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.padding]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
    };
    readonly variant: {
        readonly neutral: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly danger: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly warning: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly success: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly info: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly neutralSubtle: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly dangerSubtle: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly warningSubtle: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly successSubtle: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        readonly infoSubtle: {
            readonly vars: {
                readonly [badgeVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                readonly [badgeVars.color]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
    };
};
export type { BadgeVariantOptions, BadgeStyles, BadgeTheme };
export { variants, styles };

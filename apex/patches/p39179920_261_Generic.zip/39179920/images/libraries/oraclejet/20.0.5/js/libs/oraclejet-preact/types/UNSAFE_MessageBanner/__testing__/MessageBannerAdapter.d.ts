import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
import { TestElement } from '@oracle/oraclejet-testing/UNSAFE_Driver';
export declare class MessageBannerAdapter extends TestAdapter {
    /**
     * Closes the message identified by the provided key.
     * @param messageLocator.key {string | number} The key within the MessageBanner's dataset associated with the individual message.
     */
    doClose(messageLocator: {
        key: string | number;
    }): Promise<void>;
    /**
     * Retrieve a TestElement which represents the custom detail content of a single message.
     * @param messageLocator.key {string | number} The key within the MessageBanner's dataset associated with the individual message.
     * @throws {Error} when the detail content rendered is not provided by the application
     * @returns The detail content of the message rendered by the application
     */
    findDetail(messageLocator: {
        key: string | number;
    }): Promise<TestElement>;
    /**
     * Creates the CSS selector for the message with the provided key.
     *
     * @param key The key of the message
     * @returns the css selector that can used to fetch the message
     */
    private getMessageSelector;
}

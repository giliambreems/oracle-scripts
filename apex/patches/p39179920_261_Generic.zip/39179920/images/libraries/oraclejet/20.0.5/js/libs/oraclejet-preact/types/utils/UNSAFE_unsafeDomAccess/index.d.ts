export { UNSAFE_DOM_ACCESS } from './unsafeDomAccess';
export type { UnsafeDomHandle } from './unsafeDomAccess';

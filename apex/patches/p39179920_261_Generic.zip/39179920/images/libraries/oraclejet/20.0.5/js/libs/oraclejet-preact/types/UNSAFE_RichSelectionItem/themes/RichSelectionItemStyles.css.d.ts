/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
declare const styles: {
    checkboxAlign: string;
    checkboxWrapper: string;
    densityWrapper: string;
    growOneColumn: string;
    iconDisabledColor: string;
    iconEnabledColor: string;
    iconWrapper: string;
    inputElement: string;
    labelOnly: string;
    mdMediaVariant: string;
    mediaDisabledOpacity: string;
    radioWrapper: string;
    selectionElement: string;
    smMediaVariant: string;
    startMinHeight: string;
    thumbnailImage: string;
};
export { styles };

import { TestIdProps } from "../hooks/UNSAFE_useTestId";
import { Avatar } from "../UNSAFE_Avatar";
import { ComponentProps } from 'preact';
type AvatarProps = ComponentProps<typeof Avatar>;
/**
 * Partial Avatar Props type utilized for the media.
 */
type RichSelectionAvatar = {
    shape?: AvatarProps['shape'];
    src?: string;
    background?: AvatarProps['background'];
    initials?: string;
};
type RichSelectionItemData<V extends string | number> = ItemDataType<V> & (NoMediaType | ThumbnailType | IconType | AvatarType);
type ItemDataType<V> = {
    /**
     * Considered as label and accessible text for the component.
     */
    label: string;
    /**
     * Provides concise detail information about the item.
     */
    secondaryText?: string;
    /**
     * Value of the RichSelectionItem.
     */
    value: V;
};
type NoMediaType = {
    avatar?: never;
    iconClass?: never;
    mediaAccessibleLabel?: never;
    thumbnailSrc?: never;
};
type ThumbnailType = {
    /**
     * This will apply aria-label to Thumbnail. If it's not provided the media would be hidden from screen readers.
     */
    mediaAccessibleLabel?: string;
    thumbnailSrc?: string;
    iconClass?: never;
    avatar?: never;
};
type IconType = {
    mediaAccessibleLabel?: never;
    thumbnailSrc?: never;
    iconClass?: string;
    avatar?: never;
};
type AvatarType = {
    /**
     * This will apply aria-label to Avatar. If it's not provided the media would be hidden from screen readers.
     */
    mediaAccessibleLabel?: string;
    thumbnailSrc?: never;
    iconClass?: never;
    avatar?: RichSelectionAvatar;
};
type RichSelectionMediaItemProps = TestIdProps & {
    hasSecondaryText?: boolean;
} & ({
    layout?: 'xl' | 'md' | 'sm';
    thumbnailSrc?: string;
    mediaAccessibleLabel?: string;
    avatar?: never;
    iconClass?: never;
} | {
    layout?: 'md' | 'sm';
    thumbnailSrc?: never;
    mediaAccessibleLabel?: string;
    avatar?: RichSelectionAvatar;
    iconClass?: never;
} | {
    layout?: 'sm';
    thumbnailSrc?: never;
    mediaAccessibleLabel?: never;
    avatar?: never;
    iconClass?: string;
});
export type { RichSelectionItemData, RichSelectionMediaItemProps };

/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { ColorProps } from '../../UNSAFE_interpolations/colors';
export type ChartPlotArea = {
    /**
     * The major tick properties corresponding to y values.
     */
    yMajorTick?: MajorTick;
    /**
     * The major tick properties corresponding to y2 values.
     */
    y2MajorTick?: MajorTick;
    /**
     * The major tick properties corresponding to y values.
     */
    xMajorTick?: MajorTick;
    /**
     * The minor tick properties corresponding to y values.
     */
    yMinorTick?: MinorTick;
    /**
     * The minor tick properties corresponding to y2 values.
     */
    y2MinorTick?: MinorTick;
    /**
     * The minor tick properties corresponding to x values.
     */
    xMinorTick?: MinorTick;
    /**
     * The color of the plot area background.
     */
    color?: ColorProps['color'];
    /**
     * An object defining properties for the x axis line. If the axis line is placed at value zero, the baseline configuration could potentially override it.
     */
    xAxisLine?: AxisLine;
    /**
     * An object defining properties for the y axis line. If the axis line is placed at value zero, the baseline configuration could potentially override it.
     */
    yAxisLine?: AxisLine;
    /**
     * An object defining properties for the y2 axis line. If the axis line is placed at value zero, the baseline configuration could potentially override it.
     */
    y2AxisLine?: AxisLine;
};
export type MajorTick = {
    /**
     * The color of the major tick mark at the baseline.
     */
    baselineColor?: ColorProps['color'];
    /**
     * The width of the major tick mark at the baseline.
     */
    baselineWidth?: number;
    /**
     * The line style of the major tick mark at the baseline.
     */
    baselineStyle?: 'dashed' | 'dotted' | 'solid';
    /**
     * The line color of the major tick.
     */
    lineColor?: ColorProps['color'];
    /**
     * The line style of the major tick.
     */
    lineStyle?: 'dashed' | 'dotted' | 'solid';
    /**
     * The line width of the major tick.
     */
    lineWidth?: number;
    /**
     * Whether the line tick is rendered or not.
     */
    isRendered?: boolean;
};
export type MinorTick = {
    /**
     * The line color of the major tick.
     */
    lineColor?: ColorProps['color'];
    /**
     * The line style of the major tick.
     */
    lineStyle?: 'dashed' | 'dotted' | 'solid';
    /**
     * The line width of the major tick.
     */
    lineWidth?: number;
    /**
     * Whether the line tick is rendered or not.
     */
    isRendered?: boolean;
};
type AxisLine = {
    /**
     * The color of the axis line.
     */
    lineColor?: ColorProps['color'];
    /**
     * The line width of the axis line.
     */
    lineWidth?: number;
    /**
     * Defines whether the axis line is rendered.
     */
    isRendered?: boolean;
};
export {};

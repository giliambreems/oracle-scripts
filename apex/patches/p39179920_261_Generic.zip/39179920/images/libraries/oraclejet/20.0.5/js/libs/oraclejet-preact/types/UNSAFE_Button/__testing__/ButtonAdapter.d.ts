import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class ButtonAdapter extends TestAdapter {
    /**
     * Click on the button
     * @returns
     */
    doAction(): Promise<void>;
}

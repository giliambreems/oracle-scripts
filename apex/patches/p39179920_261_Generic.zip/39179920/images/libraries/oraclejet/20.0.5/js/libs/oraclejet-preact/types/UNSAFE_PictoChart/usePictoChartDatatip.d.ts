/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { ItemInfo } from './pictoChart.type';
import { ComponentChildren } from 'preact';
import { Property } from 'csstype';
import { Dimension } from "../utils/UNSAFE_visTypes/common";
type Props = {
    touchResponse: 'touchStart' | 'touchHold';
    content?: ComponentChildren;
    borderColor?: Property.BorderColor;
    focusedItemInfo: ItemInfo;
    width: number;
    getFocusedItemDimension: (item: ItemInfo) => Dimension | undefined;
    defaultContainer?: 'enabled' | 'disabled';
};
/**
 * Returns the datatip.
 * @param content The text string for the picto chart item.
 * @param focusedItemRef The ref for focused item node.
 * @param focusedItemInfo The ItemInfo for focused item node.
 * @returns
 */
export declare const usePictoChartDatatip: ({ touchResponse, content, borderColor, width, focusedItemInfo, getFocusedItemDimension, defaultContainer }: Props) => {
    datatipContent: import("preact").JSX.Element | null;
    datatipProps: {
        'aria-describedby': string | undefined;
    };
};
export {};

declare const Redwood: {
    name: string;
    base: {
        cursor: {
            clickable: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        boxShadow: {
            xs: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            sm: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            md: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            lg: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            xl: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        borderRadius: {
            sm: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            md: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            lg: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            xl: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
    };
    colorScheme: {
        palette: {
            neutral: {
                '0': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '200': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            danger: {
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            success: {
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            warning: {
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            info: {
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            brand: {
                '10': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '20': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '30': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '40': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '50': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '60': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '70': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '80': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '90': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '100': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '110': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '120': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '130': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '140': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '150': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '160': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '170': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '180': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                '190': `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        overlay: {
            hover: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            active: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dangerHover: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dangerActive: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            scrim: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            inverseHover: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            inverseActive: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dropActive: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        pageBackground: {
            neutral0: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral10: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral20: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral30: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral40: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        surface: {
            neutral0: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral10: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral20: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral30: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            selected: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            disabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            popup: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            neutral: {
                low: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                subtle: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                strong: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            success: {
                low: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                subtle: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                strong: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            info: {
                low: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                subtle: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                strong: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            warning: {
                low: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                subtle: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                strong: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            danger: {
                low: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                subtle: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                strong: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        border: {
            enabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            disabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            divider: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dividerOpaqueColor: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dividerOpaquePercent: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            selected: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            dropLine: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            selectedNeutral: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            warning: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            danger: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            keyboardFocus: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        boxshadow: {
            shadowcolor: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        textIcon: {
            primary: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            secondary: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            disabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            inverse: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            onColor: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            link: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            success: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            info: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            warning: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            danger: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        textfield: {
            surface: {
                enabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            border: {
                enabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        collection: {
            header: {
                text: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                surface: {
                    selected: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                    partialSelected: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                };
            };
        };
        collectionGrid: {
            cell: {
                surfaceEdit: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        measure: {
            track: {
                enabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                disabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            fill: {
                enabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                disabled: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            thumb: {
                surface: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            reference: {
                line: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                lineContrast: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                area: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        dvt: {
            contrastLine: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            paletteQualitative: {
                1: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                2: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                3: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                4: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                5: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                6: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                7: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                8: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                9: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                10: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                11: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                12: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            threshold: {
                success: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                warning: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                danger: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            marquee: {
                border: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                surface: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            referenceObject: {
                area: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                line: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
            overview: {
                background: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                windowBackground: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                windowBorder: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
    };
    scale: {
        size: {
            units: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
    };
    density: {
        density: {
            units: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
    };
};
export { Redwood };

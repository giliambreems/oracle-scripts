import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class RadioSetAdapter extends TestAdapter {
    /**
     * Change the value of the component.
     * @param value {string | number} The new value.
     * @returns Promise<void>
     */
    changeValue(value: number | string): Promise<void>;
}

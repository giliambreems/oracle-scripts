import type { TestDriver, TestElement } from '@oracle/oraclejet-testing/UNSAFE_Driver';
import type { ElementLocator } from '@oracle/oraclejet-testing/UNSAFE_Locators';
import { ListViewAdapter } from './ListViewAdapter';
/**
 * Get the test adapter for the Preact ListView, identified by the given locator.
 * If a driverOrElement is given, the locator will be searched from there.
 * @param locator The ElementLocator used to search for the ListView
 * @param driverOrElement The optional TestDriver or TestElement from which to search. If
 * TestElement is given, locator will search underneath that element. If TestDriver is given
 * or the parameter is undefined, the DOM is searched globally.
 * @returns The test adapter for ListView
 */
export declare function findListView(locator: ElementLocator, driverOrElement?: TestDriver | TestElement): ListViewAdapter;

/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { DataAxisProps, Group, GroupAxisProps, TimeAxisProps } from '.';
import { ComponentChildren } from 'preact';
import { ChartPlotArea } from './plotArea.types';
import { DataCursorProps } from './dataCursor.types';
import type { TestIdProps } from '../../../hooks/UNSAFE_useTestId';
import { Property } from 'csstype';
import { ContextMenuConfig, DatatipConfig } from '../common';
import { VisTextStyle } from "../../UNSAFE_visUtils";
import { Size } from '../../UNSAFE_size';
import { Dimension } from '../common';
import { ValueFormats } from './valueFormats.types';
import { ChartDndProps } from './dnd.types';
import { ViewportDetail } from './axis.types';
import { ColorProps } from "../../UNSAFE_interpolations/colors";
import { ReferenceAreaData, ReferenceLineData } from './refObj.types';
export type ChartGroupInfo = {
    levelIndex?: number;
    groupIndex?: number;
    isCurrent?: boolean;
    isFocusVisible?: boolean;
};
type YAxisSizeHandle = {
    _getYaxis: () => {
        getPreferredSize: (_width: number, _height: number) => {
            width: number;
            height: number;
        };
        bounds: Dimension;
    };
};
type Y2AxisSizeHandle = {
    _getY2axis: () => {
        getPreferredSize: (_width: number, _height: number) => {
            width: number;
            height: number;
        };
        bounds: Dimension;
    };
};
type XAxisSizeHandle = {
    _getXaxis: () => {
        getPreferredSize: (_width: number, _height: number) => {
            width: number;
            height: number;
        };
        bounds: Dimension;
    };
};
export type SizeHandle = YAxisSizeHandle & Y2AxisSizeHandle & XAxisSizeHandle;
export type Info = {
    seriesIndex?: number;
    refObjId?: string;
} & Partial<ChartGroupInfo>;
export type ChartContextMenuConfig<K, D> = ContextMenuConfig<ChartContextMenuContext<K, D>>;
export type ChartContextMenuContext<K, D> = {
    type: 'item';
    groupIndex: number;
    seriesIndex: number;
    data: D;
} | {
    type: 'axisTitle';
    axis: 'x' | 'y';
} | {
    type: 'series';
    data: ChartSeriesData<K, D>;
} | {
    type: 'xAxisTickLabel';
    data: Group;
} | {
    type: 'background';
};
export type ItemInfo = Required<Pick<Info, 'seriesIndex' | 'groupIndex'>>;
export type AxisPosition = 'start' | 'end' | 'top' | 'bottom';
export type ItemDetail<K, D> = {
    /**
     * The group index of the given item. For hierarchical group, the groupIndex will be the leaf index.
     */
    groupIndex: number;
    /**
     * The groupPath is an array of indices that represents the path from the outermost group to the target group.
     * For non-hierarchical groups, the groupPath is an array of just one number - the groupIndex.
     */
    groupPath: number[];
    /**
     * The series index of the given item.
     */
    seriesIndex: number;
    /**
     * The id of the given item.
     */
    id: K;
    /**
     * The data item.
     */
    data: D;
    /**
     * The color of the data item.
     */
    color?: ColorProps['color'];
};
export type GroupDetail = {
    /**
     * The index of the group in the groups array. For hierarchical group, the groupIndex will be the leaf index.
     */
    groupIndex: number;
    /**
     * An array of indices that represents the path from the outermost group to the target group.
     * For non-hierarchical groups, the groupPath is an array of just one number - the groupIndex.
     */
    groupPath: number[];
    /**
     * The id of the group.
     */
    id: string | number;
    /**
     * The group data.
     */
    group: Group;
};
export type SelectionProps<K, D> = {
    /**
     * An array used to define the ids of the initially selected objects.
     */
    selectedIds?: K[];
    /**
     * The type of selection behavior that is enabled on the chart.
     * If single or multiple is specified, selection gestures will be enabled, and the chart's selection styling will be applied to all items specified by the selection attribute.
     * If none is specified, selection gestures will be disabled, and the chart's selection styling will not be applied to any items specified by the selection attribute.
     */
    selectionMode?: 'single' | 'multiple' | 'none';
    /**
     * The callback to be fired when chart selection is changed. selection prop should be updated by this function.
     */
    onSelectionChange?: SelectionDetail<K, D>;
};
export type DrillProps<K, D> = {
    /**
     * Triggered on a chart item (double click if selection is enabled, single click otherwise).
     */
    onItemDrill?: (detail: ItemDetail<K, D>) => void;
    /**
     * Triggered on a chart group drill gesture (double click if selection is enabled, single click otherwise).
     */
    onGroupDrill?: (detail: GroupDetail) => void;
    /**
     * Whether drilling is enabled.
     * Drillable objects will show a pointer cursor on hover and fire an onItemDrill or onGroupDrill event on click (double click if selection is enabled).
     * Use "on" to enable drilling for all group objects (x-axis labels) and data items such as bars, area and marker.
     * To enable or disable drilling on group or data item use the drilling attribute in each series, group, or data item.
     */
    drilling?: 'on' | 'off' | 'groupsOnly';
};
export type ChartItemData<K> = {
    /**
     * The  color of the bar item.
     */
    color?: Property.BorderColor;
    /**
     * The border color of the bar item.
     */
    borderColor?: Property.BorderColor;
    /**
     * The label to be used for accessibility purposes.
     */
    accessibleLabel?: string;
    /**
     * Defines the label for the data item.
     */
    label?: string;
    /**
     * Defines the label style for the data item.
     */
    labelStyle?: VisTextStyle;
    /**
     * The id of the data item.
     */
    id: K;
    /**
     * Whether the item is drillable or not.
     */
    drilling?: 'on' | 'off' | 'inherit';
};
export type ChartSeriesData<K, D> = {
    /**
     * The id of the series.
     */
    id: K;
    /**
     * The name of the series.
     */
    name?: string;
    /**
     * The color of the items of the series.
     */
    color?: Property.BorderColor;
    /**
     * The border color of the items of the series.
     */
    borderColor?: Property.BorderColor;
    /**
     * The label to be used for accessibility purposes.
     */
    accessibleLabel?: string;
    /**
     * The items present in the series.
     */
    items: D[];
    /**
     * Whether the series is associated with the y or y2 axis.
     */
    associatedYAxis?: 'y' | 'y2';
};
export type ChartOverviewConfig = {
    /**
     * The height of the overview chart.
     */
    height: `${number}px` | `${number}%`;
    /**
     * The function called to get the custom content for the overview background. The content should set it's
     * height and width to be 100% in order to fit inside the overview container.
     */
    renderer?: () => ComponentChildren;
};
export type ChartCommonProps<K, D> = {
    /**
     * Whether automatic initial zooming is enabled.
     */
    initialZooming?: 'first' | 'last' | 'none';
    /**
     * Defines the hide and show behavior. When data items are hidden, the y axes can be optionally rescaled to fit to the remaining data.
     */
    hideAndShowBehavior?: 'withoutRescale' | 'withRescale' | 'none';
    /**
     * The ids of the hidden items.
     */
    hiddenIds?: K[];
    /**
     * An array of ids used for highlighting. Series or data items matching the ids in the array will be highlighted.
     */
    highlightedIds?: K[];
    /**
     * The orientation of the chart.
     */
    orientation?: 'vertical' | 'horizontal';
    /**
     * The width of the chart. The default value for this is theme driven.
     */
    width?: Size;
    /**
     * Defines the behavior applied when hovering over data items.
     * When hover behavior is set to dim, it will dim all other data items except the one being hovered.
     */
    hoverBehavior?: 'dim' | 'none';
    /**
     * The action that is performed when a drag occurs on the chart. Pan and marquee zoom are only available if zoom and scroll is turned on.
     * Marquee select is only available if multiple selection is turned on. If the value is set to "user" and multiple actions are available,
     * buttons will be displayed on the plot area to let users switch between modes. Only 'select' and 'pan' buttons are showed in mobile, as
     * zoom in or out can be performed with 2 finger pinch gesture.
     */
    dragMode?: 'user' | 'zoom' | 'select' | 'pan' | 'off';
    /**
     * The viewport change callback. This callback should update the xAxis and yAxis viewport props.
     */
    onViewportChange?: (detail: ViewportDetail) => void;
    /**
     * Triggered when item is hovered or looses hover.
     */
    onItemHover?: (detail: {
        seriesIndex?: number;
        groupIndex?: number;
    }) => void;
    /**
     * Triggered when item is is keyboard focused or looses focus
     */
    onItemFocus?: (detail: {
        seriesIndex?: number;
        groupIndex?: number;
    }) => void;
    /**
     * The function called to get the data item for given seriesIndex and groupIndex. With this callback, data items are not bound to particular
     * series or groups data structure. The groupPath is an array of indices that represents the path from the outermost group to the target group.
     * For non-hierarchical groups, the groupPath is an array of just one number - the groupIndex.
     */
    getDataItem: (seriesIndex: number, groupIndex: number, groupIndexPath: number[]) => D | undefined;
    /**
     * The height of the chart. The default value for this is theme driven.
     */
    height?: Size;
    /**
     * An object defining properties for the yAxis, tick marks, tick labels, and axis titles.
     */
    yAxis?: DataAxisProps;
    /**
     * An object defining properties for the y2Axis, tick marks, tick labels, and axis titles.
     */
    y2Axis?: DataAxisProps & {
        /**
         * Specifies if the y2 axis should be rendered in a seperate split view in the plot area. If set to number,
         * it determines the fraction of plot area in which y2 axis series is rendered.
         */
        split?: 'off' | number;
    };
    /**
     * An object defining properties for the xAxis, tick marks, tick labels, and axis titles.
     */
    xAxis?: GroupAxisProps | TimeAxisProps | DataAxisProps;
    /**
     * An array of nested group objects.
     */
    groups: Group[];
    /**
     * The function that returns datatip for the given item context.
     */
    datatip?: DatatipConfig<ChartDatatipDetail<K, D>>;
    /**
     * Configuration to specify the chart overview.
     */
    overview?: 'on' | 'off' | ChartOverviewConfig;
    /**
     * Configuration used to specify the context menu.
     */
    contextMenuConfig?: ChartContextMenuConfig<K, D>;
    /**
     * The plot area of the chart.
     */
    plotArea?: ChartPlotArea;
    /**
     * Specifies the zoom and scroll behavior of the chart. "live" behavior means that the chart will be updated continuously as it is being manipulated.
     */
    zoomAndScroll?: 'live' | 'off';
    /**
     * An object specifying value formatting and tooltip behavior, whose keys generally correspond to the attribute names on the data items.
     */
    valueFormats?: ValueFormats;
    /**
     * The aria label of the chart.
     */
    'aria-label'?: string;
    /**
     * One or more ids (separated by spaces) of elements that label the chart. This will be used for the aria-labelledby of the DOM element.
     */
    'aria-labelledby'?: string;
    /**
     * One or more ids (separated by spaces) of elements that describe the chart. This will be used for the aria-describedby of the DOM element.
     */
    'aria-describedby'?: string;
} & TestIdProps & DataCursorProps & SelectionProps<K, D> & DrillProps<K, D> & ChartDndProps<D>;
export type GetNextChartItemType = (info: Info, key: 'ArrowUp' | 'ArrowDown' | 'ArrowRight' | 'ArrowLeft') => Info;
export type getDataPosType = (seriesIndex: number, groupIndex: number) => Dimension | undefined;
export type Scale = {
    transform: (value: number) => number;
    invert: (value: number) => number;
    range: () => number[];
    domain: () => number[];
};
export type SelectionDetail<K, D> = (detail: {
    ids: K[];
    data: (D | undefined)[];
}) => void;
export type ChartDatatipDetail<K, D> = {
    type: 'item';
    data: D;
    seriesIndex: number;
    groupIndex: number;
    id: K;
    groupPath: number[];
} | {
    type: 'referenceLine';
    axis: 'x' | 'y' | 'y2';
    data: ReferenceLineData;
} | {
    type: 'referenceArea';
    axis: 'x' | 'y' | 'y2';
    data: ReferenceAreaData;
};
export {};

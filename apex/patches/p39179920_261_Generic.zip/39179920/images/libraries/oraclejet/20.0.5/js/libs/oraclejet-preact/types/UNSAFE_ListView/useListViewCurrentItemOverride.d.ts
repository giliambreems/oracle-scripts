import { Item as CurrentItem } from "../UNSAFE_Collection";
import { ListProps } from './List.types';
/**
 * This hook handles the currentItemOverride passing to PRIVATE_List layer.
 *
 * If the app provided new value for 'currentItemOverride', we pass that down to PRIVATE_List layer;
 * otherwise, we will pass down the value of internal override, which would be the value
 * updated by useListViewContextMenu hook
 *
 * @param currentItemOverride
 */
export declare const useListViewCurrentItemOverride: <K extends string | number, D>(currentItemOverride: ListProps<K, D>["currentItemOverride"]) => {
    currentItemOverride: CurrentItem<K> | undefined;
    updateCurrentItemOverride: (key: K) => void;
};

import { ComponentProps } from 'preact';
import { type ColorValue } from "../utils/UNSAFE_color";
import { ValueUpdateDetail } from "../utils/UNSAFE_valueUpdateDetail";
import { ColorPicker } from "../UNSAFE_ColorPicker";
import { InputText } from "../UNSAFE_InputText";
import type { TestIdProps } from "../hooks/UNSAFE_useTestId";
type ColorPickerProps = ComponentProps<typeof ColorPicker>;
type PickedPropsFromColorPicker = Pick<ColorPickerProps, 'palette' | 'swatchSize'>;
type InputTextProps = ComponentProps<typeof InputText>;
type PickedPropsFromInputText = Pick<InputTextProps, 'aria-describedby' | 'assistiveText' | 'autoComplete' | 'columnSpan' | 'hasClearIcon' | 'helpSourceLink' | 'helpSourceText' | 'isDisabled' | 'isReadonly' | 'isRequired' | 'isRequiredShown' | 'label' | 'labelEdge' | 'labelStartWidth' | 'messages' | 'placeholder' | 'textAlign' | 'userAssistanceDensity' | 'variant'>;
export type InputColorPublicProps = TestIdProps & PickedPropsFromInputText & PickedPropsFromColorPicker & {
    /**
     * The current display value of the component.
     */
    value?: ColorValue;
    /**
     * Callback invoked when the user commits the entered value by blurring or hitting the enter key.
     * It is also called when a selection is made in the color palette.
     */
    onCommit?: (detail: ValueUpdateDetail<ColorValue>) => void;
    /**
     * Callback invoked each time the user changes the value. For example, if the user
     * types '#ff' this callback will be called thrice to change the color first to "#"
     * then to '#f' and then '#ff'.
     */
    onInput: (detail: ValueUpdateDetail<ColorValue>) => void;
};
export {};

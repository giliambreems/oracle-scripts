/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { RefObject } from 'preact';
/**
 * Return the dataset info of target element.
 * @param target
 * @param rootRef
 * @returns
 */
export declare function getElementData(rootRef: RefObject<Element>, target: HTMLElement): DOMStringMap | null;
/**
 * Returns the group or item info.
 * @param rootRef
 * @param event
 * @returns
 */
export declare function getInfo(rootRef: RefObject<HTMLElement>, target: HTMLElement): {
    groupIndex: number | undefined;
    seriesIndex: number | undefined;
    itemIndex: number | undefined;
    levelIndex: number | undefined;
    refObjId: string | undefined;
} | undefined;
/**
 * Prevent defaults and stops propagation of event.
 * @param event
 */
export declare function cancelEvent(event: Event): void;
/**
 * Compares if two sets are equal.
 */
export declare const isEqual: <T>(setA: Set<T>, setB: Set<T>) => boolean;

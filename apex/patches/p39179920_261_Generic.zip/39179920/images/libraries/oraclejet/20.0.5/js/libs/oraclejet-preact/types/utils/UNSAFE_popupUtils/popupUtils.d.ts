export declare const isLogicalAncestor: (ancestorNode: Node, node: Node) => boolean;

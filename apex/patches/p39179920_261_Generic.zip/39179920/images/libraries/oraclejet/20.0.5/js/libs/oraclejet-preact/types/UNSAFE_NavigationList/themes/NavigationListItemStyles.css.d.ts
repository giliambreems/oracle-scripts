import { ComponentThemeType, CompoundVariantStyles, VariantOptions } from '../../UNSAFE_Theme';
type NavigationListItemVariant = typeof variants;
type NavigationListItemVariantOptions = VariantOptions<NavigationListItemVariant>;
type NavigationListItemStyles = typeof styles;
type NavigationListItemTheme = ComponentThemeType<NavigationListItemVariant, NavigationListItemStyles>;
declare const baseStyle: string;
declare const styles: {
    labelContainerClasses: string;
    iconContainer: string;
    iconLabelContainer: string;
    startIconPadding: string;
    startIconStacked: string;
    endContentPadding: string;
    removeIconPaddingWithEndContent: string;
    navigationItemStackedBadge: string;
    navigationItemStackedBadgeRtl: string;
    navigationItemMetadata: string;
    navigationlistRemoveIcon: string;
    navigationListItemLink: string;
};
declare const variants: {
    readonly focusRing: {
        readonly isFocusRing: "";
        readonly notFocusRing: "";
    };
    readonly current: {
        readonly isCurrent: "";
        readonly notCurrtent: "";
    };
    readonly selected: {
        readonly isSelected: "";
        readonly notSelected: "";
    };
    readonly hybridHover: {
        readonly isHybridHover: "";
        readonly notHybridHover: "";
    };
    readonly pseudoHover: {
        readonly isPseudoHover: "";
        readonly notPseudoHover: "";
    };
    readonly active: {
        readonly isActive: "";
        readonly notActive: "";
    };
    readonly direction: {
        readonly isRtl: "";
        readonly notRtl: "";
    };
    readonly edgeEnd: {
        readonly isEnd: "";
        readonly notEnd: "";
    };
    readonly iconOnly: {
        readonly isIconOnly: string;
        readonly notIconOnly: "";
    };
};
declare const compoundVariants: CompoundVariantStyles<NavigationListItemVariantOptions>;
export type { NavigationListItemVariantOptions, NavigationListItemStyles, NavigationListItemTheme };
export { variants, compoundVariants, baseStyle, styles };

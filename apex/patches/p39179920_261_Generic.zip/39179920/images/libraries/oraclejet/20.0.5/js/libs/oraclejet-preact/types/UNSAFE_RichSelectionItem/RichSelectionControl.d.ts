import type { RefObject } from 'preact';
/**
 * Selective Element Props Type.
 */
type RichSelectionControlProps = {
    ariaLabel?: string;
    value: string | number;
    inputRef?: RefObject<HTMLInputElement>;
    inputReadonlyRef?: RefObject<HTMLInputElement>;
    isFocus?: boolean;
    isLayoutXL?: boolean;
    isDisabled?: boolean;
    isReadonly?: boolean;
    isSelected?: boolean;
    describedBy?: string;
    labelledBy: string;
    onBlur?: (event: FocusEvent) => void;
    onFocus?: (event: FocusEvent) => void;
};
export declare const RadioControl: ({ ariaLabel, value, inputRef, isFocus, isDisabled, isLayoutXL, isReadonly, isSelected, describedBy, labelledBy, onBlur, onFocus }: RichSelectionControlProps) => import("preact").JSX.Element;
export declare const CheckboxControl: ({ ariaLabel, value, inputRef, inputReadonlyRef, isSelected, isLayoutXL, isDisabled, isReadonly, describedBy, labelledBy, onBlur, onFocus }: RichSelectionControlProps) => import("preact").JSX.Element;
export {};

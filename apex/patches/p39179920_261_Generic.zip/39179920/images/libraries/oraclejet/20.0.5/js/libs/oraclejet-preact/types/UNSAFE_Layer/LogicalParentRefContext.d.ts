/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { UnsafeDomHandle } from "../utils/UNSAFE_unsafeDomAccess";
import { type RefObject } from 'preact';
/**
 * Ref to the logical parent element for layered content.
 * Defaults to undefined when no provider is present.
 */
export type LogicalParentRef = RefObject<Element> | RefObject<UnsafeDomHandle<Element>> | undefined;
export declare const LogicalParentRefContext: import("preact").Context<LogicalParentRef>;

import { Property } from 'csstype';
type Props = {
    color?: Property.Color;
    backgroundColor?: Property.BackgroundColor;
};
declare const colorInterpolations: {
    color: ({ color }: Pick<Props, "color">) => {
        color?: undefined;
    } | {
        color: string;
    };
    backgroundColor: ({ backgroundColor }: Pick<Props, "backgroundColor">) => {
        backgroundColor?: undefined;
    } | {
        backgroundColor: string;
    };
};
export { colorInterpolations };
export type ColorProps = Props;

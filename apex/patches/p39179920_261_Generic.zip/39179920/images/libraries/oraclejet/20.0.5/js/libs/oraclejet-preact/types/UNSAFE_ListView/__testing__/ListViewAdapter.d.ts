import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class ListViewAdapter extends TestAdapter {
    /**
     * Toggles the selection state of an item.
     * @param key The key of the item to select or de-select in the ListView
     * @returns Promise<void> or throw error if the key is not found
     */
    doToggleSelection<K extends string | number>(key: K): Promise<void>;
    /**
     * Simulates scroll down to trigger fetching of more data
     * Test author would use this to ensure the item is available before performing operations such as select or reorder on it.
     * @returns Promise<void>
     */
    doLoadMore(): Promise<void>;
    /**
     * Reorder an item in the ListView
     * @param key The key of the item to reorder in the ListView
     * @param position The drop position relative to the zero-based reference index or key of the item to move in front of, if the referenceKey is null, the item will move to the end of the list
     * @returns Promise<void> or throw error if the key is not found or the position is invalid
     */
    doReorder<K extends string | number>(key: K, position: {
        index: number;
    } | {
        referenceKey: K | null;
    }): Promise<void>;
    /**
     * Perform the context menu action for an item in the ListView
     * @param key The key to the item to perform the context menu action on.
     * @param path The path that consist of the label/key of the menu item and the label/key of the submenu that leads to the menu item.
     * @returns Promise<void> or throw error if the key is not found or the path is invalid
     */
    doContextMenuAction<K extends string | number>(key: K, path: {
        menuItemLabel: string | string[];
        menuItemKey?: never;
    } | {
        menuItemKey: string | string[];
        menuItemLabel?: never;
    }): Promise<void>;
    /**
     * Perform the context menu group action for an item in the ListView
     * @param key The key to the item to perform the context menu action on.
     * @param path The path that consist of the label/key of the menu item and the label/key of the submenu that leads to the menu item. If key is specified it also include item value of the select menu item that is going to be clicked.
     * @returns Promise<void> or throw error if the key is not found or the path is invalid
     */
    doContextMenuGroupAction<K extends string | number>(key: K, path: {
        menuItemLabel: string | string[];
        menuItemKey?: never;
        menuItemValue?: never;
    } | {
        menuItemKey: string | string[];
        menuItemValue?: string;
        menuItemLabel?: never;
    }): Promise<void>;
}

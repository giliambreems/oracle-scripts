import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class InputSensitiveTextAdapter extends TestAdapter {
    /**
     * Clear and commit the value of the input element
     * @returns Promise<void>
     */
    clear(): Promise<void>;
    /**
     * Change and commit the value of the input element
     * @param value {string | undefined} The new value
     * @returns Promise<void>
     */
    changeValue(value: string | undefined): Promise<void>;
}

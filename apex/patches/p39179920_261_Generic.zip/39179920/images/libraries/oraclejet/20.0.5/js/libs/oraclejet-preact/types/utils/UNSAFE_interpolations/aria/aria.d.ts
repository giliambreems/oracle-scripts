export type AriaProps = {
    'aria-label'?: string;
    'aria-labelledby'?: string;
};
declare const ariaInterpolations: {
    ariaLabel: ({ "aria-label": ariaLabel }: Pick<AriaProps, "aria-label">) => {
        ariaLabel?: undefined;
    } | {
        ariaLabel: string;
    };
    ariaLabelledBy: ({ "aria-labelledby": ariaLabelledBy }: Pick<AriaProps, "aria-labelledby">) => {
        ariaLabelledBy?: undefined;
    } | {
        ariaLabelledBy: string;
    };
};
export { ariaInterpolations };

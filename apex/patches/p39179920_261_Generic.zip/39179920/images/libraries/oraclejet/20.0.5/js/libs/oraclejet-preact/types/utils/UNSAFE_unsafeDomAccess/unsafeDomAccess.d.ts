/**
 * Instead of forwarding refs to DOM elements, the JET Preact components
 * leverage imperative handles to limit DOM access via refs.  For example,
 * rather than resolving to an actual HTML button element, a ref that is passed
 * into the JET Preact Button component will resolve to an imperative handle
 * that exposes just the focus, blur and click methods.
 *
 * By using imperative handles to abstract away from the DOM, we limit the
 * ability for JET Preact consumers to build brittle components/applications
 * that are dependent on JET Preact component's internal DOM implementation
 * details.
 *
 * While the abstractions that we expose via our imperative handles should
 * be sufficient for almost all use cases, there are some exceptional cases
 * where it may be necessary to access an underlying DOM element.  One example
 * where this can be necessary is when anchoring/positioning one component
 * relative to another, as is often the case when implementing popop/floating
 * content.
 *
 * To meet the needs of such exceptional cases, some JET Preact components
 * expose access to their root DOM elements via the UNSAFE_DOM_ACCESS symbol-based
 * key on the imperative handle.  This symbol can be used to retrieve component's
 * root DOM element.
 *
 * Note that this type of DOM access is considered to be unsafe as JET Preact makes
 * no guarantees about the structure of this DOM.  The DOM element type and structure
 * is an implementation detail of the component and can change at any point,
 * including in patch releases.  If consuming code contains assumptions about the
 * the type or structure of this DOM, this code should be considered brittle and
 * at risk of breaking.
 *
 * As such, unsafe DOM access should be use very sparingly, if at all.
 */
export declare const UNSAFE_DOM_ACCESS: unique symbol;
/**
 * Utility type for imperative handles that provide access to an underlying
 * DOM element via the UNSAFE_DOM_ACCESS field.
 */
export type UnsafeDomHandle<E extends Element = HTMLElement> = {
    [UNSAFE_DOM_ACCESS]: E;
};

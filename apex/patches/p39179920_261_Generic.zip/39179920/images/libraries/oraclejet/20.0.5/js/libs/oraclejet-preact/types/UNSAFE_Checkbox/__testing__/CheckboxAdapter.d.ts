import { TestAdapter } from '@oracle/oraclejet-testing/UNSAFE_TestAdapter';
export declare class CheckboxAdapter extends TestAdapter {
    /**
     * Change the value of the component.
     * @param value {boolean | undefined} The new value.
     * @returns Promise<void>
     */
    changeValue(value: boolean | undefined): Promise<void>;
    /**
     * Clear the value of the component.
     * @returns Promise<void>
     */
    clear(): Promise<void>;
}

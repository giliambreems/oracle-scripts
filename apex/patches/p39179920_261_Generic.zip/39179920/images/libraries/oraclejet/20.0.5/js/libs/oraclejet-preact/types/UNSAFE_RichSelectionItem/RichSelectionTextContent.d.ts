type RichSelectionTextContentProps = {
    secondaryTextId?: string;
    label?: string;
    secondaryText?: string;
    isDisabled?: boolean;
    isLayoutXL?: boolean;
    labelId: string;
};
export declare const RichSelectionTextContent: ({ secondaryTextId, isDisabled, isLayoutXL, label, labelId, secondaryText }: RichSelectionTextContentProps) => import("preact").JSX.Element;
export {};

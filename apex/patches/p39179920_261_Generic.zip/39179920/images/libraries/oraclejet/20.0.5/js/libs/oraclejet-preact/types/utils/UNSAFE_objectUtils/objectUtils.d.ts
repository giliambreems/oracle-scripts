import type { Obj } from "../../PRIVATE_oraclejet-internal-utilities/typeUtils";
export declare const isObj: (v: unknown) => v is Obj;

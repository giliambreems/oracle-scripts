/**
 * @license
 * Copyright (c) 2019 %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { Range } from "../../PRIVATE_oraclejet-internal-utilities/typeUtils";
export type Hour = Range<0, 24>;
export type Minute = Range<0, 60>;
export type Second = Range<0, 60>;
export type Millisecond = number;
export type Time = {
    hour?: Hour;
    minute?: Minute;
    second?: Second;
    millisecond?: Millisecond;
};
type TimeIsoBase = {
    hour: Hour;
    minute: Minute;
};
type TimeWithoutMilliseconds = TimeIsoBase & {
    second?: Second;
    millisecond?: never;
};
type TimeWithMillisecond = TimeIsoBase & {
    second: Second;
    millisecond: Millisecond;
};
export type TimeWithValidIsoStrParts = TimeWithoutMilliseconds | TimeWithMillisecond;
type TimeSegmentType = 'hour' | 'minute' | 'second' | 'millisecond' | 'dayPeriod' | 'literal';
type TimePlaceholder<T extends TimeSegmentType, V extends string> = {
    type: T;
    value: V;
};
export type HourPlaceholder = TimePlaceholder<'hour', 'hh'>;
export type MinutePlaceholder = TimePlaceholder<'minute', 'mm'>;
export type SecondPlaceholder = TimePlaceholder<'second', 'ss'>;
export type MillisecondPlaceholder = TimePlaceholder<'millisecond', 'sss'>;
export type DayPeriodPlaceholder = TimePlaceholder<'dayPeriod', 'am/pm'>;
export type SeparatorPlaceholder = TimePlaceholder<'literal', string>;
export type SpacePlaceholder = TimePlaceholder<'literal', string>;
type BaseTimePlaceholders = [HourPlaceholder, SeparatorPlaceholder, MinutePlaceholder];
type OptionalTimePlaceholders = [] | [SeparatorPlaceholder, SecondPlaceholder] | [SeparatorPlaceholder, SecondPlaceholder, SeparatorPlaceholder, MillisecondPlaceholder];
type BaseAndOptionalTimePlaceholders = [...BaseTimePlaceholders, ...OptionalTimePlaceholders];
type DayPeriodStart = [DayPeriodPlaceholder, SpacePlaceholder, ...BaseAndOptionalTimePlaceholders] | [DayPeriodPlaceholder, ...BaseAndOptionalTimePlaceholders];
type DayPeriodEnd = [...BaseAndOptionalTimePlaceholders, SpacePlaceholder, DayPeriodPlaceholder] | [...BaseAndOptionalTimePlaceholders, DayPeriodPlaceholder];
export type TimePlaceholders = BaseAndOptionalTimePlaceholders | DayPeriodStart | DayPeriodEnd;
export type TimeGranularity = 'minute' | 'second' | 'millisecond';
export type FilteredDateTimeFormatPart = {
    type: 'hour';
    value: string;
} | {
    type: 'minute';
    value: string;
} | {
    type: 'second';
    value: string;
} | {
    type: 'fractionalSecond';
    value: string;
} | {
    type: 'dayPeriod';
    value: string;
} | {
    type: 'literal';
    value: string;
};
export type AmPmLocalizedValues = {
    am: string;
    pm: string;
};
export {};

import library from '@oracle/oraclejet-config-eslint/library';
import nodeLibrary from '@oracle/oraclejet-config-eslint/node-library';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  {
    ignores: ['test_results/', 'test/built/']
  },
  {
    files: ['Bundler.js', 'l10nBundleBuilder.js', 'PatternCompiler.js', 'test/cliTest.js'],
    extends: [
      ...nodeLibrary
    ],
    rules: {
      'n/hashbang': 'warn',
      'n/no-process-exit': 'warn'
    }
  },
  {
    files: ["./test/*.ts"],
    extends: [
      ...library,
      tseslint.configs.base,
      ...tseslint.configs.recommended,
    ],
    rules: {
      '@typescript-eslint/no-explicit-any': 'warn',
      '@typescript-eslint/no-require-imports': 'warn',
      '@typescript-eslint/no-unused-vars': 'warn',
      'prefer-rest-params': 'warn',
      'no-empty': 'warn'
    }
  },
);


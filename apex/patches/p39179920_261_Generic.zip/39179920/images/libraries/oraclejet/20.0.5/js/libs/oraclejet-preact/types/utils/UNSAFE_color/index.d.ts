/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
export { parseColorValue, getColorValue, getEightDigitHex, getSixDigitHex, getExpandedColorValue, convertPalette, sortPalette, colorsAreDifferent, isValidColorValue, isEightDigitHex, type ColorValue } from './color';
export { defaultRedwoodPaletteValues, defaultRedwoodNoFillPaletteValues, uniqueColorMap } from './swatchData';

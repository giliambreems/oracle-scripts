export type CommonDndProps<DragStartDetail, DropDetail> = {
    /**
     * An optional callback function that receives the HTML5 'dragStart' event and context information as arguments.
     */
    onDragStart?: (detail: DragStartDetail) => void;
    /**
     * A optional callback function that receives the HTML5 'drag' event as an argument.
     */
    onDrag?: (detail: DragDetail) => void;
    /**
     * A optional callback function that receives the HTML5 'dragEnd' event as an argument.
     */
    onDragEnd?: (detail: DragDetail) => void;
    /**
     * A optional callback function that receives the HTML5 "dragenter" event and context information as arguments.
     * This function should call event.preventDefault() to indicate the dragged data can be accepted.
     */
    onDragEnter?: (detail: DropDetail) => void;
    /**
     * An optional callback function that receives the HTML5 "dragleave" event and context information as arguments.
     */
    onDragLeave?: (detail: DropDetail) => void;
    /**
     * A callback function that receives the HTML5 "dragover" event and context information as arguments.
     * This function should call event.preventDefault() to indicate the dragged data can be accepted.
     */
    onDragOver?: (detail: DropDetail) => void;
    /**
     * A callback function that receives the HTML5 "drop" event and context information as arguments.
     * This function should call event.preventDefault() to indicate the dragged data can be accepted.
     */
    onDrop?: (detail: DropDetail) => void;
};
export type DragDetail = {
    event: DragEvent;
};

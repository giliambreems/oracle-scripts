/*******************
 * Component Style
 *******************/
declare const baseStyle: string;
/*******************
 * Style Variants
 *******************/
/*******************
 * Component Variants
 *******************/
/*******************
 * Exports
 *******************/
export { baseStyle };

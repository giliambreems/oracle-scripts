/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { ComboChartProps, LineAreaItem } from './ComboChart.types';
import { SizeHandle } from "../utils/UNSAFE_visTypes/chart";
import { Ref, VNode } from 'preact';
export type ForwardRefComboChart = <K extends string | number, D extends LineAreaItem<K>>(props: ComboChartProps<K, D> & {
    ref?: Ref<SizeHandle>;
}) => VNode | null;
/**
 * The ComboChart displays information graphically using bars, lines and filled areas, making relationships among the data easier to understand.
 */
export declare const ComboChart: ForwardRefComboChart;

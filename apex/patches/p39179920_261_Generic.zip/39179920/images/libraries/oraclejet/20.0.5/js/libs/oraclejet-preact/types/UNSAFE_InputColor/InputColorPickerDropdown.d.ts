/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { ComponentProps } from 'preact';
import { ColorPicker } from "../UNSAFE_ColorPicker";
import { type CloseDetail as DropdownCloseDetail } from "../UNSAFE_Dropdown";
import { StickyPositioningDropdown } from "../PRIVATE_FormControls";
import { type CloseDetail as SheetCloseDetail } from "../UNSAFE_Sheet";
import type { TestIdProps } from "../hooks/UNSAFE_useTestId";
import { InputColorPublicProps as InputColorProps } from './InputColor.types';
type StickyPositioningDropdownProps = ComponentProps<typeof StickyPositioningDropdown>;
type ColorPickerProps = ComponentProps<typeof ColorPicker>;
type PickedPropsFromColorPicker = Pick<ColorPickerProps, 'value' | 'onCommit'>;
type PickedPropsFromDropdown = Omit<StickyPositioningDropdownProps, 'onClose'>;
type CloseDetail = SheetCloseDetail | DropdownCloseDetail;
type PickedPropsFromInputColor = Pick<InputColorProps, 'swatchSize' | 'palette' | 'value' | 'aria-describedby' | 'assistiveText' | 'columnSpan' | 'helpSourceLink' | 'helpSourceText' | 'isDisabled' | 'isReadonly' | 'isRequired' | 'isRequiredShown' | 'label' | 'labelEdge' | 'labelStartWidth' | 'messages' | 'textAlign' | 'testId' | 'userAssistanceDensity' | 'variant'>;
type Props = PickedPropsFromColorPicker & PickedPropsFromInputColor & PickedPropsFromDropdown & TestIdProps & {
    /**
     * Called when the dropdown or sheet is supposed to be closed.
     */
    onClose?: (detail: CloseDetail) => void;
};
/**
 * Component that renders ColorPicker either inside a dropdown or sheet; in mobile,
 * it renders inside a sheet. Additionally, when a dropdown is being shown beneath
 * the component, we also show any user assistance text or messages below the picker
 * because otherwise that information would be obscured from view. When a sheet is being
 * shown, it will always display UA and messages at the bottom of the sheet.
 */
declare const InputColorPickerDropdown: ({ anchorRef, assistiveText, swatchSize, palette, helpSourceLink, helpSourceText, isDisabled, isOpen, isReadonly, label, onClose, onCommit, messages, testId, userAssistanceDensity, value }: Props) => import("preact").JSX.Element;
export { InputColorPickerDropdown, type CloseDetail };

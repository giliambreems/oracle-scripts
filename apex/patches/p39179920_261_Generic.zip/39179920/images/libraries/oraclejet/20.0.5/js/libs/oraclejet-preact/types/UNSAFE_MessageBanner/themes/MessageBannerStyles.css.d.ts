import { ComponentThemeType, VariantOptions } from "../../UNSAFE_Theme";
import { messageBannerVars } from './MessageBannerContract.css';
type MessageBannerVariants = typeof variants;
type MessageBannerVariantOptions = VariantOptions<MessageBannerVariants>;
type MessageBannerStyles = typeof styles;
type MessageBannerTheme = ComponentThemeType<MessageBannerVariants, MessageBannerStyles>;
/*******************
 * Component Variants
 *******************/
declare const variants: {
    severity: {
        error: {
            vars: {
                [messageBannerVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                [messageBannerVars.startIconColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                [messageBannerVars.summaryTextColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        warning: {
            vars: {
                [messageBannerVars.backgroundColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                [messageBannerVars.startIconColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
                [messageBannerVars.summaryTextColor]: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
            };
        };
        confirmation: string;
        info: string;
        none: string;
    };
};
declare const styles: {};
export type { MessageBannerVariantOptions, MessageBannerTheme, MessageBannerStyles };
export { variants };

/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { ReferenceObjectData } from './refObj.types';
import { ColorProps } from "../../UNSAFE_interpolations/colors";
import { VisTextStyle } from '../common';
export type AxisPosition = 'left' | 'right' | 'top' | 'bottom';
export type Group = {
    /**
     * Whether drilling is enabled in the group label.
     */
    drilling?: 'on' | 'off' | 'inherit';
    /**
     * The id of the group.
     */
    id: string;
    /**
     * The name of the group.
     */
    name?: string;
    /**
     * The description of the group. This is used for the customizing the tooltip text and only applies to a categorical axis.
     */
    accessibleLabel?: string;
    /**
     * An array of sub groups belonging to this group.
     */
    groups?: Group[];
};
export type FormatFunction = (value: number) => string;
export type TickLabel = {
    /**
     * The function called to get the formatted value of the label.
     */
    format?: FormatFunction;
    /**
     * Whether the ticklabels are rendered or not.
     */
    isRendered?: boolean;
    /**
     * The style for the tick labels.
     */
    style?: VisTextStyle;
    /**
     * Defines whether the chart will automatically rotate the labels by 90 degrees in order to fit more labels on the axis.
     * The rotation will only be applied to categorical labels for a horizontal axis.
     */
    autoRotate?: boolean;
};
export type DataAxisInfoProps = {
    /**
     * The maximum data value corresponding to an axis. If specified, the automatic axis extent calculation will use this value.
     */
    dataMax?: number;
    /**
     * The maximum data value corresponding to an axis. If specified, the automatic axis extent calculation will use this value.
     */
    dataMin?: number;
    /**
     * The minimum increment between major tick marks. This is typically used to prevent fractional axis values for discrete measures. Only applies to numerical axes.
     */
    minStep?: number;
    /**
     * The increment between minor tick marks. Defaults to null for automatic calculation based on the data.
     * For log axis, the step is a multiplier, so for example, if the minorStep is 2, the minor tick marks will be rendered at 1, 2, 4, 8, and so on.
     */
    minorStep?: number;
    /**
     * The minimum value of the axis.
     */
    min?: number;
    /**
     * The maximum value of the axis.
     */
    max?: number;
    /**
     * The step between each tick labels.
     */
    step?: number;
    /**
     * Defines the axis scale.
     */
    scale?: 'log' | 'linear';
    /**
     * The minimum value of the current axis viewport.
     */
    viewportMin?: number;
    /**
     * The maximum value of the current axis viewport.
     */
    viewportMax?: number;
    /**
     * Defines whether the axis baseline starts at the minimum value of the data or at zero.
     */
    baselineScaling?: 'zero' | 'min';
    /**
     * The reference objects for the axis.
     */
    referenceObjects?: ReferenceObjectData[];
};
export type DataAxisProps = DataAxisInfoProps & {
    /**
     * The axis title.
     */
    title?: string;
    /**
     * The axis title style.
     */
    titleStyle?: VisTextStyle;
    /**
     * The ticklabel options for the axis.
     */
    tickLabel?: TickLabel;
    /**
     * The position of the data axis. Horizontal chart supports top and bottom
     * while vertical chart only support start and end data axis position.
     */
    position?: 'start' | 'end' | 'top' | 'bottom';
    /**
     * Specifies the size of the axis as a ratio from 0 to 1, based on the width (for horizontal) or height (for vertical) of the chart.
     * This value determines the proportion of space allocated to the axis. The chart will arrange axis elements within this space.
     * If all elements cannot fit, some may be omitted. When the axis title and tick labels do not fit within the available space,
     * the tick labels will be dropped first, followed by the axis title.
     */
    size?: number;
    /**
     * Specifies the maximum size of the axis as a ratio from 0 to 1: axis width divided by chart width (for horizontal axes) or axis height divided by chart height (for vertical axes).
     * When the axis title and tick labels do not fit within the available space, the tick labels will be dropped first, followed by the axis title.
     */
    maxSize?: number;
    /**
     * Whether the axis is rendered or not.
     */
    isRendered?: boolean;
};
export type XAxisInfoProps = {
    /**
     * The axis title.
     */
    title?: string;
    /**
     * The axis title style.
     */
    titleStyle?: VisTextStyle;
    /**
     * The options to specify, format and style the x axis labels.
     */
    tickLabel?: Omit<TickLabel, 'format'>;
    /**
     * The axis groups.
     */
    groups: Group[];
    /**
     * The viewportStartGroup.
     */
    viewportStartGroup?: string;
    /**
     * The viewport end group.
     */
    viewportEndGroup?: string;
    /**
     * The step of the time axis.
     */
    step?: number;
    /**
     * The start and end offset of the axis.
     */
    offset: number;
    /**
     * Specifies the size of the axis as a ratio from 0 to 1, based on the width (for horizontal) or height (for vertical) of the chart.
     * This value determines the proportion of space allocated to the axis. The chart will arrange axis elements within this space.
     * If all elements cannot fit, some may be omitted. When the axis title and tick labels do not fit within the available space,
     * the inner-level tick labels will be dropped first, followed by the axis title.
     */
    size?: number;
    /**
     * Specifies the maximum size of the axis as a ratio from 0 to 1: axis width divided by chart width (for horizontal axes) or axis height divided by chart height (for vertical axes).
     * When the axis title and tick labels do not fit within the available space, the inner-level tick labels will be dropped first, followed by the axis title.
     */
    maxSize?: number;
    /**
     * Whether the axis is rendered or not.
     */
    isRendered?: boolean;
};
export type GroupAxisProps = Omit<XAxisInfoProps, 'groups' | 'offset'> & {
    /**
     * The viewport min. The group index will be treated as the axis coordinate.
     */
    viewportMin?: number;
    /**
     * The viewport min. The group index will be treated as the axis coordinate.
     */
    viewportMax?: number;
    /**
     * Specifies the presence and color of the group separator lines in hierarchical axis.
     */
    groupSeparators?: GroupSeparatorsConfig;
    /**
     * The reference objects for the axis.
     */
    referenceObjects?: ReferenceObjectData[];
};
/**
 * Configuration options for rendering group separator lines in a hierarchical axis.
 */
export type GroupSeparatorsConfig = {
    /**
     * Whether the group separator lines are rendered.
     */
    isRendered?: boolean;
    /**
     * The color of the group separator lines.
     */
    color?: ColorProps['color'];
};
export type TimeAxisProps = Omit<XAxisInfoProps, 'groups' | 'offset'> & {
    /**
     * The viewport min. The string should be in ISO time string format.
     */
    viewportMin?: string;
    /**
     * The viewport min. The string should be in ISO time string format.
     */
    viewportMax?: string;
    /**
     * The time axis type.
     */
    timeAxisType?: 'enabled' | 'mixedFrequency' | 'skipGaps';
    /**
     * The options to specify, format and style the x axis time labels.
     */
    tickLabel?: TimeAxisTickLabel;
    /**
     * The reference objects for the axis.
     */
    referenceObjects?: ReferenceObjectData[];
};
type TimeAxisTickLabel = {
    /**
     * A function or an array of two format functions used to format the time axis label.
     * If an array of two format functions is provided, the functions are applied respectively to the first and second level labels of time axis.
     */
    format?: FormatFunction | [FormatFunction, FormatFunction];
    /**
     * Whether the ticklabels are rendered or not.
     */
    isRendered?: boolean;
    /**
     * The style for the tick labels.
     */
    style?: VisTextStyle;
};
export type ViewportDetail = {
    /**
     * The viewport min of the x axis.
     */
    xMin?: number;
    /**
     * The viewport max of the x axis.
     */
    xMax?: number;
    /**
     * The viewport min of the y axis.
     */
    yMin?: number;
    /**
     * The viewport max of the y axis.
     */
    yMax?: number;
    /**
     * The viewport min of the y2 axis.
     */
    y2Min?: number;
    /**
     * The viewport max of the y2 axis.
     */
    y2Max?: number;
};
export {};

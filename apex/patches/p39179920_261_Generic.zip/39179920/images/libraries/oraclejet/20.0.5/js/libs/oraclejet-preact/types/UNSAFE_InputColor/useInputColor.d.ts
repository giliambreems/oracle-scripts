/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { RefObject } from 'preact';
import { type ColorValue } from "../utils/UNSAFE_color";
import { CloseDetail } from './InputColorPickerDropdown';
import type { ValueUpdateDetail } from "../utils/UNSAFE_valueUpdateDetail";
import { InputColorPublicProps as InputColorProps } from './InputColor.types';
type Props = {
    onCommit: InputColorProps['onCommit'];
    onInput: InputColorProps['onInput'];
    value: InputColorProps['value'];
};
/**
 * Hook that provides handlers and other functionality for InputColor.
 */
declare const useInputColor: ({ onCommit, onInput, value: currentValue }: Props) => {
    colorIconActionHandler: (details: import("../hooks/UNSAFE_useToggleAction").ToggleDetail) => void;
    colorPickerCommitHandler: (detail: ValueUpdateDetail<ColorValue>) => void;
    dropdownCloseHandler: (detail: CloseDetail) => void;
    containerDropdownProps: Record<string, any>;
    colorValue: ColorValue | undefined;
    iconRef: RefObject<{
        focus: () => void;
        blur: () => void;
        click: () => void;
    } & import("../utils/UNSAFE_unsafeDomAccess").UnsafeDomHandle>;
    isOpen: boolean;
    colorCommitHandler: (detail: ValueUpdateDetail<ColorValue>) => void;
    colorInputHandler: (detail: ValueUpdateDetail<ColorValue>) => void;
    colorRef: RefObject<HTMLInputElement>;
};
export { useInputColor };

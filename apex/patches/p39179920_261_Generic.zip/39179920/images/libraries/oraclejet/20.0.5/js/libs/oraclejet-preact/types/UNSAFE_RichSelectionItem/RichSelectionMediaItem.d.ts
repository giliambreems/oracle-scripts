import { RichSelectionMediaItemProps } from './RichSelectionTypes';
type DisabledType = {
    isDisabled?: boolean;
};
export declare const RichSelectionMediaItem: ({ avatar, iconClass, isDisabled, hasSecondaryText, mediaAccessibleLabel, layout, thumbnailSrc, testId }: RichSelectionMediaItemProps & DisabledType) => import("preact").JSX.Element | null;
export {};

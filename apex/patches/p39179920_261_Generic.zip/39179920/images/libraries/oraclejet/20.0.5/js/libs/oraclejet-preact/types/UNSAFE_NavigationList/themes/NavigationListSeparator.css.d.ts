declare const styles: {
    separator: string;
};
export { styles };

import type { TestDriver, TestElement } from '@oracle/oraclejet-testing/UNSAFE_Driver';
import type { ElementLocator } from '@oracle/oraclejet-testing/UNSAFE_Locators';
import { MessageBannerAdapter } from './MessageBannerAdapter';
/**
 * Get the test adapter for the Preact MessageBanner, identified by the given locator.
 * If a driverOrElement is given, the locator will be searched from there.
 * @param locator The ElementLocator used to search for the MessageBanner
 * @param driverOrElement The optional TestDriver or TestElement from which to search. If
 * TestElement is given, locator will search underneath that element. If TestDriver is given
 * or the parameter is undefined, the DOM is searched globally.
 * @returns The test adapter for MessageBanner
 */
export declare function findMessageBanner(locator: ElementLocator, driverOrElement?: TestDriver | TestElement): MessageBannerAdapter;

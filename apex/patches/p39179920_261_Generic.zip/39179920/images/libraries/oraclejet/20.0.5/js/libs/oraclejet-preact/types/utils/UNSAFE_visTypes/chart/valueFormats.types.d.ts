/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
export type TextValueFormat = {
    /**
     * Whether the string is displayed in the tooltip.
     */
    isDisplayed?: boolean;
    /**
     * A string representing the label that is displayed before the value in the tooltip.
     */
    label?: string;
};
export type GroupValueFormat = {
    /**
     * Whether the string is displayed in the tooltip.
     */
    isDisplayed?: boolean;
    /**
     * A string representing the label that is displayed before the value in the tooltip.
     * This value can also take an array of strings to be applied to hierarchical group names, from outermost to innermost.
     */
    label?: string | string[];
};
export type NumericalValueFormat = {
    /**
     * Whether the value is displayed in the tooltip.
     */
    isDisplayed?: boolean;
    /**
     * A string representing the label that is displayed before the value in the tooltip.
     */
    label?: string;
    /**
     * The function called to get the formatted value.
     */
    format?: (value: number) => string;
};
export type ValueFormats = {
    /**
     * Object that specifies the value formatting and tooltip behavior for the group.
     */
    group?: GroupValueFormat;
    /**
     * Object that specifies the tooltip behavior for the series.
     */
    series?: TextValueFormat;
    /**
     * Object that specifies the tooltip behavior for the data item labels.
     */
    label?: TextValueFormat;
    /**
     * Object that specifies the value formatting and tooltip behavior for the item value.
     */
    value?: NumericalValueFormat;
    /**
     * Object that specifies the value formatting and tooltip behavior for the item x.
     */
    x?: NumericalValueFormat;
    /**
     * Object that specifies the value formatting and tooltip behavior for the item y.
     */
    y?: NumericalValueFormat;
    /**
     * Object that specifies the value formatting and tooltip behavior for the item widthWeight.
     */
    widthWeight?: NumericalValueFormat;
    /**
     * Object that specifies the value formatting and tooltip behavior for the item y2.
     */
    y2?: NumericalValueFormat;
};

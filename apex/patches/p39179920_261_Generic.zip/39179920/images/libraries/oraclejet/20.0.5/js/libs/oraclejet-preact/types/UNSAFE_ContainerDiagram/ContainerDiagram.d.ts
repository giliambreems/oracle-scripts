/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { ContainerDiagramProps } from './diagram.types';
import { DiagramLayoutOutput, DiagramLinkData, DiagramNodeData } from "../PRIVATE_BaseDiagram/diagram.types";
/**
 * Container Diagrams are used to display a set of nested nodes and the links between them.
 */
export declare function ContainerDiagram<K1 extends string | number, K2 extends string | number, D1 extends DiagramNodeData<K1, D1>, D2 extends DiagramLinkData<K2, K1>, L extends DiagramLayoutOutput<K1, K2>>(props: ContainerDiagramProps<K1, K2, D1, D2, L>): import("preact").JSX.Element;

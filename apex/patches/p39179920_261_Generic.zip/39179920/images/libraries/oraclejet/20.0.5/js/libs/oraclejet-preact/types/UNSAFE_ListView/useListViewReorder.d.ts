import type { RefObject } from 'preact';
import { ViewportConfig } from '../hooks/UNSAFE_useViewportIntersect';
import { ListProps } from './List.types';
type useListViewReorderProps<K, D> = Pick<ListProps<K, D>, 'onReorder'> & {
    rootRef: RefObject<HTMLDivElement>;
    viewportConfig?: ViewportConfig;
};
export declare const useListViewReorder: <K extends string | number, D>({ onReorder, rootRef, viewportConfig }: useListViewReorderProps<K, D>) => {
    readonly reorderProps: {
        onKeyDown?: undefined;
    } | {
        onKeyDown: (e: KeyboardEvent) => void;
    };
    readonly reorderContext: {
        readonly currentItemKey: import("preact/hooks").MutableRef<K | undefined>;
    };
    readonly reorderInstructionsId: string;
    readonly reorderInstructions: string;
    readonly reorderItemProps?: undefined;
} | {
    readonly reorderProps: {
        onKeyDown: (event: KeyboardEvent) => void;
        onDragOver: (event: DragEvent) => void;
    };
    readonly reorderItemProps: {
        dragKey: K | undefined;
        setDragKey: import("preact/hooks").Dispatch<import("preact/hooks").StateUpdater<K | undefined>>;
        onReorder: ((detail: import("../UNSAFE_Collection").ReorderDetail<K>) => void) | undefined;
        rootRef: RefObject<HTMLDivElement>;
    };
    readonly reorderContext: {
        readonly currentItemKey: import("preact/hooks").MutableRef<K | undefined>;
    };
    readonly reorderInstructionsId: string;
    readonly reorderInstructions: string;
};
export {};

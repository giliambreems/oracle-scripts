import { DataType } from 'csstype';
export type ColorValueHex = `#${string}`;
export type ColorValue = DataType.NamedColor | ColorValueHex | 'TRANSPARENT';
/**
 * Parse a color value and return a hex string or 'TRANSPARENT'.
 * ie, 'blue' => '#0000FF'
 * If not valid keyword, returns ''
 * @param value
 * @returns
 */
export declare function parseColorValue(value?: string): string;
/** Get the ColorValue from a string
 */
export declare function getColorValue(value?: string): ColorValue;
/**
 * Can convert array to all hex values and 'transparent'
 * as desired.
 * @param palette
 * @returns
 */
export declare function convertPalette(palette: Array<ColorValue>): Array<ColorValue>;
/**
 * More 'transparent' to first position
 * @param palette
 * @returns
 */
export declare function sortPalette(palette: Array<ColorValue>): Array<ColorValue>;
/**
 * Return true if the color params represent 2 different colors.
 */
export declare const colorsAreDifferent: (c1: ColorValue | undefined, c2: ColorValue | undefined, isExpandable?: boolean) => boolean;
/**
 * Return true if the color value is a valid hex color or 'TRANSPARENT'
 * Valid values to type include
 * - '#xxxxxx'
 * - '#xxxxxxxx'
 * - 'TRANSPARENT'
 * - 'transparent'
 * - named color (e.g. 'blue', 'red', etc.)
 * @param value
 * @returns
 */
export declare const isValidColorValue: (value: string) => boolean;
/**
 * Convert a color value to an 8 digit hex value.
 * If the value is a valid hex color, it will return the value with an alpha channel of 'FF'.
 * If the value is not valid, it will return an empty string.
 * @param value
 * @returns
 */
export declare const getEightDigitHex: (value: ColorValue) => ColorValue;
/**
 * Convert a color value to an 6 digit hex value.
 * If any other alpha, return empty string.
 * @param value
 * @returns
 */
export declare const getSixDigitHex: (value: ColorValue) => ColorValue;
/**
 * Returns true if value is an 8 digit hex value
 * @param value
 * @returns
 */
export declare const isEightDigitHex: (value: ColorValue) => boolean;
/**
 * Returns the intended color value for a partially specified color value.
 * Can request 8 or 6 digit hex rgb return values.  Note that 'transparent' is
 * always returned unconverted as it is a valid css value and requested to stay
 * untouched for ux reasons.  Finds first valid hex substring and applies
 * heuristics.
 *
 * Returns '' if the value is not valid.
 * @param value
 * @returns
 */
export declare const getExpandedColorValue: (value?: string | ColorValue, hasEightDigitHex?: boolean) => ColorValue;

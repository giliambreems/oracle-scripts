/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
export type Dimension = {
    x: number;
    width: number;
    y: number;
    height: number;
};
export type CommonLineType = 'straight' | 'curved' | 'stepped' | 'segmented' | 'none';
export type AllLineType = 'straight' | 'curved' | 'stepped' | 'centeredStepped' | 'segmented' | 'centeredSegmented' | 'none';

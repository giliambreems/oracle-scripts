declare const multiVariantStyles: import("@vanilla-extract/recipes").RuntimeFn<{
    readonly focusRing: {
        readonly isFocusRing: "";
        readonly notFocusRing: "";
    };
    readonly current: {
        readonly isCurrent: "";
        readonly notCurrtent: "";
    };
    readonly selected: {
        readonly isSelected: "";
        readonly notSelected: "";
    };
    readonly hybridHover: {
        readonly isHybridHover: "";
        readonly notHybridHover: "";
    };
    readonly pseudoHover: {
        readonly isPseudoHover: "";
        readonly notPseudoHover: "";
    };
    readonly active: {
        readonly isActive: "";
        readonly notActive: "";
    };
    readonly direction: {
        readonly isRtl: "";
        readonly notRtl: "";
    };
    readonly edgeEnd: {
        readonly isEnd: "";
        readonly notEnd: "";
    };
    readonly iconOnly: {
        readonly isIconOnly: string;
        readonly notIconOnly: "";
    };
}>;
export { multiVariantStyles };

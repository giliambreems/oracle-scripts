/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { Ref } from 'preact';
import { FocusableHandle } from '../hooks/UNSAFE_useFocusableTextField';
import { SelectableHandle } from "../hooks/UNSAFE_useSelectableTextField";
import { InputColorPublicProps as Props } from './InputColor.types';
type FocusSelectHandle = FocusableHandle & SelectableHandle;
/**
 * An Input Color is a form field that allows users to select or input a color value,
 * using a color picker or by enterihg a HEX code.
 */
export declare const InputColor: import("preact").FunctionalComponent<import("preact/compat").PropsWithoutRef<Props> & {
    ref?: Ref<FocusSelectHandle> | undefined;
}>;
export {};

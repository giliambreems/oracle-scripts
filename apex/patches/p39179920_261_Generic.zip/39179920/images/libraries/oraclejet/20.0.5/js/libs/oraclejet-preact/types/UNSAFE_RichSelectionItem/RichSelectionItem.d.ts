import { type RichSelectionItemData } from './RichSelectionTypes';
import { type TestIdProps } from "../hooks/UNSAFE_useTestId";
type RichSelectionItemProps<V extends string | number> = RichSelectionItemData<V> & TestIdProps & {
    /**
     * Specifies if the card is read-only.
     */
    isReadonly?: boolean;
};
/**
 * `RichSelectionItem` is a customizable input card element used in selection interfaces. It can display a label,
 * optional secondary text, and media (such as an avatar, thumbnail, or icon). It supports both radio and checkbox
 * controls, allowing users to make a single or multiple selections, respectively. The component also handles
 * different states such as disabled, readonly, and focus, and renders dynamically based on layout( 'xl', 'md', or 'sm').
 */
export declare const RichSelectionItem: <V extends string | number>({ avatar, iconClass, isReadonly: propsIsReadonly, mediaAccessibleLabel, secondaryText, thumbnailSrc, label, value, testId }: RichSelectionItemProps<V>) => import("preact").JSX.Element;
export {};

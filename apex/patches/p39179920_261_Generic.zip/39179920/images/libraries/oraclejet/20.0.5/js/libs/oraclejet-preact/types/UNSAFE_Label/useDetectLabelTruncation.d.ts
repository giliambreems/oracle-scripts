import { RefObject } from 'preact';
type Props = {
    isDisabled?: boolean;
    rootRef: RefObject<HTMLLabelElement>;
};
/**
 * Hook that detects truncated text when you hover the mouse over a label.
 */
declare const useDetectLabelTruncation: ({ isDisabled, rootRef }: Props) => {
    detectTruncationProps: {
        onMouseOver: () => void;
        onMouseOut: () => void;
    } | {
        onMouseOver?: undefined;
        onMouseOut?: undefined;
    };
    isTextTruncated: boolean;
};
export { useDetectLabelTruncation };

/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
type ReferenceObjectCommonProps = {
    id: string;
    color?: string;
    location: 'front' | 'back';
    accessibleLabel?: string;
};
export type ReferenceLineData = ReferenceObjectCommonProps & {
    lineWidth?: number;
    lineStyle?: 'solid' | 'dashed' | 'dotted';
    type: 'line';
    value?: number;
    items?: {
        value: number;
    }[];
};
export type ReferenceAreaData = ReferenceObjectCommonProps & {
    type: 'area';
    low?: number;
    high?: number;
    items?: {
        low: number;
        high: number;
    }[];
};
export type ReferenceObjectData = ReferenceLineData | ReferenceAreaData;
export {};

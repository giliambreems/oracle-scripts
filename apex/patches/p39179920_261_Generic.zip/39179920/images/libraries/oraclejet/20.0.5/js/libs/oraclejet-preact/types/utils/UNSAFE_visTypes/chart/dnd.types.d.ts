/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { CommonDndProps } from '../common';
import { Group } from './axis.types';
export type ChartDndProps<D> = {
    /**
     * 'on' if groups are draggable
     */
    groupDraggable?: (group: Group) => 'on' | 'off';
    /**
     * 'on' if items are draggable
     */
    itemsDraggable?: (data: D, seriesIndex: number, groupIndex: number) => 'on' | 'off';
} & CommonDndProps<DragStartDetail<D>, DropDetail>;
export type DragStartDetail<D> = {
    type: 'xAxisTickLabel';
    group: Group;
    groupIndex: number;
    event: DragEvent;
} | {
    type: 'items';
    items: {
        data: D;
        seriesIndex: number;
        groupIndex: number;
    }[];
    event: DragEvent;
} | undefined;
export type DropDetail = {
    type: 'plotArea';
    x: number;
    y: number;
    y2?: number;
    event: DragEvent;
} | {
    type: 'xAxis';
    x: number;
    event: DragEvent;
} | {
    type: 'yAxis';
    y: number;
    event: DragEvent;
};

import type { ComponentProps, RefObject } from 'preact';
import { DataState, ListItemContext, CurrentKeyDetail } from "../UNSAFE_Collection";
import { ListView } from './ListView';
type ListViewProps<K extends string | number, D> = ComponentProps<typeof ListView<K, D>>;
export declare const useListViewContextMenu: <K extends string | number, D>(dataState: DataState<K, D> | null, contextMenuConfig: ListViewProps<K, D>["contextMenuConfig"], scrollListRef: RefObject<HTMLElement | null>, updateCurrentKey: (key: K) => void) => {
    readonly menuProps: {
        readonly onClose: (detail: {
            reason: "dismissed" | "itemAction" | "outsideClick" | "anchorClick";
        }) => void;
        readonly placement?: import("../UNSAFE_Floating").Placement | undefined;
        readonly isOpen?: boolean;
        readonly anchorRef: RefObject<Element | import("../UNSAFE_Floating").Coords | import("../utils/UNSAFE_unsafeDomAccess").UnsafeDomHandle<Element>>;
        readonly offsetValue?: import("../UNSAFE_Floating").Offset | undefined;
        readonly initialFocus?: "menu" | "firstItem";
    };
    readonly onClose: (detail: {
        reason: "dismissed" | "itemAction" | "outsideClick" | "anchorClick";
    }) => void;
    readonly contextMenuContext: ListItemContext<K, D>;
    readonly triggerProps: Record<string, any>;
    readonly notifyCurrentKeyChanged: (detail: CurrentKeyDetail<K>) => void;
};
export {};

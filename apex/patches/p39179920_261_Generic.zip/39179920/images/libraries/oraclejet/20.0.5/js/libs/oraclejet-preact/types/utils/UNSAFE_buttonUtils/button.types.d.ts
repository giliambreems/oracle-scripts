/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { JSX } from 'preact';
import type { UnpackSignals } from "../UNSAFE_attributeUtils";
export type ButtonIntrinsicProps = Pick<UnpackSignals<JSX.HTMLAttributes<HTMLElement>>, 'autofocus' | 'title' | 'onBlur' | 'onFocus' | 'onMouseDown' | 'onMouseLeave' | 'onMouseEnter' | 'onMouseUp' | 'onTouchEnd' | 'onTouchStart' | 'onTouchCancel' | 'onKeyDown' | 'onKeyUp'>;
export type ButtonIntrinsicAriaProps = Pick<UnpackSignals<JSX.AriaAttributes>, 'aria-label' | 'aria-describedby' | 'aria-hidden' | 'aria-roledescription' | 'aria-expanded' | 'aria-pressed' | 'aria-checked' | 'aria-live' | 'aria-disabled' | 'aria-haspopup' | 'aria-selected'>;

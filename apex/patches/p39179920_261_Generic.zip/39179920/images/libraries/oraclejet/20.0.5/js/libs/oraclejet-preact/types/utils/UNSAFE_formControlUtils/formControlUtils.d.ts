import { Size } from "../UNSAFE_size";
import { LayoutColumnSpan } from "../UNSAFE_styles/Layout";
/**
 * Calculate the width of a start label, taking into account the column span.
 * @param labelStartWidth specified width of the start label
 * @param columnSpan  number of columns to span
 * @returns start label width to use
 */
declare function computeStartLabelWidth(labelStartWidth: Size, columnSpan: LayoutColumnSpan): string;
export { computeStartLabelWidth };

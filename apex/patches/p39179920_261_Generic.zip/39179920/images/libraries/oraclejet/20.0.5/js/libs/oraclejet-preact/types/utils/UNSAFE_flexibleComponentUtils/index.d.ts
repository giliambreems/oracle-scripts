export type { Position, Rect } from './flexibleComponentUtils';

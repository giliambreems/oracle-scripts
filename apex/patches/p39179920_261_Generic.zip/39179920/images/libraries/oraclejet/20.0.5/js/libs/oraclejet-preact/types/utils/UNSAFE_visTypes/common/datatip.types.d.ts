/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { Property } from 'csstype';
import { ComponentChildren } from 'preact';
export type DatatipConfig<C> = (context: C) => {
    content?: ComponentChildren;
    borderColor?: Property.BorderColor;
    defaultContainer?: 'enabled' | 'disabled';
};

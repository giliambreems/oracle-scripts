/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import type { RefObject } from 'preact';
import { type gestureTypes } from "../hooks/PRIVATE_useVisContextMenu";
import type { PictoChartContextMenuConfig, ItemInfo } from './pictoChart.type';
type Props<D> = {
    focusedItemInfo: ItemInfo;
    items: D[];
    rootRef: RefObject<HTMLDivElement>;
    contextMenuConfig?: PictoChartContextMenuConfig<D>;
    onContextMenuDismissed?: (gesture: gestureTypes) => void;
    getItemInfo: (element: HTMLElement) => {
        idx: number;
    } | undefined;
};
export declare const usePictoChartContextMenu: <D>({ rootRef, contextMenuConfig, focusedItemInfo, items, onContextMenuDismissed, getItemInfo }: Props<D>) => {
    contextMenuContent: import("preact").JSX.Element | undefined;
    contextMenuProps: Record<string, any>;
};
export {};

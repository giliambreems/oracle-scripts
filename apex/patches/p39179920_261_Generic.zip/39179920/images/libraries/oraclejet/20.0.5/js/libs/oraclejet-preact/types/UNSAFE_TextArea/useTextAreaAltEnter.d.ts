import { ComponentProps, RefObject } from 'preact';
import { TextFieldInput } from "../UNSAFE_TextField";
type UseTextAreaAltEnterOptions = {
    /**
     * The onInput of the TextFieldInput
     */
    onInput: NonNullable<ComponentProps<typeof TextFieldInput>['onInput']>;
    /**
     * The ref to the textarea element
     */
    textAreaRef: RefObject<HTMLTextAreaElement>;
};
/**
 * A custom hook to enable an alternate way for entering a new line in the TextArea components using
 * Alt + Enter (or option + return in MacOS). This is particularly useful in scenarios where pressing Enter
 * could mean a different action, like exiting from edit mode in a Table/DataGrid containing a TextArea.
 */
export declare const useTextAreaAltEnter: ({ onInput, textAreaRef }: UseTextAreaAltEnterOptions) => {
    handleKeyDown: (event: KeyboardEvent) => void;
};
export {};

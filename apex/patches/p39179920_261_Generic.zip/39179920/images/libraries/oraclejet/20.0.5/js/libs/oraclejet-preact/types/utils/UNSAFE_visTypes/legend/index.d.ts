/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
export type { ItemActionDetail, ItemFocusDetail, ItemHoverDetail, ItemInfo, LegendMarkerShape, SymbolProps, LegendItemData, LegendSectionData, TextStylesProps, CommonProps, BaseLegendProps, LegendContextMenuContext, SectionalLegendContextMenuContext, LegendDndProps, DropDetail } from './baseLegend.type';

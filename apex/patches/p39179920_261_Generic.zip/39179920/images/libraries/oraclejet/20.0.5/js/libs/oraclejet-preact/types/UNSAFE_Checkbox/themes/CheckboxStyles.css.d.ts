import { ComponentThemeType, VariantOptions } from "../../UNSAFE_Theme";
type CheckboxVariants = typeof variants;
type CheckboxVariantOptions = VariantOptions<CheckboxVariants>;
type CheckboxStyles = typeof styles;
type CheckboxTheme = ComponentThemeType<CheckboxVariants, CheckboxStyles>;
declare const checkboxBaseStyle: string;
declare const valueLabelStyle: string;
/*******************
 * Style Variants
 *******************/
declare const variants: {
    readonly cursor: {
        readonly arrow: "";
        readonly pointer: string;
    };
    readonly disabled: {
        readonly isDisabled: {
            color: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
        readonly notDisabled: {
            color: `var(--${string})` | `var(--${string}, ${string})` | `var(--${string}, ${number})`;
        };
    };
};
declare const styles: {
    checkboxBaseStyle: string;
    checkboxSpanStyle: string;
    valueLabelStyle: string;
};
export type { CheckboxVariantOptions, CheckboxStyles, CheckboxTheme };
export { checkboxBaseStyle, valueLabelStyle, styles, variants };

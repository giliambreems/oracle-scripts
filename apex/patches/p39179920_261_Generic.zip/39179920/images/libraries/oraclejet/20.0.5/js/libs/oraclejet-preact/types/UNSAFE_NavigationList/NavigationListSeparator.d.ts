/**
 * NavigationListSeparator is a component that renders a visual separator (displayed
 * as a horizontal line) between collections of items within NavigationList.
 *
 * @param {NavigationListSeparatorProps} props Component props for NavigationListSeparator.
 * @returns {JSX.Element} Component element for NavigationListSeparator.
 */
export declare function NavigationListSeparator(): import("preact").JSX.Element;

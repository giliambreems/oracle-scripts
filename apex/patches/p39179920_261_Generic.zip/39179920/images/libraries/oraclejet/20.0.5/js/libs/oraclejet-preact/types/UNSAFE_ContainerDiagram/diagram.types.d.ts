/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { CommonDiagramProps } from "../PRIVATE_BaseDiagram/diagram.types";
export type ContainerDiagramProps<K1, K2, D1, D2, L> = CommonDiagramProps<K1, K2, D1, D2, L>;

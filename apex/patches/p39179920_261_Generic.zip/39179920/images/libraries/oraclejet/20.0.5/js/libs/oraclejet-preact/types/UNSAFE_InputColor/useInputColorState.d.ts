/**
 * @license
 * Copyright (c) %FIRST_YEAR% %CURRENT_YEAR%, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 * @ignore
 */
import { type ColorValue } from "../utils/UNSAFE_color";
type InputColorState = {
    /**
     * Represents the current color value of the component. The user either selected
     * the color in the picker, or typed it into the color field.
     */
    colorValue?: ColorValue;
};
type ColorChangedAction = {
    type: 'colorChanged';
    data?: ColorValue;
};
type ColorResetAction = {
    type: 'reset';
    data?: ColorValue;
};
type ColorSelectedAction = {
    type: 'colorSelected';
    data?: ColorValue;
};
type InputColorReducerAction = ColorChangedAction | ColorResetAction | ColorSelectedAction;
type Props = {
    /**
     * The value of the InputColor, or undefined.
     */
    value?: ColorValue;
};
/**
 * useInputColorState calls useReducer to determine the initial state. Any changes to that state
 * are managed by dispatching actions to the reducer function.
 */
declare const useInputColorState: ({ value }: Props) => {
    state: InputColorState;
    dispatch: import("preact/hooks").Dispatch<InputColorReducerAction>;
};
export { useInputColorState };

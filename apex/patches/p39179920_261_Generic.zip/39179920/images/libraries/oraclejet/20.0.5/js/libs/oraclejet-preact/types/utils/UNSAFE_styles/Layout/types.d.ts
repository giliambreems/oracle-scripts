import { Range } from "../../../PRIVATE_oraclejet-internal-utilities/typeUtils";
export type LayoutColumns = Range<1, 7>;
export type LayoutColumnSpan = LayoutColumns;

import { ComponentChildren } from 'preact';
import { MutableRef } from 'preact/hooks';
import { TabBarContextMenuConfig, TabBarItemContextMenuContext } from '../UNSAFE_TabBarCommon';
export declare const REMOVE_ICON_SELECTOR = "[data-oj-navigationlist-item-remove-icon]";
/**
 * type for payload of selection change event handler
 */
type SelectionDetail<K> = {
    value: K;
    reason: 'pointer' | 'keyboard';
};
/**
 * type for payload of remove event handler
 */
type RemoveDetail<K> = {
    value: K;
};
export declare function useNavigationList<K extends string | number>({ containerRef, selection, onRemove, onSelectionChange, children, contextMenuConfig }: {
    containerRef: MutableRef<HTMLDivElement>;
    selection?: K;
    onRemove?: <K extends string | number>(detail: RemoveDetail<K>) => void;
    onSelectionChange?: <K extends string | number>(detail: SelectionDetail<K>) => void;
    children: ComponentChildren;
    contextMenuConfig?: TabBarContextMenuConfig<K>;
}): {
    showFocusRing: boolean;
    currentKey: K | undefined;
    onCurrentKeyChange: (<K_1 extends string | number>(detail: {
        value: K_1;
    }) => void) | undefined;
    onKeyDown: (event: KeyboardEvent) => void;
    menuProps: {
        onClose: (detail: {
            reason: "dismissed" | "itemAction" | "outsideClick" | "anchorClick";
        }) => void;
        placement?: import("../UNSAFE_Floating").Placement | undefined;
        isOpen?: boolean | undefined;
        anchorRef: import("preact").RefObject<Element | import("../UNSAFE_Floating").Coords | import("../utils/UNSAFE_unsafeDomAccess").UnsafeDomHandle<Element>>;
        offsetValue?: import("../UNSAFE_Floating").Offset | undefined;
        initialFocus?: "menu" | "firstItem" | undefined;
    };
    contextMenuContext: TabBarItemContextMenuContext<K> | undefined;
    contextMenuDescription: string;
    contextMenuDescriptionId: string;
    accStatusInfo: string | undefined;
    containerHandlers: {};
};
export declare const getItemAttribute: <K extends string | number>(itemKey: K, root: HTMLElement, attribute: string) => Element | null | undefined;
export {};

declare const formControlStyles: {
    embeddedRoot: string;
};
export { formControlStyles };

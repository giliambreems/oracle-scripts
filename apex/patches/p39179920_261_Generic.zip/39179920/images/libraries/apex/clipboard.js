/*!
 Copyright (c) 2017, 2026, Oracle and/or its affiliates. All rights reserved.
*/
/*
 * Clipboard cross browser support for cut, copy, paste clipboard operations
 *
 * Clipboard support requires responding to the user initiating cut, copy, and paste operations by customary means.
 * The cut, copy, and paste events are used for this and are fully and widely supported.
 * It is also highly desirable to initiate the same operations programmatically in response to the user interacting
 * with application controls such as menu items or buttons. For security and privacy reasons the context in which
 * JavaScript code can access the clipboard is constrained and the details vary by browser.
 *
 * Programmatic initiation uses the Clipboard API for paste and old deprecated document.execCommand for cut and copy.
 * The Clipboard API is newish and not fully supported in any browser and the UX differs among browsers but now it is
 * complete enough in the browsers we support. The deprecated document.execCommand is still preferred for
 * copy and cut because it is simpler and works everywhere without extra permissions but still with some constraints.
 *
 * Handling custom clipboard formats (ex "application/x-myformat"):
 * The old execCommand would allow calling dataTransfer.setData with any format and when
 * handling a paste event you could read it back with getData. However the custom formats would only be available
 * from the same browser. For example copy paste a custom format from Chrome to Chrome (same or different tab, same or
 * different origin) works fine but not from Chrome to Firefox or the reverse. Also they only work from browser
 * initiated paste events not with programmatic access.
 * The new Clipboard API supports custom formats if they start with the prefix "web ".
 * However this is currently only implemented in Chrome based browsers.
 * These 2 ways cannot be mixed so if you write a custom format using the Clipboard API you can't
 * access it with the legacy paste event dataTransfer.getData. So if custom formats are needed and the browser
 * supports them it is best to use the Clipboard API. Otherwise it is better to use the legacy execCommand
 * and events and realize that the custom format is not available from programmatic access.
 *
 * Paste is initiated with Ctrl+V key (Command+V on Macs) or the Paste menu item on the browser context menu
 * (or menu bar Edit menu if there is one). Similarly copy is initiated with Ctrl/Command+C or the browser
 * Copy menu item, and cut is initiated with Ctrl/Command+X or the browser Cut menu item.
 * The keyboard keys generate the corresponding event no matter where focus is (this was not always true which
 * is one reason why initially this module only supported copy).
 *
 * The default browser context menu is only available when focus is in a text editing context.
 * For practical purposes this means a textarea element or an input type=text element.
 *
 * The old execCommand API and new Clipboard API are very different. The old way would cause a corresponding
 * cut or copy event to be triggered and therefore all cut and copy handling happens the same way. The new
 * way is asynchronous and does not trigger a paste event so you need to handle the existing paste event and
 * also direct async programmatic read access. This API normalizes clipboard operations so they are handled
 * the same way no matter if initiated by the cut, copy, paste events or through the cut, copy, paste methods.
 *
 * Depends on these strings being defined in the apex.lang message facility
 *     APEX.CLIPBOARD.NOTSUP (lazy load)
 *     APEX.CLIPBOARD.COPIED
 *
 * Issues/Questions
 * - Use permission api to check if clipboard-read is granted?
 * - Only Firefox browser context menu shows Copy (unless focus in text field *before* context menu).
 * - Seems no browser puts Cut on the context menu.
 * - Behavior of context menu Select All and others like undo/redo/delete is not desirable.
 */

/**
 * <p>The apex.clipboard namespace contains functions to help interact with the clipboard.
 * It handles cross browser differences and supports widgets that need to copy something other than the built-in
 * browser text selection.</p>
 *
 * @ignore
 * @namespace
 * @since 5.2
 */
apex.clipboard = ( function ( apex ) {
    "use strict";
    const {debug, lang, jQuery: $} = apex;

    const SEL_NO_SELECT = ".is-disabled, .js-no-select",
        CB_DUMMY_ELEMENT = "apexCBMDummySelection",
        CUSTOM_JSON_FORMAT_RE = /^(web )?application\/.+json$/,
        isMac = apex.util.hasMacKeyboard(),
        hasQueryCommand = Boolean( document.execCommand && document.queryCommandSupported ),
        clipboardAPI = window.navigator.clipboard,
        hasClipboardRead = Boolean( clipboardAPI && clipboardAPI.read ),
        // if browser supports one custom format assume it should support any
        // Safari 18.3 has ClipboardItem but not the supports method (bug 39683227)
        supportsCustomFormats = Boolean( window?.ClipboardItem?.supports?.( "web application/any" ) );
    const clipboardHandlers = {
        cut: [],
        copy: [],
        paste: []
    };

    const EVENT_CLICK = "click",
        CB_OP_CUT = "cut",
        CB_OP_COPY = "copy",
        CB_OP_PASTE = "paste";

    let gActualCopyCutElement = null,
        gDOMPurifyLoading = false;

    // todo consider cache last found handler
    function findHandlerForActiveElement( op ) {
        const handlers = clipboardHandlers[op] || [],
            target$ = $( gActualCopyCutElement || document.activeElement );

        for ( let i = 0; i < handlers.length; i++ ) {
            const ch = handlers[i];

            if ( target$.closest( ch.element ).length > 0 ) {
                return ch.handler;
            }
        }
        return null;
    }

    function makeCutCopyHandler( op ) {
        return ( event => {
            const cbEvent = event.originalEvent,
                dataTransfer = cbEvent.clipboardData;

            if ( !dataTransfer ) {
                return;
            }
            const handler = findHandlerForActiveElement( op );

            if ( handler ) {
                // use async clipboard API if try to use a custom format and custom formats are supported
                const done = async function() {
                    if ( customFormat && supportsCustomFormats ) {
                        const clipboardItem = new ClipboardItem( items );

                        await navigator.clipboard.write( [clipboardItem] );
                    } else {
                        for ( const f of Object.keys ( items ) ) {
                            dataTransfer.setData( f, items[f] );
                        }
                    }
                };
                let customFormat = false;
                const items = {},
                    asyncDataTransfer = {
                        setData: function( format, data ) {
                            if ( format.startsWith( "web " ) ) {
                                customFormat = true;
                            }
                            items[format] = data;
                        }
                    };

                if ( handler( asyncDataTransfer ) ) {
                    event.preventDefault();
                    done();
                }
            }
        } );
    }

    function pasteHandler( event ) {
        const cbEvent = event.originalEvent,
            dataTransfer = cbEvent.clipboardData;

        if ( !dataTransfer ) {
            return;
        }
        const handler = findHandlerForActiveElement( CB_OP_PASTE );

        if ( handler ) {
            let status;

            if ( supportsCustomFormats ) {
                status = clipboardManager.paste();
            } else {
                // For consistency between paste event handling and the paste method
                // make up an async data transfer interface that is simpler than the clipboard API and only
                // slightly more work than synchronous use of clipboardData.
                const dataTransferAsync = {
                    types: dataTransfer.types,
                    special: false,
                    asyncGetData: ( type ) => {
                        return new Promise( resolve => {
                            resolve( clipboardManager.sanitizeClipboardData( type, dataTransfer.getData( type ) ) );
                        } );
                    }
                };
                status = handler( dataTransferAsync );
            }
            if ( status ) {
                event.preventDefault();
            }
        }
    }

    const handlers = {
        cut: makeCutCopyHandler( CB_OP_CUT ),
        copy: makeCutCopyHandler( CB_OP_COPY ),
        paste: pasteHandler
    };

    function warnNoHandler() {
        debug.warn( "No clipboard handler for active element." );
    }

    function checkOperation( op ) {
        if ( ![CB_OP_CUT, CB_OP_COPY, CB_OP_PASTE].includes( op ) ) {
            throw new Error( "Unknown operation" );
        }
    }

    function showNotSupportedMessage( op ) {
        const key = "APEX.CLIPBOARD.NOTSUP";

        lang.loadMessagesIfNeeded( [key], function () {
            apex.message.alert( lang.formatMessage( key, clipboardManager.acceleratorKeyFor( op ) ), () => {} );
        } );
    }

    /*
     * This function creates a selection in a "hidden" dummy element so that copy/cut will work better as follows:
     * When document.execCommand( "copy" ) or document.execCommand( "cut" ) is called it will cause a copy or cut
     * event to be triggered respectively. Ideally it shouldn't matter where focus is when they are called and this
     * is true for Firefox and Chrome. Safari currently seems to need some text selected (maybe focus in that element
     * too) for the copy command to work and focus in a text input (or textarea; assumed) with a selection for the cut
     * command to work. In addition, Firefox will add the Copy menu item to the default context menu if there is
     * a text selection.
     */
    function makeDummySelection() {
        const active = document.activeElement,
            dummy = $( "#" + CB_DUMMY_ELEMENT )[0];

        gActualCopyCutElement = active;
        if ( active.nodeName === "INPUT" || active.nodeName === "TEXTAREA" ) {
            return; // no need when focus on something that already supports selection
        }

        // todo think: A side effect is selection is scrolled into view when it might not be otherwise.
        //   May be non-issue because view is already focused in order to issue copy/cut command and this can cause
        //   scrolling. Not sure if dummy.focus( {preventScroll: true} ) and dummy.setSelectionRange(0,1) will help.
        //   Keep it simple for now.
        dummy.select();
    }

    function clearDummySelection() {
        if ( gActualCopyCutElement ) {
            gActualCopyCutElement.focus();
            gActualCopyCutElement = null;
        }
    }

    function getKey( op, mac, win ) {
        let accKey = null,
            key = {"cut": "X", "copy": "C", "paste": "V", "select_all": "A"}[op];

        if ( key ) {
            accKey = ( isMac ? mac : win ) + key;
        }
        return accKey;
    }

    /**
     * @lends apex.clipboard
     */
    const clipboardManager = {
        /**
         * Clipboard operation string constants
         */
        operation: Object.freeze( {
            "cut": CB_OP_CUT,
            "copy": CB_OP_COPY,
            "paste": CB_OP_PASTE
        } ),

        /**
         * Return true if the browser supports using the given clipboard operation. Most modern browsers support
         * the document.queryCommandSupported API with the copy and cut commands but not the paste command.
         * Most modern browsers support the clipboard API for paste including reading various formats.
         * Browsers may require permission or an extra action to invoke the paste (read) operation.
         * Use this to check that copy, cut, or paste is supported and if needed, modify the UI if it isn't.
         * Note that it is possible for clipboard read (paste) to fail even if it is supported and the failure is
         * async.
         *
         * @ignore
         * @param {string} pOperation The clipboard operation to check. One of "copy", "cut", "paste".
         *   defaults to "copy".
         * @return {boolean} true if the browser supports using the command and false otherwise.
         */
        isSupported: function( pOperation = CB_OP_COPY ) {
            if ( [CB_OP_COPY, CB_OP_CUT].includes( pOperation ) ) {
                return hasQueryCommand && document.queryCommandSupported( CB_OP_COPY );
            } else if ( pOperation === CB_OP_PASTE ) {
                return hasClipboardRead;
            } else {
                return false;
            }
        },

        /**
         * Return the OS dependent keyboard accelerator key display name for the given clipboard operation.
         *
         * @param {string} pOperation The clipboard operation to return the key for.
         *   One of "copy", "cut", "paste", "select_all".
         *   defaults to "copy".
         * @param pOperation
         * @return {string|null} The accelerator key name or null if pOperation is not valid
         */
        acceleratorKeyFor: function( pOperation = CB_OP_COPY ) {
            return getKey( pOperation, "\u2318 ", "Ctrl+" );
        },

        /**
         * Return the OS dependent aria-keyshortcuts value for the given clipboard operation.
         *
         * @param {string} pOperation The clipboard operation to return the aria shortcut key for.
         *   One of "copy", "cut", "paste", "select_all".
         *   defaults to "copy".
         * @param pOperation
         * @return {string|null} The accelerator key name or null if pOperation is not valid
         */
        ariaKeyshortcutFor: function( pOperation = CB_OP_COPY ) {
            return getKey( pOperation, "Meta+", "Control+" );
        },

        /**
         * <p>Execute the copy command in a way that will work cross browser and for widgets that don't have
         * a traditional browser text selection range. This only executes the copy command. Doing something
         * requires handling the copy event by calling {@Link apex.clipboard.addHandler} (or addElement or addText).
         * If the browser doesn't support copy or fails to do the copy an alert message is shown advising the
         * user that they can try Ctrl+C. Set pNoWarn to true to suppress this alert.</p>
         * <p>Before calling this method focus must be on or within an element that was passed to addHandler
         * otherwise a debug message is logged, no copy is done, and false is returned.</p>
         *
         * @ignore
         * @param {object} [pOptions] An options object.
         * @param {boolean} [pOptions.noWarn] If true don't show a warning dialog if the browser fails to do the copy.
         * @param {Element} [pOptions.tooltipElement] The element to show a copied to clipboard tooltip
         *   message on success.
         * @return {boolean} true if copy supported and document.execCommand("copy") returns true and false otherwise.
         */
        copy: function( pOptions = {} ) {
            let status = false;

            if ( !findHandlerForActiveElement( CB_OP_COPY ) ) {
                warnNoHandler();
                return status;
            }

            if ( this.isSupported( CB_OP_COPY ) ) {
                makeDummySelection();
                status = document.execCommand( CB_OP_COPY );
                clearDummySelection();
            }
            if ( !status ) {
                if ( !pOptions.noWarn ) {
                    showNotSupportedMessage( CB_OP_COPY );
                }
                debug.info( "Browser does not support clipboard copy command." );
            }
            if ( status && pOptions.tooltipElement ) {
                $( pOptions.tooltipElement ).tooltip( {
                    content: lang.getMessage( "APEX.CLIPBOARD.COPIED" ),
                    close: function() {
                        $( this ).tooltip( "destroy" );
                    }
                } );
            }
            return status;
        },
        // todo consider a factory to make cut, copy methods

        /**
         * <p>Execute the cut command in a way that will work cross browser and for widgets that don't have
         * a traditional browser text selection range. This only executes the cut command. Doing something
         * requires handling the cut event by calling {@Link apex.clipboard.addHandler}.
         * If the browser doesn't support cut or fails to do the cut an alert message is shown advising the
         * user that they can try Ctrl+X. Set pNoWarn to true to suppress this alert.</p>
         * <p>Before calling this method focus must be on or within an element that was passed to addHandler
         * otherwise a debug message is logged, no cut is done, and false is returned.</p>
         *
         * @ignore
         * @param {object} [pOptions] An options object.
         * @param {boolean} [pOptions.noWarn] If true don't show a warning dialog if the browser fails to do the cut.
         * @param {Element} [pOptions.tooltipElement] The element to show a copied to clipboard tooltip message
         *   on success.
         * @return {boolean} true if cut supported and document.execCommand("cut") returns true and false otherwise.
         */
        cut: function( pOptions = {} ) {
            let status = false;

            if ( !findHandlerForActiveElement( CB_OP_CUT ) ) {
                warnNoHandler();
                return status;
            }

            if ( this.isSupported( CB_OP_CUT ) ) {
                makeDummySelection();
                status = document.execCommand( CB_OP_CUT );
                clearDummySelection();
            }
            if ( !status ) {
                if ( !pOptions.noWarn ) {
                    showNotSupportedMessage( CB_OP_CUT );
                }
                debug.info( "Browser does not support clipboard cut command." );
            }
            if ( status && pOptions.tooltipElement ) {
                $( pOptions.tooltipElement ).tooltip( {
                    content: lang.getMessage( "APEX.CLIPBOARD.COPIED" ),
                    close: function() {
                        $( this ).tooltip( "destroy" );
                    }
                } );
            }
            return status;
        },

        /**
         * <p>Execute the paste command in a way that will work cross browser and for widgets that don't have
         * a traditional browser text editing context. This calls the handler added in
         * {@Link apex.clipboard.addHandler}.
         * If the browser doesn't support paste or fails to read the clipboard an alert message is shown advising the
         * user that they can try Ctrl+V. Because the clipboard API is asynchronous errors can happen after
         * this method returns and after the handler calls the async data transfer interface. So an alert message
         * may be shown after this method returns. Set pNoWarn to true to suppress this alert.</p>
         * <p>Before calling this method focus must be on or within an element that was passed to addHandler
         * otherwise a debug message is logged and nothing happens.</p>
         *
         * @ignore
         * @param {object} [pOptions] An options object.
         * @param {boolean} [pOptions.special] This sets the special property of the async data transfer interface
         *   passed to the handler. The default is false.
         * @param {boolean} [pOptions.noWarn] If true don't show a warning dialog if the browser fails to do the paste.
         * @return {boolean} true if handler will handle paste, false otherwise
         */
        paste: function( pOptions = {} ) {
            const handler = findHandlerForActiveElement( CB_OP_PASTE );
            let status = false;

            if ( !handler ) {
                warnNoHandler();
                return status;
            }

            if ( this.isSupported( CB_OP_PASTE ) ) {
                clipboardAPI.read()
                    .then( cbItems => {
                        const cbItem = cbItems[0], // there seems to only ever be one
                            // For consistency between paste event handling and the paste method
                            // make up an async data transfer interface that is simpler than the clipboard API and only
                            // slightly more work than synchronous use of clipboardData.
                            dataTransferAsync = {
                                types: cbItem.types,
                                special: Boolean( pOptions.special ),
                                asyncGetData: ( type ) => {
                                    return new Promise( resolve => {
                                        cbItem.getType( type )
                                            .then( blob => {
                                                return blob.text();
                                            } ).then( data => {
                                                resolve( this.sanitizeClipboardData( type, data ) );
                                            } );
                                    } );
                                }
                            };

                        status = handler( dataTransferAsync );
                    } )
                    .catch( error => {
                        if ( !pOptions.noWarn ) {
                            showNotSupportedMessage( CB_OP_PASTE );
                            // todo should this check clipboard read permission and give a different message if blocked?
                        }
                        debug.info( "Browser does not support clipboard paste. Reason:", error );
                    } );
            } else {
                if ( !pOptions.noWarn ) {
                    showNotSupportedMessage( CB_OP_PASTE );
                }
                debug.info( "Browser does not support clipboard paste." );
            }
            return status;
        },

        /**
         * Sanitize clipboard data based on type.
         * The legacy clipboard interface doesn't sanitize at all. The new clipboard read method does but only
         * supported by some browsers so we do it ourselves.
         * Using DOMPurify over jQuery parseHTML because it lets us remove specific tags and will remove
         * inline handler attributes.
         * This can and should be used with data from event.dataTransfer for drop events.
         * @param {string} pType must be a text based type. text/html is sanitized with DOMPurify to remove
         *   script and styles. Custom types that contain JSON are parsed as json. For JSON parsing to be done
         *   the type must start with "application/" optionally prefixed with "web " and end with "+json".
         * @param {string} pData text clipboard data
         * @returns {string}
         */
        sanitizeClipboardData( pType, pData ) {
            if ( pType === "text/html" ) {
                if ( !window.DOMPurify ) {
                    throw new Error( "Failed to sanitize clipboard" );
                }
                // todo if/when needed provide a way to customize the options on a per handler basis
                return apex.util.sanitizeHtml( pData, {
                    // exclude img tags because they can be used for tracking
                    FORBID_TAGS: ["img", "style", "iframe"],
                    // The clipboard contains a whole document. Most programs put lots of stuff in head such
                    // as styles. Consumers may or may not want it but safest to include it and makes processing
                    // simpler and more consistent.
                    WHOLE_DOCUMENT: true,
                    // exclude inline style attributes because they can be used in XSS attacks
                    FORBID_ATTR: ["style"]
                } );
            } else if ( CUSTOM_JSON_FORMAT_RE.test( pType  ) ) {
                try {
                    // turn it into objects/arrays
                    pData = JSON.parse( pData );
                } catch( ex ) {
                    // if it is not valid return null and log reason
                    debug.warn( "Invalid clipboard data:", ex );
                    pData = null;
                }
            } // else
            // todo think is there any sanitization needed for other types?
            return pData;
        },

        /**
         * Wrapper around addHandler
         * details todo
         * @ignore
         * @param pElement
         * @param pButton
         */
        addElement: function( pElement, pButton ) {
            const self = this,
                el$ = $( pElement );

            if ( el$.prop( "tabIndex" ) === -1 ) {
                el$.prop( "tabIndex", 0 );
            }
            apex.clipboard.addHandler( CB_OP_COPY, pElement, function( dt ) {
                dt.setData( "text/plain", ( el$.text() || el$.val() ).replace( /\n/g, "\r\n" ) );
                return true;
            } );
            if ( pButton ) {
                $( pButton ).on( EVENT_CLICK, function() {
                    el$.trigger( "focus" );
                    self.copy( {
                        tooltipElement: pButton
                    } );
                    $( this ).trigger( "focus" );
                } );
            }
        },

        /**
         * Wrapper around addHandler
         * details todo
         * @ignore
         * @param pText
         * @param pButton
         */
        addText: function( pText, pButton ) {
            const self = this,
                b$ = $( pButton );

            apex.clipboard.addHandler( CB_OP_COPY, pButton, function( dt ) {
                dt.setData( "text/plain", pText );
                return true;
            } );
            b$.on( EVENT_CLICK, function() {
                self.copy( {
                    tooltipElement: pButton
                } );
                $( this ).trigger( "focus" );
            } );
        },

        /**
         * <p>Add a handler function, pCallback, to be called when the given clipboard operation event
         * happens on pElement or a child of pElement. There should only be one handler function per operation
         * per element.
         * </p>
         *
         * @ignore
         * @param {string} [pOperation] The clipboard operation to add a handler for. One of "copy", "cut", "paste".
         *   defaults to "copy".
         * @param {Element} pElement The element to add clipboard support to.
         * @param {function} pCallback A function that receives a simplified interface object for data transfer.
         * For cut and copy the object will contain at least the setData function from
         * a DataTransfer object (or a wrapper around it).
         * For paste the object will contain:
         * - types: an array of types
         * - special: if true a paste special operation was initiated
         * - asyncGetData( type ): async function that returns a promise that is resolved with the text data
         *   of the requested type (format).
         * For all operations the handler function must return true if it intends to handle the operation.
         * Returning true will prevent the default clipboard event handling.
         */
        addHandler: function( pOperation, pElement, pCallback ) {
            // for backward compatibility the first arg is optional, shift args forward and fill in default op
            if ( typeof pOperation !== "string" ) {
                pCallback = pElement;
                pElement = pOperation;
                pOperation = CB_OP_COPY;
            }

            checkOperation( pOperation ); // may throw

            if ( clipboardHandlers[pOperation].length === 0 ) {
                // the operation names are the same as the event names
                $( document ).on( pOperation + ".cbManager", handlers[pOperation] );
                // Create element used by makeDummySelection if not present
                if ( ( pOperation === CB_OP_COPY || pOperation ===  CB_OP_CUT ) &&
                    !$( "#" + CB_DUMMY_ELEMENT ).length ) {

                    /* Notes on choice of dummy selection element: (see also comments on makeDummySelection)
                     * Firefox would be happy with just a visually hidden span and using
                     * createRange, selectNode, getSelection().addRange() to select text in the span. It doesn't
                     * even need the selection to be focused.
                     * Safari needs to have a selection that can be cut in order for cut to work. So a text input
                     * is best. (No advantage to using a textarea.) It doesn't seem to mind if the input is display:none
                     * but it does need to be focused (yes focused display none sounds like a strange combination).
                     * Combining both needs results in the following:
                     */
                    $( document.body ).append(
                        `<input id="${CB_DUMMY_ELEMENT}" aria-hidden="true" class="u-vh" tabindex="-1" value="x">` );
                }
            }
            if ( pOperation === CB_OP_COPY ) {
                // This dummy selection on context menu event only helps Firefox so that it includes a Copy item in the
                // default context menu. Chrome and Safari seem to first clear the selection before the default
                // context menu is open and ignore selection set during, including if set during mouse down or mouse up.
                $( pElement ).on( "contextmenu.cbManager", function () {
                    // A widget that is disabled should not be doing selection or have special clipboard handling so
                    // let the default browser behavior happen by not making a dummy selection
                    if ( $( this ).is( SEL_NO_SELECT ) ) {
                        return;
                    }
                    makeDummySelection();
                    setTimeout( () => {
                        clearDummySelection();
                    }, 0 );
                } );
            }
            if ( pOperation === CB_OP_PASTE && !window.DOMPurify && !gDOMPurifyLoading ) {
                // if adding a paste handler and DOMPurify not loaded, load it because it is used to sanitize
                // data read from the clipboard.
                gDOMPurifyLoading = true;
                apex.server.loadScript( {
                        path: `${apex.env.APEX_FILES}libraries/purify/${apex.libVersions.domPurify}/purify.min.js`,
                        requirejs: true,
                        global: "DOMPurify"
                    },
                    () => {
                        gDOMPurifyLoading = false;
                    } );
            }
            clipboardHandlers[pOperation].push( {
                element: pElement,
                handler: pCallback
            } );
        },

        /**
         * <p>Remove the handler for the given operation added by {@link apex.clipboard.addHandler}.</p>
         *
         * @ignore
         * @param {string} [pOperation] The clipboard operation to remove a handler for. One of "copy", "cut", "paste".
         *   defaults to "copy".
         * @param {Element} pElement The element to remove copy to clipboard support from.
         */
        removeHandler: function( pOperation, pElement ) {
            // for backward compatibility the first arg is optional, shift args forward and fill in default op
            if ( typeof pOperation !== "string" ) {
                pElement = pOperation;
                pOperation = CB_OP_COPY;
            }

            checkOperation( pOperation ); // may throw

            const handlers = clipboardHandlers[pOperation] || [];

            for ( let i = 0; i < handlers.length; i++ ) {
                let ch = handlers[i];

                if ( ch.element === pElement ) {
                    handlers.splice( i, 1 );
                    break; // assumes there is only one
                }
            }
            if ( handlers.length === 0 ) {
                $( document ).off( pOperation + ".cbManager" );
            }
            if ( pOperation === CB_OP_COPY ) {
                $( pElement ).off( ".cbManager" );
            }
            // remove the dummy element when there are no more copy or cut handlers
            if ( clipboardHandlers[CB_OP_COPY].length + clipboardHandlers[CB_OP_CUT].length === 0 ) {
                $( "#" + CB_DUMMY_ELEMENT ).remove();
            }
        }
    };

    // process declarative attribute data-clipboard-source
    $( function() {
        $( "[data-clipboard-source]", apex.gPageContext$ ).each( function() {
            const trigger$ = $( this ),
                source = trigger$.attr( "data-clipboard-source" );

            if ( source.substring( 0, 1 ) === "#" ) {
                clipboardManager.addElement( $( source )[0], trigger$[0] );
            } else {
                clipboardManager.addText( source, trigger$[0] );
            }
        } );
    } );

    return Object.freeze( clipboardManager );

} )( apex );

/*!
 Copyright (c) 2014, 2026, Oracle and/or its affiliates.
 */

/*
 * A jQuery UI widget for the Interactive Report component of APEX
 *
 * Depends:
 *    jquery.ui.core.js
 *    jquery.ui.widget.js
 *    apex/util.js
 *    apex/region.js
 *    apex/debug.js
 *    apex/server.js
 *    apex/navigation.js
 *    apex/lang.js
 */

/* global $x_Show,$x_Hide,$x_Show_Hide,$f_get_emptys,html_ReturnToTextSelection,$u_js_temp_drop,$d_Find,dhtml_ShuttleObject */

( function () {
    "use strict";

    const { jQuery: $, util, debug, server, navigation, lang, message, date, locale, env, ai, widget } = apex;

    /**
     * @interface interactiveReportRegion
     * @since 26.1
     * @extends {region}
     * @classdesc
     * <p>The interactiveReportRegion interface is used to access the properties and methods of any
     * Interactive Report region.
     * You get access to the interactiveReportRegion interface with the {@link apex.region} function when passed
     * the regionId (HTML DOM ID) of a Interactive Report region.
     * </p>
     */
    /**
     * <p>The Interactive Report region type is "InteractiveReport".</p>
     * @member type
     * @memberOf interactiveReportRegion.prototype
     * @type {string}
     */
    /**
     * <p>Set focus to the Interactive Report if possible. If the report supports selection
     * then the last focused (current) row will be focused. Otherwise, the first focusable
     * element within the region, if any, will be focused.</p>
     *
     * @method focus
     * @memberOf interactiveReportRegion.prototype
     * @example <caption>This example puts focus in the report.</caption>
     * apex.region( "regionDomId" ).focus();
     */
    /**
     * <p>Refreshes the report with new data from the server.</p>
     *
     * @method refresh
     * @memberOf interactiveReportRegion.prototype
     * @param {boolean} [pKeepPagination] Controls the pagination and scroll behavior after refresh.
     * @example <caption>The following example will refresh an Interactive Report region while maintaining the same page.</caption>
     * apex.region( "regionDomId" ).refresh( true );
     */
    /**
     * <p>Get the name of the current view. Interactive Report supports multiple views,
     * such as:</p>
     * <ul>
     *   <li>REPORT (Standard Report View)</li>
     *   <li>CHART (Chart View)</li>
     *   <li>DETAIL (Detail View)</li>
     *   <li>GROUP_BY (Group By View)</li>
     *   <li>ICON (Icon View)</li>
     *   <li>PIVOT (Pivot View)</li>
     * </ul>
     *
     * @method getViewName
     * @memberOf interactiveReportRegion.prototype
     * @returns {string} The current view mode.
     * @example <caption>The following example gets the current view name.</caption>
     * var view = apex.region( "regionDomId" ).getViewName();
     */
    /**
     * <p>Returns the current row as a jQuery object.
     * The current row is the row that has or last had focus.</p>
     * <p>This is only applicable if the report supports selection.</p>
     *
     * @method getCurrentRow
     * @memberOf interactiveReportRegion.prototype
     * @returns {jQuery} The current row or null if not supported.
     * @example <caption>This example gets the current row in the report.</caption>
     * var current$ = apex.region( "regionDomId" ).getCurrentRow();
     * console.log( "make use of current row", current$ );
     */
    /**
     * <p>Sets the last focused row to the given pRow$. If pRow$ is not a row
     * or not in the report container the current row is not changed.</p>
     * <p>This is only applicable if the report supports selection.</p>
     * <p>The {@link apex.event:apexcurrentrowchange} event is triggered any time the current row changes.</p>
     *
     * @method setCurrentRow
     * @memberOf interactiveReportRegion.prototype
     * @param {jQuery} pRow$ The row to make current.
     * @param {boolean} [pFocus] If true also focus the row.
     * @example <caption>This example finds a particular row using jQuery and then makes it the
     * current row and sets focus to it. In this example report rows have class "my-row".</caption>
     * var current$ = $( "#regionDomId .my-row" ).first().closest( "tr" );
     * apex.region( "regionDomId" ).setCurrentRow( current$, true );
     */
    /**
     * <p>Returns the value of the current row.
     * The current row is the row that has or last had focus.
     * The value of a row is its primary key in the <code class="prettyprint">data-id</code> attribute.</p>
     * <p>This is only applicable if the report supports selection.</p>
     *
     * @method getCurrentRowValue
     * @memberOf interactiveReportRegion.prototype
     * @returns {string} The current row value or null if not supported.
     */
    /**
     * <p>Sets the last focused row to the one with the given pRowValue. If no row has the given value
     * the current row is not changed. The row must be rendered in order to be made the current row.
     * The value of a row is its primary key in the <code class="prettyprint">data-id</code> attribute.</p>
     * <p>This is only applicable if the report supports selection.</p>
     * <p>The {@link apex.event:apexcurrentrowchange} event is triggered any time the current row changes.</p>
     *
     * @method setCurrentRowValue
     * @memberOf interactiveReportRegion.prototype
     * @param {string} pRowValue The value of a row.
     * @param {boolean} [pFocus] If true also focus the row.
     */
    /**
     * <p>Return the currently selected rows as a jQuery collection.</p>
     *
     * <p>This is only applicable if the report supports selection.</p>
     * <p>Because this returns a jQuery collection it can only return selected rows that are
     * currently in the DOM. To get a more complete selection result, not just the ones in the DOM,
     * it is better to use {@link interactiveReportRegion#getSelectedValues}</p>
     * <p>See also {@link interactiveReportRegion#setSelection}.</p>
     *
     * @method getSelection
     * @memberOf interactiveReportRegion.prototype
     * @return {?jQuery} The selected row elements as a jQuery collection.
     * Returns null if selection isn't supported.
     * @example <caption>This example get the current selection.</caption>
     * var selection$ = apex.region( "regionDomId" ).getSelection();
     * console.log( "make use of selected rows", selection$ );
     */
    /**
     * <p>Set the selected rows. Triggers the {@link apex.event:apexselectionchange} event if the selection
     * changes unless <code class="prettyprint">pNoNotify</code> is true.</p>
     *
     * <p>This is only applicable if the report supports selection.</p>
     * <p>See also {@link interactiveReportRegion#getSelection}.</p>
     *
     * @method setSelection
     * @memberOf interactiveReportRegion.prototype
     * @param {jQuery} pElements$ A jQuery object with row elements such as the return value of getSelection.
     * @param {boolean} [pFocus] If true the first row element of the selection is given focus.
     * @param {boolean} [pNoNotify] If true the selection change event will be suppressed.
     * @example <caption>This example finds a particular row using jQuery and then selects it
     * and sets focus to it. In this example report rows have class "my-row".</caption>
     * var toSelect$ = $( "#regionDomId .my-row" ).first().closest( "tr" );
     * apex.region( "regionDomId" ).setSelection( toSelect$, true );
     */
    /**
     * <p>Select all the rows in the report that can be selected. Typically this applies to all currently
     * visible rows. Triggers the {@link apex.event:apexselectionchange} event if the selection
     * changes unless <code class="prettyprint">pNoNotify</code> is true.</p>
     *
     * <p>This is only applicable if the report supports multiple selection.</p>
     *
     * @method selectAll
     * @memberOf interactiveReportRegion.prototype
     * @param {?boolean} [pFocus] If true the first selected row is given focus. If false the first selected
     * row is made focusable. If null or not given the current item and focus is not changed.
     * @param {boolean} [pNoNotify] If true the selection change notification will be suppressed.
     * @example <caption>This example selects all the rows in the report.</caption>
     * apex.region( "regionDomId" ).selectAll();
     */
    /**
     * <p>Returns the value for each selected row.
     * The value of a row is its primary key in the <code class="prettyprint">data-id</code> attribute</p>
     *
     * <p>This is only applicable if the report supports selection.</p>
     *
     * @method getSelectedValues
     * @memberOf interactiveReportRegion.prototype
     * @returns {?string[]} Array of selected record values.
     * Returns null if selection is not supported.
     */
    /**
     * <p>Selects the report rows that correspond to the given values.
     * The value of a row is the primary key in the <code class="prettyprint">data-id</code> attribute.
     * The row must be rendered in order to be made a selectable row.
     * Triggers the {@link apex.event:apexselectionchange} event if the selection
     * changes unless <code class="prettyprint">pNoNotify</code> is true.</p>
     *
     * <p>This is only applicable if the report supports selection.</p>
     *
     * @method setSelectedValues
     * @memberOf interactiveReportRegion.prototype
     * @param {string[]} pValues Array of row values to select.
     * @param {boolean} [pFocus] If true the first row of the selection is given focus.
     * @param {boolean} [pNoNotify] If true the selection change event will be suppressed.
     * @return {number} Count of the rows actually selected or -1 if selection is not supported.
     */
    // don't doc methods/properties that don't apply to interactiveReportRegion
    /**
     * @ignore
     * @member widgetName
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @member filterRegionId
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @member parentRegionId
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @member widget
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @method call
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @method on
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @method off
     * @memberOf interactiveReportRegion.prototype
     */
    /**
     * @ignore
     * @method alternateLoadingIndicator
     * @memberOf interactiveReportRegion.prototype
     */

    let scrollYPosition = null,
        regionScrollYPositions = {};

    function getMsg( pKey ) {
        return lang.getMessage( pKey );
    }
    function getIRMsg( pKey ) {
        return lang.getMessage( "APEXIR_" + pKey );
    }
    function formatNoEscape( pKey ) {
        var pattern = getIRMsg( pKey ),
            args = [ pattern ].concat( Array.prototype.slice.call( arguments, 1 ) );
        return lang.formatNoEscape.apply( this, args );
    }
    function getIdSelector( pDomId ) {
        return "#" + util.escapeCSS( pDomId );
    }

    var C_IRR                           = "a-IRR",
        C_IRR_DIALOG                    = C_IRR + "-dialog",
        C_IRR_SORT_WIDGET               = C_IRR + "-sortWidget",
        C_IRR_SORT_WIDGET_BUTTON        = C_IRR_SORT_WIDGET + "-button",
        SEL_IRR_SORT_WIDGET_BUTTON      = "button." + C_IRR_SORT_WIDGET_BUTTON,
        C_IRR_GROUP_BY_COLUMN           = C_IRR + "-group-by-column",
        C_IRR_ADD_FUNCTION              = C_IRR + "-add-function",
        C_IRR_FUNCTION                  = C_IRR + "-function",
        C_IRR_FUNCTION_COL              = C_IRR + "-function-col",
        C_IRR_SEQ_NUM                   = C_IRR + "-sequenceNumber",
        C_IRR_FUNCTION_NUM_COL          = C_IRR + "-function-num-col",
        C_IRR_FUNCTION_ROW              = C_IRR + "-function-row-",
        C_IRR_PIVOT_COLUMN              = C_IRR + "-pivot-column",
        C_IRR_ROW_COLUMN                = C_IRR + "-row-column",
        C_IRR_COL_VALUE                 = C_IRR + "-col-value",
        C_IRR_SINGLE_ROW_GROUP          = C_IRR + "-singleRow-group",
        C_UI_BUTTON_HOT                 = "ui-button--hot",
        C_IS_ACTIVE                     = "is-active",
        C_JS_NO_PIE                     = "js-no-pie",
        C_SWITCH                        = "a-Switch",
        SEL_SCROLLABLE_REGION           = ".t-fht-tbody",
        C_VISUALLY_HIDDEN               = "u-vh",
        C_HIDDEN                        = "u-hidden",
        C_TOOLBAR_AI                    = "a-IRR-toolbar--ai-enabled",
        C_SEARCH_FIELD_AI_PROCESSSING   = "a-IRR-search-field--ai-processing",
        C_JS_ACCESSIBLE_READONLY        = "js-accessible-readonly",
        C_IRR_INLINE_CHAT_OPEN          = C_IRR + "-chat--isOpen",
        C_INLINE_CHAT_CONTAINER         = "a-ChatOuterContainer",
        C_INLINE_CHAT_CONTAINER_OPEN    = C_INLINE_CHAT_CONTAINER + "--open",
        C_SEARCH_MODE = {
            AI: "a-IRR-searchMode--ai",
            ROW: "a-IRR-searchMode--row",
            COLUMN: "a-IRR-searchMode--column",
        },
        C_ICON_SEARCH            = "icon-search",
        C_ICON_SEARCH_AI         = "icon-search-ai",
        C_ICON_MICROPHONE        = "icon-microphone",
        C_ICON_MICROPHONE_LISTEN = "icon-microphone-listening",
        C_ICON_MENU_DROPDOWN     = "icon-menu-drop-down",
        C_ICON_ACTIONS           = "icon-actions",
        SEL_ICON_SEARCH          = "." + C_ICON_SEARCH,
        SEL_ICON_SEARCH_AI       = "." + C_ICON_SEARCH_AI,
        SEL_ICON_MENU_DROPDOWN   = "." + C_ICON_MENU_DROPDOWN,
        SEL_ICON_ACTIONS         = "." + C_ICON_ACTIONS,
        SEL_IRR_ACTIONS_LABEL    = ".a-IRR-actionsLabel",
        // constants
        REPORT                   = "REPORT",
        ICON                     = "ICON",
        DETAIL                   = "DETAIL",
        GROUP_BY                 = "GROUP_BY",
        PIVOT                    = "PIVOT",
        CHART                    = "CHART",
        SHOW_COLUMN              = "SHOW_COLUMN",
        SHOW_FILTER              = "SHOW_FILTER",
        SHOW_HIGHLIGHT           = "SHOW_HIGHLIGHT",
        SHOW_ORDERING            = "SHOW_ORDERING",
        SHOW_CTRL_BREAK          = "SHOW_CTRL_BREAK",
        SHOW_COMPUTATION         = "SHOW_COMPUTATION",
        SHOW_AGGREGATE           = "SHOW_AGGREGATE",
        SHOW_CHART               = "SHOW_CHART",
        SHOW_GROUP_BY            = "SHOW_GROUP_BY",
        SHOW_GROUP_BY_SORT       = "SHOW_GROUP_BY_SORT",
        SHOW_PIVOT               = "SHOW_PIVOT",
        SHOW_PIVOT_SORT          = "SHOW_PIVOT_SORT",
        SHOW_FLASHBACK           = "SHOW_FLASHBACK",
        SHOW_RENAME              = "SHOW_RENAME",
        SHOW_DELETE              = "SHOW_DELETE",
        SHOW_SAVE_DEFAULT        = "SHOW_SAVE_DEFAULT",
        SHOW_RENAME_DEFAULT      = "SHOW_RENAME_DEFAULT",
        SHOW_DELETE_DEFAULT      = "SHOW_DELETE_DEFAULT",
        SHOW_RESET               = "SHOW_RESET",
        SHOW_DOWNLOAD            = "SHOW_DOWNLOAD",
        SHOW_NOTIFY              = "SHOW_NOTIFY",
        SAVE_REPORT              = "SAVE_REPORT",
        ACTION                   = "action",
        ASC                      = "ASC",
        DESC                     = "DESC",
        DIALOG_JS_ID             = "dialog_js",
        CHECKED                  = "checked",
        PAGE                     = "PAGE",
        REGION                   = "REGION",
        ATTACHMENT               = "ATTACHMENT",
        EVENT_SELECTION_CHANGE   = "apexselectionchange",
        EVENT_CURRENT_ROW_CHANGE = "apexcurrentrowchange",
        MSG = {
            SEARCH: {
                PLACEHOLDER: getIRMsg( "SEARCH_PLACEHOLDER" ),
                PLACEHOLDER_AI: getIRMsg( "SEARCH_PLACEHOLDER_AI" ),
                MICROPHONE_START: getIRMsg( "AI_MICROPHONE_START" ),
                MICROPHONE_STOP: getIRMsg( "AI_MICROPHONE_STOP" ),
                AI_SEARCH: getIRMsg( "AI_SEARCH" ),
                ROW_SEARCH: getIRMsg( "ROW_SEARCH" ),
                COLUMN_SEARCH: getIRMsg( "COLUMN_SEARCH" ),
                CHAT_SEARCH_COLUMN: getIRMsg( "AI_CHAT_SEARCH_COLUMN" ),
                CHAT_SEARCH_ROW: getIRMsg( "AI_CHAT_SEARCH_ROW" )
            },
            BUTTON: {
                CANCEL: getIRMsg( "CANCEL" ),
                DELETE: getIRMsg( "DELETE" ),
                APPLY: getIRMsg( "APPLY" ),
                SEND: getIRMsg( "SEND" ),
                DOWNLOAD: getIRMsg( "DOWNLOAD" ),
                ARIA_CHAT_NEW_MESSAGE: getIRMsg( "AI_CHAT_NEW_MESSAGE" ),
                ARIA_CHAT_OPEN: getIRMsg( "AI_CHAT_OPEN" ),
                ARIA_CHAT_CLOSE: getIRMsg( "AI_CHAT_CLOSE" ),
                ARIA_CHAT_DETACH: getIRMsg( "AI_CHAT_DETACH" ),
                ARIA_CHAT_RESTORE: getIRMsg( "AI_CHAT_RESTORE" )
            },
            DIALOG_TITLE: {
                SELECT_COLUMNS: getIRMsg( "SELECT_COLUMNS" ),
                FILTER: getIRMsg( "FILTER" ),
                HIGHLIGHT: getIRMsg( "HIGHLIGHT" ),
                SORT: getIRMsg( "SORT" ),
                CONTROL_BREAK: getIRMsg( "CONTROL_BREAK" ),
                COMPUTATION: getIRMsg( "COMPUTE" ),
                AGGREGATE: getIRMsg( "AGGREGATE" ),
                CHART: getIRMsg( "CHART" ),
                GROUP_BY: getIRMsg( "GROUP_BY" ),
                GROUP_BY_SORT: getIRMsg( "GROUP_BY_SORT" ),
                PIVOT: getIRMsg( "PIVOT" ),
                PIVOT_SORT: getIRMsg( "PIVOT_SORT" ),
                FLASHBACK: getIRMsg( "FLASHBACK" ),
                SAVE_REPORT: getIRMsg( "SAVE_REPORT" ),
                RENAME_REPORT: getIRMsg( "RENAME_REPORT" ),
                DELETE_REPORT: getIRMsg( "DELETE_REPORT" ),
                SAVE_DEFAULT_REPORT: getIRMsg( "SAVE_DEFAULT_REPORT" ),
                RENAME_DEFAULT_REPORT: getIRMsg( "RENAME_DEFAULT_REPORT" ),
                DELETE_DEFAULT_REPORT: getIRMsg( "DELETE_DEFAULT_REPORT" ),
                RESET: getIRMsg( "RESET" ),
                DOWNLOAD: getIRMsg( "DOWNLOAD" ),
                SUBSCRIPTION: getIRMsg( "SUBSCRIPTION" )
            },
            AI_INLINE_CHAT_VIEW: {
                TITLE: getIRMsg( "AI_CHAT_TITLEBAR" ),
                LOADING_MESSAGES: [
                    { message: getIRMsg( "AI_CHAT_THINKING_1" ), duration: 4000, displayLimit: 1 },
                    { message: getIRMsg( "AI_CHAT_THINKING_2" ), duration: 4000, displayLimit: 1 },
                    { message: getIRMsg( "AI_CHAT_THINKING_3" ), duration: 5000, displayLimit: 1 },
                    { message: getIRMsg( "AI_CHAT_THINKING_4" ), duration: 7000, displayLimit: 1 },
                    { message: getIRMsg( "AI_CHAT_THINKING_5" ), duration: 10000, displayLimit: 1 },
                    { message: getIRMsg( "AI_CHAT_THINKING_6" ), duration: 10000 } // Keep the last visible
                ]
            }
        },
        AI_CHATVIEW_DIALOG = ai?.ChatView.renderModes.DIALOG,
        AI_CHATVIEW_INLINE = ai?.ChatView.renderModes.INLINE,
        INLINE_CHAT_MIN_HEIGHT = 200,
        INLINE_CHAT_FOCUS_TARGET = {
            INPUT: "input",
            CLOSE_BUTTON: "closeButton"
        },
        SEL_INLINE_CHAT_INPUT = ".a-ChatInput-text",
        SEL_INLINE_CHAT_CLOSE_BUTTON = ".a-ChatHeaderActions--close";

    /*
     * Allow column header popup to work in jQuery UI dialogs
     */
        var dialogMixin = {
            _allowInteraction: function ( event ) {
                return $( event.target ).closest( "." + C_IRR_SORT_WIDGET ).length > 0 || this._super( event );
            }
        };

        if ( $.ui.dialog ) {
            $.widget( "ui.dialog", $.ui.dialog, dialogMixin );
            $.widget( "apex.popup", $.apex.popup, dialogMixin );
        }

    // ARIA attributes
    const
        TITLE = "title",
        ARIA_PRESSED = "aria-pressed",
        ARIA_LABEL = "aria-label",
        ARIA_DESCRIBEDBY = "aria-describedby",
        ARIA_READONLY = "aria-readonly",
        ARIA_DETAILS = "aria-details",
        ARIA_CONTROLS = "aria-controls";

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    // Ignore occluders that belong to known shell/UI containers so inline chat sizing stays based on
    // the viewport area that matters to the current IR, even if those containers are added later.
    const OCCLUSION_EXCLUDE_SELECTOR = ".t-Body-nav, .ui-dialog, .a-IRR";

    $.widget( "apex.interactiveReport", {
        widgetEventPrefix:              "interactivereport",
        lastFunction:                   null,       // hook to fire a callback after the Ajax call has finished
        idPrefix:                       null,
        currentColumnId:                null,       // used by column header
        lastColumnId:                   null,       //
        computationId:                  null,       // stores the computation ID, when the column header sort widget is opened for a computation column
        reportId:                       null,       // current report ID
        worksheetId:                    null,       // worksheet ID
        region$:                        null,       // jQuery object containing main region HTML DOM id element, used by the refresh mechanism
        dialogDrop$:                    null,       // jQuery object containing the DIV used to drop the dialog
        tempReturnElement$:             null,       // jQuery object containing temporary return element used by narrow...
        viewMode:                       REPORT,     // Current report type (REPORT, CHART, GROUP_BY, PIVOT, etc.)
        ariaProcessingHandler:          null,       // a handler to stop "Still processing" ARIA live message
        options: {
            regionId:                   null,
            ajaxIdentifier:             null,       // The Ajax Identifier used to identify the Ajax call to the region
            toolbar:                    true,       // toolbar enabled (search field, actions menu, view buttons, etc., called 'Search Bar' in UI)
            searchField:                true,       // toolbar - search field
            columnSearch:               true,       // toolbar - column-specific search menu ( 'Finder Drop Down' in UI )
            rowsPerPageSelect:          false,      // toolbar - row select list
            reportsSelect:              true,       // toolbar - saved reports select list
            actionsMenu:                true,       // toolbar - actions menu enable
            reportViewMode:             REPORT,     // toolbar - For REPORT viewMode, there are 3 sub-options (REPORT, ICON and DETAIL)
            selectColumns:              true,       // toolbar - actions menu - select columns option
            filter:                     true,
            rowsPerPage:                true,       // toolbar - actions menu - row selection
            currentRowsPerPage:         50,         // current visible rows per page
            maxRowsToDisplay:           null,       // maximum rows to display per page
            maxRowsPerPage:             null,       // maximum number to display in the rows per page selector
            maxRowCount:                null,       // maximum number of rows processed by query on server
            sort:                       true,       // defines whether end users can define sort columns for this report
            controlBreak:               true,       // defines whether end users can define control breaks for this report
            highlight:                  true,       // defines whether end users can define highlights for this report
            compute:                    true,       // defines whether end users can define computational columns for this report
            aggregate:                  true,       // defines whether end users can define aggregates for this report
            chart:                      true,       // defines whether end users can define charts for this report
            groupBy:                    true,       // defines whether end users can define group by break-downs for this report
            pivot:                      true,       // defines whether end users can define pivot break-downs for this report
            flashback:                  true,       // defines whether end users can utilize flashback queries for this report
            saveReport:                 true,       // defines whether end users can save their current report definition
            saveDefaultReport:          false,      // defines whether developers can save default reports
            reset:                      true,       // defines whether end users can reset their reports from the Actions menu
            help:                       true,       // defines whether end users can invoke the built-in help modal dialog for interactive reports
            helpLink:                   "",         // server generated help link, required if option help = true
            download:                   true,       // defines whether end users can download the report to one of the download formats specified
            downloadContentDisposition: ATTACHMENT, // defines the content-disposition for the download
            subscription:               true,       // defines whether end users can define subscription settings for this report
            pagination:                 true,       // Does the IR have pagination enabled ( this does distinguish if pagination is currently shown, or the specific pagination type )
            detailLink:                 false,      // Single row view currently available
            isControlPanelCollapsed:    false,      // Control panel collapsed state
            fixedHeader:                PAGE,       // Report has fixed headers
            fixedHeaderMaxHeight:       null,       // When fixedHeader is "REGION", we need a maximum height
            pageItems:                  null,       // page items to submit
            actionsMenuStructure:       "IG",       // Use the updated Actions menu structure that is consistent with the Interactive Grid Actions menu
            lazyLoading:                false,      // Is Lazy Loading enabled so that the report doesn't load data until it becomes visible
            enableChatSpeechRecognition:false,      // Whether AI chat can use browser speech recognition. Passed only if aiEnabled and the global dictation is enabled.
            selection:                  null,       // Row selection support. Server writes object containing selectionStateItem, multiple, selectAll, selectAllId
            // callbacks/events
            beforeRefresh:              null,       // maybe we don't need these here, just available by virtue of the _trigger calls in the code?
            afterRefresh:               null
        },

        /*
         * Lifecycle methods
         */
        _create: function () {

            var lRegionId   = this.options.regionId,
                self        = this,
                lRegion$    = $( getIdSelector( lRegionId ), apex.gPageContext$ ),
                lIr$        = $( getIdSelector( lRegionId + "_ir" ), apex.gPageContext$ );

            // If there is no region container, add one on the fly (necessary for our refresh mechanism).
            if( lRegion$.length === 0 ) {
                lRegion$ = lIr$.wrap( "<div id=\"" + lRegionId + "\"></div>" );
            }

            this.idPrefix = ( this.options.regionId );
            this.reportId = this._getElement( "report_id" ).val();
            this.worksheetId = this._getElement( "worksheet_id" ).val();
            this.viewMode = this._getElement( "view_mode" ).val();
            this.region$ = lRegion$;
            this.dialogDrop$ =  this._getElement( DIALOG_JS_ID );
            this.needsLazyLoading = false;
            this.currentRecordId = null;

            this.selection = {
                hasPaginated: false,
                savedSelection: null
            };
            this.inlineChatHorizontalInsets = null;
            this.inlineChatVerticalInsets = null;
            this.inlineChatFixedState = null;

            this._getElement( "worksheet_region" ).addClass( C_IRR );

            this._initOnCreate();
            this._on( this.region$, {
                "apexrefresh": function( event ) {
                    this._search();
                    event.stopPropagation();
                }
            } );

            // menu needs an init call after they where rendered
            // todo we need to have such a button as web component that handles
            // the create and destroy of the menu when it connect/disconnects
            const transformMenuButtons = ( pContext ) => {
                const irContent$ = $( pContext ).find( ".a-IRR-table" );

                $( "button[data-menu^='tc_menu_a']", irContent$ ).each( function() {
                    const menuId = util.escapeCSS( this.getAttribute( "data-menu" ) );

                    $( `div.a-Menu[id=${ menuId }]` ).remove();
                    $( `#${ menuId }` ).menu( { "owningRegion": lRegionId } );
                } );
            };

            transformMenuButtons( lIr$ );

            $( this.region$ ).on( "apexafterrefresh", function() {
                if ( scrollYPosition ) {
                    window.scrollTo( 0, scrollYPosition );
                    scrollYPosition = null;
                }
                if ( Object.keys( regionScrollYPositions ).length > 0 ){
                    for ( const regPos in regionScrollYPositions ) {
                        if ( Object.prototype.hasOwnProperty.call( regionScrollYPositions, regPos ) ) {
                            $( $( SEL_SCROLLABLE_REGION )[ regPos ] ).scrollTop( regionScrollYPositions[ regPos ] );
                        }
                    }
                    regionScrollYPositions = {};
                }
                transformMenuButtons( lIr$ );

                // re-initialize selection after report refresh, e.g. when changing views, pagination etc.
                if ( self.options.selection ) {
                    self._initSelection( true, self.selection.hasPaginated );

                    // reset our states
                    self.selection.hasPaginated = false;
                }
            } );

            // Register IG with our region interface
            apex.region.create( lRegionId, function( baseRegion ) {

                const isDefined = function( value ) {
                    return value != null;
                };
                const getRecord = function( el, recordId ) {
                    if ( !isDefined( recordId ) ) {
                        return;
                    }
                    function isJSON( val ) {
                        try {
                            JSON.parse( val );
                            return true;
                        } catch ( e ) {
                            return false;
                        }
                    }

                    // IR composite primary keys are JSON escaped in data-id="..." attributes
                    // It's almost impossible to properly escape CSS selectors that may have tabs, line breaks
                    // multi-byte characters etc. in the JSON values. Ideally we should have stored these values
                    // as base64 encoded values to make our life easier. The workaround is to use JSON to parse
                    // and stringify to match our JSON escaped primary key record indetifiers passed through the URL
                    if ( isJSON( recordId ) ) {
                        // this will stop at the first row found which is more efficient than a generic filter
                        // we need to call JSON.parse first to convert escape sequences in the data value e.g. \uXXXX
                        return $( el.find( "tr[data-id]" ).toArray().find( ( row ) =>
                            JSON.stringify( JSON.parse( $( row ).attr( "data-id" ) ) ) === recordId
                        ) );
                    } else {
                        return el.find( `[data-id="${util.escapeCSS( recordId )}"]` );
                    }
                };

                const getChecksumInfo = function( el ) {
                    const tbl$ = el.find( ".a-IRR-table" );
                    return {
                        "salt": tbl$.attr( "data-salt" ),
                        "protected": tbl$.attr( "data-protected" ),
                        "submittable": tbl$.attr( "data-submittable" )
                    };
                };

                $.extend( baseRegion, {
                    type: "InteractiveReport",
                    refresh: function( pKeepPagination = false ) {
                        if ( pKeepPagination ) {
                            scrollYPosition = window.scrollY;
                            for ( const regPos in $( SEL_SCROLLABLE_REGION ) ) {
                                if ( Object.prototype.hasOwnProperty.call( $( SEL_SCROLLABLE_REGION ), regPos )
                                     && $( $( SEL_SCROLLABLE_REGION )[ regPos ] ).scrollTop() > 0 ) {
                                    regionScrollYPositions[ regPos ] = $( $( SEL_SCROLLABLE_REGION )[ regPos ] ).scrollTop();
                                }
                            }
                        }
                        self.refresh( {pKeepPagination} );
                    },
                    getViewName: () => {
                        return self.viewMode === REPORT ? self.options.reportViewMode : self.viewMode;
                    },
                    openInlineChat: function() {
                        self.openInlineChat();
                    },
                    openDialogChat: function() {
                        self.openDialogChat();
                    },
                    closeChat: function() {
                        self.closeChat();
                    },
                    /**
                     * <p>Gets the current record ID being processed</p>
                     * @ignore
                     * @method getCurrentRecordId
                     * @memberOf interactiveReportRegion.prototype
                     * @returns {String} the current record ID being processed
                     */
                    getCurrentRecordId: function () {
                        return self.currentRecordId;
                    },
                    /**
                     * <p>Returns the column values for the given primary key</p>
                     * @ignore
                     * @method getRecordValues
                     * @memberOf interactiveReportRegion.prototype
                     * @returns {Object} an object containing key:value pairs for the column values
                     */
                    getRecordValues: function ( recordId ) {
                        const headerMap = self.options.sessionState.headerMap,
                            record = getRecord( this.element, recordId || this.getCurrentRecordId() ),
                            values = {};
                        for ( const column in headerMap ) {
                            if ( column ) {
                                const dataValue = record.attr( `data-${column.toLowerCase()}` );
                                values[column] = isDefined( dataValue ) ? dataValue + "" : record.find( `[headers~="${headerMap[column]}"]` ).text().trim();
                            }
                        }
                        return values;
                    },
                    /**
                     * <p>Returns the required values for the given list of page items / column names to be
                     * submitted via AJAX and set in session state server-side</p>
                     * @ignore
                     * @method getSessionState
                     * @memberOf interactiveReportRegion.prototype
                     * @param {Array} an array of page item names or report column names
                     */
                    getSessionState: function( itemsToSubmit ) {
                        const headerMap = self.options.sessionState.headerMap,
                            fields = Object.keys( headerMap ),
                            stateConfig = { ...self.options.sessionState, ...getChecksumInfo( this.element ) };

                        let i, checksums,
                            sessionState = {},
                            pageItems = [],
                            columnItems = [];

                        function getChecksums( recordId ) {
                            const record = getRecord( this.element, recordId );
                            let checksumValues = {};
                            if ( typeof record !== "object" ) {
                                return {};
                            }
                            for ( const column in headerMap ) {
                                if ( column ) {
                                    let checksumValue = record.attr( `data-${column.toLowerCase()}-ck` );
                                    if ( checksumValue ) {
                                        checksumValues[column] = checksumValue;
                                    }
                                }
                            }
                            return checksumValues;
                        }

                        // Split out column and page items from itemsToSubmit
                        if ( itemsToSubmit ) {

                            checksums = getChecksums.call( this, this.getCurrentRecordId() );

                            for ( i = 0; i < itemsToSubmit.length; i++ ) {

                                // Check if item is defined in IR column metadata, if so it's a column item, if not assume it's a page item
                                if ( fields.includes( itemsToSubmit[i] ) ) {

                                    let itemDetails = {
                                        "n":  itemsToSubmit[ i ],
                                        "v":  $v( itemsToSubmit[ i ] ) + "", // value will be in memory state
                                        "ck": checksums[ itemsToSubmit[ i ] ]
                                    };
                                    // remove the attribute if it has no value
                                    if ( !itemDetails.ck ) {
                                        delete itemDetails.ck;
                                    }
                                    columnItems.push( itemDetails );

                                } else {
                                    pageItems.push( itemsToSubmit[ i ] );
                                }
                            }
                        }

                        // If there are no column items, just return the page items
                        sessionState.pageItems = pageItems;

                        if ( columnItems.length > 0 ) {

                            // If there are column items, get the current record metadata and return pageItems and the region data
                            sessionState.region = {
                                "id":             stateConfig.regionId,
                                "ajaxIdentifier": self.options.ajaxIdentifier,
                                "setSessionState": {
                                    "values":         columnItems,
                                    "protected":      stateConfig.protected,
                                    "submittable":    stateConfig.submittable,
                                    "salt":           stateConfig.salt
                                }
                            };
                        }
                        return sessionState;
                    },
                    /**
                     * <p>Sets the current record ID for the given primary key, if a record can be located in the report html</p>
                     * @ignore
                     * @method setCurrentRecordId
                     * @memberOf interactiveReportRegion.prototype
                     * @param {String} the primary key value to locate the record
                     */
                    setCurrentRecordId: function ( recordId ) {
                        self.currentRecordId = recordId;
                    },
                    /**
                     * <p>Sets the column data values for the given primary key</p>
                     * @ignore
                     * @method setRecordValues
                     * @memberOf interactiveReportRegion.prototype
                     * @param {String} the primary key value to locate the record
                     * @param {Object} an object containing key:value pairs for the new column values
                     */
                    setRecordValues: function ( recordId, values ) {
                        const headerMap = self.options.sessionState.headerMap,
                            record = getRecord( this.element, recordId );
                        if ( record ) {
                            for ( const [ column, value ] of Object.entries( values ) ) {
                                if ( column ) {
                                    let col = column.toLowerCase(),
                                        attr = `data-${col}`,
                                        dataValue = record.attr( attr ),
                                        cell = record.find( `[headers=${headerMap[column]}]` ),
                                        text = cell.text().trim();
                                    // not all our columns might be in memory state so they might not be in data attributes
                                    // so we need to check the cell text as well
                                    if ( cell.length > 0 && ( ( isDefined( dataValue ) && dataValue ) || text ) !== value ) {
                                        record.attr( attr, value );
                                    }
                                }
                            }
                        }
                    },
                    // not public
                    widget: function() {
                        return self.element;
                    }

                } );

                // add selection related API to region interface
                baseRegion.getListViewSelection = () => {
                    if ( !self.options.selection ) {
                        return;
                    }

                    return self.listViewSelection;
                };
                baseRegion.getSelection = self.listViewSelection ? self.listViewSelection.getSelection.bind( self.listViewSelection ) : () => null;
                baseRegion.setSelection = self.listViewSelection ? self.listViewSelection.setSelection.bind( self.listViewSelection ) : () => {};
                baseRegion.getSelectedValues = self.listViewSelection ? self.listViewSelection.getSelectedValues.bind( self.listViewSelection ) : () => null;
                baseRegion.setSelectedValues = self.listViewSelection ? self.listViewSelection.setSelectedValues.bind( self.listViewSelection ) : () => -1;
                baseRegion.getCurrentRow = self.listViewSelection ? self.listViewSelection.getCurrentItem.bind( self.listViewSelection ) : () => null;
                baseRegion.setCurrentRow = self.listViewSelection ? self.listViewSelection.setCurrentItem.bind( self.listViewSelection ) : () => {};
                baseRegion.selectAll = self.listViewSelection ? self.listViewSelection.selectAll.bind( self.listViewSelection ) : () => {};
                baseRegion.getCurrentRowValue = () => {
                    if ( !self.options.selection ) {
                        return;
                    }

                    const item$ = baseRegion.getCurrentRow();
                    return item$.length ? item$.attr( "data-id" ) : null;
                };
                baseRegion.setCurrentRowValue = ( pValue, pFocus ) => {
                    if ( !self.options.selection ) {
                        return;
                    }

                    const selectionDetails = self._getSelectionDetails(),
                          item$ = selectionDetails.container$.find( `${selectionDetails.itemSelector}[data-id="${util.escapeCSS( pValue )}"]` );
                    baseRegion.setCurrentRow( item$, pFocus );
                };
                baseRegion.focus = () => {
                    let elemToFocus$;

                    // for selection: try to focus current row
                    if ( self.options.selection && self.listViewSelection ) {
                        self.listViewSelection.focus();
                        return;
                    }

                    // otherwise try to focus search field
                    elemToFocus$ = self.element.find( ".a-IRR-search-field" );

                    // else find the first focusable element within the region
                    if ( !( elemToFocus$ && elemToFocus$.length ) ) {
                        elemToFocus$ = self.element.find( ":focusable" ).first();
                    }

                    elemToFocus$.trigger( "focus" );
                };
            } );

            // if we're lazy, make the toolbar invisible, remember that we still need to be loaded
            // (see onVisibilityChange in _initCreate and making the toolbar re-visible in _finishedLoading)
            if ( this.options.lazyLoading ) {
                this.needsLazyLoading = true;

                // If, after all the init processing has completed, we find that we're already visible, refresh immediately
                setTimeout( () => {
                    if ( apex.widget.util.isVisible( lRegion$ ) ) {
                        self.needsLazyLoading = false;
                        self.refresh();
                    }
                },0 );
            }

            if ( this.options.aiEnabled ) {
                const { ChatModel } = ai;
                const { events } = ChatModel;

                const model = new ChatModel( {
                    ajaxId: this.options.ajaxIdentifier,
                    responseHandler: ( model, response ) => {
                        const { type: responseType, messages = [] } = response;
                        const ASSISTANT = ai.ChatModel.roles.ASSISTANT;

                        if ( responseType === "complete" ) {
                            const msgsWithToolCalls = messages.find( msg => msg.role === ASSISTANT && msg.toolCalls?.length );
                            if ( msgsWithToolCalls ) {
                                // Keep a visible spinner for the report refresh, but suppress spinner ARIA live
                                // announcements so they don't interrupt the assistant message announcement.
                                this.refresh( { pA11yQuietSpinner: true } );
                            }
                            else if ( !this.chatView ) {
                                this.pendingAutoOpenInlineChat = true;
                            }
                        }
                    }
                } );

                [
                    events.LOCK,
                    events.COMMIT_SUCCESS,
                    events.COMMIT_ABORT,
                    events.COMMIT_ERROR,
                    events.MESSAGE_ADDED,
                    events.NOTIFICATION_ADDED,
                    events.CLEAR
                ].forEach( eventName => {
                    model.on( eventName, this._onChatModelEvent, { scope: this } );
                } );

                this.chatModel = model;
                this.chatTranscriptScrollState = null;
                this.pendingAutoOpenInlineChat = false;

                const chatContainerEl = document.createElement( "div" );
                chatContainerEl.classList.add( C_INLINE_CHAT_CONTAINER );

                const chatInnerEl = document.createElement( "div" );
                chatInnerEl.classList.add( "a-ChatInnerContainer" );
                chatInnerEl.setAttribute( "role", "region" );
                chatInnerEl.setAttribute( ARIA_LABEL, MSG.AI_INLINE_CHAT_VIEW.TITLE );

                this.element.append( chatContainerEl );
                chatContainerEl.append( chatInnerEl );

                this.chatContainerEl$ = $( chatContainerEl );
                this.chatInnerEl$ = $( chatInnerEl );

                this._createInlineChatToolbar();

                // Observe whether the size of the element changed due to something we don't listen to. If so, resize the chat element.
                this.resizeObserver = new ResizeObserver( () => {
                    this._invalidateInlineChatLayoutCache();
                    this._fitInlineChatView();

                } );
                this.resizeObserver.observe( this._getElement( "full_view" )[0] );
                this.resizeObserver.observe( this._getElement( "single_row_view" )[0] );

                // We are going to track whether the IR is visible in the viewport and resize the chat element only if it is.
                this.isIntersectingViewport = true;
                this.intersectionObserver = new IntersectionObserver( entries => {
                    this.isIntersectingViewport = entries[0].isIntersecting;
                } );
                this.intersectionObserver.observe( this.element[0] );

                const scrollParent$ = this.element.scrollParent();
                const scrollParent = scrollParent$[0];
                // scrollParent() can return document as the scroll container (browser dependent / not consistently window).
                // In that case we already listen on window scroll below, and binding to document would be redundant.
                if ( scrollParent !== window && scrollParent !== document ) {
                    scrollParent$.on( "scroll", () => {
                        this._fitInlineChatView();
                    } );
                }

                $( window ).on( "scroll", () => {
                    if ( this.isIntersectingViewport ) {
                        this._fitInlineChatView();
                    }
                } );

                $( window ).on( "apexwindowresized", () => {
                    if ( this.isIntersectingViewport ) {
                        this._invalidateInlineChatLayoutCache();
                        this._fitInlineChatView();
                    }
                } );
            }
        },

        _initChatButton: function () {
            if ( this.options.aiEnabled ) {
                this.chatBtn$ = $( ".a-IRR-chatButton", this._getElement( "toolbar_controls" ) );
                this.chatUnreadBadge$ = $( ".a-ChatNotification-icon", this.chatBtn$ );
                this._syncChatButtonUnreadState();
            }
        },

        _syncChatButtonUnreadState: function() {
            if ( !this.chatBtn$?.length || !this.chatUnreadBadge$?.length ) {
                return;
            }

            const unreadBadgeEl = this.chatUnreadBadge$[0];
            const unreadBadgeId = unreadBadgeEl.id || this._getId( "chat_unread_badge" );
            const hasUnreadMessages = !!this.hasUnreadChatMessages;

            unreadBadgeEl.id = unreadBadgeId;
            this.chatUnreadBadge$.toggleClass( C_HIDDEN, !hasUnreadMessages );

            if ( hasUnreadMessages ) {
                this.chatUnreadBadge$
                    .attr( ARIA_LABEL, MSG.BUTTON.ARIA_CHAT_NEW_MESSAGE )
                    .attr( "role", "img" );

                this.chatBtn$.attr( ARIA_DESCRIBEDBY, unreadBadgeId );
            } else {
                this.chatUnreadBadge$
                    .removeAttr( ARIA_LABEL )
                    .removeAttr( "role" );

                this.chatBtn$.removeAttr( ARIA_DESCRIBEDBY );
            }
        },

        _createInlineChatToolbar: function () {
            const toolbarEl = document.createElement( "div" );

            const toolbarTitleEl = document.createElement( "h2" );
            toolbarTitleEl.classList.add( "a-ChatHeader-title" );
            toolbarTitleEl.textContent = MSG.AI_INLINE_CHAT_VIEW.TITLE;

            const closeBtnEl = document.createElement( "button" );
            closeBtnEl.classList.add( "a-ChatHeaderActions", "a-ChatHeaderActions--close", "a-Button", "a-IRR-button" );
            closeBtnEl.setAttribute( "type", "button" );
            closeBtnEl.setAttribute( TITLE, MSG.BUTTON.ARIA_CHAT_CLOSE );
            closeBtnEl.setAttribute( ARIA_LABEL, MSG.BUTTON.ARIA_CHAT_CLOSE );

            const closeIconEl = document.createElement( "span" );
            closeIconEl.classList.add( "a-Icon", "icon-tab-close" );
            closeBtnEl.append( closeIconEl );

            const openModalChatBtnEl = document.createElement( "button" );
            openModalChatBtnEl.classList.add( "a-ChatHeaderActions", "a-ChatHeaderActions--openModal", "a-Button", "a-IRR-button" );
            openModalChatBtnEl.setAttribute( "type", "button" );
            openModalChatBtnEl.setAttribute( TITLE, MSG.BUTTON.ARIA_CHAT_DETACH );
            openModalChatBtnEl.setAttribute( ARIA_LABEL, MSG.BUTTON.ARIA_CHAT_DETACH );

            const dialogIconEl = document.createElement( "span" );
            dialogIconEl.classList.add( "a-Icon", "icon-open-in-dialog" );
            openModalChatBtnEl.append( dialogIconEl );

            closeBtnEl.addEventListener( "click", () => {
                this.closeChat();
            } );

            openModalChatBtnEl.addEventListener( "click", () => {
                this.openDialogChat();
                this.chatBtn$.hide();
            } );

            toolbarEl.append( toolbarTitleEl );
            toolbarEl.append( openModalChatBtnEl );
            toolbarEl.append( closeBtnEl );

            toolbarEl.classList.add( "a-ChatHeader" );

            this.chatInnerEl$.append( toolbarEl );
        },

        _resetInlineChatViewportStyles: function () {
            this.inlineChatFixedState = null;
            this.chatInnerEl$.css( {
                "block-size": "100%",
                position: "absolute",
                "inset-block-start": 0,
                "inset-inline-start": 0,
                "inline-size": "100%",
                "z-index": ""
            } );
        },

        _fitInlineChatView: function ( minHeight = INLINE_CHAT_MIN_HEIGHT ) {
            if ( this.chatView?.getMode() !== AI_CHATVIEW_INLINE ) {
                return;
            }

            // The mobile drawer layout owns the positioning. Clear any viewport-fit styles that
            // may have been left behind after resizing from desktop fixed mode.
            if ( this.chatContainerEl$.css( "position" ) === "fixed" ) {
                this._resetInlineChatViewportStyles();
                return;
            }

            const transcriptScrollState = this.chatView.getTranscriptScrollStateFromBottom();
            const containerRect = this.chatContainerEl$[0].getBoundingClientRect();

            // Compute visibility once and reuse both height + top offset for inline fit calculations.
            const { visibleHeight, visibleTopOffset, isTopClamped, primaryVisibleSegment } = widget.visibilityMetrics.measureVisibility( this.chatContainerEl$[0], {
                occluderIgnoreSelector: OCCLUSION_EXCLUDE_SELECTOR
            } );

            // If the chat container is fully clipped out of view, do not keep any viewport-pinned
            // styles around. The min-height fallback below is only valid while some part of the IR
            // still intersects the viewport.
            if ( visibleHeight === 0 || !primaryVisibleSegment ) {
                this._resetInlineChatViewportStyles();
                return;
            }

            // outerContainerBottom is the bottom edge of the outer chat container in viewport
            // coordinates. We use it later when the chat is fixed, so the fixed chat never
            // hangs below the IR.
            const outerContainerBottom = Math.round( containerRect.bottom - ( this.inlineChatVerticalInsets || 0 ) );
            const visibleBoundaryTop = Math.round( primaryVisibleSegment[0] );

            // measureVisibility can still report a tiny visible segment here, so the earlier
            // visibleHeight === 0 guard is not enough. Once the IR bottom reaches the effective
            // top visibility boundary (typically the fixed page header bottom), there is no
            // meaningful span left for a viewport-pinned chat. Without this guard, fixed mode can
            // still win, preserve min height, and leave the chat hanging below the header.
            if ( outerContainerBottom <= visibleBoundaryTop ) {
                this._resetInlineChatViewportStyles();
                return;
            }

            // rawHeight is the chat height we would like to use before we apply any extra limits.
            // rawTop is the natural top offset inside the IR container before we round values.
            const rawHeight = this._calculateChatViewHeight( visibleHeight );
            const rawTop = visibleTopOffset;

            // maxAvailableHeight is the full height that the outer chat container can offer.
            // The chat must stay inside this height.
            const maxAvailableHeight = Math.max( 0, this.chatContainerEl$[0].offsetHeight );

            // top is the current top offset of the chat inside the IR container.
            // height is the current chat height.
            // Round values here so later comparisons use stable whole pixels.
            let top = Math.round( rawTop );
            let height = Math.min( maxAvailableHeight, Math.max( 0, Math.round( rawHeight ) ) );

            if ( height < minHeight ) {
                // If the visible chat area is smaller than the preferred minimum height,
                // first try to create more room by moving the chat upward inside the IR.
                const heightShortfall = minHeight - height;

                // We can only move up by at most "top" pixels, because once top reaches 0
                // the chat is already touching the top of its container.
                const topAdjustment = Math.min( heightShortfall, top );

                // Prefer shifting the top edge up first to keep the bottom anchored while the chat nears the viewport bottom.
                top -= topAdjustment;
                height += topAdjustment;

                // If moving upward was not enough, use any remaining free space below.
                // maxContainerHeight is the biggest height the chat can still have at the
                // current top position without leaving the IR container.
                const maxContainerHeight = Math.max( 0, this.chatContainerEl$[0].offsetHeight - top );

                // Grow the height only by the remaining shortfall, but never past the space
                // that the container still has.
                height = Math.min( height + ( heightShortfall - topAdjustment ), maxContainerHeight );
            }

            // Keep the inline chat fully inside the IR container even when the visible report area
            // becomes smaller than the preferred minimum chat height.
            if ( top + height > maxAvailableHeight ) {
                // If the bottom would go below the IR container, move the whole chat up just
                // enough so its bottom sits exactly on the container bottom.
                top = Math.max( 0, maxAvailableHeight - height );
            }

            if ( height > maxAvailableHeight - top ) {
                // Final safety clamp: if the height is still too large for the remaining space,
                // shrink it so it fits exactly between top and the container bottom.
                height = Math.max( 0, maxAvailableHeight - top );
            }

            // shouldUseFixed means the chat should be pinned to the viewport instead of moving
            // with the report content.
            let shouldUseFixed = isTopClamped;
            let fixedTop;
            let fixedHeight;

            if ( !shouldUseFixed && height < minHeight && maxAvailableHeight >= minHeight ) {
                // Special case:
                // The report is still large enough to hold the minimum chat height, but the
                // currently visible part is too small. In that case switch to fixed mode so the
                // chat can keep its minimum height while staying inside the IR bounds.
                shouldUseFixed = true;
                fixedHeight = minHeight;

                // Place the fixed chat so its bottom aligns with the outer container bottom.
                fixedTop = Math.round( outerContainerBottom - fixedHeight );
            }

            if ( shouldUseFixed ) {
                const {
                    paddingInlineStart,
                    paddingInlineEnd,
                    borderInlineStart,
                    borderInlineEnd
                } = this._getInlineChatHorizontalInsets();

                // When the chat becomes fixed we position the inner container against the viewport.
                // We therefore need the width of the *content box* of the outer container, not the
                // full border box from getBoundingClientRect(), otherwise the fixed inner chat can
                // end up a few pixels too wide and overlap the outer border.
                const fixedLeft = Math.round( containerRect.left + borderInlineStart + paddingInlineStart );
                const fixedContentWidth = Math.max(
                    0,
                    Math.round(
                        containerRect.width
                        - borderInlineStart
                        - borderInlineEnd
                        - paddingInlineStart
                        - paddingInlineEnd
                    )
                );

                // Use the canonical primaryVisibleSegment from visibilityMetrics rather than a raw
                // segment array entry so Firefox sticky/fixed transition slivers don't briefly force
                // the stuck top to 0px.
                if ( fixedTop == null ) {
                    // If we did not already compute a fixed top, use the visible top segment.
                    // If that is not available, fall back to the container top plus the current
                    // local offset.
                    fixedTop = primaryVisibleSegment ? Math.round( primaryVisibleSegment[0] ) : containerRect.top + top;
                }

                if ( fixedHeight == null ) {
                    // Use at least the minimum height in fixed mode. If the measured visible
                    // height is larger, keep that larger value.
                    fixedHeight = Math.max( minHeight, Math.max( 0, Math.round( rawHeight ) ) );

                    // Keep the required minimum height and move the top upward when necessary so the
                    // bottom never extends past the IR container.
                    if ( fixedTop + fixedHeight > outerContainerBottom ) {
                        // If the fixed chat would hang below the IR, move it upward until its
                        // bottom aligns with the IR bottom.
                        fixedTop = Math.round( outerContainerBottom - fixedHeight );
                    }
                }

                // Store the fixed-state values so they can be applied directly to CSS.
                if ( !this.inlineChatFixedState ) {
                    this.inlineChatFixedState = {
                        top: fixedTop,
                        left: fixedLeft,
                        width: fixedContentWidth,
                        height: fixedHeight
                    };
                } else {
                    this.inlineChatFixedState.top = fixedTop;
                    this.inlineChatFixedState.left = fixedLeft;
                    this.inlineChatFixedState.width = fixedContentWidth;
                    this.inlineChatFixedState.height = fixedHeight;
                }
            } else {
                this.inlineChatFixedState = null;
            }

            const fixedState = this.inlineChatFixedState;

            // block-size is the chat height.
            // In fixed mode it comes from the fixed state.
            // In non-fixed mode it comes from the local height inside the IR container.
            // inset-block-start is the top offset in both modes:
            // - fixed mode: viewport top for the fixed chat
            // - non-fixed mode: relative top offset inside the IR container
            const css = {
                "block-size": shouldUseFixed ? fixedState.height : height,
                // Keep desktop inline chat out of document flow in both modes so a temporary
                // fixed/non-fixed handoff cannot resize the IR row and create white space.
                position: shouldUseFixed ? "fixed" : "absolute",
                "inset-block-start": shouldUseFixed ? fixedState.top : top
            };

            if ( shouldUseFixed ) {
                // In fixed mode also set the horizontal position and width, otherwise the chat
                // would no longer line up with the IR container.
                css["inset-inline-start"] = fixedState.left;
                css["inline-size"] = fixedState.width;
                css["z-index"] = "1";
            } else {
                // These properties are only needed in fixed mode. Clear them when we return to
                // non-fixed mode, but keep the chat anchored to the local sidebar width while
                // staying out of document flow.
                css["inset-inline-start"] = 0;
                css["inline-size"] = "100%";
                css["z-index"] = "";
            }

            this.chatInnerEl$.css( css );

            // Preserve the transcript's relative position from the bottom as the inline chat is refit.
            this.chatView.scrollTranscriptToStateFromBottom( transcriptScrollState, { behavior: "instant" } );
        },

        _invalidateInlineChatLayoutCache: function () {
            this.inlineChatHorizontalInsets = null;
            this.inlineChatVerticalInsets = null;
        },

        _getInlineChatHorizontalInsets: function () {
            if ( this.inlineChatHorizontalInsets == null ) {
                const containerStyle = getComputedStyle( this.chatContainerEl$[0] );
                const toNum = value => Number.parseFloat( value ) || 0;

                this.inlineChatHorizontalInsets = {
                    paddingInlineStart: toNum( containerStyle.paddingInlineStart || containerStyle.paddingLeft ),
                    paddingInlineEnd: toNum( containerStyle.paddingInlineEnd || containerStyle.paddingRight ),
                    borderInlineStart: toNum( containerStyle.borderInlineStartWidth || containerStyle.borderLeftWidth ),
                    borderInlineEnd: toNum( containerStyle.borderInlineEndWidth || containerStyle.borderRightWidth )
                };
            }

            return this.inlineChatHorizontalInsets;
        },

        _focusInlineChatView: function( focusTarget = INLINE_CHAT_FOCUS_TARGET.INPUT ) {
            if ( this.chatView?.getMode() !== AI_CHATVIEW_INLINE ) {
                return;
            }

            const closeButtonEl = this.chatInnerEl$[0].querySelector( SEL_INLINE_CHAT_CLOSE_BUTTON );
            const textAreaEl = this.chatView.el.querySelector( SEL_INLINE_CHAT_INPUT );

            // conditional check for the els is not really necessary but we are executing this in a rAF
            // so defensively adding it
            if ( focusTarget === INLINE_CHAT_FOCUS_TARGET.CLOSE_BUTTON ) {
                closeButtonEl?.focus( { preventScroll: true } );
            } else {
                textAreaEl?.focus( { preventScroll: true } );
            }
        },

        _calculateChatViewHeight: function ( visibleHeight ) {
            const el = this.chatContainerEl$[0];
            const fullViewEl = this._getElement( "full_view" )[0];
            const singleRowEl = this._getElement( "single_row_view" )[0];
            const irHeight = Math.max( fullViewEl.offsetHeight, singleRowEl.offsetHeight );

            // we might need to account for borders and paddings but we will cache the value
            if ( this.inlineChatVerticalInsets == null ) {
                const cs = getComputedStyle( el );
                const toNum = v => Number.parseFloat( v ) || 0;
                this.inlineChatVerticalInsets = toNum( cs.paddingTop ) + toNum( cs.paddingBottom ) + toNum( cs.borderTopWidth ) + toNum( cs.borderBottomWidth );
            }

            // just a defensive clamp cos of possible sub-pixel values from measureVisibleHeight
            const clampedVisibleHeight = Math.min( visibleHeight, el.offsetHeight );
            const availableHeight = clampedVisibleHeight - this.inlineChatVerticalInsets;

            return Math.max( 0, Math.min( availableHeight, irHeight ) );
        },

        _saveChatTranscriptScrollState: function () {
            if ( this.chatView ) {
                this.chatTranscriptScrollState = this.chatView.getTranscriptScrollStateFromBottom();
            }
        },

        _restoreChatTranscriptScrollState: function () {
            if ( this.chatView && this.chatTranscriptScrollState != null ) {
                this.chatView.scrollTranscriptToStateFromBottom( this.chatTranscriptScrollState, { behavior: "instant" } );
            }
        },

        _clearChatTranscriptScrollState: function () {
            this.chatTranscriptScrollState = null;
        },

        _destroyChatView: function () {
            this.chatView.destroy();
            this.chatView = null;
            this.chatBtn$.show();
            this.chatBtn$[0].focus( { preventScroll: true } );
        },

        _lockSearchField: function () {
            this.ariaProcessingHandler = message.ariaProcessing( { finishedMsgType: "polite" } );
            this._getElement( "search_field" )
                .addClass( [C_SEARCH_FIELD_AI_PROCESSSING, C_JS_ACCESSIBLE_READONLY] )
                .attr( ARIA_READONLY, true );
            this._getElement( "voice_search" ).prop( "disabled", true );
        },

        _unlockSearchField: function () {
            this._getElement( "search_field" )
                .removeClass( [C_SEARCH_FIELD_AI_PROCESSSING, C_JS_ACCESSIBLE_READONLY] )
                .removeAttr( ARIA_READONLY );
            this._getElement( "voice_search" ).prop( "disabled", false );
            message.ariaProcessed( this.ariaProcessingHandler, { finishedMsgType: "polite" } );
        },

        _clearSearchField: function () {
            this._getElement( "search_field" ).val( "" );
        },

        _onChatModelEvent: function ( e, arg ) {
            const { events } = ai.ChatModel;
            switch ( e.type ) {

                case events.LOCK:
                    this._lockSearchField();
                    break;

                case events.COMMIT_SUCCESS:
                    this._unlockSearchField();
                    this._clearSearchField();
                    if ( this.pendingAutoOpenInlineChat && !this.chatView ) {
                        this.openInlineChat( INLINE_CHAT_FOCUS_TARGET.INPUT, { restoreTranscriptOffset: false } );
                    }
                    this.pendingAutoOpenInlineChat = false;
                    break;

                case events.COMMIT_ABORT:
                    this._unlockSearchField();
                    this._clearSearchField();
                    this.pendingAutoOpenInlineChat = false;
                    break;

                case events.COMMIT_ERROR:
                    this._unlockSearchField();
                    this.pendingAutoOpenInlineChat = false;
                    if ( !this.chatView ) {
                        this.openInlineChat( INLINE_CHAT_FOCUS_TARGET.INPUT, { restoreTranscriptOffset: false } );
                    }
                    break;

                case events.CLEAR:
                    this.pendingAutoOpenInlineChat = false;
                    this.hasUnreadChatMessages = false;
                    this._syncChatButtonUnreadState();
                    this._clearChatTranscriptScrollState();
                    break;

                case events.MESSAGE_ADDED: {
                    const msgModel = arg;
                    if ( !msgModel.user.isAi && !this.chatView ) {
                        // A fresh user prompt should reopen the inline transcript on the latest content.
                        this._clearChatTranscriptScrollState();
                    }
                    this._maybeShowChatUnreadBadge( msgModel );
                    break;
                }

                case events.NOTIFICATION_ADDED: {
                    const notifModel = arg;
                    if ( !this.chatView ) {
                        // A fresh notification should reopen the inline transcript on the latest content.
                        this._clearChatTranscriptScrollState();
                    }
                    this._maybeShowChatUnreadBadge( notifModel );
                    break;
                }
            }
        },

        /**
         * Shows a little badge icon on the assistant button if the conditions are met:
         * - an AI message has been added which is not hidden OR a notification has been added
         * - AND there is no open chat view
         *
         * @ignore
         * @param {ai.MessageModel|ai.NotificationModel} itemModel The item that was added to the chat model.
         */
        _maybeShowChatUnreadBadge: function ( itemModel ) {
            const show = ( itemModel instanceof ai.MessageModel && itemModel.user.isAi && !itemModel.hidden ) || itemModel instanceof ai.NotificationModel;
            if ( show && !this.chatView ) {
                this.hasUnreadChatMessages = true;
                this._syncChatButtonUnreadState();
            }
        },

        _destroy: function () {
            this.resizeObserver?.unobserve( this._getElement( "full_view" )[0] );
            this.resizeObserver?.unobserve( this._getElement( "single_row_view" )[0] );

            this.chatView?.destroy();
            this.chatModel?.destroy();

            this._getElement( "worksheet_region" ).removeClass( C_IRR );
            apex.region.destroy( this.options.regionId );
        },

        _setOption: function ( key, value ) {
            this._super( key, value );
        },

        /*
         * Private functions
         */

        /**
         * The basic AJAX call for ACTIONs for the IR, just a wrapper around _get
         * @ignore
         * @function _action
         * */
        _action: function( pAction, pData ) {
            var lData = $.extend( {
                widgetMod:      "ACTION",
                widgetAction:   pAction
            }, pData );
            this._get( lData );
        },

        /**
         * Delete an Aggregation
         * @ignore
         */
        _aggregateClear: function( pAggregate ) {
            this._action( "DELETE_AGGREGATE", {
                id: pAggregate
            } );
        },
        /**
         * Controls any adjustments needed when displaying aggregate control
         * @ignore
         */
        _aggregateControl: function() {
            var lAggregateBy = this._getDialogElement( "aggregate_by" ).val(),
                lIsAllColumns = ( $.inArray( lAggregateBy, [ "COUNT", "COUNT_DISTINCT" ] ) !== -1 );
            this._getDialogElement( "all_columns_container" ).toggle( lIsAllColumns );
            this._getDialogElement( "number_columns_container" ).toggle( !lIsAllColumns );
        },
        /**
         * Save an aggregate on report
         * @ignore
         */
        _aggregateSave: function() {
            var lColumn,
                lAggregateBy = this._getDialogElement( "aggregate_by" ).val(),
                lAggregation = this._getDialogElement( "aggregation" ).val();
            if ( $.inArray( lAggregateBy, [ "COUNT", "COUNT_DISTINCT" ] ) !== -1 ) {
                lColumn = this._getDialogElement( "all_columns" ).val();
            } else {
                lColumn = this._getDialogElement( "number_columns" ).val();
            }
            this._action( "SAVE_AGGREGATE", {
                id:     lAggregation,
                value:  lAggregateBy,
                x05:    lColumn
            } );
        },

        /**
         * @ignore
         * @namespace
         */
        _chartClear: function() {
            this.options.reportViewMode = REPORT;
            this._action( "DELETE_CHART" );
        },
        /**
         * Toggles the chart attributes that are not required for pie charts
         * @ignore
         * @function _chartControl
         * */
        _chartControl: function() {
            var chartControls$ = $( ".a-IRR-dialogCol." + C_JS_NO_PIE, this._getElement( DIALOG_JS_ID ) ).find( "input, select" );
            if ( this._getDialogElement( "chart_type_2" ).prop( CHECKED ) ) {
                chartControls$.prop( "disabled",true );
                chartControls$.filter( "input" ).val( "" );
                chartControls$.addClass( "is-disabled" );
            } else {
                chartControls$.prop( "disabled",false );
                chartControls$.removeClass( "is-disabled" );
            }
        },
        /**
         * calls SAVE_CHART action with the items posted to the f01 array in the order listed
         * @ignore
         * @function
         */
        _chartSave: function() {
            this._action( "SAVE_CHART", {
                f01: this._utilGetFormElValues( [ this._getId( "chart_type" ),
                                                  this._getId( "chart_label" ),
                                                  this._getId( "chart_value" ),
                                                  this._getId( "aggregate_by" ),
                                                  this._getId( "label_axis_title" ),
                                                  this._getId( "value_axis_title" ),
                                                  this._getId( "sort" ),
                                                  this._getId( "orientation" ) ] )
            } );
        },
        /**
         * calls SAVE_CHART action with the items posted to the f01 array in the order listed
         * @ignore
         * @function
         */
        _chartView: function() {
            this._action( "VIEW_CHART" );
        },

        /**
         * Applies quick sort and order dialog
         * @ignore
         * @function
         * */
        _columnOrder: function( pDirection ) {
            var lFArrays;
            if( pDirection === ASC || pDirection === DESC ) {
                this._action( "COLUMN_ORDER", {
                    f01: this.lastColumnId,
                    f02: pDirection
                } );
            } else {
                lFArrays = this._utilGetFormElAttributes();
                this._action( "SORT", {
                    f01: lFArrays.ids,
                    f02: lFArrays.values
                } );
            }
        },
        /**
         * Select Columns: Gets the current selected columns from the column shuttle and issues the Ajax call to update the report
         * @ignore
         * @function
         **/
        _columnDisplay: function() {
            var lOptionValues = [];
            this._getDialogElement( "shuttle_right" ).find( "option" ).each( function() {
                lOptionValues.push( this.value );
            } );
            this._action( "SET_COLUMNS", {
                f01: lOptionValues
            } );
        },
        /**
         * @ignore
         * */
        _columnHelp: function() {
            this._controlsGet( "INFO", this.currentColumnId );
        },
        /**
         * Hides a column
         *
         * @ignore
         * */
        _columnHide: function( pColumnId ) {
            var lValue;
            if ( pColumnId ) {
                lValue = pColumnId;
            } else {
                lValue = this.currentColumnId;
            }
            this._action( "HIDE", {
                id: lValue
            } );
        },
        /**
         * Shows the column search drop down by completing the async fetch menu processing
         * @ignore
         **/
        _columnSearchShow: function ( pData ) {
            var i, lIsRowSearch, lIsAISearch, lItems = [], lChoices = [],
                that = this,
                lRows = JSON.parse( pData ).row;

            for ( i = 0; i < lRows.length; i++ ) {
                lIsRowSearch = ( lRows[ i ].C === "0" );
                lIsAISearch  = ( lRows[ i ].C === "2" );

                if ( lIsRowSearch ) {

                    // For "Row Search", add a regular "action" menu item and a separator
                    lItems.push( {
                        type: ACTION, label: lRows[ i ].D, value: lRows[ i ].R, action: function() {
                            that.element.removeClass( [ C_SEARCH_MODE.AI, C_SEARCH_MODE.COLUMN ] ).addClass( C_SEARCH_MODE.ROW );
                            that._initToolbarStyles();
                            that._action( "UPDATE_SEARCH_MODE", {
                                x06: C_SEARCH_MODE.ROW
                            } );
                        }
                    } );
                    lItems.push( { type: "separator" } );
                } else if ( lIsAISearch ) {

                    // For "Search with AI", add a regular "action" menu item and a separator
                    lItems.push( {
                        type: ACTION, label: lRows[ i ].D, value: lRows[ i ].R, action: function() {
                            that.element.removeClass( [ C_SEARCH_MODE.ROW, C_SEARCH_MODE.COLUMN ] ).addClass( C_SEARCH_MODE.AI );
                            that._initToolbarStyles();
                            that._action( "UPDATE_SEARCH_MODE", {
                                x06: C_SEARCH_MODE.AI
                            } );
                        }
                    } );
                } else {

                    // For other columns, add a choice to be used in a radioGroup item
                    lChoices.push ( { label: lRows[ i ].D, value: lRows[ i ].R } );
                }
            }
            lItems.push( {
                type: "radioGroup",
                get: function() {
                    return that._getElement( "column_search_current_column" ).val();
                },
                set: function( pValue ) {
                    var lLabel, lValue,
                        lChoices = this.choices;

                    // Loop through choices to find current selected choice
                    for ( i = 0; i < lChoices.length; i++ ) {
                        if ( lChoices[ i ].value === pValue ) {
                            that.element.removeClass( [ C_SEARCH_MODE.AI, C_SEARCH_MODE.ROW ] ).addClass( C_SEARCH_MODE.COLUMN );
                            that._initToolbarStyles();
                            lLabel = formatNoEscape( "SEARCH_COLUMN", lChoices[ i ].label );
                            lValue = lChoices[ i ].value;
                            that._getElement( "column_search_current_column" ).val( lValue );
                            that._getElement( "search_field" ).attr( { placeholder: lLabel } );
                            break;
                        }
                    }
                },
                choices: lChoices
            } );
            this.searchMenu.items = lItems;
            this.searchMenuCallback();
            this.searchMenuCallback = null;
            this.searchMenu = null;
        },

        /**
         * @ignore
         */
        _computationClear: function() {
            this._action( "DELETE_COMPUTATION", {
                id: this._getDialogElement( "comp_id" ).val()
            } );
        },
        /**
         * Part 1 : save computation this is a 2 part process first to see if the computation is valid then show messaging
         * or to repull the report
         * @function
         * @ignore
         **/
        _computationSave: function() {
            var lValidate = $f_get_emptys( [ this._getId( "column_heading" ),this._getId( "computation_expr" ) ], "error", "" );
            if( lValidate ) {
                return;
            }
            this._action( "SAVE_COMPUTATION", {
                id:     this._getDialogElement( "comp_id" ).val(),
                value:  this._getDialogElement( "column_heading" ).val(),
                x06:    this._getDialogElement( "format_mask" ).val(),
                x07:    this._getDialogElement( "computation_expr" ).val()
            } );
        },
        /**
         * Opens the computation dialog
         * @ignore
         * @function
         */
        _computationShow: function( pId ) {
            var lId;
            if ( pId ) {
                lId = pId;
            } else {
                lId = this.computationId;
            }
            this._controlsGet( SHOW_COMPUTATION, lId );
            this.computationId = null;
        },

        /**
         * Apply column break on a column
         * @ignore */
        _controlBreakOn: function( pColumnId ) {
            if( pColumnId ) {
                this.currentColumnId = pColumnId;
            }
            this._action( "BREAK", {
                id: this.currentColumnId
            } );
        },
        /**
         * Applies control break dialog settings
         * @ignore
         * @function
         * */
        _controlBreakSave: function() {
            var i, lIds = [];
            for ( i = 1; i < 7; i++ ) {
                lIds.push( this._getId( "column" ) + "_0" + i );
                lIds.push( this._getId( "enable" ) + "_0" + i );
            }
            this._action( "SAVE_BREAK", {
                f01:    lIds,
                f02:    this._utilGetFormElValues( lIds )
            } );
        },
        _controlBreakToggle: function ( pColumn, pChecked ) {
            this._action( "BREAK_TOGGLE", {
                id:     pColumn,
                value:  pChecked
            } );
        },

        /**
         * Pulls a Format Mask dropdown
         * @ignore
         * @function
         */
        _controlsFormatMask: function( pID ) {
            this.tempReturnElement$ = $( getIdSelector( pID ) );
            this._controlsGet( "FORMAT_MASK_LOV" );
        },
        /**
         * Central call to get a control (used for dialogs and other popups such as sort widget)
         * @ignore
         * @param {String} pControl
         * @param {String} pID
         *
         * @function
         **/
        _controlsGet: function( pControl, pID ) {
            this._dialogReset();
            if( pID ) {
                this.currentColumnId = pID;     //todo seems incorrect, pID not always the column ID (eg show_computation; computation id)
            }
            this._get( {
                widgetMod:          "CONTROL",
                widgetAction:       pControl,
                id:                 pID
            } );
        },

        /**
         * Pulls a Narrow Filter dropdown on a text area
         * @ignore
         * @function
         */
        _controlsNarrow: function( pID ) {
            this.tempReturnElement$ = $( getIdSelector( pID ) );
            this._controlsGet( "NARROW", this._getDialogElement( "column_name" ).val() );
        },
        /**
         * Loads single row view for a specific row
         * @ignore
         * */
        _controlsRow: function( pRowId ) {
            this._controlsGet( "SHOW_DETAIL", pRowId );
        },

        /**
         * Checks if a click event happens outside of a container, and if so...
         * @ignore
         * */
        _dialogCheck: function( pContainer, pCallback ) {
            var lContainer = "." + C_IRR_SORT_WIDGET,
                lCallback = this._dialogReset;
            if ( pContainer ) {
                lContainer = pContainer;
            }
            if ( pCallback ) {
                lCallback = pCallback;
            }
            this._on( this.document, {
                click: function( pEvent ) {
                    if ( !$( pEvent.target ).closest( lContainer ).length ) {
                        lCallback.call( this );
                    }
                },
                dragstart: function( pEvent ) {
                    if ( !$( pEvent.target ).closest( lContainer ).length ) {
                        lCallback.call( this );
                    }
                }
            } );
        },
        /**
         * used for Interactive report filter and computation dialog
         *
         * @ignore
         **/
        _dialogComp: function( pItem, pValue ) {
            var lSpace = ( !( isNaN( pValue ) ) || pValue === "." );
            html_ReturnToTextSelection( pValue + "", pItem, lSpace );
        },
        /**
         * Get a jQuery element containing the current operator element for the column filter control set
         * @ignore
         */
        _dialogCurrentOperator: function() {
            var lColumn$ = this._getDialogElement( "column_name" ),
                lColumnType = $( lColumn$.find( "option" )[ lColumn$.prop( "selectedIndex" ) ] ).attr( "class" );
            return this._getDialogElement( lColumnType + "_OPT" );
        },
        /**
         * Checks that proper operator select list is shown for filter and highlight dialogs
         *
         * @ignore
         * */
        _dialogColumnCheck: function() {
            var lCurrentOperator$ = this._dialogCurrentOperator();
            var lOperatorContainer$ = lCurrentOperator$.parents( ".u-Form-fieldContainer" );
            $( lOperatorContainer$ )
                .siblings()
                .hide()
                .end()
                .show();
            this._dialogOperatorCheck( lCurrentOperator$ );
        },
        /**
         * This function is the central control to display modal dialog
         * @ignore
         * @function
         */
        _dialogOpen: function( currentControl, pInit ) {
            var lIRRDlg$, lTitle, lId, lError, lButtons,
                lMinHeight = 0,
                lWidth = 720,
                lDialogClass = "",
                that = this,
                regionDialog$ = this._getElement( DIALOG_JS_ID );
            lButtons = [{
                text  : MSG.BUTTON.CANCEL,
                click : function() {
                    that._getElement( DIALOG_JS_ID ).dialog( "close" );
                }
            }];

            function displayButton( pId, pAction, pLabel, pHot, pClose ) {
                var lLabel, lStyle;
                if ( pLabel ) {
                    lLabel = pLabel;
                } else {
                    lLabel = MSG.BUTTON.APPLY;
                }
                if ( pHot ) {
                    lStyle = C_UI_BUTTON_HOT;
                }
                lButtons.push( {
                    text  : lLabel,
                    "class" : lStyle,
                    click : function() {
                        if ( pId ) {
                            pAction.call( that, pId );
                        } else {
                            pAction.call( that );
                        }
                        if ( pClose ) {
                            that._getElement( DIALOG_JS_ID ).dialog( "close" );
                        }
                    }
                } );
            }
            switch ( currentControl ) {
                case SHOW_COLUMN:
                    lTitle = MSG.DIALOG_TITLE.SELECT_COLUMNS;
                    lDialogClass = C_IRR_DIALOG + "--selectColumns";
                    lWidth = 480;
                    displayButton( null, that._columnDisplay, null, true, true );
                    break;
                case SHOW_FILTER:
                    lTitle = MSG.DIALOG_TITLE.FILTER;
                    lDialogClass = C_IRR_DIALOG + "--filter";
                    lMinHeight = 230;
                    lId = that._getDialogElement( "filter_id" ).val();
                    if ( lId ) {
                        displayButton( lId, that._filterDelete, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( lId, that._filterSave, null, true, false );
                    break;
                case SHOW_HIGHLIGHT:
                    lTitle = MSG.DIALOG_TITLE.HIGHLIGHT;
                    lDialogClass = C_IRR_DIALOG + "--highlight";
                    lMinHeight = 400;
                    lId = that._getDialogElement( "highlight_id" ).val();
                    if ( lId ) {
                        displayButton( lId, that._highlightClear, MSG.BUTTON.DELETE, false, true );
                    }
                    that._setIRHighlightPreview();
                    displayButton( lId, that._highlightSave, null, true, false );
                    break;
                case SHOW_ORDERING:
                    lTitle = MSG.DIALOG_TITLE.SORT;
                    lDialogClass = C_IRR_DIALOG + "--sort";
                    lWidth = 480;
                    displayButton( this, that._columnOrder, null, true, true );
                    break;
                case SHOW_CTRL_BREAK:
                    lTitle = MSG.DIALOG_TITLE.CONTROL_BREAK;
                    lDialogClass = C_IRR_DIALOG + "--controlBreak";
                    lWidth = 480;
                    displayButton( null, that._controlBreakSave, null, true, true );
                    break;
                case SHOW_COMPUTATION:
                    lTitle = MSG.DIALOG_TITLE.COMPUTATION;
                    lDialogClass = C_IRR_DIALOG + "--computation";
                    lId = that._getDialogElement( "comp_id" ).val();
                    if ( lId ) {
                        displayButton( null, that._computationClear, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._computationSave, null, true, false );
                    break;
                case SHOW_AGGREGATE:
                    lTitle = MSG.DIALOG_TITLE.AGGREGATE;
                    lDialogClass = C_IRR_DIALOG + "--aggregate";
                    lWidth = 480;
                    lId = that._getDialogElement( "aggregation" ).val();
                    if ( lId ) {
                        displayButton( lId, that._aggregateClear, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._aggregateSave, null, true, true );
                    break;
                case SHOW_CHART:
                    lTitle = MSG.DIALOG_TITLE.CHART;
                    lDialogClass = C_IRR_DIALOG + "--chart";
                    lWidth = 480;
                    lId = that._getDialogElement( "chart_type_hidden" ).val();
                    if ( lId ) {
                        displayButton( null, that._chartClear, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._chartSave, null, true, false );
                    break;
                case SHOW_GROUP_BY:
                    lTitle = MSG.DIALOG_TITLE.GROUP_BY;
                    lDialogClass = C_IRR_DIALOG + "--groupBy";
                    lWidth = 720;
                    lId = that._getDialogElement( "group_by_id" ).val();
                    if ( lId ) {
                        displayButton( null, that._groupByRemove, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._groupBySave, null, true, false );
                    break;
                case SHOW_GROUP_BY_SORT:
                    lTitle = MSG.DIALOG_TITLE.GROUP_BY_SORT;
                    lDialogClass = C_IRR_DIALOG + "--groupBySort";
                    lWidth = 480;
                    displayButton( this, that._groupBySort, null, true, true );
                    break;
                case SHOW_PIVOT:
                    lTitle = MSG.DIALOG_TITLE.PIVOT;
                    lDialogClass = C_IRR_DIALOG + "--pivot";
                    lWidth = 720;
                    lId = that._getDialogElement( "pivot_id" ).val();
                    if ( lId ) {
                        displayButton( null, that._pivotRemove, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._pivotSave, null, true, false );
                    break;
                case SHOW_PIVOT_SORT:
                    lTitle = MSG.DIALOG_TITLE.PIVOT_SORT;
                    lDialogClass = C_IRR_DIALOG + "--pivotSort";
                    displayButton( this, that._pivotSort, null, true, true );
                    break;
                case SHOW_FLASHBACK:
                    lTitle = MSG.DIALOG_TITLE.FLASHBACK;
                    lDialogClass = C_IRR_DIALOG + "--flashback";
                    lWidth = 480;
                    lId = that._getDialogElement( "flashback_time" ).val();
                    if ( lId ) {
                        displayButton( null, that._flashbackClear, MSG.BUTTON.DELETE, false, true );
                    }
                    displayButton( null, that._flashbackSave, null, true, false );
                    break;
                case SAVE_REPORT:
                    lTitle = MSG.DIALOG_TITLE.SAVE_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--save";
                    lWidth = 480;
                    displayButton( null, that._save, null, true, false );
                    break;
                case SHOW_RENAME:
                    lTitle = MSG.DIALOG_TITLE.RENAME_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--rename";
                    lWidth = 480;
                    displayButton( that.reportId, that._save, null, true, false );
                    break;
                case SHOW_DELETE:
                    lTitle = MSG.DIALOG_TITLE.DELETE_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--delete";
                    lWidth = 480;
                    displayButton( null, that._remove, null, true, true );
                    break;
                case SHOW_SAVE_DEFAULT:
                    lTitle = MSG.DIALOG_TITLE.SAVE_DEFAULT_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--saveDefault";
                    lWidth = 480;
                    displayButton( null, that._saveDefault, null, true, false );
                    break;
                case SHOW_RENAME_DEFAULT:
                    lTitle = MSG.DIALOG_TITLE.RENAME_DEFAULT_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--renameDefault";
                    lWidth = 480;
                    displayButton( "RENAME_DEFAULT", that._saveDefault, null, true, false );
                    break;
                case SHOW_DELETE_DEFAULT:
                    lTitle = MSG.DIALOG_TITLE.DELETE_DEFAULT_REPORT;
                    lDialogClass = C_IRR_DIALOG + "--deleteDefault";
                    lWidth = 480;
                    displayButton( "DELETE_DEFAULT", that._remove, null, true, true );
                    break;
                case SHOW_RESET:
                    lTitle = MSG.DIALOG_TITLE.RESET;
                    lDialogClass = C_IRR_DIALOG + "--reset";
                    lWidth = 320;
                    displayButton( null, that._reset, null, true, true );
                    break;
                case SHOW_DOWNLOAD:
                    lTitle = MSG.DIALOG_TITLE.DOWNLOAD;
                    lDialogClass = C_IRR_DIALOG + "--download";
                    lWidth = 480;
                    // lButtons = {};
                    displayButton( "DOWNLOAD", that._download, MSG.BUTTON.DOWNLOAD, true, false );
                    break;
                case SHOW_NOTIFY:
                    lTitle = MSG.DIALOG_TITLE.SUBSCRIPTION;
                    lDialogClass = C_IRR_DIALOG + "--subscription";
                    lId = that._getDialogElement( "notify_id" ).val();
                    lError = that._getDialogElement( "email_not_configured" ).text();
                    if ( lId ) {
                        displayButton( null, that._notifyClear, MSG.BUTTON.DELETE, false, true );
                    }
                    if ( !lError ) {
                        displayButton( null, that._notifySave, null, true, false );
                    }
                    break;
            }
            lDialogClass = ( C_IRR_DIALOG + " " + lDialogClass ).trim();
            lIRRDlg$ = regionDialog$.dialog( {
                modal      : true,
                dialogClass: lDialogClass,
                width      : lWidth,
                minHeight  : lMinHeight,
                title      : lTitle,
                buttons    : lButtons,
                show       : "apexDialogShow",
                hide       : "apexDialogHide",
                closeText  : getMsg( "APEX.DIALOG.CLOSE" ),
                position: {
                    my: "left+10 top+10",
                    at: "left top",
                    of: this._getElement( "content" )
                },
                close      : function() {
                    that._off( lIRRDlg$ );
                    lIRRDlg$.dialog( "destroy" );
                }
            } );

            // Post open initialisation specific to the current dialog, if passed
            if ( pInit ) {
                pInit.call();
            }

        },
        _dialogColumnHandlers: function() {
            this._on( this._getDialogElement( "column_name" ), {
                "change": function() {
                    this._dialogColumnCheck();
                }
            } );
            this._on( this._getElement( DIALOG_JS_ID ), {
                "change select.a-IRR-operator": function( pEvent ) {
                    this._dialogOperatorCheck( $( pEvent.target ) );
                },
                "click button.a-IRR-button--menu": function( pEvent ) {
                    var lNarrow = $( pEvent.currentTarget ).data( "picker-for" );
                    this._controlsNarrow( lNarrow );
                }
            } );
        },
        /**
         * This checks that the proper UI is displayed based on operator for filter and highlight dialogs (was dialog.operator_check)
         *
         * @ignore
         * */
        _dialogOperatorCheck: function( pOperator$ ) {
            var lFormatMask,
                lThis = [],
                lValue = pOperator$.val(),
                lColumnType = pOperator$.data( "column-type" ),
                lLastNextStyleOperatorValues = [ "is in the last", "is not in the last", "is in the next", "is not in the next" ];

            lThis[ 0 ] = $x( this._getId( "expression"   )  ).parentNode;
            lThis[ 1 ] = $x( this._getId( "expression2"  )  ).parentNode;
            lThis[ 2 ] = $x( this._getId( "expression3"  )  ).parentNode; // time duration
            lThis[ 3 ] = $x( this._getId( "between_from" )  ).parentNode;
            lThis[ 4 ] = $x( this._getId( "between_to"   )  ).parentNode;
            lThis[ 5 ] = $x( this._getId( "and"          )  );

            $x_Show_Hide( this._getId( "expression_icon_link" ), lThis );

            $x_Hide( lThis[ 5 ] ); // hide and from the beginning

            if ( lValue === "is null" || lValue === "is not null" ) {
                this._getDialogElement( "expression_container" ).hide();
            } else {
                this._getDialogElement( "expression_container" ).show();
                if ( lColumnType === "DATE" && $.inArray( lValue, lLastNextStyleOperatorValues ) === -1 ) {
                    $x_Show( lThis[ 3 ] );
                    lFormatMask = this._getDialogElement( "column_name" ).find( ":selected" ).data( "format-mask" );
                    this._setDateFieldFormatMask( this._getDialogElement( "between_from" ), lFormatMask );
                    this._getDialogElement( "between_from" ).siblings( ".ui-datepicker-trigger" ).addClass( "a-Button a-Button--calendar" );
                    if ( lValue === "between" ) {
                        $x_Show( lThis[ 4 ] );
                        $x_Show( lThis[ 5 ] );
                        this._setDateFieldFormatMask( this._getDialogElement( "between_to" ), lFormatMask );
                        this._getDialogElement( "between_to" ).siblings( ".ui-datepicker-trigger" ).addClass( "a-Button a-Button--calendar" );
                    }
                } else {
                    // Show Expression 1
                    $x_Show( lThis[ 0 ] );
                    if ( lValue === "between" ) {
                        $x_Show( lThis[ 5 ] );
                        $x_Show( lThis[ 1 ] );
                    }
                    if ( $.inArray( lValue, lLastNextStyleOperatorValues ) > -1 ) {
                        $x_Show_Hide( lThis[ 2 ], this._getId( "expression_icon_link" ) ); // expression 3
                    }
                }
            }
        },
        /**
         * Resets dialog and page to no dialog showing
         * @ignore
         * @function _dialogReset
         **/
        _dialogReset: function() {
            if( !this.suppressUpdate ) {
                this.currentColumnId = null;
                this.computationId = null;
                this._off( this.document, "click" );
            }
        },
        /**
         * This returns an object that can be used in dialog validate or highlight save or filter save
         * @ignore
         * @function
         */
        _dialogUtilExpType: function() {
            var l_ob = {};
            l_ob.col = $x( this._getId( "column_name" ) );
            l_ob.col_type = l_ob.col.options[l_ob.col.selectedIndex].className;
            l_ob.col_opt = $x( this._getId( l_ob.col_type + "_OPT" ) );
            l_ob.col_opt_val = $v( l_ob.col_opt );
            if( l_ob.col_type === "DATE" && !( l_ob.col_opt_val==="is in the last" || l_ob.col_opt_val==="is not in the last" || l_ob.col_opt_val==="is in the next" || l_ob.col_opt_val==="is not in the next" ) ){
                l_ob.form_items = [ this._getId( "between_from" ), this._getId( "between_to" ) ];
            }else{
                l_ob.form_items = [ this._getId( "expression" ), this._getId( "expression2" ) ];
            }
            return l_ob;
        },
        _dialogValidate: function() {
            var lTest = [];
            var l_OB = this._dialogUtilExpType();
            switch( true ){
                case ( l_OB.col_opt_val === "between" ):
                    lTest = [ l_OB.form_items[ 0 ], l_OB.form_items[ 1 ] ];
                    break;
                case ( l_OB.col_opt_val === "is null" || l_OB.col_opt_val === "is not null" ):
                    lTest = [];
                    break;
                case ( l_OB.col_opt_val === "is in the last" || l_OB.col_opt_val === "is not in the last" || l_OB.col_opt_val === "is in the next" || l_OB.col_opt_val === "is not in the next" ):
                    lTest = [ l_OB.form_items[0], this._getId( "expression3" ) ];
                    break;
                default:
                    lTest = [ l_OB.form_items[ 0 ] ];
            }
            if( $f_get_emptys( lTest, "error", "" ) ) {
                return false;
            } else {
                return l_OB;
            }
        },

        /**
         * Calls DOWNLOAD action with the items posted to the f01 array in the order listed
         * @ignore
         */
        _download: function() {

            var lIds,
                lRequired = [ this._getId( "download_format" ) ],
                lValidate = $f_get_emptys( lRequired, "error", "" );
            if ( lValidate ) {
                return;
            }
            lIds = [ this._getId( "download_format" ),
                     this._getId( "data_only" ),
                     this._getId( "pdf_page_size" ),
                     this._getId( "pdf_orientation" ),
                     this._getId( "strip_rich_text" ),
                     this._getId( "accessible" ) ];

            this._action( "GET_DOWNLOAD_LINK", {
                f01: lIds,
                f02: this._utilGetFormElValues( lIds )
            } );
        },

        /**
         * Calls SEND_EMAIL action with the items posted to the f01 array in the order listed
         * @ignore
         */
        _emailSend: function() {
            var lIds,
                lRequired = [ this._getId( "email_to" ),
                              this._getId( "download_format" ) ],
                lValidate = $f_get_emptys( lRequired, "error", "" );
            if ( lValidate ) {
                return;
            }
            lIds = [ this._getId( "email_to" ),
                     this._getId( "email_cc" ),
                     this._getId( "email_bcc" ),
                     this._getId( "email_subject" ),
                     this._getId( "email_body" ),
                     this._getId( "download_format" ),
                     this._getId( "data_only" ),
                     this._getId( "pdf_page_size" ),
                     this._getId( "pdf_orientation" ),
                     this._getId( "strip_rich_text" ),
                     this._getId( "accessible" ) ];
            this._action( "SEND_EMAIL", {
                f01: lIds,
                f02: this._utilGetFormElValues( lIds )
            } );

            // Manually close dialog because this control has client-side validation, and we don't automatically close in case there's an error
            this._getElement( DIALOG_JS_ID ).dialog( "close" );

        },
        /** @ignore */
        _emailShow: function() {
            var lButtons,
                that = this,
                lDlgContent$ = this._getElement( DIALOG_JS_ID ),
                lEmailContainer$ = this._getDialogElement( "email" ),
                lEmailButton$ = this._getDialogElement( "email_button" );
            lEmailContainer$.show();
            lEmailButton$.show();
            if ( lEmailButton$.is( ":visible" ) ) {
                lButtons = [{
                    text  : MSG.BUTTON.CANCEL,
                    click : function() {
                        lDlgContent$.dialog( "close" );
                    }
                },
                {
                    text  : MSG.BUTTON.SEND,
                    "class" : C_UI_BUTTON_HOT,
                    click : function () {
                        that._emailSend();
                    }
                }];
                lDlgContent$.dialog( "option", "buttons", lButtons );
            }
        },

        /** @ignore */
        _emailHide: function() {
            var lDlgContent$ = this._getElement( DIALOG_JS_ID ),
                that = this,
                lEmailContainer$ = this._getDialogElement( "email" ),
                lButtons = [{
                    text  : MSG.BUTTON.CANCEL,
                    click : function() {
                        lDlgContent$.dialog( "close" );
                    }
                },
                {
                    text  : MSG.BUTTON.DOWNLOAD,
                    "class" : C_UI_BUTTON_HOT,
                    click : function () {
                        that._download();
                    }
                }];
            lEmailContainer$.hide();
            lDlgContent$.dialog( "option", "buttons", lButtons );
        },

        /**
         * Deletes the display of search or a filter.
         * @ignore
         * @function
         * */
        _filterDelete: function( pFilterId ) {
            this._action( "FILTER_DELETE", {
                id: pFilterId
            } );
        },
        /**
         * applies quick filter and filter dialog
         * @ignore
         * */
        _filterSave: function( pThis ) {
            var l_OB, lTemp,
                lActionMod = "ADD",
                lFilterTypeItem$ = $( "#" + this._getId( "filter_type" ) ).find( "input:checked" ),
                lFilterType = lFilterTypeItem$.val(),
                lFilterTypeId = lFilterTypeItem$.attr( "id" );

            if( pThis ) {
                this.currentColumnId = pThis;   // why are we setting filter id as the current column, is this the filter id or column id? was current_col_id
                lActionMod = "UPDATE";
            } else {
                pThis = this._getDialogElement( "column_name" ).val();
            }
            if ( lFilterType === "COLUMN" ) {
                l_OB = this._dialogValidate();
                if( !l_OB ){
                    return;
                }
                lTemp = [ lFilterTypeId, l_OB.col.id, l_OB.col_opt.id, l_OB.form_items[ 0 ], l_OB.form_items[ 1 ], this._getId( "expression3" ) ];
            } else {
                lTemp = [ lFilterTypeId, this._getId( "filter_expr" ), this._getId( "filter_name" ) ];
            }

            this._action( "FILTER", {
                widgetActionMod:    lActionMod,
                f01:                this._utilGetFormElValues( lTemp ),
                id:                 pThis
            } );
        },
        /**
         * Calls flashback to pull report data from N minutes ago (Step 1 of 2)
         * @ignore
         * @function
         */
        _flashbackSave: function() {
            this._action( "FLASHBACK_SET", {
                value: this._getDialogElement( "flashback_time" ).val()
            } );
        },
        /**
         * toggle display of search or a filter
         * @ignore
         * @function
         * */
        _filterToggle: function( pFilterId, pChecked ) {
            this._action( "FILTER_TOGGLE", {
                id:     pFilterId,
                value:  pChecked
            } );
        },

        /**
         * @ignore
         */
        _flashbackClear: function() {
            this._action( "FLASHBACK_CLEAR" );
        },
        /**
         * @ignore
         */
        _flashbackToggle: function() {
            this._action( "FLASHBACK_TOGGLE" );
        },

        /**
         * Controls any adjustments needed when displaying group by control
         * @ignore
         * @function
         */
        _functionControl: function( pThis ) {
            var lElId, lRowNum, lIsNumberColumn,
                lNumFunctions = [ "SUM", "AVG", "MAX", "MIN", "MEDIAN", "RATIO_TO_REPORT_SUM" ];
            if( pThis ){
                lElId = pThis.id;
                lRowNum = lElId.substr( lElId.length - 2 );
                lIsNumberColumn = ( $.inArray( $( pThis ).val(), lNumFunctions ) !== -1 );
                this._getDialogElement( "number_columns_container_" + lRowNum ).toggle( lIsNumberColumn );
                this._getDialogElement( "all_columns_container_" + lRowNum ).toggle( !lIsNumberColumn );
            }
        },

        /**
         * Base IR AJAX call
         * @ignore
         * @param {Object}  pData   Object with the following options:
         *      widgetMod
         *      widgetAction
         *      widgetActionMod
         *      worksheetId         Uses x01
         *      reportId            Uses x02
         *      id                  Uses x03
         *      value               Uses x04
         *      x05 --> x10         Flexible additional values
         *
         * @function _get
         **/
        _get: function ( pData ) {
            var lData, lOptions,
                that = this,
                lTriggerRefresh = false,
                lUseQuietSpinner = !!pData.a11yQuietSpinner,

                widgetMod = pData.widgetMod,
                widgetAction = pData.widgetAction,
                widgetActionMod = pData.widgetActionMod,

                // for these actions suppress the AJAX update. useful for setting a preference or value without bugging user
                suppressUpdate = [
                    "SAVE_CHART",
                    "SAVE_COMPUTATION",
                    "FILTER",
                    "FLASHBACK_SET",
                    "GROUP_BY_SAVE",
                    "SAVE_HIGHLIGHT",
                    "CONTROL_MIN",
                    "SAVE_NOTIFY",
                    "SAVE_PIVOT",
                    "CHANGE_DETAIL_OPTION",
                    "FORMAT_MASK_LOV",
                    "NARROW",
                    "UPDATE_SEARCH_MODE"
                ].includes( widgetAction );

            // ----------------------------
            // after the fix for #22964626,
            // suppressUpdate, currentAction and currentControl were removed from the global scope,
            // but a global suppressUpdate is still needed by _dialogreset
            // TODO: find a way to completely keep these local
            // after the fix for 36523225 currentControl was removed from _initOnCreate
            this.suppressUpdate = suppressUpdate;
            // ---------------------------

            /**
             * This function is the central control for AJAX returns in the IR
             * @ignore
             * @function _return
             **/
            function _return ( pData ){
                var lSetFocusTo$, dialogInit, lData$, lToolbar$, lContent$;

                if( widgetMod === "CONTROL" ) {
                    if( widgetAction === "SORT_WIDGET" ) {               // Column header sort widget
                        that._sortWidgetShow( pData );
                    } else if ( widgetAction === "INFO" ) {              // Help section of sort widget
                        that._helpWidgetShow( pData );
                    } else if( widgetAction === "NARROW" ) {             // Shows inline pickers (eg for expression drop down)
                        lSetFocusTo$ = that._inlinePicker( "NARROW", pData );
                    } else if ( widgetAction === "FORMAT_MASK_LOV" ) {
                        lSetFocusTo$ = that._inlinePicker( "FORMAT_MASK_LOV", pData );
                    } else if ( widgetAction === "SEARCH_COLUMN" ) {     // Shows column search menu
                        that._columnSearchShow( pData );
                    } else if ( widgetAction === "SHOW_DETAIL" ) {       // Shows Single Row View
                        that._singleRowViewShow( pData );
                    } else {

                        // Showing all the dialogs
                        switch ( widgetAction ) {
                            case SHOW_FILTER:
                                dialogInit = function() {
                                    var lDlgContent$ = that._getElement( DIALOG_JS_ID );
                                    that._dialogColumnCheck();
                                    that._dialogColumnHandlers();

                                    that._on( that._getDialogElement( "filter_type" ), {
                                        "click input": function( pEvent ) {
                                            var lIsColumnFilter = ( pEvent.target.value === "COLUMN" );
                                            that._getDialogElement( "column_filter" ).toggle( lIsColumnFilter );
                                            that._getDialogElement( "row_filter" ).toggle( !lIsColumnFilter );
                                        }
                                    } );

                                    /*
                                     * Row filter handlers
                                     */
                                    that._on( that._getDialogElement( "filter_expr_clear" ), {
                                        "click": function( pEvent ) {
                                            that._getDialogElement( "filter_expr" ).val( "" );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "row_filter_columns" ), {
                                        "click li": function( pEvent ) {
                                            var lColumnId = $( pEvent.currentTarget ).data( "column-id" );
                                            that._dialogComp( that._getId( "filter_expr" ), lColumnId );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "row_filter_operators" ), {
                                        "click li": function( pEvent ) {
                                            var lOperator = $( pEvent.currentTarget ).data( "operator" );
                                            that._dialogComp( that._getId( "filter_expr" ), lOperator );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    lDlgContent$.find( ".a-IRR-dialogContent" ).show();
                                };
                                break;
                            case SHOW_HIGHLIGHT:
                                dialogInit = function() {
                                    var lDlgContent$ = that._getElement( DIALOG_JS_ID ).find( ".a-IRR-dialogContent" ),
                                        lDlgBgColor$ = that._getDialogElement( "bg_color" ),
                                        lDlgFontColor$ = that._getDialogElement( "font_color" );

                                    that._dialogColumnCheck();
                                    that._dialogColumnHandlers();
                                    that._on( lDlgBgColor$.add( lDlgFontColor$ ), {
                                        "change": function() {
                                            let contrast,
                                                contrast$ = that._getDialogElement( "_contrast" ),
                                                bgColor = lDlgBgColor$[0].getValue() || "#ffffff", // todo can these defaults be picked up from variables?
                                                fontColorItem = lDlgFontColor$[0],
                                                fontColor = fontColorItem.getValue() || "#000000";

                                            that._getDialogElement( "highlight_preview" ).css( {
                                                backgroundColor: bgColor,
                                                color: fontColor
                                            } );
                                            contrast = fontColorItem.contrastWith( bgColor );
                                            apex.widget.util.colorPicker.updateColorContrastReport( contrast$, contrast );
                                        }
                                    } );
                                    lDlgContent$.find( ".a-IRR-highlightContrast" ).html(
                                        apex.widget.util.colorPicker.renderColorContrastReport( that._getId( "_contrast" ) ) );
                                    lDlgContent$.show();

                                    // call item attach to setup color pickers in the hightlight dialog
                                    apex.item.attach( lDlgContent$ );

                                    // trigger a change so that the contrast is updated
                                    lDlgBgColor$.trigger( "change" );
                                };
                                break;
                            case SHOW_CHART:
                                dialogInit = function() {
                                    that._chartControl();
                                    that._on( that._getDialogElement( "chart_type" ), {
                                        "click input": function() {
                                            that._chartControl();
                                        }
                                    } );
                                };
                                break;
                            case SHOW_COMPUTATION:
                                dialogInit = function() {
                                    that._on( that._getDialogElement( "comp_id" ), {
                                        "change": function( pEvent ) {
                                            that._computationShow( $( pEvent.currentTarget ).val() );
                                        }
                                    } );
                                    that._on( that._getDialogElement( "format_mask_picker" ), {
                                        "click": function( pEvent ) {
                                            that._controlsFormatMask( that._getId( "format_mask" ) );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "computation_expr_clear" ), {
                                        "click": function( pEvent ) {
                                            that._getDialogElement( "computation_expr" ).val( "" );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    // Columns grid
                                    that._on( that._getDialogElement( "computation_columns" ), {
                                        "click li": function( pEvent ) {
                                            var lColumnId = $( pEvent.currentTarget ).data( "column-id" );
                                            that._dialogComp( that._getId( "computation_expr" ), lColumnId );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    // Keypad grid
                                    that._on( that._getDialogElement( "computation_keypad" ), {
                                        "click button": function( pEvent ) {
                                            var lKey = $( pEvent.currentTarget ).data( "key" );
                                            that._dialogComp( that._getId( "computation_expr" ), lKey );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    // Functions grid
                                    that._on( that._getDialogElement( "computation_functions" ), {
                                        "click li": function( pEvent ) {
                                            var lFunction = $( pEvent.currentTarget ).data( "function" );
                                            that._dialogComp( that._getId( "computation_expr" ), lFunction );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    // Examples
                                    that._getDialogElement( "compute_examples_container" ).collapsible( {
                                        controllingElement: "button",
                                        content: "#" + that._getId( "compute_examples" ),
                                        collapsed:  true
                                    } );
                                };
                                break;
                            case SHOW_COLUMN:
                                dialogInit = function() {
                                    that.g_Shuttlep_v01 = null;
                                    window.g_Shuttlep_v01 = new dhtml_ShuttleObject( $x( that._getId( "shuttle_left" ) ), $x( that._getId( "shuttle_right" ) ) );
                                };
                                break;
                            case SAVE_REPORT:
                                dialogInit = function() {
                                    that._on( that._getDialogElement( "save_option" ), {
                                        "change": function( pEvent ) {
                                            that._controlsGet( pEvent.target.value );
                                        }
                                    } );
                                };
                                break;
                            case SHOW_SAVE_DEFAULT:
                            case SHOW_RENAME_DEFAULT:
                                dialogInit = function() {
                                    that._on( that._getDialogElement( "default_type" ), {
                                        "click input": function( pEvent ) {
                                            this._saveDefaultTypeCheck( pEvent.target.value );
                                        }
                                    } );
                                    that._saveDefaultTypeCheck( $v( that._getId( "default_type" ) ) );  // use $v because this is a radio group with fieldset
                                };
                                break;
                            case SHOW_AGGREGATE:
                                dialogInit = function() {
                                    that._aggregateControl();

                                    that._on( that._getDialogElement( "aggregation" ), {
                                        "change": function( pEvent ) {
                                            this._controlsGet( SHOW_AGGREGATE, $( pEvent.currentTarget ).val() );
                                        }
                                    } );
                                    that._on( that._getDialogElement( "aggregate_by" ), {
                                        "change": function() {
                                            this._aggregateControl();
                                        }
                                    } );
                                };
                                break;
                            case SHOW_NOTIFY:
                            case SHOW_DOWNLOAD:
                                dialogInit = function() {
                                    const lFormat = that._getDialogElement( "download_format" ).val();
                                    let lformatIcon$;
                                    that._getDialogElement( "download_formats" ).iconList( {
                                        selectionChange: function() {
                                            that._getDialogElement( "download_format" )
                                                .val( $( this ).iconList( "getSelectionValues" )[ 0 ] )
                                                .trigger( "change" );
                                        }
                                    } );

                                    // Activate the current or first format
                                    if ( lFormat ) {
                                        lformatIcon$ = that._getDialogElement( "download_formats" ).find( `.a-IRR-iconList-item[data-value='${lFormat}']` );
                                    }

                                    if ( !lformatIcon$ || lformatIcon$.length === 0 ) {
                                        lformatIcon$ = that._getDialogElement( "download_formats" ).find( ".a-IRR-iconList-item" ).first();
                                    }

                                    lformatIcon$.trigger( "click" );

                                    lSetFocusTo$ = lformatIcon$;

                                    that._on( that._getDialogElement( "download_format" ), {
                                        "change": function() {
                                            const lDownloadFormat$ = that._getDialogElement( "download_format" );
                                            const lConditionalElements = [
                                                {
                                                    id: "pdf_container",
                                                    active: ( pFormat ) => {
                                                        return pFormat === "PDF";
                                                    }
                                                },
                                                {
                                                    id: "strip_rich_text_container",
                                                    active: ( pFormat ) => {
                                                        return [ "CSV", "XLSX" ].includes( pFormat );
                                                    }
                                                },
                                                {
                                                    id: "data_only_container",
                                                    active: ( pFormat ) => {
                                                        return pFormat !== "CSV";
                                                    }
                                                }
                                            ];

                                            lConditionalElements.forEach( ( el ) => {
                                                if ( el.active( lDownloadFormat$.val() ) ) {
                                                    that._getDialogElement( el.id ).show();
                                                } else {
                                                    that._getDialogElement( el.id ).hide();
                                                }
                                            } );
                                        }
                                    } );

                                    if ( widgetAction === SHOW_DOWNLOAD ) {
                                        that._on( that._getDialogElement( "send_as_email" ), {
                                            "change": function() {
                                                var lEmailCheckbox$ = that._getDialogElement( "send_as_email" );
                                                if ( lEmailCheckbox$.is( ":checked" ) ) {
                                                    that._emailShow();
                                                } else {
                                                    that._emailHide();
                                                }
                                            }
                                        } );
                                    }

                                };
                                break;
                            case SHOW_GROUP_BY:
                                dialogInit = function() {
                                    that._initFunctionsControl( "group_by_functions" );

                                    that._on( that._getDialogElement( "add_column" ), {
                                        "click": function( pEvent ) {
                                            this._utilAddMoreColumn( this._groupByMaxValue, C_IRR_GROUP_BY_COLUMN );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "group_by_functions" ), {
                                        "change select.a-IRR-function": function( pEvent ) {
                                            this._functionControl( pEvent.target );
                                        },
                                        "click button.a-Button--menu": function( pEvent ) {
                                            that._controlsFormatMask( $( pEvent.currentTarget ).data( "picker-for" ) );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "add_function" ), {
                                        "click": function( pEvent ) {
                                            this._utilAddMoreFunction( this._groupByMaxValue );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                };
                                break;
                            case SHOW_PIVOT:
                                dialogInit = function() {
                                    that._initFunctionsControl( "pivot_functions" );

                                    that._on( that._getDialogElement( "add_pivot_column" ), {
                                        "click": function( pEvent ) {
                                            this._utilAddMoreColumn( this._pivotMaxValue, C_IRR_PIVOT_COLUMN );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "add_row_column" ), {
                                        "click": function( pEvent ) {
                                            this._utilAddMoreColumn( this._pivotMaxValue, C_IRR_ROW_COLUMN );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "pivot_functions" ), {
                                        "change select.a-IRR-function": function( pEvent ) {
                                            this._functionControl( pEvent.target );
                                        },
                                        "click a.a-IRR-format-mask-picker": function( pEvent ) {
                                            that._controlsFormatMask( $( pEvent.currentTarget ).data( "picker-for" ) );
                                            pEvent.preventDefault();
                                        },
                                        // Fix Bug Num. 31908618
                                        "click button.a-Button--menu": function( pEvent ) {
                                            that._controlsFormatMask( $( pEvent.currentTarget ).data( "picker-for" ) );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                    that._on( that._getDialogElement( "add_function" ), {
                                        "click": function( pEvent ) {
                                            this._utilAddMoreFunction( this._pivotMaxValue );
                                            pEvent.preventDefault();
                                        }
                                    } );
                                };
                                break;
                        }
                        that._getElement( DIALOG_JS_ID ).html( pData );

                        // finally show
                        that._dialogOpen( widgetAction, dialogInit );
                    }
                    // If lSetFocusTo$ has been assigned, use that, otherwise fallback to first focusable element
                    if ( lSetFocusTo$ === undefined ) {

                        // focus on first input field of drop panel, if any form fields exist within a drop panel
                        lSetFocusTo$ = $( ":input:visible", that._getElement( DIALOG_JS_ID ) ).first();
                    }
                    if ( lSetFocusTo$.length > 0 ) {
                        lSetFocusTo$.trigger( "focus" );
                    }
                } else if ( widgetAction === "GET_DOWNLOAD_LINK" ) {
                    // JSON as response means an error
                    try {
                        const lData = JSON.parse( pData );

                        message.showErrors( {
                            message: lData.error,
                            location: "page"
                        } );

                    } catch {
                        // Not JSON, so redirect to the URL
                        navigation.redirect( pData, ( that.options.downloadContentDisposition === ATTACHMENT ) );
                    }

                } else { // if widgetMod === "ACTION"

                    if ( suppressUpdate ) {
                        that.lastFunction = function() {
                            that._validAction( pData );
                        };
                    } else {
                        // keep selection state when paginate
                        if ( that.options.selection ) {
                            if ( widgetAction === PAGE ) {
                                that.selection.hasPaginated = true;
                                if ( that.options.selection.multiple ) {
                                    that.selection.savedSelection = that?.listViewSelection?.getSelectedValues();
                                }
                            } else {
                                // clear selection state for all other report refreshes except pagination
                                if ( that.options.selection.selectionStateItem ) {
                                    apex.item( that.options.selection.selectionStateItem ).setValue( "" );
                                }
                                that.selection.savedSelection = null;
                                that?.listViewSelection?.setSelection( $() );
                            }
                        }

                        let pData$ = $( pData );
                        // Updating NONCE to the one from the current request.
                        pData$.find( "style[nonce]" ).attr( "nonce", env.NONCE );

                        lData$ = $( $u_js_temp_drop() );

                        // Note, this also causes any JS to be executed that the call returns
                        lData$.html( pData$ );

                        lToolbar$ = lData$.find( that._getIdSelector( "toolbar_controls" ) );
                        lContent$ = lData$.find( that._getIdSelector ( "content" ) );

                        // Replace toolbar controls and content, use widget context for first selector to pick up the
                        // the element to be replaced
                        that._getElement( "toolbar_controls", that.element ).replaceWith( lToolbar$ );
                        that._getElement( "content", that.element ).replaceWith( lContent$ );

                        // Update current pagination option, based on updated value from server
                        that.options.currentRowsPerPage = that._getElement( "row_select" ).val() * 1;

                        // Update current view mode, based on updated value from server
                        that.viewMode = that._getElement( "view_mode" ).val();

                        // Re-initialise toolbar and styles after the content has been replaced
                        that._initToolbar();
                        that._initToolbarStyles();

                        // Re-initialise the control panel
                        that._initControlPanel();

                        that.reportId = that._getElement( "report_id" ).val();

                        // Clear single row view HTML
                        that._singleRowViewHide();

                        that._getElement( "full_view" ).show();

                        // Remove the temporary DIV used to store the response
                        lData$.remove();

                        that._initFixedHeader( true );

                        if ( widgetAction === "RESET" ) {
                            that.chatModel?.clear();
                        }

                        // Try to re-instate focus following a refresh, but only if no other element currently has focus (bug #21214580).
                        if ( !$( ":focus" ).length ) {

                            // If prior to the refresh, the active element was an element with an ID, then let's use this
                            // Note: currentElementId could be undefined if the active element did not have an ID, the
                            // truthy check will take care of this also.
                            if ( that.currentElementId ) {
                                lSetFocusTo$ = $( "#" + that.currentElementId );
                            } else {

                                // Otherwise we just use the first focusable element as a fallback
                                lSetFocusTo$ = that.element.find( ":focusable" ).first();
                            }

                            if ( lSetFocusTo$.length > 0 ) {
                                lSetFocusTo$.trigger( "focus" );
                            }
                        }
                    }
                }
                if ( that.chatView ) {
                    that.chatBtn$.hide();
                }
            }  // _return

            /**
             * Gets called after all worksheet AJAX calls
             * @ignore
             * @function
             */
            function _finishedLoading() {
                if ( that.lastFunction ){
                    that.lastFunction();
                    that.lastFunction = false;
                }
                // re-show the toolbar, in case it was made invisible as we lazy loaded
                $( getIdSelector( that.options.regionId + "_toolbar" ), apex.gPageContext$ ).css( "visibility", "" );
                // remove is-loading class, in case it was added as we lazy loaded
                $( getIdSelector( that.options.regionId + "_content" ), apex.gPageContext$ ).removeClass( "is-loading" );

                // make sure the search menu is completed in error cases
                if ( widgetAction === "SEARCH_COLUMN" && that.searchMenuCallback ) {
                    that.searchMenuCallback( false );
                    that.searchMenuCallback = null;
                    that.searchMenu = null;
                }
            }  // _finishedLoading

            // For all calls except showing column help, hide the sort widget
            if ( widgetAction !== "INFO" ) {
                this._sortWidgetHide();
            }

            // We only want to trigger the refresh event when doing an action that actually updates
            // the data (eg applying a new filter, searching, moving through single row view, etc.)
            if ( widgetMod && !suppressUpdate ) {
                if ( [ "ACTION", "PULL" ].includes( widgetMod ) ) {
                    lTriggerRefresh = true;
                } else if ( widgetMod === "CONTROL" && widgetAction === "SHOW_DETAIL" ) {
                    lTriggerRefresh = true; // Single Row View also
                }
            }
            lData = $.extend( {
                p_widget_name:          "worksheet",
                p_widget_mod:           widgetMod,
                p_widget_action:        widgetAction,
                p_widget_action_mod:    widgetActionMod,
                p_widget_num_return:    that.options.currentRowsPerPage,
                x01:                    that.worksheetId,
                x02:                    that.reportId,
                x03:                    pData.id,
                x04:                    pData.value,
                x11 :                   pData.keepPagination,
                pageItems:              this.options.pageItems
            }, pData );

            // delete properties we expose with more meaningful names and that are not required by the call
            delete lData.widgetMod;
            delete lData.widgetAction;
            delete lData.widgetActionMod;
            delete lData.id;
            delete lData.value;
            delete lData.a11yQuietSpinner;

            // for a Reset, or when the saved report is changed, don't pass the rows per page, instead the server
            // will provide the saved value
            if ( lData.p_widget_action === "RESET" || lData.p_widget_action === "REPORT_CHANGED" ) {
                delete lData.p_widget_num_return;
            }

            // p_widget_action_mod is sometimes not required, so let's not send it in that case
            if ( !lData.p_widget_action_mod ) {
                delete lData.p_widget_action_mod;
            }

            lOptions = {
                dataType:                   "html",
                refreshObject:              ( lTriggerRefresh ) ? this.region$: null,
                success:                    _return,
                complete:                   _finishedLoading
            };

            if ( lUseQuietSpinner ) {
                lOptions.loadingIndicator = function () {
                    return util.showSpinner( that._getElement( "worksheet_region" ), {
                        suppressAria: true
                    } );
                };
            } else {
                lOptions.loadingIndicator = that._getElement( "worksheet_region" );
                lOptions.loadingIndicatorPosition = "centered";
            }

            server.plugin( this.options.ajaxIdentifier, lData, lOptions );
        }, // _get

        _getId: function( pId ) {
            return this.idPrefix + "_" + pId;
        },

        _getIdSelector: function( pId ) {
            return getIdSelector( this._getId( pId ) );
        },

        _getElement: function( pId, pContext$ ) {
            var lContext$;
            // TODO consider if the context is even needed - these are after all ids we are selecting on.
            if ( pContext$ ) {
                lContext$ = pContext$;
            } else if ( pId === DIALOG_JS_ID || /^sort_widget.*$/.test( pId ) ) {
                lContext$ = apex.gPageContext$;
            } else {
                lContext$ = this.element;
            }
            return $( this._getIdSelector( pId ), lContext$ );
        },
        _getDialogElement: function( pId ) {
            return this._getElement( pId, this._getElement( DIALOG_JS_ID ) );
        },

        _groupByMaxValue: 8,
        _groupByRemove: function() {
            this._action( "GROUP_BY_REMOVE" );
        },
        _groupBySave: function() {
            var lFArrays = this._utilGetFormElAttributes();
            this._action( "GROUP_BY_SAVE", {
                f01: lFArrays.ids,
                f02: lFArrays.values
            } );
        },
        /**
         * applies group by sort dialog
         * @ignore
         * @function
         * */
        _groupBySort: function( pThis ) {
            var lFArrays,
                lGroupById = this._getDialogElement( "group_by_id" ).val();
            if( pThis === ASC || pThis === DESC ) {
                this.lastColumnId = pThis.id;
                this._action( "GROUP_BY_COLUMN_SORT", {
                    id:     lGroupById,
                    f01:    this.lastColumnId,
                    f02:    pThis
                } );
            } else {
                lFArrays = this._utilGetFormElAttributes();
                this._action( "GROUP_BY_SORT", {
                    id:     lGroupById,
                    f01:    lFArrays.ids,
                    f02:    lFArrays.values
                } );
            }
        },
        _groupByView: function() {
            this._action( "VIEW_GROUP_BY" );
        },

        _helpWidgetShow: function( pData ) {
            const
                helpRegionId = this._getId( "sort_widget_help" ),
                helpBtn$ = this._getElement( "sort_widget_action_help" ).find( SEL_IRR_SORT_WIDGET_BUTTON ),
                isHelpActive = $( helpBtn$ ).hasClass( C_IS_ACTIVE );

            if ( isHelpActive ) {
                this._getElement( "sort_widget_help" )
                    .empty()
                    .hide();
                helpBtn$.removeClass( C_IS_ACTIVE )
                    .attr( ARIA_PRESSED, "false" )
                    .removeAttr( ARIA_DESCRIBEDBY )
                    .removeAttr( ARIA_DETAILS )
                    .removeAttr( ARIA_CONTROLS );
            } else {
                this._getElement( "sort_widget_help" )
                    .html( "<div role='alert'>" + pData + "</div>" )
                    .show();
                helpBtn$.addClass( C_IS_ACTIVE )
                    .attr( ARIA_PRESSED, "true" )
                    .attr( ARIA_DESCRIBEDBY, helpRegionId )
                    .attr( ARIA_DETAILS, helpRegionId )
                    .attr( ARIA_CONTROLS, helpRegionId );
            }
            this.lastColumnId = this.currentColumnId;
            this._dialogCheck( null, this._sortWidgetHide );
        },

        /**
         * Removes a highlight rule.
         * @ignore
         * @param {String} pHighlightId
         * */
        _highlightClear: function( pHighlightId ) {
            var lHighlightId;
            if ( pHighlightId ) {
                lHighlightId = pHighlightId;
            } else {
                lHighlightId = $x( "HIGHLIGHT_ID" ).value;
            }
            this._action( "CLEAR_HIGHLIGHT", {
                id: lHighlightId
            } );
        },
        /**
         * Save a highlight rule (Step 1 of 2) next call is
         * @ignore
         * @function
         **/
        _highlightSave: function() {
            var lFArrays,
                l_OB = this._dialogValidate();
            if( !l_OB ) {
                return;
            }
            lFArrays = this._utilGetFormElAttributes();
            this._action( "SAVE_HIGHLIGHT", {
                f01: lFArrays.ids,
                f02: lFArrays.values
            } );
            l_OB = null;
        },
        /**
         * toggles a highlight rule
         * @ignore
         * @param {String}     pHighlightId
         * @param {String}     pChecked
         * */
        _highlightToggle: function( pHighlightId, pChecked ) {
            this._action( "TOGGLE_HIGHLIGHT", {
                id:     pHighlightId,
                value:  pChecked
            } );
        },

        /**
         * @ignore
         * @param {String} pContainerId
         */
        _initFunctionsControl: function( pContainerId ) {
            this._getDialogElement( pContainerId )
                .find( "select.a-IRR-function" )
                .each( ( _, el ) => this._functionControl( el ) );
        },

        // Handlers for all control panel / report settings functionality
        _initControlPanel: function() {
            var that = this;

            this._on( this._getElement( "control_panel" ), {

                // Edit filters, saved reports, highlights, charts, ...
                // Expanded view
                "click a.a-IRR-controlsLabel": function( pEvent ) {
                    var lLink$ = $( pEvent.currentTarget ),
                        lSetting = lLink$.data( "setting" );
                    switch ( lSetting ) {
                        case "filter":
                            this._controlsGet( SHOW_FILTER, lLink$.data( "filter-id" ) );
                            break;
                        case "report":
                            this._controlsGet( SHOW_RENAME );
                            break;
                        case "report-default":
                            this._controlsGet( SHOW_RENAME_DEFAULT );
                            break;
                        case "highlight":
                            this._controlsGet( SHOW_HIGHLIGHT, lLink$.data( "highlight-id" ) );
                            break;
                        case "break":
                            this._controlsGet( SHOW_CTRL_BREAK );
                            break;
                        case "chart":
                            this._controlsGet( SHOW_CHART );
                            break;
                        case "group_by":
                            this._controlsGet( SHOW_GROUP_BY );
                            break;
                        case "pivot":
                            this._controlsGet( SHOW_PIVOT );
                            break;
                        case "flashback":
                            that._controlsGet( SHOW_FLASHBACK );
                            break;
                    }
                    pEvent.preventDefault();
                },

                // Edit button to edit filters, saved reports, highlights, charts, ...
                // Expanded view
                "click button.a-IRR-button--edit": function( pEvent ) {
                    var lButton$ = $( pEvent.currentTarget ),
                        lSetting = lButton$.data( "setting" );
                    switch ( lSetting ) {
                        case "filter":
                            this._controlsGet( SHOW_FILTER, lButton$.data( "filter-id" ) );
                            break;
                        case "report":
                            this._controlsGet( SHOW_RENAME );
                            break;
                        case "report-default":
                            this._controlsGet( SHOW_RENAME_DEFAULT );
                            break;
                        case "highlight":
                            this._controlsGet( SHOW_HIGHLIGHT, lButton$.data( "highlight-id" ) );
                            break;
                        case "break":
                            this._controlsGet( SHOW_CTRL_BREAK );
                            break;
                        case "chart":
                            this._controlsGet( SHOW_CHART );
                            break;
                        case "group_by":
                            this._controlsGet( SHOW_GROUP_BY );
                            break;
                        case "pivot":
                            this._controlsGet( SHOW_PIVOT );
                            break;
                        case "flashback":
                            that._controlsGet( SHOW_FLASHBACK );
                            break;
                    }
                    pEvent.preventDefault();
                },

                // Now collapsed view
                "click a.a-IRR-reportSummary-label": function( pEvent ) {
                    var lLink$ = $( pEvent.currentTarget ),
                        lSetting = lLink$.data( "setting" );
                    switch ( lSetting ) {
                        case "filter":
                            this._controlsGet( SHOW_FILTER, lLink$.data( "filter-id" ) );
                            break;
                        case "report":
                            this._controlsGet( SHOW_RENAME );
                            break;
                        case "report-default":
                            this._controlsGet( SHOW_RENAME_DEFAULT );
                            break;
                        case "highlight":
                            this._controlsGet( SHOW_HIGHLIGHT, lLink$.data( "highlight-id" ) );
                            break;
                        case "break":
                            this._controlsGet( SHOW_CTRL_BREAK );
                            break;
                        case "chart":
                            this._controlsGet( SHOW_CHART );
                            break;
                        case "group-by":
                            this._controlsGet( SHOW_GROUP_BY );
                            break;
                        case "pivot":
                            this._controlsGet( SHOW_PIVOT );
                            break;
                        case "flashback":
                            that._controlsGet( SHOW_FLASHBACK );
                            break;
                        default:
                            that._getElement( "control_panel" ).collapsible( "expand" );
                            break;
                    }
                    pEvent.preventDefault();
                },


                // Toggles to enabled / disable control breaks, filters, highlights ...
                "click input.a-IRR-controlsCheckbox": function( pEvent ) {
                    var lCheckbox$ = $( pEvent.target ),
                        lChecked = ( lCheckbox$.prop( CHECKED ) ) ? "Y" : "N",
                        lSetting = lCheckbox$.data( "setting" );
                    switch ( lSetting ) {
                        case "break":
                            this._controlBreakToggle( lCheckbox$.data( "break-column" ), lChecked );
                            break;
                        case "filter":
                            this._filterToggle( lCheckbox$.data( "filter-id" ), lChecked );
                            break;
                        case "highlight":
                            this._highlightToggle( lCheckbox$.data( "highlight-id" ), lChecked );
                            break;
                        case "flashback":
                            this._flashbackToggle();
                            break;
                    }
                },

                // Deletes control breaks, filters, ..., works the same for both collapsed / expanded views
                "click button.a-IRR-button--remove": function( pEvent ) {
                    var lButton$ = $( pEvent.currentTarget ),
                        lSetting = lButton$.data( "setting" );
                    switch ( lSetting ) {
                        case "break":
                            this._controlBreakOn( lButton$.data( "break-column" ) );
                            break;
                        case "filter":
                            this._filterDelete( lButton$.data( "filter-id" ) );
                            break;
                        case "report":
                            this._controlsGet( SHOW_DELETE );
                            break;
                        case "report-default":
                            this._controlsGet( SHOW_DELETE_DEFAULT );
                            break;
                        case "highlight":
                            this._highlightClear( lButton$.data( "highlight-id" ) );
                            break;
                        case "flashback":
                            this._flashbackClear();
                            break;
                        case "chart":
                            this._chartClear();
                            break;
                        case "group-by":
                            this._groupByRemove();
                            break;
                        case "pivot":
                            this._pivotRemove();
                            break;
                    }
                    pEvent.preventDefault();
                }

            } );

            function _expand() {
                if ( that.options.isControlPanelCollapsed ) {
                    that.options.isControlPanelCollapsed = false;
                    that._action( "CONTROL_MIN", {
                        value: "N"
                    } );
                }
                that._getElement( "control_panel_summary" ).hide();

            }

            function _collapse() {
                if ( !that.options.isControlPanelCollapsed ) {
                    that.options.isControlPanelCollapsed = true;
                    that._action( "CONTROL_MIN", {
                        value: "Y"
                    } );
                }
                that._getElement( "control_panel_summary" ).show();
            }

            this._getElement( "control_panel" ).collapsible( {
                content:      "div.a-MediaBlock-content",
                collapsed:  that.options.isControlPanelCollapsed,
                collapse:   _collapse,
                expand:     _expand,
                renderIcon: false
            } );
        },
        _initFixedHeader: function( pWindowResize ) {
            var lContainerClass,
                o = this.options;

            if ( o.fixedHeader === PAGE || o.fixedHeader === REGION ) {

                // todo remove this restriction once fixed table header JS supports complex headings (bug #20143941)
                if ( $( ".a-IRR-header--group", this.element ).length === 0 ) {

                    switch( this.viewMode ) {
                        case REPORT:
                            if ( o.reportViewMode === REPORT ) {
                                lContainerClass = "a-IRR-reportView";
                            }
                            break;
                        case GROUP_BY:
                            lContainerClass = "a-IRR-groupByView";
                            break;
                        /* todo reinstate PIVOT when fixed table header JS supports complex headings (bug #20143941)
                         case PIVOT:
                         lContainerClass = "a-IRR-pivotView";
                         break;
                         */
                    }

                    if ( lContainerClass ) {
                        if ( $( this.element ).find( ".a-IRR-iconViewTable" ).length === 0 ) {
                            switch ( o.fixedHeader ) {
                                case PAGE:
                                    $( "." + lContainerClass, this.element ).setTableHeadersAsFixed();
                                    $( ".js-stickyTableHeader", this.element ).stickyWidget( {
                                        toggleWidth: true,
                                        stickToEnd: true
                                    } );
                                    break;
                                case REGION:
                                    $( "." + lContainerClass, this.element ).setTableHeadersAsFixed( {
                                        maxHeight: o.fixedHeaderMaxHeight
                                    } );
                                    break;
                            }
                        }

                        if ( pWindowResize ) {
                            $( window ).trigger( "apexwindowresized" );
                        }
                    }
                }
            }
        },
        /**
         * Menu initialisation code
         * @ignore
         * @function _initMenus
         **/
        _initMenus: function() {
            var lActionMenu, i,
                that = this,
                o = this.options,
                // TODO Rows per page sub menu does not match the rows per page selector select list. Missing are [ 30, 200, 500, 2000 ]
                rowsPerPageChoices = [ 1, 5, 10, 15, 20, 25, 50, 100, 1000 ];   // All/10,000 is a special case


            function findById( items, id ) {
                for ( i = 0; i < items.length; i++ ) {
                    if ( items[ i ].id === id ) {
                        return items[ i ];
                    }
                }
            }

            function getMaxRows( pMaxRowsPerPage, pMaxRowCount, pMaxRowsDisplay ) {
                const lMaxRowsPerPage = Number( pMaxRowsPerPage ) || null,
                      lMaxRowCount = Number( pMaxRowCount ) || null,
                      lMaxRowsDisplay = Number( pMaxRowsDisplay ) || null,
                      limitRows = lMaxRowCount !== null ? lMaxRowCount : lMaxRowsDisplay;

                // The value used to limit the rows per page selector is different depending on how the
                // max row count/max rows to display and max rows per page attributes have been defined...
                if ( lMaxRowsPerPage !== null && limitRows !== null ) {
                     return Math.min( lMaxRowsPerPage, limitRows );
                }

                return lMaxRowsPerPage !== null ? lMaxRowsPerPage : limitRows;
            }

            // New, Interactive Grid style actions menu
            if ( o.actionsMenuStructure === "IG" ) {

                lActionMenu = {
                    items: [
                        { id: "irColumn", type: ACTION, label: getIRMsg( "COLUMNS" ), hide: true, icon: "icon-irr-select-cols", action: function () {
                            that._controlsGet( SHOW_COLUMN, "COLUMN" );
                        } },
                        { type: "separator" },
                        { id: "irFilter", type: ACTION, label: getIRMsg( "FILTER" ), hide: true, icon: "icon-irr-filter" , action: function () {
                            that._controlsGet( SHOW_FILTER );
                        } },
                        //todo update class to use irr based icon
                        { id: "irData", type: "subMenu", label: getIRMsg( "DATA" ), hide: false, icon: "icon-ig-data", menu: { items: [
                            { id: "irOrdering", type: ACTION, label: getIRMsg( "SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_ORDERING );
                            } },
                            { id: "irGroupBySort", type: ACTION, label: getIRMsg( "GROUP_BY_SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_GROUP_BY_SORT );
                            } },
                            { id: "irPivotSort", type: ACTION, label: getIRMsg( "PIVOT_SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_PIVOT_SORT );
                            } },
                            { id: "irAggregate", type: ACTION, label: getIRMsg( "AGGREGATE" ), hide: true, icon: "icon-irr-aggregate", action: function () {
                                that._controlsGet( SHOW_AGGREGATE );
                            } },
                            { id: "irCompute", type: ACTION, label: getIRMsg( "COMPUTE" ), hide: true, icon: "icon-irr-compute", action: function () {
                                that._computationShow();
                            } },
                            { id: "irFlashback", type: ACTION, label: getIRMsg( "FLASHBACK" ), hide: true, icon: "icon-irr-flashback", action: function () {
                                that._controlsGet( SHOW_FLASHBACK );
                            } }
                        ]}
                        },
                        { id: "irFormat", type: "subMenu", label: getIRMsg( "FORMAT" ), hide: false, icon: "icon-irr-format", menu: { items: [

                            { id: "irCtrlBreak", type: ACTION, label: getIRMsg( "CONTROL_BREAK" ), hide: true, icon: "icon-irr-control-break", action: function () {
                                that._controlsGet( SHOW_CTRL_BREAK );
                            } },
                            { id: "irHighlight", type: ACTION, label: getIRMsg( "HIGHLIGHT" ), hide: true, icon: "icon-irr-highlight", action: function () {
                                that._controlsGet( SHOW_HIGHLIGHT );
                            } },
                            { id: "irRowsPerPage", type: "subMenu", label: getIRMsg( "ROWS_PER_PAGE" ), hide: true, icon: "icon-irr-rows", menu: { items: [
                                { type: "radioGroup", set: function ( v ) {
                                    that.options.currentRowsPerPage = v * 1;
                                    that._search( "SEARCH" );
                                }, get: function () {
                                    return that.options.currentRowsPerPage;
                                }, choices: [
                                ] }
                            ]}
                            }
                        ]}
                        },
                        { type: "separator" },
                        { id: "irChart", type: ACTION, label: getIRMsg( "CHART" ), hide: true, icon: "icon-irr-chart", action: function () {
                            that._controlsGet( SHOW_CHART );
                        } },
                        { id: "irGroupBy", type: ACTION, label: getIRMsg( "GROUP_BY" ), hide: true, icon: "icon-irr-group-by", action: function () {
                            that._controlsGet( SHOW_GROUP_BY );
                        } },
                        { id: "irPivot", type: ACTION, label: getIRMsg( "PIVOT" ), hide: true, icon: "icon-irr-pivot", action: function () {
                            that._controlsGet( SHOW_PIVOT );
                        } },
                        { type: "separator" },
                        { id: "irReport", type: "subMenu", label: getIRMsg( "REPORT" ), hide: false, icon: "icon-irr-saved-report", menu: { items: [
                            //todo-51 update icon to use 'irr' equivalent for both save and save default
                            { id: "irSaveReport", type: ACTION, label: getIRMsg( "SAVE_REPORT" ), hide: true, icon: "icon-ig-save", action: function () {
                                that._controlsGet( SAVE_REPORT );
                            } },
                            { id: "irSaveDefault", type: ACTION, label: getIRMsg( "SAVE_REPORT_DEFAULT" ), hide: true, icon: "icon-ig-save", action: function () {
                                that._controlsGet( SHOW_SAVE_DEFAULT );
                            } },
                            { type: "separator" },
                            { id: "irReset", type: ACTION, label: getIRMsg( "RESET" ), hide: true, icon: "icon-irr-reset", action: function () {
                                that._controlsGet( SHOW_RESET );
                            } }
                        ]}
                        },
                        { type: "separator" },
                        { id: "irDownload", type: ACTION, label: getIRMsg( "DOWNLOAD" ), hide: true, icon: "icon-irr-download", action: function () {
                            that._controlsGet( SHOW_DOWNLOAD );
                        } },
                        { id: "irNotify", type: ACTION, label: getIRMsg( "SUBSCRIPTION" ), hide: true, icon: "icon-irr-subscription", action: function () {
                            that._controlsGet( SHOW_NOTIFY );
                        } },
                        { type: "separator" },
                        { id: "irHelp", type: ACTION, label: getIRMsg( "HELP" ), hide: true, icon: "icon-irr-help", action: function () {
                            navigation.popup.url( that.options.helpLink );
                        } }
                    ],
                    beforeOpen: function( event, menu ) {
                        var rpp, rowsPerPageItemChoices, maxRows,
                            items = menu.menu.items,
                            dataItem = findById( items, "irData" ),
                            dataSubItems = dataItem.menu.items,
                            orderingItem = findById( dataSubItems, "irOrdering" ),
                            aggregateItem = findById( dataSubItems, "irAggregate" ),
                            flashbackItem = findById( dataSubItems, "irFlashback" ),
                            computeItem = findById( dataSubItems, "irCompute" ),
                            groupBySortItem = findById( dataSubItems, "irGroupBySort" ),
                            pivotSortItem = findById( dataSubItems, "irPivotSort" ),
                            formatItem = findById( items, "irFormat" ),
                            formatSubItems = formatItem.menu.items,
                            ctrlBreakItem = findById( formatSubItems, "irCtrlBreak" ),
                            highlightItem = findById( formatSubItems, "irHighlight" ),
                            rowsPerPageItem = findById( formatSubItems, "irRowsPerPage" ),
                            reportItem = findById( items, "irReport" ),
                            reportSubItems = reportItem.menu.items;

                        that._dialogReset();
                        that._sortWidgetHide();

                        // display select columns menu only for report view
                        findById( items, "irColumn" ).hide = !( o.selectColumns && that.viewMode === REPORT );
                        findById( items, "irFilter" ).hide = !o.filter;

                        /*
                         * Data sub-menu
                         */
                        dataItem.hide = true;
                        if ( that.viewMode === REPORT ) {
                            if ( o.sort || o.aggregate || o.flashback || o.compute ) {
                                dataItem.hide = false;
                                orderingItem.hide = !o.sort;
                                aggregateItem.hide = !o.aggregate;
                                flashbackItem.hide = !o.flashback;
                                computeItem.hide = !o.compute;
                                groupBySortItem.hide = true;
                                pivotSortItem.hide = true;
                            }
                        } else if ( that.viewMode === GROUP_BY ) {
                            if ( o.groupBy ) {
                                dataItem.hide = false;
                                orderingItem.hide = true;
                                aggregateItem.hide = true;
                                flashbackItem.hide = !o.flashback;
                                computeItem.hide = true;
                                groupBySortItem.hide = false;
                                pivotSortItem.hide = true;
                            }
                        } else if ( that.viewMode === PIVOT ) {
                            if ( o.pivot ) {
                                dataItem.hide = false;
                                orderingItem.hide = true;
                                aggregateItem.hide = true;
                                flashbackItem.hide = !o.flashback;
                                computeItem.hide = true;
                                groupBySortItem.hide = true;
                                pivotSortItem.hide = false;
                            }
                        } else if ( that.viewMode === CHART ) {
                            dataItem.hide = false;
                            orderingItem.hide = true;
                            aggregateItem.hide = true;
                            flashbackItem.hide = !o.flashback;
                            computeItem.hide = true;
                            groupBySortItem.hide = true;
                            pivotSortItem.hide = true;
                        }

                        /*
                         * Format sub-menu
                         */
                        formatItem.hide = true;
                        if ( that.viewMode === REPORT ) {
                            if ( o.controlBreak || o.highlight ) {
                                formatItem.hide = false;
                                ctrlBreakItem.hide = !o.controlBreak;
                                highlightItem.hide = !o.highlight;
                                rowsPerPageItem.hide = !o.rowsPerPage;
                            }
                        } else if ( that.viewMode === GROUP_BY ) {
                            if ( o.groupBy ) {
                                formatItem.hide = false;
                                ctrlBreakItem.hide = true;
                                highlightItem.hide = true;
                                rowsPerPageItem.hide = !o.rowsPerPage;
                            }
                        } else if ( that.viewMode === PIVOT ) {
                            if ( o.pivot ) {
                                formatItem.hide = false;
                                ctrlBreakItem.hide = true;
                                highlightItem.hide = true;
                                rowsPerPageItem.hide = !o.rowsPerPage;
                            }
                        } else if ( that.viewMode === CHART ) {
                            formatItem.hide = false;
                            ctrlBreakItem.hide = true;
                            highlightItem.hide = true;
                            rowsPerPageItem.hide = !o.rowsPerPage;
                        }
                        if ( o.rowsPerPage ) {
                            rowsPerPageItem = findById( formatSubItems, "irRowsPerPage" );
                            rowsPerPageItem.menu.items[ 0 ].choices = [];
                            rowsPerPageItemChoices = rowsPerPageItem.menu.items[ 0 ].choices;
                            maxRows = getMaxRows( o.maxRowsPerPage, o.maxRowCount, o.maxRowsToDisplay );

                            for ( i = 0; i < rowsPerPageChoices.length; i++ ) {
                                rpp = rowsPerPageChoices[ i ];

                                // If neither max row count or max rows per page are defined, maxRows will be null,
                                // in which case we still want the rows per page selector, so allow null maxRows (bug #27062517)
                                if ( maxRows && rpp > maxRows ) {
                                    break;
                                }
                                rowsPerPageItemChoices.push(
                                    { label: "" + rpp, value: rpp }
                                );
                            }

                            // If no max rows per page defined, add 'All' option
                            if ( !o.maxRowsPerPage ) {
                                rowsPerPageItemChoices.push(
                                    { label: getIRMsg( "ALL" ), value: 100000 }
                                );
                            }

                        }

                        /*
                         * Views
                         */
                        if ( that.viewMode === REPORT ) {
                            if ( o.chart || o.groupBy || o.pivot ) {
                                findById( items, "irChart" ).hide = !o.chart;
                                findById( items, "irGroupBy" ).hide = !o.groupBy;
                                findById( items, "irPivot" ).hide = !o.pivot;
                            }
                        } else if ( that.viewMode === GROUP_BY ) {
                            if ( o.groupBy ) {
                                findById( items, "irChart" ).hide = true;
                                findById( items, "irGroupBy" ).hide = false;
                                findById( items, "irPivot" ).hide = true;
                            }
                        } else if ( that.viewMode === PIVOT ) {
                            if ( o.pivot ) {
                                findById( items, "irChart" ).hide = true;
                                findById( items, "irGroupBy" ).hide = true;
                                findById( items, "irPivot" ).hide = false;
                            }
                        } else if ( that.viewMode === CHART ) {
                            findById( items, "irChart" ).hide = false;
                            findById( items, "irGroupBy" ).hide = true;
                            findById( items, "irPivot" ).hide = true;
                        }

                        /*
                         * Report sub-menu
                         */
                        reportItem.hide = true;
                        if ( o.saveReport || o.saveDefaultReport || o.reset ) {
                            reportItem.hide = false;
                            findById( reportSubItems, "irSaveReport" ).hide = !o.saveReport;
                            findById( reportSubItems, "irSaveDefault" ).hide = !o.saveDefaultReport;
                            findById( reportSubItems, "irReset" ).hide = !o.reset;
                        }

                        // 'download' and 'subscription' options both indicate if the developer has download enabled.
                        // if both cases, we also need to check the current view supports it.
                        findById( items, "irDownload" ).hide = !( o.download && $.inArray( that.viewMode, [ REPORT, GROUP_BY, PIVOT ] ) !== -1 );
                        findById( items, "irNotify" ).hide = !( o.subscription && $.inArray( that.viewMode, [ REPORT, GROUP_BY, PIVOT ] ) !== -1 );

                        findById( items, "irHelp" ).hide = !o.help;
                    }
                };


            } else {
                lActionMenu = {
                    items: [
                        { id: "irColumn", type: ACTION, label: getIRMsg( "SELECT_COLUMNS" ), hide: true, icon: "icon-irr-select-cols", action: function () {
                            that._controlsGet( SHOW_COLUMN, "COLUMN" );
                        } },
                        { type: "separator" },
                        { id: "irFilter", type: ACTION, label: getIRMsg( "FILTER" ), hide: true, icon: "icon-irr-filter" , action: function () {
                            that._controlsGet( SHOW_FILTER );
                        } },
                        { id: "irRowsPerPage", type: "subMenu", label: getIRMsg( "ROWS_PER_PAGE" ), hide: true, icon: "icon-irr-rows", menu: { items: [
                            { type: "radioGroup", set: function ( v ) {
                                that.options.currentRowsPerPage = v * 1;
                                that._search( "SEARCH" );
                            }, get: function () {
                                return that.options.currentRowsPerPage;
                            }, choices: [
                            ] }
                        ]}
                        },
                        { id: "irFormat", type: "subMenu", label: getIRMsg( "FORMAT" ), hide: false, icon: "icon-irr-format", menu: { items: [
                            { id: "irOrdering", type: ACTION, label: getIRMsg( "SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_ORDERING );
                            } },
                            { id: "irCtrlBreak", type: ACTION, label: getIRMsg( "CONTROL_BREAK" ), hide: true, icon: "icon-irr-control-break", action: function () {
                                that._controlsGet( SHOW_CTRL_BREAK );
                            } },
                            { id: "irHighlight", type: ACTION, label: getIRMsg( "HIGHLIGHT" ), hide: true, icon: "icon-irr-highlight", action: function () {
                                that._controlsGet( SHOW_HIGHLIGHT );
                            } },
                            { id: "irCompute", type: ACTION, label: getIRMsg( "COMPUTE" ), hide: true, icon: "icon-irr-compute", action: function () {
                                that._computationShow();
                            } },
                            { id: "irAggregate", type: ACTION, label: getIRMsg( "AGGREGATE" ), hide: true, icon: "icon-irr-aggregate", action: function () {
                                that._controlsGet( SHOW_AGGREGATE );
                            } },
                            { id: "irChart", type: ACTION, label: getIRMsg( "CHART" ), hide: true, icon: "icon-irr-chart", action: function () {
                                that._controlsGet( SHOW_CHART );
                            } },
                            { id: "irGroupBySort", type: ACTION, label: getIRMsg( "GROUP_BY_SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_GROUP_BY_SORT );
                            } },
                            { id: "irGroupBy", type: ACTION, label: getIRMsg( "GROUP_BY" ), hide: true, icon: "icon-irr-group-by", action: function () {
                                that._controlsGet( SHOW_GROUP_BY );
                            } },
                            { id: "irPivotSort", type: ACTION, label: getIRMsg( "PIVOT_SORT" ), hide: true, icon: "icon-irr-sort", action: function () {
                                that._controlsGet( SHOW_PIVOT_SORT );
                            } },
                            { id: "irPivot", type: ACTION, label: getIRMsg( "PIVOT" ), hide: true, icon: "icon-irr-pivot", action: function () {
                                that._controlsGet( SHOW_PIVOT );
                            } }
                        ]}
                        },
                        { type: "separator" },
                        { id: "irFlashback", type: ACTION, label: getIRMsg( "FLASHBACK" ), hide: true, icon: "icon-irr-flashback", action: function () {
                            that._controlsGet( SHOW_FLASHBACK );
                        } },
                        { type: "separator" },
                        { id: "irSaveReport", type: ACTION, label: getIRMsg( "SAVE_REPORT" ), hide: true, icon: "icon-irr-saved-report", action: function () {
                            that._controlsGet( SAVE_REPORT );
                        } },
                        { id: "irSaveDefault", type: ACTION, label: getIRMsg( "SAVE_REPORT_DEFAULT" ), hide: true, icon: "icon-irr-saved-report", action: function () {
                            that._controlsGet( SHOW_SAVE_DEFAULT );
                        } },
                        { id: "irReset", type: ACTION, label: getIRMsg( "RESET" ), hide: true, icon: "icon-irr-reset", action: function () {
                            that._controlsGet( SHOW_RESET );
                        } },
                        { type: "separator" },
                        { id: "irHelp", type: ACTION, label: getIRMsg( "HELP" ), hide: true, icon: "icon-irr-help", action: function () {
                            navigation.popup.url( that.options.helpLink );
                        } },
                        { type: "separator" },
                        { id: "irDownload", type: ACTION, label: getIRMsg( "DOWNLOAD" ), hide: true, icon: "icon-irr-download", action: function () {
                            that._controlsGet( SHOW_DOWNLOAD );
                        } },
                        { id: "irNotify", type: ACTION, label: getIRMsg( "SUBSCRIPTION" ), hide: true, icon: "icon-irr-subscription", action: function () {
                            that._controlsGet( SHOW_NOTIFY );
                        } }
                    ],
                    beforeOpen: function( event, menu ) {
                        var rpp, rowsPerPageItem, rowsPerPageItemChoices, maxRows,
                            items = menu.menu.items,
                            formatItem = findById( items, "irFormat" ),
                            formatSubItems = formatItem.menu.items,
                            orderingItem = findById( formatSubItems, "irOrdering" ),
                            ctrlBreakItem = findById( formatSubItems, "irCtrlBreak" ),
                            highlightItem = findById( formatSubItems, "irHighlight" ),
                            computeItem = findById( formatSubItems, "irCompute" ),
                            aggregateItem = findById( formatSubItems, "irAggregate" ),
                            chartItem = findById( formatSubItems, "irChart" ),
                            groupBySortItem = findById( formatSubItems, "irGroupBySort" ),
                            groupByItem = findById( formatSubItems, "irGroupBy" ),
                            pivotSortItem = findById( formatSubItems, "irPivotSort" ),
                            pivotItem = findById( formatSubItems, "irPivot" );

                        that._dialogReset();
                        that._sortWidgetHide();

                        // display select columns menu only for report view
                        findById( items, "irColumn" ).hide = !( o.selectColumns && that.viewMode === REPORT );
                        findById( items, "irFilter" ).hide = !o.filter;
                        findById( items, "irRowsPerPage" ).hide = !o.rowsPerPage;

                        // format menu
                        formatItem.hide = true;
                        if ( that.viewMode === REPORT ) {
                            if ( o.sort || o.controlBreak || o.highlight || o.compute || o.aggregate || o.chart || o.groupBy || o.pivot ) {
                                formatItem.hide = false;
                                orderingItem.hide = !o.sort;
                                ctrlBreakItem.hide = !o.controlBreak;
                                highlightItem.hide = !o.highlight;
                                computeItem.hide = !o.compute;
                                aggregateItem.hide = !o.aggregate;
                                chartItem.hide = !o.chart;
                                groupBySortItem.hide = true;
                                groupByItem.hide = !o.groupBy;
                                pivotSortItem.hide = true;
                                pivotItem.hide = !o.pivot;
                            }
                        } else if ( that.viewMode === GROUP_BY ) {
                            if ( o.groupBy ) {
                                formatItem.hide = false;
                                orderingItem.hide = true;
                                ctrlBreakItem.hide = true;
                                highlightItem.hide = true;
                                computeItem.hide = true;
                                aggregateItem.hide = true;
                                chartItem.hide = true;
                                groupBySortItem.hide = false;
                                groupByItem.hide = false;
                                pivotSortItem.hide = true;
                                pivotItem.hide = true;
                            }
                        } else if ( that.viewMode === PIVOT ) {
                            if ( o.pivot ) {
                                formatItem.hide = false;
                                orderingItem.hide = true;
                                ctrlBreakItem.hide = true;
                                highlightItem.hide = true;
                                computeItem.hide = true;
                                aggregateItem.hide = true;
                                chartItem.hide = true;
                                groupBySortItem.hide = true;
                                groupByItem.hide = true;
                                pivotSortItem.hide = false;
                                pivotItem.hide = false;
                            }
                        } else if ( that.viewMode === CHART ) {
                            formatItem.hide = false;
                            orderingItem.hide = true;
                            ctrlBreakItem.hide = true;
                            highlightItem.hide = true;
                            computeItem.hide = true;
                            aggregateItem.hide = true;
                            chartItem.hide = false;
                            groupBySortItem.hide = true;
                            groupByItem.hide = true;
                            pivotSortItem.hide = true;
                            pivotItem.hide = true;
                        }
                        findById( items, "irFlashback" ).hide = !o.flashback;
                        findById( items, "irSaveReport" ).hide = !o.saveReport;
                        findById( items, "irSaveDefault" ).hide = !o.saveDefaultReport;
                        findById( items, "irReset" ).hide = !o.reset;
                        findById( items, "irHelp" ).hide = !o.help;

                        // 'download' and 'subscription' options both indicate if the developer has download enabled.
                        // if both cases, we also need to check the current view supports it.
                        findById( items, "irDownload" ).hide = !( o.download && $.inArray( that.viewMode, [ REPORT, GROUP_BY, PIVOT ] ) !== -1 );
                        findById( items, "irNotify" ).hide = !( o.subscription && $.inArray( that.viewMode, [ REPORT, GROUP_BY, PIVOT ] ) !== -1 );

                        if ( o.rowsPerPage ) {
                            rowsPerPageItem = findById( items, "irRowsPerPage" );
                            rowsPerPageItem.menu.items[ 0 ].choices = [];
                            rowsPerPageItemChoices = rowsPerPageItem.menu.items[ 0 ].choices;
                            maxRows = getMaxRows( o.maxRowsPerPage, o.maxRowCount, o.maxRowsToDisplay );

                            for ( i = 0; i < rowsPerPageChoices.length; i++ ) {
                                rpp = rowsPerPageChoices[ i ];

                                // If neither max row count or max rows per page are defined, maxRows will be null,
                                // in which case we still want the rows per page selector, so allow null maxRows (bug #27062517)
                                if ( maxRows && rpp > maxRows ) {
                                    break;
                                }
                                rowsPerPageItemChoices.push(
                                    { label: "" + rpp, value: rpp }
                                );
                            }

                            // If no max rows per page defined, add 'All' option
                            if ( !o.maxRowsPerPage ) {
                                rowsPerPageItemChoices.push(
                                    { label: getIRMsg( "ALL" ), value: 100000 }
                                );
                            }
                        }
                    }
                };
            }


            if ( o.toolbar && o.actionsMenu ) {
                that._getElement( "actions_menu" ).menu( lActionMenu );
            }
        },
        /**
         * Get useful details such as view type, selectors etc used by selection support
         * @ignore
         * @function _getSelectionDetails
         * @return {object}
         **/
        _getSelectionDetails: function() {
            const isReportView           = ( this.options.reportViewMode === REPORT ),
                  isIconView             = ( this.options.reportViewMode === ICON ),
                  isDetailView           = ( this.options.reportViewMode === DETAIL ),
                  detailViewItemSelector = isDetailView &&
                                           this.region$.find( ".a-IRR-detailView [data-id]" ).length > 0 ? // find the "For Each Row" attribute element
                                           this.region$.find( ".a-IRR-detailView [data-id]" )[0].nodeName.toLowerCase() :
                                           "li", // fallback to a ul/li element for "Before Rows/For Each Row" attributes
                  itemSelector           = ( isDetailView ? detailViewItemSelector : isIconView ? "td" : "tr" ) + "[data-id]", // let's add [data-id] to exclude certain elements we don't want
                  container$             = isReportView ? this.region$.find( ".a-IRR-table tbody" ) : // default IR
                                           isIconView ? this.region$.find( ".a-IRR-iconViewTable tbody" ) : // icon view
                                           isDetailView ? this.region$.find( ".a-IRR-detailView" ).children().first() : // detail view
                                           null;

            return {
                isReportView: isReportView,
                isIconView: isIconView,
                isDetailView: isDetailView,
                itemSelector: itemSelector,
                container$: container$
            };
        },
        /**
         * Initialize row selection support using ListViewSelection API
         * @ignore
         * @function _initSelection
         * @param pRefreshOnly
         * @param pHasPaginated
         **/
        _initSelection: function( pRefreshOnly, pHasPaginated ) {
            const self              = this,
                  options           = self.options,
                  refreshOnly       = pRefreshOnly || false,
                  hasPaginated      = pHasPaginated || false,
                  selectionDetails  = self._getSelectionDetails();

            const _contentChanged = () => {
                const content$ = selectionDetails.isReportView ? self.region$.find( `.a-IRR-table tbody ${selectionDetails.itemSelector}` ) : // default IR
                                 selectionDetails.isIconView ? self.region$.find( `.a-IRR-iconViewTable tbody ${selectionDetails.itemSelector}` ) : // icon view
                                 selectionDetails.isDetailView ? self.region$.find( `.a-IRR-detailView ${selectionDetails.itemSelector}` ) : // detail view
                                 null;

                // some options may have changed due to refresh or view change etc
                // so we re-set them properly
                self.listViewSelection.itemSelector = selectionDetails.itemSelector;
                self.listViewSelection.groupSelector = selectionDetails.isIconView ? "tr" : null;
                // The widget.stickyTableHeader implementation appears to interfere with the
                // initial application of certain options.  To work around this, we re-apply
                // these options asynchronously.  This resolves two problems
                // 1. Correct functionality of the select-all input (header was copied).
                // 2. Tabstop functionality on the first row (handled by itemNavigationMode).
                setTimeout( () => {
                    self.listViewSelection.selectAllId = selectionDetails.isReportView ? options.selection.selectAllId : null;
                    self.listViewSelection.itemNavigationMode = "select";
                }, 0 );

                if ( content$ && content$.length ) {
                    self.listViewSelection.contentChanged( content$ );

                    // re-apply visible state of already selected rows after pagination
                    if ( hasPaginated && options.selection.multiple ) {
                        self.listViewSelection.setSelectedValues( self.selection.savedSelection );
                    }
                }
            };

            // removes values from the saved selection that are no longer selected
            const removeUnselectedFromSaved = () => {
                if ( !self.selection.savedSelection ) {
                    return;
                }

                const notSelectedContent$ = selectionDetails.isReportView ? self.region$.find( `.a-IRR-table tbody ${selectionDetails.itemSelector}:not(.is-selected)` ) : // default IR
                                            selectionDetails.isIconView ? self.region$.find( `.a-IRR-iconViewTable tbody ${selectionDetails.itemSelector}:not(.is-selected)` ) : // icon view
                                            selectionDetails.isDetailView ? self.region$.find( `.a-IRR-detailView ${selectionDetails.itemSelector}:not(.is-selected)` ) : // detail view
                                            null;

                if ( notSelectedContent$ && notSelectedContent$.length ) {
                    let notSelectedValues = [];

                    notSelectedContent$.each( function () {
                      notSelectedValues.push( $( this ).attr( "data-id" ) );
                    } );


                    const notSelectedSet = new Set( notSelectedValues );

                    self.selection.savedSelection = self.selection.savedSelection.filter( x => !notSelectedSet.has( x ) );
                }
            };

            if ( options.selection ) {
                // we don't want selection to be initialized for views like charts, pivot etc
                if ( self.viewMode !== REPORT ) {
                    return;
                }

                // when the report get refreshed (pagination etc) we don't want to completely initialize
                // the selection API again
                if ( refreshOnly && self.listViewSelection ) {
                    _contentChanged();
                    return;
                }

                self.listViewSelection = new apex.widget.ListViewSelection( self.region$, {
                    itemNavigationMode: "select",
                    multiple: options.selection.multiple,
                    allowSelectAll: options.selection.selectAll,
                    selectAllId: selectionDetails.isReportView ? options.selection.selectAllId : null, // selectAll control is only visible in default report view
                    itemSelector: selectionDetails.itemSelector,
                    groupSelector: selectionDetails.isIconView ? "tr" : null, // improve keyboard navigation in icon view when multiple columns per row are used
                    selectionStateItem: options.selection.selectionStateItem,
                    allowCopy: true,
                    clipboardValue: ( i, item$ /*, m, record, recordId */ ) => {
                        const view = apex.region( self.options.regionId ).getViewName(),
                              clone$ = item$.clone(),
                              rowSelector$ = clone$.find( "input.u-selector" );

                        // cleanup the item DOM and remove our row selector column from it
                        if ( rowSelector$.length ) {
                            if ( view === "REPORT" ) {
                                rowSelector$.closest( "td" ).remove();
                            } else {
                                rowSelector$.remove();
                            }
                        }
                        return clone$;
                    }
                }, {
                    isValid: () => {
                        return self.region$.hasClass( "t-IRR-region" );
                    },
                    getContainer: () => {
                        return self._getSelectionDetails().container$;
                    },
                    getPagination: () => {
                        return {
                            virtual: false,
                            scroll: false,
                            loadMore: false
                        };
                    },
                    getValuesForItems: ( items$ ) => {
                        return items$.map( ( i, el ) => { return $( el ).attr( "data-id" ); } ).get();
                    },
                    // IR trims its saved multi-page selection before selectionStateItem is synchronized
                    // so pagination keeps the correct cross-page selection state.
                    beforeSelectionSync: () => {
                        removeUnselectedFromSaved();
                    },
                    selectionChanged: () => {
                        self.region$.trigger( EVENT_SELECTION_CHANGE, [{
                            selectedValues: self.listViewSelection.getSelectedValues()
                        }] );
                    },
                    currentItemChanged: () => {
                        self.region$.trigger( EVENT_CURRENT_ROW_CHANGE, [{
                            currentValue: apex.region( self.options.regionId ).getCurrentRowValue()
                        }] );
                    },
                    updateStatus: () => {}, // TODO: can be used for displaying a selection count in future for example
                    keyboardIgnoreSelector: () => {
                        return [
                            ".a-IRR-paginationWrap",
                            self._getIdSelector( "toolbar" ),
                            getIdSelector( self.options.regionId ) + " ." + C_INLINE_CHAT_CONTAINER
                        ].join( ", " );
                    }
                } );

                // overwrite getSelectedValues to include and keep saved state between page pagination
                self.listViewSelection._getSelectedValues = self.listViewSelection.getSelectedValues;

                self.listViewSelection.getSelectedValues = () => {
                    let currentSelection = self.listViewSelection._getSelectedValues();

                    // We take selection.savedSelection value into account
                    // useful if we want to persist selection state after pagination or refresh
                    if ( self.selection.savedSelection?.length > 0 ) {
                        currentSelection = [...new Set( [ ...self.selection.savedSelection, ...currentSelection ] )]; // merge savedSelection & currentSelection and remove dups
                    }
                    return currentSelection;
                };

                self.listViewSelection.initialize();

                _contentChanged();
            }
        },
        /**
         * Event handlers that are registered on _create
         * @ignore
         * @function _initOnCreate
         **/
        _initOnCreate: function() {

            function _setCurrentElementId( pEvent ) {
                this.currentElementId = $( pEvent.target ).attr( "id" );
            }

            var o = this.options,
                self = this;


            if ( o.toolbar ) {
                this._initToolbar( true );
            }

            this._initControlPanel();

            this._initSelection();

            // move column sort popup to the end of the document so that it doesn't get clipped
            $( document.body ).append( this._getElement( "sort_widget" ) );

            // Track current element for better focus management (bug #28293165). Mainly handled by focusin, but also
            // requires some logic on click for cases where focusin doesn't trigger (button click, enabling / disabling
            // settings).
            // Note: By virtue of being handlers on this.element, this logic will (correctly) exclude setting the
            // current element when focusing / clicking on elements in menu's, dialogs, etc.
            this._on( this.element, {
                "focusin": _setCurrentElementId,
                "click button, input[type=checkbox]": _setCurrentElementId
            } );

            this._on( this.element, {
                "click a.a-IRR-headerLink": function( pEvent ) {
                    if ( this.viewMode === REPORT ) {
                        this._controlsGet( "SORT_WIDGET", $( pEvent.currentTarget ).data( "column" ) );
                    } else if ( this.viewMode === GROUP_BY ) {
                        this._controlsGet( SHOW_GROUP_BY_SORT );
                    } else if ( this.viewMode === PIVOT ) {
                        this._controlsGet( SHOW_PIVOT_SORT );
                    }
                    pEvent.preventDefault();
                }
            } );

            // Pagination
            this._on( this.element, {
                "click button.a-IRR-button--pagination": function( pEvent ) {
                    let currentTarget$ = $( pEvent.currentTarget );
                    if ( o.detailLink && currentTarget$.data( "row-id" ) !== undefined ) {
                        this._controlsRow( currentTarget$.data( "row-id" ) );
                    } else if ( o.pagination ) {
                        this._paginate( currentTarget$.data( "pagination" ) );
                    }
                },
                "click a.a-IRR-pagination-reset": function( pEvent ) {
                    this._search( "SEARCH" );
                    pEvent.preventDefault();
                }
            } );
            if ( o.pagination ) {
                this._on( this.element, {
                    "click a.a-IRR-pagination-reset": function( pEvent ) {
                        this._search( "SEARCH" );
                        pEvent.preventDefault();
                    }
                } );
            }

            // Single row view
            if ( o.detailLink ) {
                this._on( this.element, {
                    "click a.a-IRR-detail-row": function ( pEvent ) {
                        this._controlsRow( $( pEvent.currentTarget ).data( "row-id" ) );
                        pEvent.preventDefault();
                    }
                } );
            }

            // Fixed header
            this._initFixedHeader();

            // Setup the handler for when visibility changes, in the case of a show we need to refresh any sticky
            // widgets and also trigger a resize event so that any listeners can resize accordingly (eg UT)
            apex.widget.util.onVisibilityChange( this.element[ 0 ], function( pShow ) {
                if ( pShow ) {
                    self.element.find( ".js-stickyTableHeader" ).trigger( "forceresize" );

                    // when the widget gets shown, if we need to be lazy loaded, refresh ourselves
                    // but only once
                    if( self.needsLazyLoading ){
                        self.needsLazyLoading = false;
                        self.refresh();
                    }
                }
            } );

        },
        /**
         * Initialises the toolbar styles
         * @ignore
         **/
        _initToolbarStyles: function() {

            // Some markup rendered from the server contains js-hidden. Safely inject the styles.
            util.applySafeHidden();

            this._getElement( "column_search_root" ).removeClass( C_IS_ACTIVE );
            this._getElement( "column_search_current_column" ).val( "" );

            if ( this.element.hasClass( C_SEARCH_MODE.AI ) ) {
                this._getElement( "column_search_root" ).find( SEL_ICON_SEARCH ).removeClass( C_ICON_SEARCH ).addClass( C_ICON_SEARCH_AI );
                this._getElement( "search_field" ).attr( { placeholder: MSG.SEARCH.PLACEHOLDER_AI } );
                this._getElement( "search_field" ).attr( ARIA_LABEL, MSG.SEARCH.AI_SEARCH );
                this._getElement( "toolbar" ).addClass( C_TOOLBAR_AI );
                this._getElement( "search_button" ).addClass( C_HIDDEN );
                this._getElement( "voice_search" ).removeClass( C_HIDDEN );
                this._getElement( "actions_button" ).find( SEL_IRR_ACTIONS_LABEL ).addClass( C_VISUALLY_HIDDEN );
                this._getElement( "actions_button" ).find( SEL_ICON_MENU_DROPDOWN ).removeClass( C_ICON_MENU_DROPDOWN ).addClass( C_ICON_ACTIONS );
            } else {
                this._getElement( "column_search_root" ).find( SEL_ICON_SEARCH_AI ).removeClass( C_ICON_SEARCH_AI ).addClass( C_ICON_SEARCH );
                this._getElement( "search_field" ).attr( { placeholder: MSG.SEARCH.PLACEHOLDER } );
                this._getElement( "toolbar" ).removeClass( C_TOOLBAR_AI );
                this._getElement( "search_button" ).removeClass( C_HIDDEN );
                this._getElement( "voice_search" ).addClass( C_HIDDEN );
                this._getElement( "actions_button" ).find( SEL_IRR_ACTIONS_LABEL ).removeClass( C_VISUALLY_HIDDEN );
                this._getElement( "actions_button" ).find( SEL_ICON_ACTIONS ).removeClass( C_ICON_ACTIONS ).addClass( C_ICON_MENU_DROPDOWN );

                if ( this.element.hasClass( C_SEARCH_MODE.ROW ) ) {
                    this._getElement( "search_field" ).attr( ARIA_LABEL, MSG.SEARCH.ROW_SEARCH );
                } else {
                    this._getElement( "search_field" ).attr( ARIA_LABEL, MSG.SEARCH.COLUMN_SEARCH );
                }
            }
        },
        /**
         * Initialises the toolbar microphone
         * @ignore
         **/
        _initToolbarMicrophone: function() {
            if ( this.options.aiEnabled && !SpeechRecognition ) {
                this._getElement( "voice_search" ).hide();
                debug.info( "Speech recognition not supported in this browser." );
            }
        },
        /**
         * Initialises the toolbar, including menus
         * @ignore
         **/
        _initToolbar: function ( pOnCreate ) {
            var o = this.options,
                that = this;

            // Persistent reference to the current speech recognition session
            let recognition = null;

            that._setIRHighlight();
            that._initToolbarMicrophone();
            that._initChatButton();
            util.setPCTGraphStyles();

            // Search field
            if ( o.searchField ) {
                this._on( this._getElement( "search_field" ), {
                    "keydown": function ( pEvent ) {
                        if ( pEvent.which === $.ui.keyCode.ENTER ) {
                            this._search( "SEARCH" );
                            pEvent.preventDefault();
                        }
                    }
                } );
                this._on( this._getElement( "search_button" ), {
                    "click": function ( pEvent ) {
                        this._search( "SEARCH" );
                        pEvent.preventDefault();
                    }
                } );
                // Clear search field and set focus back
                this._on( this._getElement( "clear_search_field" ), {
                    "click": function ( pEvent ) {
                        this._getElement( "search_field" ).val( "" ).trigger( "focus" );
                        pEvent.preventDefault();
                    }
                } );
                this._on( this._getElement( "voice_search" ), {
                    "click": function ( pEvent ) {

                        if ( o.aiEnabled && !SpeechRecognition ) {
                            debug.info( "Speech recognition not supported in this browser." );
                            return;
                        }

                        if ( !o.aiEnabled ) {
                            debug.info( "AI must be enabled on this Interactive Report for speech recognition." );
                            return;
                        }

                        const $button = this._getElement( "voice_search" );
                        const $icon  = $button.find( ".a-Icon" );

                        // If icon shows mic is active, we assume recognition is running
                        const isActive = $icon.hasClass( C_ICON_MICROPHONE_LISTEN );

                        // Helper to toggle mic icon UI based on recognition state
                        const setMicIcon = isOn => {

                            $icon.toggleClass( C_ICON_MICROPHONE, !isOn );
                            $icon.toggleClass( C_ICON_MICROPHONE_LISTEN, isOn );

                            if ( isOn ) {
                                $button.attr( TITLE, MSG.SEARCH.MICROPHONE_STOP );
                                $button.attr( ARIA_LABEL, MSG.SEARCH.MICROPHONE_STOP );
                                that._getElement( "search_field" )
                                    .addClass( C_JS_ACCESSIBLE_READONLY )
                                    .attr( ARIA_READONLY, true );
                            } else {
                                $button.attr( TITLE, MSG.SEARCH.MICROPHONE_START );
                                $button.attr( ARIA_LABEL, MSG.SEARCH.MICROPHONE_START );
                                that._getElement( "search_field" )
                                    .removeClass( C_JS_ACCESSIBLE_READONLY )
                                    .removeAttr( ARIA_READONLY );
                            }
                        };

                        // If already recording, stop recognition on second click
                        if ( isActive && recognition ) {
                            recognition.stop(); // onend will handle UI and cleanup
                            return;
                        }

                        // Create new recognition session using app language and live transcription
                        recognition = new SpeechRecognition();
                        recognition.lang = locale.getLanguage();
                        recognition.interimResults = true;

                        // Finalized speech content
                        let finalTranscript = "";
                        setMicIcon( true );
                        recognition.start();

                        recognition.onresult = event => {
                            let interimTranscript = "";

                            // Process all results starting from resultIndex
                            for ( let i = event.resultIndex; i < event.results.length; i++ ) {
                                const transcript = event.results[i][0].transcript;
                                if ( event.results[i].isFinal ) {
                                    finalTranscript += transcript + " ";
                                } else {
                                    interimTranscript += transcript;
                                }
                            }

                            // Continuously update input with final + current partial text
                            const currentTranscript = finalTranscript + interimTranscript;
                            this._getElement( "search_field" ).val( currentTranscript.trim() ).trigger( "input" );
                            pEvent.preventDefault();
                        };

                        recognition.onerror = event => {
                            if ( event.error === "no-speech" ) {
                                debug.warn( "No speech detected. Please try again." );
                            } else {
                                debug.error( "Speech recognition error:", event.error );
                            }

                            // Reset UI and recognition state
                            setMicIcon( false );
                            recognition = null;
                        };

                        recognition.onend = () => {
                            // Called when recognition ends naturally or is stopped
                            setMicIcon( false );
                            recognition = null;


                            // Trigger the actual search action after speech ends
                            if ( finalTranscript.trim() ) {
                                this._search( "SEARCH" );
                            }
                        };
                    }
                } );

                if ( o.columnSearch ) {
                    // initialize the search menu on create
                    if ( pOnCreate ) {
                        this._getElement( "column_search_drop" ).menu( {
                            asyncFetchMenu: function( menu, callback ) {
                                that.searchMenu = menu;
                                that.searchMenuCallback = callback;
                                that._controlsGet( "SEARCH_COLUMN" );
                            },
                            afterClose: function( event, data ) {
                                // radio menu item choices don't allow the set method to set focus
                                // so set focus here after a delay because the menu will put the focus back on the
                                // menu button after a delay
                                if ( data.actionTaken ) {
                                    setTimeout( function() {
                                        that._getElement( "search_field" ).trigger( "focus" );
                                    }, 100 );
                                }
                            },
                            items: [] // no items to start with they get filled in async
                        } );
                    }
                    // note: you wont see any code to open or toggle the search column menu because it is a menu button
                }
            }

            // Row select list
            if ( o.rowsPerPageSelect ) {
                this._on( this._getElement( "row_select" ), {
                    "change": function ( pEvent ) {
                        var lRowValue = pEvent.target.value;
                        this._search( "SEARCH", lRowValue );
                        pEvent.preventDefault();
                    }
                } );
            }

            // Saved reports select list
            if ( o.reportsSelect ) {
                this._on( this._getElement( "saved_reports" ), {
                    "change": function ( pEvent ) {
                        var lReportId = pEvent.target.value;
                        this._pull( {pAction: "REPORT_CHANGED", pReportId: lReportId} );
                        pEvent.preventDefault();
                    }
                } );
            }

            // View buttons
            this._on( this._getElement( "toolbar_controls" ), {
                "click .a-IRR-button--views": function ( pEvent ) {
                    var lView = $( pEvent.currentTarget ).data( "view" );
                    switch ( lView ) {
                        case "report":
                            this._reportView( REPORT );
                            break;
                        case "icon":
                            this._reportView( ICON );
                            break;
                        case "details":
                            this._reportView( DETAIL );
                            break;
                        case "chart":
                            this._chartView();
                            break;
                        case "group_by":
                            this._groupByView();
                            break;
                        case "pivot":
                            this._pivotView();
                            break;
                    }
                    //pEvent.preventDefault();
                },
                "click .a-IRR-chatButton": () => {
                    if ( this.chatView?.getMode() !== AI_CHATVIEW_INLINE ) {
                        this.openInlineChat( INLINE_CHAT_FOCUS_TARGET.INPUT );
                    }
                }
            } );

            // Actions menu
            if ( o.actionsMenu ) {
                // init the actions menu only once on create
                if ( pOnCreate ) {
                    this._initMenus();
                }
                // note: you wont see any code to open or toggle the actions menu because it is a menu button
            }
        },

        _inlinePicker: function( pControl, pData ) {
            const
                out = util.htmlBuilder(),
                lData = JSON.parse( pData ),
                lIcon$ = $( "[data-picker-for=" + util.escapeCSS( this.tempReturnElement$.attr( "id" ) ) + "]", this._getElement( DIALOG_JS_ID ) ),
                lInput$ = $( "#" + this.tempReturnElement$.attr( "id" ) ),
                lInputDialog$ = lInput$.closest( ".ui-dialog" ),
                lColValuesDropId = this._getId( "col_values_drop" ),
                selColValuesDrop = "#" + lColValuesDropId;
            let lColValuesDrop$;

            out.markup( "<div" )
                .attr( "role", "listbox" )
                .attr( ARIA_LABEL, getMsg( "APEX.POPUP_LOV.LIST_OF_VALUES" ) )
                .attr( "id", lColValuesDropId )
                .attr( "class", "a-IRR-col-values-drop" )
                .css( "position" ,"fixed" )
                .css( "top", ( lInput$[ 0 ].getBoundingClientRect().top + lInput$.outerHeight() ) + "px" )
                .css( "left", lInput$.offset().left + "px" )
                .markup( ">" );
            for ( let i = 0; i < lData.row.length; i++ ) {
                out.markup( "<a" )
                    .attr( "href", "#" )
                    .attr( "role", "option" )
                    .attr( "class", C_IRR_COL_VALUE )
                    .attr( "data-return-value", lData.row[ i ].R )
                    .markup( ">" )
                    .markup( lData.row[ i ].D ) // Escaping handled server-side according to column definition
                    .markup( "</a>" );
            }
            out.markup( "</div>" );
            // Popup LOV should not be clipped by the modal dialog. Temporarily set overflow to visible
            // The staticly positioned content of the dialog (ui-dialog-content) still has overflow:hidden
            lInputDialog$.css( "overflow", "visible" );
            // To be accessible with JAWS, the LOV code should be inside an element with role="dialog" (aria-modal=true)
            lInputDialog$.append( out.toJquery() );
            lColValuesDrop$ = $( selColValuesDrop );
            if( pControl === "NARROW" ) {
                this._on( lColValuesDrop$, {
                    "click a.a-IRR-col-value": function( pEvent ) {
                        var lCurrentValue,
                            lSelectedValue = $( pEvent.currentTarget ).data( "returnValue" ),
                            lCurrentOperator = this._dialogCurrentOperator().val();

                        if ( lCurrentOperator === "in" || lCurrentOperator === "not in" ) {
                            lCurrentValue = this.tempReturnElement$.val();
                            if ( lCurrentValue ) {
                                lSelectedValue = lCurrentValue + "," + lSelectedValue;
                            }
                            this.tempReturnElement$.val( lSelectedValue );
                        } else {
                            this.tempReturnElement$.val( lSelectedValue );
                            // Remove temporarily set overflow which was added to avoid the popup to be clipped
                            lInputDialog$.css( "overflow", "" );
                            lColValuesDrop$.remove();
                            this.tempReturnElement$.trigger( "focus" );
                        }
                        pEvent.preventDefault();
                    }
                } );
            } else {
                this._on( lColValuesDrop$, {
                    "click a.a-IRR-col-value": function( pEvent ) {
                        var lSelectedValue = $( pEvent.currentTarget ).data( "returnValue" );
                        this.tempReturnElement$.val( lSelectedValue );
                        // Remove temporarily set overflow which was added to avoid the popup to be clipped
                        lInputDialog$.css( "overflow", "" );
                        lColValuesDrop$.remove();
                        this.tempReturnElement$.trigger( "focus" );
                        pEvent.preventDefault();
                    }
                } );
            }

            // Bind keydown handler for keyboard navigation of narrow list, delegated to DIV container
            this._on( lColValuesDrop$, {
                "keydown a": function ( pEvent ) {
                    var lAnchorList$        = lColValuesDrop$.find( "a" ),  //$( "#apexir_col_values_drop a" ),
                        lCurrentIndex       = lAnchorList$.index( $( pEvent.target ) ),
                        lAnchorListLength   = lAnchorList$.length - 1;     /* minus 1, as this value is used to
                                                                            * compare to the current index, which
                                                                            * is itself zero indexed */

                    // Take anchors out of the natural tab order. Only UP and DOWN keys will work to move up
                    // and down the menu options. TAB will move to the next control out of the menu.
                    lAnchorList$.attr( "tabindex", -1 );
                    switch ( pEvent.which ) {
                        case $.ui.keyCode.DOWN:
                            if ( lCurrentIndex < lAnchorListLength ) {
                                // Move focus down if this is not the last anchor in the list
                                lAnchorList$.eq( lCurrentIndex + 1 )
                                    .attr( "tabindex", 0 )
                                    .trigger( "focus" );
                            } else {
                                // Move focus to first element if this is the last
                                lAnchorList$.eq( 0 )
                                    .attr( "tabindex", 0 )
                                    .trigger( "focus" );
                            }
                            pEvent.preventDefault();
                            break;
                        case $.ui.keyCode.UP:
                            if ( lCurrentIndex > 0 ) {
                                // Move focus up if this is not the first anchor in the list
                                lAnchorList$.eq( lCurrentIndex - 1 )
                                    .attr( "tabindex", 0 )
                                    .trigger( "focus" );
                            } else {
                                // Move focus to last element if this is the first
                                lAnchorList$.eq( lAnchorListLength )
                                    .attr( "tabindex", 0 )
                                    .trigger( "focus" );
                            }
                            pEvent.preventDefault();
                            break;
                        case $.ui.keyCode.TAB:

                            // If the user tabs, close the menu. We can't rely on browser to naturally set the
                            // focus for the next element, because different browsers behave differently (Firefox
                            // sets focus back to expression input, chrome sets focus back to top of the page).
                            // So we explicitly set this back to the calling popup icon.
                            // Remove temporarily set overflow which was added to avoid the popup to be clipped
                            lInputDialog$.css( "overflow", "" );
                            lColValuesDrop$.remove();
                            lIcon$.trigger( "focus" );
                            pEvent.preventDefault();
                            break;
                        case $.ui.keyCode.ESCAPE:

                            // If the user hits ESC, close the menu and move focus back to calling popup icon.
                            // Also stop immediate propagation so the event handlers at document level for
                            // Actions menu IRR keyboard support do not get triggered.
                            // Remove temporarily set overflow which was added to avoid the popup to be clipped
                            lInputDialog$.css( "overflow", "" );
                            lColValuesDrop$.remove();
                            lIcon$.trigger( "focus" );
                            pEvent.stopImmediatePropagation();
                            break;
                        default:
                            null;
                    }
                }
            } );

            // set up event handler to handle when the user clicks outside the container or drag the modal dialog
            this._dialogCheck( selColValuesDrop, function() {
                // Remove temporarily set overflow which was added to avoid the popup to be clipped
                lInputDialog$.css( "overflow", "" );
                lColValuesDrop$.remove();
            } );

    // close on page scroll
            this._on( this.document, {
                scroll: function( pEvent ) {
                    if ( !$( pEvent.target ).closest( selColValuesDrop ).length ) {
                        // Remove temporarily set overflow which was added to avoid the popup to be clipped
                        lInputDialog$.css( "overflow", "" );
                        lColValuesDrop$.remove();
                    }
                }
            } );

            // Return what we want to set focus to the first element
            return lColValuesDrop$.find( "a:first" );
        },

        /**
         * @ignore
         * */
        _paginate: function( pData ) {
            this._action( PAGE, {
                widgetActionMod: pData
            } );
        },

        /**
         * @ignore
         */
        _notifyClear: function() {
            this._action( "DELETE_NOTIFY", {
                id: this._getDialogElement( "notify_id" ).val()
            } );
        },
        /**
         * Saves a report notification via SAVE_NOTIFY action, passing item values via f01
         * @ignore
         */
        _notifySave: function() {
            var lIds = [ this._getId( "notify_id" ),
                         this._getId( "email_address" ),
                         this._getId( "email_subject" ),
                         this._getId( "notify_interval" ),
                         this._getId( "skip_if_ndf" ),
                         this._getId( "start_date" ),
                         this._getId( "end_date" ),
                         this._getId( "download_format" ),
                         this._getId( "data_only" ),
                         this._getId( "pdf_page_size" ),
                         this._getId( "pdf_orientation" ),
                         this._getId( "strip_rich_text" ),
                         this._getId( "accessible" ) ],
            lRequired = [ this._getId( "download_format" ) ],
            lValidate = $f_get_emptys( lRequired, "error", "" );

            if ( lValidate ) {
                return;
            }

            this._action( "SAVE_NOTIFY", {
                f01:    lIds,
                f02:    this._utilGetFormElValues( lIds )
            } );
        },

        _pivotMaxValue: 3,
        _pivotRemove: function() {
            this._action( "DELETE_PIVOT" );
        },
        _pivotSave: function() {
            var lFArrays = this._utilGetFormElAttributes();
            this._action( "SAVE_PIVOT", {
                f01: lFArrays.ids,
                f02: lFArrays.values
            } );
        },
        _pivotSort: function( pThis ) {
            var lFArrays,
                lPivotId = this._getDialogElement( "pivot_id" ).val();

            if( pThis === ASC || pThis === DESC ) {
                this.lastColumnId = pThis.id;
                this._action( "PIVOT_COLUMN_SORT", {
                    id:     lPivotId,
                    f01:    this.lastColumnId,
                    f02:    pThis
                } );
            } else {
                lFArrays = this._utilGetFormElAttributes();
                this._action( "PIVOT_SORT", {
                    id:     lPivotId,
                    f01:    lFArrays.ids,
                    f02:    lFArrays.values
                } );
            }
        },
        _pivotView: function() {
            this._action( "VIEW_PIVOT" );
        },

        /**
         * Pull worksheet report setting pReportId to current report
         * @ignore
         * @function
         * */
        _pull: function( { pAction, pReportId, pData } ) {
            var lData = $.extend( {
                widgetMod:      "PULL",
                widgetAction:   pAction,
                keepPagination: pData?.keepPagination
            }, pData );
            if( pReportId ) {
                this.reportId = pReportId;
            }
            this._get( lData );
        },

        /**
         * Delete current worksheet report
         * @ignore
         * @function
         * */
        _remove: function( pAction ) {
            var lAction = "DELETE";
            if ( pAction ) {
                lAction = pAction;
            }
            this._action( lAction );
        },

        /*
         * Controls the current view of the region (report, icon, etc.)
         */
        _reportView: function( pMode ) {
            this.options.reportViewMode = pMode;
            this._action( "VIEW_REPORT", {
                p_widget_view_mode: this.options.reportViewMode
            } );
        },

        /**
         * Reset current worksheet report to initial state
         * @ignore
         * @function
         * */
        _reset: function() {
            // Reset should stop any in-flight AI round-trip immediately, but only clear the
            // transcript once the reset request succeeds.
            this.chatModel?.abortCommit();
            this._action( "RESET" );
        },

        /**
         * Save or Rename current worksheet report state
         * @ignore
         * @function
         * @param {String} pReportId      Passed for a rename (although the report Id is actually determined from the form items)
         * */
        _save: function( pReportId ) {
            var lIds = [],
                lAction = "SAVE",
                lReportNameId = this._getId( "report_name" ),
                lValidate = $f_get_emptys( [ lReportNameId ], "error", "" );

            if ( lValidate ) {
                return;
            }
            if ( pReportId ) {
                lAction = "RENAME";
            }
            lIds.push( lReportNameId );
            lIds.push( this._getId( "public_report" ) );    //todo don't need to send this when save public reports is off
            lIds.push( this._getId( "report_description" ) );
            this._action( lAction, {
                f01:    lIds,
                f02:    this._utilGetFormElValues( lIds )
            } );

            // Manually close dialog because this control has client-side validation, and we don't automatically close in case there's an error
            this._getElement( DIALOG_JS_ID ).dialog( "close" );
        },

        /**
         * Save current worksheet report state as default worksheet report
         * @ignore
         * @function
         * */
        _saveDefault: function( pAction ) {
            var lValidate,
                lIds = [],
                lValues = [],
                lAction = "SAVE_DEFAULT",
                lDefaultTypeId = this._getId( "default_type" ),
                lDefaultType = $v( lDefaultTypeId ),
                lReportNameId = this._getId( "report_name" );
            if ( lDefaultType === "ALTERNATIVE" ) {
                lValidate = $f_get_emptys( [ lReportNameId ], "error", "" );
            }
            if( !lValidate ){
                if ( pAction ) {
                    lAction = pAction;
                }
                lIds.push( lDefaultTypeId );
                lValues.push( lDefaultType );

                // Only send report name if saving alternative default
                if ( lDefaultType === "ALTERNATIVE" ) {
                    lIds.push( lReportNameId );
                    lValues.push( this._getDialogElement( "report_name" ).val() );
                }
                this._action( lAction, {
                    f01:    lIds,
                    f02:    lValues
                } );

                // Manually close dialog because this control has client-side validation, and we don't automatically close in case there's an error
                this._getElement( DIALOG_JS_ID ).dialog( "close" );

            }
        },

        /**
         * Init style function used by save default dialog
         * todo move to closer scope
         * @ignore
         * @function _saveDefaultTypeCheck
         **/
        _saveDefaultTypeCheck: function ( pDefaultType ) {
            var lIsAlternativeDefault = ( pDefaultType === "ALTERNATIVE" );
            this._getDialogElement( "report_name" )
                .closest( ".u-Form-fieldContainer" )
                .toggle( lIsAlternativeDefault );
        },

        /**
         * Runs the basic search functionality of the worksheet.
         * @ignore
         * @param {String} [pThis] if set to SEARCH check
         * @param {Number} [pRows] Optionally set to control the number of rows displayed, needs to be done with the search
         *                         because the user could enter a new search, then select the rows which would issue the search
         *
         * */
        _search: function( pThis, pRows ) {
            let lData,
                lFArrays;
            const o = this.options,
                lSearch = this._getElement( "search_field" ).val(),
                wordCount = lSearch.trim().split( /\s+/ ).length;

            // If pRows passed, this has been changed and the new value used, but only allow if either actions menu
            // row select, or search bar row select is enabled
            if ( pRows && ( o.rowsPerPage || o.rowsPerPageSelect ) ) {
                o.currentRowsPerPage = pRows * 1;
            }

            lFArrays = this._utilGetFormElAttributes( this._getId( "toolbar_controls" ) );
            lData = {
                f01:    lFArrays.ids,
                f02:    lFArrays.values
            };
            if ( lSearch === "" ) {
                this._pull( { pReportId: this.reportId, pData: lData } );
            } else {
                if ( this.element.hasClass( C_SEARCH_MODE.AI ) && wordCount >= 3 ) {
                    // Don't trigger AI search if it's already in progress
                    if ( !this.chatModel.isLocked() ) {
                        this.chatModel.addUserMessage( lSearch );
                        this.chatModel.commit().catch( () => { } );
                    }
                } else {
                    if ( this.options.aiEnabled ) {
                        // lFArrays.values[0] contains the columnName by which we will get the display name
                        // and show a notification in the chat widget - something like "you searched for ABC on column XYZ".
                        // If falsy, it was a row search and we won't show the column display name in the notification at all.
                        this._addNonAiFilterNotificationToChat( lSearch, { columnName: lFArrays.values[0] } );
                    }
                    this._action( "QUICK_FILTER", lData );
                }
            }
        },

        _addNonAiFilterNotificationToChat: async function ( searchString, { columnName, columnDisplayName } ) {
            if ( !this.columnMapping && columnName && !columnDisplayName ) {
                try {
                    // Reusing the SEARCH_COLUMN menu's functionality / props
                    const map = await server.plugin( this.options.ajaxIdentifier, {
                        p_widget_name: "worksheet",
                        p_widget_mod: "CONTROL",
                        p_widget_action: "SEARCH_COLUMN",
                        p_widget_num_return: this.options.currentRowsPerPage,
                        x01: this.worksheetId,
                        x02: this.reportId,
                        pageItems: this.options.pageItems
                    } );
                    // transform into: { COLUMN_NAME: "Column Name", ... }
                    this.columnMapping = map.row.reduce( ( acc, { R, D } ) => {
                        if ( !isNaN( R ) ) {
                            return acc; // skip numeric keys
                        }
                        acc[R] = D;
                        return acc;
                    }, {} );
                } catch {
                    // silent
                }
            }

            // if no columnName and no displayName, it is a "regular" row search, otherwise column search
            if ( columnName && !columnDisplayName ) {
                columnDisplayName = this.columnMapping?.[columnName];
            }

            const str = columnDisplayName ? MSG.SEARCH.CHAT_SEARCH_COLUMN : MSG.SEARCH.CHAT_SEARCH_ROW;
            this.chatModel?.addNotification( str, {
                type: ai.ChatModel.notificationTypes.GENERIC,
                placeholders: {
                    SEARCH_STRING: searchString,
                    COLUMN_NAME: columnDisplayName
                }
            } );
        },

        _setDateFieldFormatMask: function( pElement$, pFormatMask ) {
            if ( pElement$.length > 0 && pFormatMask ) {
                // When loading the dialog of a saved filter, setting some datepicker options can either clear or
                // change the datepicker field's display to show the format, therefore we save the value first so as
                // to be able to re-instate it after the datepicker option changes
                const lOldValue = pElement$.attr( "value" ),
                      currentDate = date.format( new Date(), pFormatMask );

                // Save old format mask, we check this later to see if the value is still in a valid format
                const lOldFormatMask = pElement$.attr( "format" );

                let lShowTime = false;

                if ( /HH|hh/.test( pFormatMask ) ) {
                    lShowTime = true;
                }

                // Set time / date specific options
                pElement$
                    .attr( "show-time", lShowTime )
                    .attr( "format", pFormatMask )
                    .attr( "placeholder", lang.formatMessageNoEscape( "APEX.SAMPLE_FORMAT_SHORT", currentDate ) );

                // Clear the datepicker, as setting some options cause the field to show the format
                pElement$.val( "" );

                // Set the value of the date field, but only if the old and new format masks are the same,
                // (we don't want to leave a value in there with an incorrect format mask).
                if ( pFormatMask === lOldFormatMask ) {
                    pElement$.val( lOldValue );
                }
            }
        },
        _singleRowViewClear: function() {
            var lSingleRowView$ = this._getElement( "single_row_view" ),
                lReportViewButton$ = this._getElement( "report_view" );
            this._off( lSingleRowView$ );
            this._off( lReportViewButton$ );
            lSingleRowView$.html( "" );
            return lSingleRowView$;
        },
        /** @ignore */
        _singleRowViewControl: function() {
            var lExcludeNulls$ = this._getElement( "exclude_nulls" ),
                lShowDisplayedOnly$ = this._getElement( "show_displayed_only" ),
                lIsExcludeNulls = lExcludeNulls$.prop( CHECKED ),
                lIsShowDisplayedOnly = lShowDisplayedOnly$.prop( CHECKED ),
                lRows$ = $( "div.a-IRR-singleRow-row", this.element ),
                lColumnsDisplayed$ = lRows$.filter( ".is-displayed" ),
                lColumnsOther$ = lRows$.not( ".is-displayed" ),
                lColumnsNull$ = lRows$.filter( ".is-null" );

            // Show relevant columns (no need to show nulls, because displayed and other (non-displayed) covers all cases)
            lColumnsDisplayed$.show();
            lColumnsOther$.show();
            lColumnsNull$.show();

            if ( lIsExcludeNulls && lIsShowDisplayedOnly ) {
                lColumnsNull$.hide();
                lColumnsOther$.hide();
            } else if ( lIsExcludeNulls ) {
                lColumnsNull$.hide();
            } else if ( lIsShowDisplayedOnly ) {
                lColumnsOther$.hide();
            }

            // This call just updates preferences, no DOM update
            this._action( "CHANGE_DETAIL_OPTION", {
                value:  ( lIsExcludeNulls ) ? lExcludeNulls$.val() : "",
                x05:    ( lIsShowDisplayedOnly ) ? lShowDisplayedOnly$.val() : ""
            } );
        },
        _singleRowViewHide: function() {
            this._singleRowViewClear().hide();
        },
        _singleRowViewShow: function( pData ) {
            var lSingleRowView$ = this._singleRowViewClear();

            this._getElement( "full_view" ).hide();
            this._getElement( "data_panel" ).val( "" );
            this._getElement( DIALOG_JS_ID ).html( "" );
            lSingleRowView$
                .html( pData )
                .show();

            // Focus back on first focusable element in single row view
            lSingleRowView$.find( ":focusable" ).first().trigger( "focus" );

            this._singleRowViewControl();

            // Handlers specific to single row view
            if ( this.options.detailLink ) {
                this._on( this._getElement( "report_view" ), {
                    "click": function( pEvent ) {
                        this._pull( {pReportId: $( pEvent.target ).data( "report-id" )} );
                    }
                } );
                this._on( lSingleRowView$, {
                    "click input.a-IRR-viewOptions-checkbox": function() {
                        this._singleRowViewControl();
                    }
                } );
                $( "." + C_IRR_SINGLE_ROW_GROUP ).collapsible( {
                    collapsed: false
                } );
            }
        },

        // hide the column header widget
        _sortWidgetHide: function() {
            const lSortWidget$ = this._getElement( "sort_widget" );

            if ( lSortWidget$.is( ":visible" ) ) {
                const
                    lSortWidgetAscButton$ = this._getElement( "sort_widget_action_up" ).find( SEL_IRR_SORT_WIDGET_BUTTON ),
                    lSortWidgetDescButton$ = this._getElement( "sort_widget_action_down" ).find( SEL_IRR_SORT_WIDGET_BUTTON ),
                    lSortWidgetRows$ = this._getElement( "sort_widget_rows" ),
                    lSortWidgetSearchField$ = this._getElement( "sort_widget_search_field" ),
                    lLastColumn$ = $( "[data-column=" + this.lastColumnId + "]", this.element );

                // As well as hide, we need to clear the previous position, and then re-instate the absolute positioning
                lSortWidget$
                    .removeAttr( "style" )
                    .css( {
                        position:   "absolute",
                        display:    "none"
                    } );
                lLastColumn$
                    .closest( ".a-IRR-header" )
                    .removeClass( C_IS_ACTIVE );
                lSortWidgetRows$.html( "" );

                // remove active state that could be on either sort up / down buttons
                $( SEL_IRR_SORT_WIDGET_BUTTON, this.element ).removeClass( C_IS_ACTIVE );
                lSortWidgetAscButton$.removeAttr( ARIA_PRESSED );
                lSortWidgetDescButton$.removeAttr( ARIA_PRESSED );

                // De-register event handlers
                this._off( lSortWidget$ );
                this._off( lSortWidgetRows$ );
                this._off( lSortWidgetSearchField$ );
            }
        },

        // sort widget executes a search in the report
        _sortWidgetSearch: function( pValue, pDoContains ) {
            const lOperator = ( pDoContains ) ? "contains" : "=";
            const lTemp = [ this.currentColumnId, lOperator, pValue, "", "" ];
            this._sortWidgetHide();
            this._action( "COL_FILTER", {
                f01: lTemp
            } );
        },

        // show the column header widget
        _sortWidgetShow: function( pData ) {
                const
                    lData = JSON.parse( pData ),
                    out = util.htmlBuilder(),
                    lSortWidget$ = this._getElement( "sort_widget" ),
                    lSortWidgetHelp$ = this._getElement( "sort_widget_help" ),
                    lSortWidgetRows$ = this._getElement( "sort_widget_rows" ),
                    lCurrentColumn$ = $( "[data-column='" + this.currentColumnId + "']", this.element ),
                    lSortWidgetSearch$ = this._getElement( "sort_widget_search" ),
                    lSortWidgetSearchField$ = this._getElement( "sort_widget_search_field" ),
                    colLabel = lCurrentColumn$.first().text(),
                    lSortWidgetAscButton$ = this._getElement( "sort_widget_action_up" ).find( SEL_IRR_SORT_WIDGET_BUTTON ),
                    lSortWidgetDescButton$ = this._getElement( "sort_widget_action_down" ).find( SEL_IRR_SORT_WIDGET_BUTTON );
            let lSortWidgetFirstFocusable$, lSortWidgetLastFocusable$, lRowLength;


            // sets up first and last focusable elements in the sort widget, used to trap keyboard focus
            function _sortWidgetFocusableFlags( pExcludeFirst ) {
                var lFocusableElements$ = lSortWidget$.find( ":focusable" );
                if ( !pExcludeFirst ) {
                    lSortWidgetFirstFocusable$ = lFocusableElements$.first();
                    lSortWidgetFirstFocusable$.data( "first", true );
                }
                lSortWidgetLastFocusable$ = lFocusableElements$.last();
                lSortWidgetLastFocusable$.data( "last", true );
            }

            // set visually hidden header to show the column name to screen reader users
            lSortWidget$.find( "h1" ).html( lang.formatMessage( "APEXIR_COLUMN_HEADER_ACTIONS_FOR", colLabel ) );

            // dialog.id can either be a column ID or computation ID, depending on the call
            this.computationId = lData.dialog.id;

            // Hide column help in case that's displayed
            lSortWidgetHelp$.empty().hide();
            this._getElement( "sort_widget_action_help" )
                .find( SEL_IRR_SORT_WIDGET_BUTTON )
                .removeClass( C_IS_ACTIVE )
                .attr( ARIA_PRESSED, "false" )
                .removeAttr( ARIA_DESCRIBEDBY )
                .removeAttr( ARIA_DETAILS )
                .removeAttr( ARIA_CONTROLS );

            //
            // This code shows or hides control elements
            //
            $( SEL_IRR_SORT_WIDGET_BUTTON , lSortWidget$ ).parent().show();

            lData.dialog.hide.forEach( function ( val ) {
                $( getIdSelector( val ), lSortWidget$ ).hide();
            } );

            // Update lead sort active state if appropriate
            if ( lData.dialog.leadSortDir ) {
                if ( lData.dialog.leadSortDir === ASC ) {
                    lSortWidgetAscButton$.addClass( C_IS_ACTIVE )
                        .attr( ARIA_PRESSED, "true" );
                    lSortWidgetDescButton$.attr( ARIA_PRESSED, "false" );
                } else if ( lData.dialog.leadSortDir === DESC ) {
                    lSortWidgetAscButton$.attr( ARIA_PRESSED, "false" );
                    lSortWidgetDescButton$.addClass( C_IS_ACTIVE )
                        .attr( ARIA_PRESSED, "true" );
                }
            } else {
                lSortWidgetAscButton$.attr( ARIA_PRESSED, "false" );
                lSortWidgetDescButton$.attr( ARIA_PRESSED, "false" );
            }

            //
            // The following code populates the unique value list
            //
            if ( lData.dialog.uv ) {
                lRowLength = lData.dialog.row.length;
                for ( let i = 0; i < lRowLength; i++ ) {
                    let lDisplay;
                    // Check if R is truthy, and as an exception allow zero 0, as that's valid for a data value (bug 20838759)
                    if ( lData.dialog.row[ i ].R === 0 || lData.dialog.row[ i ].R ) {
                        if ( lData.dialog.row[ i ].D === 0 || lData.dialog.row[ i ].D ) {
                            lDisplay = lData.dialog.row[ i ].D;
                        }
                        else {
                            lDisplay = lData.dialog.row[ i ].R;
                        }
                        out.markup( "<a" )
                            .attr( "href", "#" )
                            .attr( "data-return-value", lData.dialog.row[ i ].R )
                            .attr( "class", "a-IRR-sortWidget-row" )
                            .markup( ">" )
                            .markup( lDisplay )  // Escaping handled server-side according to column definition
                            .markup( "</a>" );
                    }
                }
                lSortWidgetRows$.append( out.toString() );
                lSortWidgetSearch$.show();
                lSortWidgetSearchField$.val( "" );
            } else {
                lSortWidgetSearch$.hide();
            }

            lSortWidget$
                .show()
                .position( {
                    my: "left top",
                    at: "left bottom",
                    of: lCurrentColumn$
                } );

            lCurrentColumn$.closest( ".a-IRR-header" ).addClass( C_IS_ACTIVE );

            this.lastColumnId = this.currentColumnId;

            /*
             * Event handlers for the sort widget
             */
            this._on( lSortWidget$, {

                // handler for clicking on the sort widget actions (sort, break, etc.)
                "click button.a-IRR-sortWidget-button": function ( pEvent ) {
                    var lTargetOption = $( pEvent.currentTarget ).data( "option" );
                    switch ( lTargetOption ) {
                        case "up":
                            this._columnOrder( ASC );
                            break;
                        case "down":
                            this._columnOrder( DESC );
                            break;
                        case "hide":
                            this._columnHide();
                            break;
                        case "break":
                            this._controlBreakOn();
                            break;
                        case "help":
                            this._columnHelp();
                            break;
                        case "computation":
                            this._computationShow();
                            break;
                    }
                },
                "keydown": function ( pEvent ) {

                    // escape to close widget, set focus back to header
                    if ( pEvent.which === $.ui.keyCode.ESCAPE ) {
                        this._sortWidgetHide();
                        pEvent.preventDefault();
                        lCurrentColumn$.trigger( "focus" );
                    }

                    // trap keyboard focus
                    if ( pEvent.which === $.ui.keyCode.TAB ) {
                        var lGoingBackwards = !!( pEvent.shiftKey );

                        // if tabbing forwards and we've tabbed away from the last, go to the first
                        if ( !lGoingBackwards && $( pEvent.target  ).data( "last" ) ) {
                            pEvent.preventDefault();
                            lSortWidgetFirstFocusable$.trigger( "focus" );
                        }

                        // if tabbing backwards and we've tabbed away from the first, go to the last
                        if ( lGoingBackwards && $( pEvent.target ).data( "first" ) ) {
                            pEvent.preventDefault();
                            lSortWidgetLastFocusable$.trigger( "focus" );
                        }
                    }
                }
            } );

            // handler for clicking on a column value to set a quick filter, does exact match on column value
            this._on( lSortWidgetRows$, {
                "click a": function ( pEvent ) {
                    this._sortWidgetSearch( $( pEvent.currentTarget ).data( "returnValue" ) );
                    pEvent.preventDefault();
                }
            } );

            // sort widget search handlers
            this._on( lSortWidgetSearchField$, {

                // handler that filters the sort widget list
                "keyup": function ( pEvent ) {
                    lSortWidgetLastFocusable$.data( "last", false );
                    $d_Find( this._getId( "sort_widget_rows" ), pEvent.target.value, "a" );
                    _sortWidgetFocusableFlags( true );
                },

                // handler that triggers a report search based on the current entered filter, does contains in case
                // current filter value is part-complete
                "keydown": function ( pEvent ) {
                    if ( pEvent.which === $.ui.keyCode.ENTER ) {
                        this._sortWidgetSearch( $( pEvent.target ).val(), true );
                        pEvent.preventDefault();
                    }
                }
            } );
            this._dialogCheck( null, this._sortWidgetHide );
            _sortWidgetFocusableFlags();

            // set focus to first focusable control
            lSortWidgetFirstFocusable$.trigger( "focus" );
        },

        /**
         * Utility function that returns a jQuery object containing all form elements within a container
         * @ignore
         * @function _utilGetFormEls
         **/
        _utilGetFormEls: function( pContainerId ) {
            return $( getIdSelector( pContainerId ) + " :input" ).not( "button" );
        },
        /**
         * Utility function that returns an object containing ids and values arrays for all elements in the container passed
         * @ignore
         * @function _utilGetFormElAttributes
         **/
        _utilGetFormElAttributes: function( pContainerId ) {
            var lContainerId, lIds = [], lValues = [];
            if ( pContainerId ) {
                lContainerId = pContainerId;
            } else {

                //default to dialog if not passed
                lContainerId = this._getId( DIALOG_JS_ID );
            }
            this._utilGetFormEls( lContainerId ).each( function( i, pElement ) {
                lIds.push( pElement.id );
                lValues.push( $v( pElement.id ) );
            } );
            return {
                ids:    lIds,
                values: lValues
            };
        },
        /**
         * Utility function that
         * @ignore
         * @function _utilGetFormElValues
         **/
        _utilGetFormElValues: function( pIdArray ) {
            var i, lValues = [];
            for ( i = 0; i < pIdArray.length; i++ ) {
                lValues.push( $v( pIdArray[ i ] ) );        // todo would like to not have to go through our base item framework here
            }
            return lValues;
        },
        /**
         * Utility function to replace attribute text
         *
         * Sometimes we call this where we only want to replace an occurence of pOld where it appears at the end of
         * the string (for example when replacing ID values where the ID itself may contain an occurrence of that string).
         * This can be done by passing in a regular expression to pOld, eg: new RegExp( "01" + "$" )
         * @ignore
         * @function _utilReplaceAttrText
         **/
        _utilReplaceAttrText: function( pSelector$, pAttr, pOld, pNew ) {
            var lNewAttrValue = pSelector$.attr( pAttr ).replace( pOld, pNew );
            pSelector$.attr( pAttr, lNewAttrValue );
        },
        /**
         * Utility function to add more column controls to a dialog (eg pivot, group by)
         * @ignore
         * @function addMoreColumn
         **/
        _utilAddMoreColumn: function( pMaxDisplay, pClass ) {
            var lDisplayed, lOldNum, lNewNum, lOldID, lNewID, lLastColumn$, lNewColumn$, lNewSelect$, lNewLabels$,
                lDialog$ = this._getElement( DIALOG_JS_ID );
            lDisplayed = $( "select." + pClass, lDialog$ ).length;
            if ( lDisplayed < pMaxDisplay ) {
                lOldNum = lDisplayed;
                lNewNum = lDisplayed + 1;
                if ( lOldNum < 10 ) {
                    lOldID = "0" + lOldNum;
                    lNewID = "0" + lNewNum;
                } else {
                    lOldID = lOldNum + "";
                    lNewID = lNewNum + "";
                }

                lLastColumn$ = $( "div." + pClass + "-row-" + lOldNum, lDialog$ );
                lNewColumn$ = lLastColumn$.clone();

                this._utilReplaceAttrText( lNewColumn$, "class", lOldNum, lNewNum );
                $( "." + C_IRR_SEQ_NUM, lNewColumn$ ).text( lNewNum );

                lNewSelect$ = $( "select." + pClass, lNewColumn$ );
                this._utilReplaceAttrText( lNewSelect$, "id", new RegExp( lOldID + "$" ), lNewID );

                lNewLabels$ = $( "label", lNewColumn$ );
                lNewLabels$.each( function(){
                    var curLabel = $( this );
                    curLabel.attr( "for",curLabel.attr( "for" ).replace( new RegExp( lOldID + "$" ), lNewID ) );
                    curLabel.text( curLabel.text().replace( lOldNum, lNewNum ) );
                } );

                lNewColumn$.insertAfter( lLastColumn$ );
            }

            if ( lNewNum === pMaxDisplay ) {
                $( "." + pClass + "-add", lDialog$ ).hide();
                lNewColumn$.trigger( "focus" );
            }
        },
        /**
         * Utility function to add more function controls to a dialog (eg pivot, group by)
         * @ignore
         * @function addMoreFunction
         **/
        _utilAddMoreFunction: function( pMaxDisplay ) {
            var lDisplayed, lOldNum, lNewNum, lOldID, lNewID, lLastFunction$,
                lNewFunction$, lNewFunctionSelect$, lNewNumColumnSelect$, lNewAllColumnSelect$,
                lNewLabel$, lNewFormatMask$, lNewFormatMaskPicker$, lNewSum$, lNewFormItemLabels$,
                lDialog$ = this._getElement( DIALOG_JS_ID );

            lDisplayed = $( "select." + C_IRR_FUNCTION, lDialog$ ).length;

            if ( lDisplayed < pMaxDisplay ) {
                lOldNum = lDisplayed;
                lNewNum = lDisplayed + 1;

                if ( lOldNum < 10 ) {
                    lOldID = "0" + lOldNum;
                    lNewID = "0" + lNewNum;
                } else {
                    lOldID = lOldNum + "";
                    lNewID = lNewNum + "";
                }

                lLastFunction$ = $( "div." + C_IRR_FUNCTION_ROW + lOldNum, lDialog$ );
                lNewFunction$ = lLastFunction$.clone();

                this._utilReplaceAttrText( lNewFunction$, "class", lOldNum, lNewNum );
                $( "." + C_IRR_SEQ_NUM, lNewFunction$ ).text( lNewNum );

                //function select list
                lNewFunctionSelect$ = $( "select." + C_IRR_FUNCTION, lNewFunction$ );

                this._utilReplaceAttrText( lNewFunctionSelect$, "id", new RegExp( lOldID + "$" ), lNewID );

                //column select list div tag
                this._utilReplaceAttrText( $( this._getIdSelector( "number_columns_container" ) + "_" + lOldID, lNewFunction$ ), "id", new RegExp( lOldID + "$" ), lNewID );
                this._utilReplaceAttrText( $( this._getIdSelector( "all_columns_container" ) + "_" + lOldID, lNewFunction$ ), "id", new RegExp( lOldID + "$" ), lNewID );

                //column select list
                lNewNumColumnSelect$ = $( "select." + C_IRR_FUNCTION_NUM_COL, lNewFunction$ );
                this._utilReplaceAttrText( lNewNumColumnSelect$, "id", new RegExp( lOldID + "$" ), lNewID );
                lNewAllColumnSelect$ = $( "select." + C_IRR_FUNCTION_COL, lNewFunction$ );
                this._utilReplaceAttrText( lNewAllColumnSelect$, "id", new RegExp( lOldID + "$" ), lNewID );

                // label
                lNewLabel$ = $( this._getIdSelector( "label" ) + "_" + lOldID, lNewFunction$ );
                this._utilReplaceAttrText( lNewLabel$, "id", new RegExp( lOldID + "$" ), lNewID );
                // INPUT elements clone the value also, so let's clear it
                lNewLabel$.val( "" );

                // format mask
                lNewFormatMask$ = $( this._getIdSelector( "format_mask" ) + "_" + lOldID, lNewFunction$ );
                this._utilReplaceAttrText( lNewFormatMask$, "id", new RegExp( lOldID + "$" ), lNewID );
                // INPUT elements clone the value also, so let's clear it
                lNewFormatMask$.val( "" );

                // format mask picker
                lNewFormatMaskPicker$ = $( this._getIdSelector( "format_mask_picker" ) + "_" + lOldID, lNewFunction$ );
                this._utilReplaceAttrText( lNewFormatMaskPicker$, "id", new RegExp( lOldID + "$" ), lNewID );
                this._utilReplaceAttrText( lNewFormatMaskPicker$, "data-picker-for", new RegExp( lOldID + "$" ), lNewID );
                this._utilReplaceAttrText( lNewFormatMaskPicker$, TITLE, lOldNum, lNewNum );
                this._utilReplaceAttrText( lNewFormatMaskPicker$, ARIA_LABEL, lOldNum, lNewNum );

                // sum
                lNewSum$ = $( this._getIdSelector( "function_sum" ) + "_" + lOldID, lNewFunction$ );
                this._utilReplaceAttrText( lNewSum$, "id", new RegExp( lOldID + "$" ), lNewID );
                this._utilReplaceAttrText( lNewSum$, TITLE, lOldNum, lNewNum );
                // INPUT elements clone the value also, so let's clear it
                lNewSum$.prop( CHECKED, false );

                lNewFormItemLabels$ = $( "label", lNewFunction$ );
                lNewFormItemLabels$.each( function(){
                    var curLabel = $( this ),
                        ariaLabelledBy = curLabel.attr( "aria-labelledby" );
                    curLabel.attr( "for",curLabel.attr( "for" ).replace( new RegExp( lOldID + "$" ), lNewID ) );
                    if ( curLabel.hasClass( C_SWITCH ) && ariaLabelledBy ) {
                        curLabel.attr( "aria-labelledby", ariaLabelledBy.replace( new RegExp( lOldID + "$" ), lNewID ) );
                    } else {
                        curLabel.text( curLabel.text().replace( lOldNum, lNewNum ) );
                    }
                } );

                lNewFunction$.insertAfter( lLastFunction$ );
            }

            if ( lNewNum === pMaxDisplay ) {
                $( "." + C_IRR_ADD_FUNCTION, lDialog$ ).hide();
                lNewFunction$.trigger( "focus" );
            }
        },

        _setIRHighlight: function() {
            $( "[data-bgcol][data-ftcol]", this.region$ ).each( function() {
                let el$ = $( this );

                el$.css( {
                    "color": el$.attr( "data-ftcol" ),
                    "background-color": el$.attr( "data-bgcol" )
                } );
            } );
        },

        _setIRHighlightPreview: function() {
            $( "[data-bg-color][data-font-color]", this.region$ ).each( function() {
                let el$ = $( this );

                el$.css( {
                    "background-color": el$.attr( "data-bg-color" ),
                    "color" : el$.attr( "data-font-color" )
                 } );
            } );
        },


        /**
         * generic call for returning dialogs with validation
         * @ignore
         * @function _validAction
         **/
        _validAction: function( pTest ) {
            if( pTest === "true" ) {
                this._pull( {pAction: "PULL_TOOLBAR"} );   //todo don't always do this with every PULL, just needed for save chart, others?
                this._getElement( DIALOG_JS_ID ).dialog( "close" );
            } else {
                this._getDialogElement( "dialog_msg" ).html( pTest );
                this.options.reportViewMode = REPORT;
            }
        },


        /*
         * Public functions
         */
        refresh: function ( { pKeepPagination = false, pA11yQuietSpinner = false } = {} ) {
            var pData = {
                keepPagination: pKeepPagination,
                a11yQuietSpinner: pA11yQuietSpinner
            };
            this._pull( { pData } );
        },

        openDialogChat: function () {
            if ( !this.options.aiEnabled ) {
                debug.info( "Natural Language Support is not enabled in this IR." );
                return;
            }

            if ( this.chatView?.getMode() === AI_CHATVIEW_DIALOG ) {
                return;
            }

            if ( this.chatView ) {
                // inline is open
                this.closeChat();

            }

            this.chatView = new ai.ChatView( this.chatModel, {
                mode: ai.ChatView.renderModes.DIALOG,
                renderPreviousConversation: true,
                modal: false,
                enableAbort: false,
                loadingMessagesDelay: 2000,
                loadingMessages: MSG.AI_INLINE_CHAT_VIEW.LOADING_MESSAGES,
                dialogClasses: "ui-dialog--chat-client-ai",
                titlebarActions: [{
                    title: MSG.BUTTON.ARIA_CHAT_RESTORE,
                    label: MSG.BUTTON.ARIA_CHAT_RESTORE,
                    iconClass: "icon-restore-alt",
                    classes: "ui-dialog-titlebar-restore",
                    showLabel: false,
                    click: () => {
                        this.openInlineChat( INLINE_CHAT_FOCUS_TARGET.CLOSE_BUTTON );
                    }
                }]
            } );
            this._restoreChatTranscriptScrollState();
            this.chatView.one( ai.ChatView.events.DIALOG_CLOSE, () => this._destroyChatView() );
        },

        openInlineChat: function( focusTarget = INLINE_CHAT_FOCUS_TARGET.INPUT, { restoreTranscriptOffset = true } = {} ) {
            if ( !this.options.aiEnabled ) {
                debug.info( "Natural Language Support is not enabled in this IR." );
                return;
            }

            if ( this.chatView?.getMode() === AI_CHATVIEW_INLINE ) {
                return;
            }
            if ( this.chatView ) {
                // dialog is open
                this.closeChat();
            }

            this.hasUnreadChatMessages = false;
            this._syncChatButtonUnreadState();

            // hide the button in IR's toolbar
            this.chatBtn$.hide();

            this.chatView = new ai.ChatView( this.chatModel, {
                el: this.chatInnerEl$[0],
                mode: ai.ChatView.renderModes.INLINE,
                renderPreviousConversation: true,
                enableAbort: false,
                loadingMessagesDelay: 2000,
                loadingMessages: MSG.AI_INLINE_CHAT_VIEW.LOADING_MESSAGES,
                // Inline chat starts out with zero size, so focus must be applied after sizing.
                // Explicit false here for that reason.
                focus: false
            } );
            // to be able to shrink it:
            this.chatView.el.style.minHeight = 0;

            this.element.addClass( C_IRR_INLINE_CHAT_OPEN );
            this.chatContainerEl$.addClass( C_INLINE_CHAT_CONTAINER_OPEN );

            this._invalidateInlineChatLayoutCache();
            this._fitInlineChatView();
            if ( restoreTranscriptOffset ) {
                this._restoreChatTranscriptScrollState();
            }

            // Apply focus after sizing has taken effect; constructor-time focus can fail
            // because the inline chat is initially rendered at zero size.
            requestAnimationFrame( () => {
                this._focusInlineChatView( focusTarget );
            } );

            // force refresh to update the header sizes
            this.element.find( ".js-stickyTableHeader" ).trigger( "forceresize" );
        },

        closeChat: function () {
            if ( this.chatView?.getMode() === AI_CHATVIEW_DIALOG ) {
                this._saveChatTranscriptScrollState();
                this.chatView.close();
                // all the post-close actions are on DIALOG_CLOSE that fires _destroyChatView
            }
            else if ( this.chatView?.getMode() === AI_CHATVIEW_INLINE ) {
                this._saveChatTranscriptScrollState();
                this._destroyChatView();
                this._invalidateInlineChatLayoutCache();
                this._resetInlineChatViewportStyles();
                this.element.removeClass( C_IRR_INLINE_CHAT_OPEN );
                this.chatContainerEl$.removeClass( C_INLINE_CHAT_CONTAINER_OPEN );
                // force refresh to update the header sizes
                this.element.find( ".js-stickyTableHeader" ).trigger( "forceresize" );
            }
        }
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-top", () => {
        window.g_Shuttlep_v01.sort2( "T" );
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-up", () => {
        window.g_Shuttlep_v01.sort2( "U" );
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-down", () => {
        window.g_Shuttlep_v01.sort2( "D" );
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-bottom", () => {
        window.g_Shuttlep_v01.sort2( "B" );
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-reset", () => {
        window.g_Shuttlep_v01.reset();
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-moveall", () => {
        window.g_Shuttlep_v01.move_all();
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-move", () => {
        window.g_Shuttlep_v01.move();
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-remove", () => {
        window.g_Shuttlep_v01.remove();
        return false;
    } );

    $( document ).on( "click", "#APEX-ir-column-dialog-shuttle-removeall", () => {
        window.g_Shuttlep_v01.remove_all();
        return false;
    } );

    $( document ).on( "keydown", ".a-IR-Column-Dialog-Multiselect-Shuttle-Left--event", ( event ) => {
        if ( event.which === 13 ) {
            window.g_Shuttlep_v01.move();
            return false;
        }
    } );

    $( document ).on( "dblclick", ".a-IR-Column-Dialog-Multiselect-Shuttle-Left--event", () => {
        window.g_Shuttlep_v01.move();
    } );

    $( document ).on( "keydown", ".a-IR-Column-Dialog-Multiselect-Shuttle-Right--event", ( event ) => {
        if ( event.which === 13 ) {
            window.g_Shuttlep_v01.remove();
            return false;
        }
    } );

    $( document ).on( "dblclick", ".a-IR-Column-Dialog-Multiselect-Shuttle-Right--event", () => {
        window.g_Shuttlep_v01.remove();
    } );

} )();

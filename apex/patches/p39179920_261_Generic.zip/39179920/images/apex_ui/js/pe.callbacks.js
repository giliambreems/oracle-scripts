/*!
 * Copyright (c) 2019, 2026, Oracle and/or its affiliates.
 */

/* global pe */

/**
 * @namespace
 **/
( function( model, $, util, locale, lang, pd, date, builder ) {
    "use strict";

    let ITEM_TYPE = {
            RICH_TEXT_EDITOR: "NATIVE_RICH_TEXT_EDITOR",
            TEXTAREA:         "NATIVE_TEXTAREA",
            FILE:             "NATIVE_FILE",
            IMAGE_UPLOAD:     "NATIVE_IMAGE_UPLOAD",
            HIDDEN:           "NATIVE_HIDDEN",
            TEXT_FIELD:       "NATIVE_TEXT_FIELD",
            MARKDOWN_EDITOR:  "NATIVE_MARKDOWN_EDITOR",
            NUMBER_FIELD:     "NATIVE_NUMBER_FIELD",
            DATE_PICKER:      "NATIVE_DATE_PICKER_APEX",
            ROW_ACTION:       "NATIVE_ROW_ACTION",
            ROW_SELECTOR:     "NATIVE_ROW_SELECTOR",
            INPUT:            "NATIVE_INPUT",
            YES_NO:           "NATIVE_YES_NO",
            RANGE:            "NATIVE_RANGE",
            // lov based items
            AUTO_COMPLETE:    "NATIVE_AUTO_COMPLETE",
            CHECKBOX:         "NATIVE_CHECKBOX",
            COMBOBOX:         "NATIVE_COMBOBOX",
            LIST_MANAGER:     "NATIVE_LIST_MANAGER",
            POPUP_LOV:        "NATIVE_POPUP_LOV",
            RADIOGROUP:       "NATIVE_RADIOGROUP",
            SELECT_LIST:      "NATIVE_SELECT_LIST",
            SHUTTLE:          "NATIVE_SHUTTLE"
        },
        REGION_TYPE = {
            FACETED_SEARCH:   "NATIVE_FACETED_SEARCH",
            SMART_FILTERS:    "NATIVE_SMART_FILTERS",
            IG:               "NATIVE_IG",
            FORM:             "NATIVE_FORM"
        },
        PROCESS_TYPE = {
            INVOKE_API:       "NATIVE_INVOKE_API",
            EXECUTION_CHAIN:  "NATIVE_EXECUTION_CHAIN",
            DOWNLOAD:         "NATIVE_DOWNLOAD",
            PRINT_REPORT:     "NATIVE_PRINT_REPORT",
            INVOKE_WF:        "NATIVE_INVOKE_WF",
            WORKFLOW:         "NATIVE_WORKFLOW",
        },
        gPendingSlotPlaceholders = new WeakMap(),
        gSavedSourceSqlQuery = "";

    // order by properties
    const SOURCE_QUERY_ORDER_BY_PROPS = [
        model.PROP.SOURCE_QUERY_ORDER_BY,
        model.PROP.SOURCE_QUERY_ORDER_BY_ITEM,
        model.PROP.SOURCE_GRAPH_ORDER_BY,
        model.PROP.SOURCE_GRAPH_ORDER_BY_ITEM
    ];

    const ITEM_TYPE_TEXTAREA_THRESHOLD = 256;

    const hasOwnProperty = util.hasOwnProperty;

    // this regex can be used to identify if a string contains an item substitution
    const REGEX_STRING_HAS_ITEM_SUBSTITUTION = /&([A-Za-z0-9_$#]+(?:%[A-Za-z0-9_]+)?)\./g;

    const MAP_LAYER_USE_VECTOR_TILES_ERR_PROPS = [
        model.PROP.MAP_POINT_ICON_IMAGE_URL,
        model.PROP.MAP_POINT_ICON_CSS_CLASSES,
        model.PROP.MAP_POINT_FEATURE_SVG_SHAPE,
        model.PROP.MAP_FEATURE_POINT_STROKE_COLOR,
        model.PROP.MAP_FEATURE_POINT_STROKE_WIDTH,
        model.PROP.MAP_FEATURE_POINT_FILL_COLOR
    ];

    function msg( pKey ) {
        return lang.getMessage( "MODEL.CALLBACKS." + pKey );
    } // msg

    function format( pKey ) {
        var pattern = msg( pKey ),
            args = [ pattern ].concat( Array.prototype.slice.call( arguments, 1 ) );
        return lang.format.apply( this, args );
    } // format

    function _hasChanged( pProperty, pAction, pChangedProperty, pOldValue ) {

        return (  pProperty
               && (  pAction === model.CALLBACK_ACTION.CREATED
                  || (  pAction === model.CALLBACK_ACTION.CHANGED
                     && pChangedProperty.id === pProperty.id
                     && ( pProperty.getValue() !== pOldValue || pOldValue === undefined )
                     )
                  )
               );
    } // _hasChanged


    function _hasChangedEqualsTo( pProperty, pAction, pChangedProperty, pValue, pOldValue ) {

        return (    _hasChanged( pProperty, pAction, pChangedProperty, pOldValue )
                 && pProperty.getValue() === pValue );
    } // _hasChangedEqualsTo


    function _hasChangedNotEqualsTo( pProperty, pAction, pChangedProperty, pValue, pOldValue ) {

        return ( _hasChanged( pProperty, pAction, pChangedProperty, pOldValue )
                 && pProperty.getValue() !== pValue );
    } // _hasChangedNotEqualsTo


    function _removeComponents( pComponents ) {

        for ( let i = 0; i < pComponents.length; i++ ) {
            pComponents[ i ].remove();
        }
    }

    function _removeChildren( pComponent, pTypeId ) {

        _removeComponents( pComponent.getChilds( pTypeId ) );

    } // _removeChildren

    function _setPropertyValue( pComponent, pPropertyId, pValue ) {

        var lProperty = pComponent.getProperty( pPropertyId );

        // only set the property if it really exists and it has changed
        if ( lProperty ) {
            lProperty.setValue( pValue );
        }
    } // _setPropertyValue

    function _revalidateProperty( pComponent, pPropertyId ) {

        let lProperty;

        // we support passing a property object as pPropertyId parameter
        // this can be handy if the calling logic already resolved a property
        if ( !pComponent && pPropertyId && pPropertyId instanceof Object ) {
            lProperty = pPropertyId;
        } else {
            lProperty = pComponent.getProperty( pPropertyId );
        }

        // force a re-validation and set property value to existing value
        if ( lProperty ) {
            lProperty.setValue( lProperty.getValue(), true );
        }
    } // _revalidateProperty

    function _setSlot( {
        componentTypeId,
        action,
        property,
        oldRegionId,
        component
    } ) {
        // Slot handling participates in create-time validation as well, but the actual write must happen after the
        // component has been registered as created. Otherwise undo stores it as a change instead of a create.
        if ( ![ model.CALLBACK_ACTION.CREATED, model.CALLBACK_ACTION.CHANGED, model.CALLBACK_ACTION.VALIDATE ].includes( action ) ) {
            return;
        }

        const isRegion = componentTypeId === model.COMP_TYPE.REGION;
        const regionPropertyId = isRegion ? model.PROP.PARENT_REGION : model.PROP.REGION;
        const newSlotPlaceholder = component.getPropertyValue( model.PROP.SLOT_PLACEHOLDER );

        if ( action === model.CALLBACK_ACTION.VALIDATE && property.id === regionPropertyId ) {
            // Upon the CALLBACK_ACTION.VALIDATE event, we have access to the old slot
            // so lets save it temporarily, so we can use it upon the subsequent CALLBACK_ACTION events
            component.oldSlotPlaceholder = newSlotPlaceholder;
            return;
        }

        const regionId = component.getPropertyValue( regionPropertyId );

        // If the slotplaceholder is not set  - we will enforce slot control
        let supportedItemType;
        let supportedRegionType;
        if ( !newSlotPlaceholder || newSlotPlaceholder === "INVALID" ) {
            if ( componentTypeId === model.COMP_TYPE.PAGE_ITEM ) {
                supportedItemType = component.getPropertyValue( model.PROP.ITEM_TYPE );
            }
            if ( componentTypeId === model.COMP_TYPE.REGION ) {
                supportedRegionType = component.getPropertyValue( model.PROP.REGION_TYPE );
            }
        }
        const slots = model.getSlots( { componentTypeId, regionId, supportedItemType, supportedRegionType } );

        const getDefaultSlotPlaceholder = () => {
            // Get the default slot where this component should go into
            const defaultSlotPlaceholder = model.getSlot( { componentTypeId, regionId, supportedItemType, supportedRegionType } )?.placeholder;
            if ( defaultSlotPlaceholder ) {
                // One last check if the list of slots contains the default one
                // New parent does not have the old slot, so let's find if the parent container has the default position
                const hasSlot = slots.some( slot => slot.placeholder === defaultSlotPlaceholder );
                // Default position was found in parent, so let's put the component in the default position
                if ( hasSlot ) {
                    return defaultSlotPlaceholder;
                }
            }
            return "";
        };

        const setDefaultSlot = () => {
            const defaultSlotPlaceholder = getDefaultSlotPlaceholder();

            if ( defaultSlotPlaceholder ) {
                _setPropertyValue( component, model.PROP.SLOT_PLACEHOLDER, defaultSlotPlaceholder );
            }
        };

        if ( action === model.CALLBACK_ACTION.CREATED ) {
            const pendingSlotPlaceholder = gPendingSlotPlaceholders.get( component );

            // Apply the cached slot after the component has been created. This keeps the implicit slot defaulting
            // behavior for auto-created components without changing values during VALIDATE.
            if ( pendingSlotPlaceholder && newSlotPlaceholder === "" ) {
                _setPropertyValue( component, model.PROP.SLOT_PLACEHOLDER, pendingSlotPlaceholder );
            }
            gPendingSlotPlaceholders.delete( component );
        } else if ( action === model.CALLBACK_ACTION.VALIDATE
            && property.id !== model.PROP.SLOT_PLACEHOLDER
            && newSlotPlaceholder === "" ) {
            // When a new component is created automatically, all the properties of the new component are populated
            // based on the global default properties. Therefore, the slot placeholder could've been "" which is invalid.
            // VALIDATE must not modify component values. Cache the default slot here and let CREATED apply it later.
            // This is needed for implicit create-time cascades such as Form regions auto-creating items, where the
            // slot placeholder can still be "" and no separate slot change follows.
            gPendingSlotPlaceholders.set( component, getDefaultSlotPlaceholder() );
        } else if ( action === model.CALLBACK_ACTION.CHANGED ) {
            // We should only set the slot when the REGION or PARENT_REGION
            // properties are changed.
            // If there are no slots available, the component gets moved to a slot that's invalid by definition
            if ( slots.length === 0 ) {
                component._properties[ model.PROP.SLOT_PLACEHOLDER ]._value = "INVALID";
            }

            if ( property.id === regionPropertyId ) {
                // No forced slot found, so that must be a move between parent region
                // else logic: if newSlotPlaceholder !== "", then that means we should not find a default value, and leave it be
                if ( newSlotPlaceholder === "" ) {
                    const hasOldSlot = slots.some( slot => slot.placeholder === component.oldSlotPlaceholder );
                    // Check if the new parent has that the old slot
                    // New parent has the old slot so let's put the component in this slot again
                    if ( hasOldSlot &&
                        // Only do this operation if the move is from page to page slot or from region to region slot
                        ( ( regionId === "" && oldRegionId === "" ) || ( regionId && oldRegionId ) ) ) {
                        _setPropertyValue( component, model.PROP.SLOT_PLACEHOLDER, component.oldSlotPlaceholder );
                    } else {
                        setDefaultSlot();
                    }
                }
                // Cleanup
                delete component.oldSlotPlaceholder;
            } else if ( property.id === model.PROP.SLOT_PLACEHOLDER ) {
                const hasSlot = slots.some( slot => slot.placeholder === property.getValue() );
                if ( !hasSlot ) {
                    setDefaultSlot();
                }
            }
        }

    } // _setSlot

    function initCapColumnName( pColumnName ) {
        // initcap column name and replace underscores with spaces
        // Escape column name to avoid issues if the column name contains html meta characters, because the column heading is normally not escaped
        return util.escapeHTML(
            pColumnName
                .replace( /_+/g, "_" ).replace( /^_+/, "" ).replace( /_+$/, "" ).replace( /_/g, " " )
                .toLowerCase()
                .split( " " )
                .map( function( word ) {
                        var firstWord = word[ 0 ] || "";
                        return word.replace( firstWord, firstWord.toUpperCase() );
                } )
                .join( " " )
        );
    } // initCapColumnName

    function syncStaticId( component, action, changedProperty, nameProperty ) {
        const nameProp = nameProperty || component.getProperty( model.PROP.NAME );
        if ( nameProp ) {
            if ( component.isCreated() && _hasChanged( nameProp, action, changedProperty ) ) {
                const staticId = model.getUniquePropertyValue( component.parentId, component.typeId, model.PROP.STATIC_ID, builder.getStaticId( nameProp.getValue() ) );
                _setPropertyValue( component, model.PROP.STATIC_ID, staticId );
            }
        }
    } // syncStaticId

    function getLegacyDmlProcesses() {

        return model.getComponents( model.COMP_TYPE.PAGE_PROCESS, {
            properties: [{
                id:    model.PROP.PAGE_PROCESS_TYPE,
                value: new RegExp( "^(NATIVE_FORM_FETCH|NATIVE_FORM_PROCESS)$" )
            }]
        } );

    } // getLegacyDmlProcesses


    function _createComponent( pOptions ) {

        // Create the component if it doesn't exists
        if ( model.getComponents( pOptions.typeId, {
                parentId:   pOptions.parentId,
                properties: pOptions.searchPropertyValues
            } ).length === 0 )
        {
            new model.Component( {
                previousComponent: pOptions.previousComponent,
                typeId:   pOptions.typeId,
                parentId: pOptions.parentId,
                values:   pOptions.searchPropertyValues.concat( pOptions.addPropertyValues )
            } );
        }
    } // _createComponent


    function manageColumns( pRegion, pColumnsParent, pColumnComponentTypeId, pDbColumnPropertyId, pOptions ) {

        function getSqlColumns( pSqlColumns, pSetSqlColumn ) {

            var i,
                lColumns = [];

            for ( i = 0; i < pSqlColumns.length; i++ ) {
                lColumns.push( {
                    name:         pSqlColumns[ i ].name,
                    type:         pSqlColumns[ i ].type,
                    maxLen:       pSqlColumns[ i ].maxLen,
                    isRequired:   pSqlColumns[ i ].isRequired,
                    isGeneric:    pSqlColumns[ i ].isGeneric,
                    isPrimaryKey: pSqlColumns[ i ].isPrimaryKey,
                    isQueryOnly:  pSqlColumns[ i ].isQueryOnly,
                    no:           i + 1,
                    regionColumn: null
                } );

                if ( pSetSqlColumn ) {
                    pSetSqlColumn( lColumns[ i ] );
                }
            }
            return lColumns;
        } // getSqlColumns

        function removeUnusedColumns( pSqlColumns, pParent, pComponentTypeId, pOptions ) {

            var lComponents,
                i, j,
                lFound,
                lDbColumnProperty,
                lDbColumnName;

            if ( pParent ) {
                lComponents = pParent.getChilds( pComponentTypeId );
            } else {
                lComponents = model.getComponents( pComponentTypeId, pOptions.filter );
            }

            // Remove all columns/items which don't exist anymore or where the type has changed
            for ( i = 0; i < lComponents.length; i++ ) {
                lFound = false;
                lDbColumnProperty = lComponents[ i ].getProperty( pDbColumnPropertyId );
                if ( lDbColumnProperty ) {
                    lDbColumnName = lDbColumnProperty.getValue();
                } else {
                    // not a database column, we can ignore it
                    lFound = true;
                }
                for ( j = 0; j < pSqlColumns.length && !lFound; j++ ) {
                    if ( pSqlColumns[ j ].name === lDbColumnName && ( !pOptions.compareCheck || pOptions.compareCheck( pSqlColumns[ j ], lComponents[ i ] ) ) ) {
                        pSqlColumns[ j ].regionColumn = lComponents[ i ];
                        lFound = true;
                        break;
                    }
                }

                if ( !lFound && ( !pOptions.removeCheck || pOptions.removeCheck( lComponents[ i ] ) ) ) {
                    lComponents[ i ].remove();
                }
            }
        } // removeUnusedColumns


        function addUpdateColumns( pSqlColumns, pParent, pComponentTypeId, pOptions ) {

            var lComponents,
                i,
                lPreviousComponent,
                lValues;

            if ( pParent ) {
                lComponents = pParent.getChilds( pComponentTypeId );
            } else {
                lComponents = model.getComponents( pComponentTypeId, pOptions.filter );
            }

            // New columns should be added after the existing columns
            if ( lComponents.length > 0 ) {
                lPreviousComponent = lComponents[ lComponents.length - 1 ];
            }

            // Add all columns where we don't have a region/report column yet or update where something has changed
            for ( i = 0; i < pSqlColumns.length; i++ ) {

                // Filter function to skip columns we don't want to add (eg. IG Column BLOB)
                if ( typeof pOptions.skipColumn === "function" &&
                    pOptions.skipColumn.call( undefined, pSqlColumns[ i ] ) ) {
                    continue;
                }

                // If the SQL statement contains a new column, add it.
                if ( !pSqlColumns[ i ].regionColumn ) {

                    lValues = [];
                    pOptions.add( lValues, pSqlColumns[ i ] );

                    if ( pParent ) {
                        lPreviousComponent = new model.Component( {
                            previousComponent:         lPreviousComponent,
                            typeId:                    pComponentTypeId,
                            parentId:                  pParent.id,
                            values:                    lValues,
                            ignorePropertyIfNotExists: true
                        } );
                    } else {
                        lPreviousComponent = new model.Component( {
                            previousComponent:         lPreviousComponent,
                            typeId:                    pComponentTypeId,
                            values:                    lValues,
                            ignorePropertyIfNotExists: true
                        } );
                    }

                } else {
                    pOptions.update( pSqlColumns[ i ].regionColumn, pSqlColumns[ i ] );
                }
            }
        }


        var lSqlColumns;

        // If we don't want that the ROWID column gets removed, we have read it as valid column but later remove it
        // before we are actually adding new columns. This is needed for IG which adds the ROWID column in case the IG
        // is editable and it shouldn't be removed as soon as the query is modified.

        lSqlColumns = model.getSourceLocationProperty( pRegion )?.getColumns( true );

        // Only if we have a valid SQL which has returned columns, we try to add/modify the report columns
        if ( lSqlColumns?.length > 0 ) {

            lSqlColumns = getSqlColumns( lSqlColumns, pOptions.setSqlColumn );

            // Remove all columns which don't exist anymore
            removeUnusedColumns( lSqlColumns, pColumnsParent, pColumnComponentTypeId, {
                compareCheck: pOptions.compareCheck,
                removeCheck:  pOptions.removeCheck,
                filter:       pOptions.filter
            } );

            // Add or Update columns
            addUpdateColumns( lSqlColumns, pColumnsParent, pColumnComponentTypeId, {
                add:        pOptions.add,
                update:     pOptions.update,
                filter:     pOptions.filter,
                skipColumn: pOptions.skipColumn
            } );
        }
    } // manageColumns

    function updateColumnAttributes( pComponent, pSqlColumn ) {
        const YES = "Y", NO = "N";
        let dataTypeProperty       = pComponent.getProperty( model.PROP.DATA_TYPE ),
            valueRequiredProperty  = pComponent.getProperty( model.PROP.VALUE_REQUIRED ),
            valueRequired          = ( pSqlColumn.isRequired ? YES : NO );

        // Update the column type property if it has changed
        // We intentionally don't set IS_VISIBLE ( or COLUMN_ALIGNMENT ), because that might have already
        // been changed by the developer
        if ( dataTypeProperty.getValue() !== pSqlColumn.type ) {
            dataTypeProperty.setValue( pSqlColumn.type );
        }

        // activate the "required" flag if the column is "not null" and currently it's unchecked
        if ( valueRequiredProperty && valueRequired === YES && valueRequiredProperty.getValue() === NO  ) {
            valueRequiredProperty.setValue( valueRequired );
        }
    } // updateColumnAttributes

    function hasOrderBy( pRegion ) {

        var lOrderByProperty = pRegion.getProperty( SOURCE_QUERY_ORDER_BY_PROPS );

        // Check region SQL statement or Order By attribute if it contains an ORDER BY clause
        return ( model.getSourceLocationProperty( pRegion ).hasOrderBy() || ( lOrderByProperty && lOrderByProperty.getValue() !== "" ) );

    } // hasOrderBy

    /**
     * Create the Web Source parameter components for the specified component
     *
     * @param {object} component the parent component of the rest-param components
     * @param {string} restModuleId ID of the REST Module component
     * @param {string} componentRestParamTypeId Component Type ID of the rest-param components to be created, eg. MAP_LAYER_WS_PARAM or REGION_WS_PARAM
     * @param {object} operationComponentDef either an Operation component, or an object that defines the parameters of the referenced Operation component (dbOperation, arrayColumnID)
     *                                       if defined, only the operation components will be created
     */
    function addRestParametersToComponent( component, restModuleId, componentRestParamTypeId, operationComponentDef ) {
        const FETCH_ROWS = "FETCH_COLLECTION", ITEM = "ITEM";
        const existingParams = component.getChilds( componentRestParamTypeId );

        // create a "dummy" (detached!) component of the specified web-src type.
        // this is needed, so we can read out the list of available web-src-params from the component's WEB_SRC_PARAM property.
        const dummyParamComponent = new model.Component( {
            typeId:  componentRestParamTypeId,
            parentId: component.id,
            isDetached: true
        } );
        // the WEB_SRC_PARAM property is always available
        const webSrcParamProp = dummyParamComponent.getProperty( model.PROP.WEB_SRC_PARAM );
        // create a list of the web-src-param ids
        const paramIds = webSrcParamProp._getLovValues().map( entry => entry.r );
        // remove the dummy component
        dummyParamComponent.remove();

        // check if a web-src-operation is defined
        let operationComponent;
        if ( operationComponentDef ) {
            if ( operationComponentDef instanceof model.Component ) {
                operationComponent = operationComponentDef;
            } else {
                operationComponent = getRestOperationComponent( {
                    moduleId: restModuleId,
                    ...operationComponentDef
                } );
            }
        }

        // store operation property values that will be used later for the component creation
        let operationDBoperation = "", operationHTTPMethod = "";
        if ( operationComponent ) {
            operationDBoperation = operationComponent.getPropertyValue( model.PROP.DATABASE_OPERATION );
            operationHTTPMethod = operationComponent.getPropertyValue( model.PROP.HTTP_METHOD );
        }

        // look up all web-src-param components from the (lov)list; if there's an "operation" component provided, we also use that for filtering
        const webSrcParams = model.getComponents( model.COMP_TYPE.WEB_SRC_MOD_PARAM, {
            ...( !operationComponent && { parentId: restModuleId } ),
            // @todo once we can reference plug-in attributes in the config, the filter on the operation could go away
            properties: [ {
                id: model.PROP.WEB_SRC_OPERATION,
                value: operationComponent?.id || ""
            } ],
            filterFunction: function() {
                return paramIds.includes( this.id );
            }
        } );

        // create the comp-web-src params using the web-src-params
        for ( const webSrcParam of webSrcParams ) {
            // skip the param, if there's already a component ws-param for it
            if ( existingParams.some( param => param.getPropertyValue( model.PROP.WEB_SRC_PARAM ) === webSrcParam.id ) ) {
                continue;
            }

            const paramDirection = webSrcParam.getPropertyValue( model.PROP.DIRECTION );
            const paramIsRequired = webSrcParam.getPropertyValue( model.PROP.PARAMETER_REQUIRED );
            const paramDefaultValue = webSrcParam.getPropertyValue( model.PROP.PARAMETER_VALUE );
            // copy some property value from the param component
            const propValues = [ {
                id: webSrcParamProp.id,
                value: webSrcParam.id
            }, {
                id: model.PROP.API_DIRECTION, // always available
                value: paramDirection
            }, {
                id: model.PROP.WEB_SRC_PARAM_DATA_TYPE, // only available for IN and IN_OUT
                value: webSrcParam.getPropertyValue( model.PROP.WEB_SRC_PARAM_DATA_TYPE )
            }, {
                id:  model.PROP.DATABASE_OPERATION, // not available for page process params
                value: operationDBoperation
            }, {
                id:  model.PROP.HTTP_METHOD, // // not available for page process params
                value: operationHTTPMethod
            } ];

            // see if the page contains an item, that might be connected with the web-src param
            // (for this, we check if there's a page item with the same name as the param)
            const paramName = webSrcParam.getPropertyValue( model.PROP.NAME );
            const matchingItem = model.getComponents( model.COMP_TYPE.PAGE_ITEM, {
                properties: [ {
                    id: model.PROP.ITEM_NAME,
                    value: `P${model.getCurrentPageId()}_${paramName.replace( /[^0-9A-Za-z#$]+/g, "_" ).toUpperCase()}`
                } ]
            } );
            const paramItemName = matchingItem[ 0 ]?.getPropertyValue( model.PROP.ITEM_NAME ) || "";

            // set some default values based on the param property values
            let isItemType;
            if ( [ "OUT", "IN_OUT" ].includes( paramDirection ) ) {
                if ( operationDBoperation !== FETCH_ROWS ) {
                    propValues.push( {
                        id: model.PROP.IGNORE_OUTPUT,
                        value: "Y"
                    } );
                }
                // for IN_OUT, or FETCH operation params the default type is ITEM
                isItemType = paramDirection !== "OUT" || operationDBoperation === FETCH_ROWS;
                if ( isItemType ) {
                    propValues.push( {
                        id: model.PROP.VALUE_TYPE,
                        value: ITEM
                    } );
                }
            } else {
                // for required params, or if we found a possible connected item, default to ITEM
                isItemType = paramIsRequired === "Y" || paramItemName !== "";
                propValues.push( {
                    id:    model.PROP.VALUE_TYPE,
                    value: ( isItemType ? ITEM : ( paramDefaultValue === "" ? "NULL" : "DEFAULT" ) )
                } );
            }

            // if the VALUE_TYPE is set to ITEM, also add the connected page item, if there's any
            if ( isItemType && paramItemName !== "" ) {
                propValues.push( {
                    id: model.PROP.VALUE_ITEM,
                    value: paramItemName
                } );
            }

            new model.Component( {
                typeId: componentRestParamTypeId,
                parentId: component.id,
                values: propValues,
                ignorePropertyIfNotExists: true
            } );
        }
    } // addRestParametersToComponent

    function getRestOperationComponent( params ) {
        const { moduleId, dbOperation, arrayColumnId } = params;

        //
        // look up the REST Operation component based on the REST Source ID and the
        // database operation
        //
        let restOperationComponent = model.getComponents( model.COMP_TYPE.WEB_SRC_OPERATION, {
            parentId: moduleId,
            properties: [ {
                id:    model.PROP.DATABASE_OPERATION,
                value: dbOperation
            }, {
                id:    model.PROP.SOURCE_WEB_SRC_ARRAY_COL,
                value: arrayColumnId
            }]
        } );

        //
        // if we did not find any operation for an Array Column ID, there is no operation
        // mapped to this array column ID. In that case, look up the operation with no
        // array column ID.
        //
        if ( restOperationComponent.length === 0 ) {
            restOperationComponent = model.getComponents( model.COMP_TYPE.WEB_SRC_OPERATION, {
                parentId: moduleId,
                properties: [{
                    id:    model.PROP.DATABASE_OPERATION,
                    value: dbOperation
                }]
            } );
        }

        //
        // if we found a REST Source operation, add its parameters to the component
        //
        return restOperationComponent[ 0 ];
    }

    function addWorkflowParameterToComponent( parameter, activity ) {
        let valueType, ignoreOutput;
        const paramType = activity.typeId === model.COMP_TYPE.WORKFLOW_ACTIVITY ? model.COMP_TYPE.WF_ACTIVITY_WF_PARAM : model.COMP_TYPE.PAGE_PROCESS_WF_PARAM;
        const direction = parameter.getPropertyValue( model.PROP.API_DIRECTION );
        const isRequired = parameter.getPropertyValue( model.PROP.PARAMETER_REQUIRED ) === "Y";
        const defaultValue = parameter.getPropertyValue( model.PROP.PARAMETER_DEFAULT_VALUE );
        const values = [ {
            id:    model.PROP.WORKFLOW_PARAM,
            value: parameter.id
        }, {
            id:    model.PROP.API_DIRECTION,
            value: direction
        }, {
            id:    model.PROP.WORKFLOW_DATA_TYPE,
            value: parameter.getPropertyValue( model.PROP.WORKFLOW_DATA_TYPE )
        } ];

        // dynamic default values
        if ( [ "IN", "IN_OUT" ].includes( direction ) ) {

            if ( direction === "IN_OUT" ) {
                ignoreOutput = "Y";
            }

            if ( isRequired ) {
                valueType = ( defaultValue !== "" ? "DEFAULT" : "ITEM" );
            } else {
                valueType = "NULL";
            }
        } else if ( direction === "OUT" ) {
            valueType = "";
            ignoreOutput = "Y";
        }

        values.push( {
            id:    model.PROP.PARAMETER_VALUE_TYPE,
            value: valueType
        }, {
            id:    model.PROP.IGNORE_OUTPUT,
            value: ignoreOutput
        } );

        new model.Component( {
            typeId: paramType,
            parentId: activity.id,
            values: values,
            ignorePropertyIfNotExists: true
        } );
    }

    function updateWorkflowActivityParameter( workflowParameter, activityParameter ) {
        const IN = "IN", OUT = "OUT", IN_OUT = "IN_OUT", TYPE_ITEM = "ITEM", ENABLED = "Y", TYPE_NULL = "NULL", TYPE_DEFAULT = "DEFAULT";
        const wfDirection = workflowParameter.getPropertyValue( model.PROP.API_DIRECTION );
        const wfIsRequired = workflowParameter.getPropertyValue( model.PROP.PARAMETER_REQUIRED ) === ENABLED;
        const wfDefaultValue = workflowParameter.getPropertyValue( model.PROP.PARAMETER_DEFAULT_VALUE );
        const actDirection = activityParameter.getPropertyValue( model.PROP.API_DIRECTION );
        const actValueType = activityParameter.getPropertyValue( model.PROP.VALUE_TYPE );
        const setParamValueType = () => {
            if ( wfDefaultValue !== "" ) {
                _setPropertyValue( activityParameter, model.PROP.PARAMETER_VALUE_TYPE, TYPE_DEFAULT );
            } else {
                _setPropertyValue( activityParameter, model.PROP.PARAMETER_VALUE_TYPE, TYPE_ITEM );
            }
        };
        if ( actDirection !== wfDirection ) {
            // first set the direction, as other properties might depend in it
            activityParameter.getProperty( model.PROP.API_DIRECTION ).setValue( wfDirection, { checkReadOnly: false } );
            if ( actValueType !== TYPE_ITEM && ( ( actDirection === OUT && wfDirection === IN_OUT ) || ( actDirection === OUT && wfDirection === IN ) ) ) {
                if ( wfIsRequired ) {
                    setParamValueType();
                } else {
                    _setPropertyValue( activityParameter, model.PROP.PARAMETER_VALUE_TYPE, TYPE_NULL );
                }
            }
        } else if ( wfIsRequired && actValueType === TYPE_NULL ) {
            setParamValueType();
        }
    }

    function syncPrintPageHeaderText ( pRegion, pAction, pComponentType, pOldTitle ) {

        if ( ! pRegion ) {
            return;
        }

        var lNewTitle = pRegion.getProperty( model.PROP.TITLE ).getValue(),
            lOldTitle = ( typeof pOldTitle === "undefined" ) ? lNewTitle : pOldTitle,
            lPrintAttributes = pRegion.getChilds( pComponentType )[ 0 ] || pRegion.getChildrenUntil( pComponentType )[ 0 ],
            lOldPrintPageHeaderText;

        if ( ! lPrintAttributes ) {
            return;
        }

        lOldPrintPageHeaderText = lPrintAttributes.getProperty( model.PROP.PRINT_PAGE_HEADER_TEXT ).getValue();

        // Keep the "Page header text" property in sync if the text is equal to the old region title
        if ( pAction === model.CALLBACK_ACTION.CREATED
            || ( lOldTitle === lOldPrintPageHeaderText ) )
        {
            _setPropertyValue( lPrintAttributes, model.PROP.PRINT_PAGE_HEADER_TEXT, lNewTitle );
        }

    } // syncPrintPageHeaderText


    /**
     * Adds and removes the web-source-parameter child components of an IG or Form region
     *
     * @param {object} component a one-to-one child of a region component: region plug-in attributes or ig-attributes
     * @returns undefined
     */
    function handleRegionWebSrcParameters( component ) {
        const DB_OPERATIONS = [ "UPDATE", "DELETE", "INSERT", "FETCH_SINGLE_ROW" ];
        const region = component.getParent();
        if ( !region ) {
            return;
        }
        const regionType = region.getPropertyValue( model.PROP.REGION_TYPE );
        const webSrc = region.getPropertyValue( model.PROP.SOURCE_WEB_SRC_QUERY );
        const useLocalTable = region.getPropertyValue( model.PROP.WEB_SRC_USE_LOCAL_TABLE );
        // we only want to process Form or IG regions, that use a Web Source and not a Local Sync Table
        if ( ![ REGION_TYPE.IG, REGION_TYPE.FORM ].includes( regionType ) || webSrc === "" || useLocalTable === "Y" ) {
            return;
        }

        const isEditable = component.getPropertyValue( model.PROP.IS_EDITABLE );
        if ( isEditable === "Y" ) {
            const arrayColumnId = region.getPropertyValue( model.PROP.SOURCE_WEB_SRC_ARRAY_COL );
            // add REST Parameters for the INSERT, UPDATE, DELETE and FETCH_SINGLE_ROW operations
            DB_OPERATIONS.forEach( dbOperation => {
                addRestParametersToComponent( region, webSrc, model.COMP_TYPE.REGION_WS_PARAM, { dbOperation, arrayColumnId } );
            } );
            // add Module Parameters
            addRestParametersToComponent( region, webSrc, model.COMP_TYPE.REGION_WS_PARAM );
        } else {
            // get all Web Source parameters of the region
            const regionWebSrcParams = region.getChilds( model.COMP_TYPE.REGION_WS_PARAM );
            // now we need to verify the parameter definition for each of the region web source parameters.
            // If a parameter is mapped to a DML Database Operation, we can remove it, as non-editable regions
            // only work with the "FETCH COLLECTION" database operation
            regionWebSrcParams.forEach( regionWebSrcParam => {
                const webSrcParamProp = regionWebSrcParam.getProperty( model.PROP.WEB_SRC_PARAM );
                const webSrcParamId = webSrcParamProp?.getValue();
                if ( webSrcParamId ) {
                    // intentionally not checking the DIRECTION property, as that is a "virtual" column (ie. its value is derived from another component)
                    if ( webSrcParamProp.hasFeatures( "OUT_PARAMETER" ) ) {
                        _removeComponents ( [ regionWebSrcParam ] );
                    } else {
                        // there's only one Web Source Module Parameter with this ID
                        const webSrcModuleParam = model.getComponents( model.COMP_TYPE.WEB_SRC_MOD_PARAM, {
                            id: webSrcParamId
                        } )[ 0 ];
                        // check if it's an operation parameter
                        const webSrcOperationId = webSrcModuleParam?.getPropertyValue( model.PROP.WEB_SRC_OPERATION );
                        if ( webSrcOperationId ) {
                            // if yes, read its "operation type" from the operation component, and remove it if not allowed anymore
                            const webSrcOperation = model.getComponents( model.COMP_TYPE.WEB_SRC_OPERATION, { id: webSrcOperationId } )[ 0 ];
                            const dbOperation = webSrcOperation?.getPropertyValue( model.PROP.DATABASE_OPERATION );
                            if ( dbOperation && DB_OPERATIONS.includes( dbOperation ) ) {
                                _removeComponents ( [ regionWebSrcParam ] );
                            }
                        }
                    }
                }
            } );
        }
    } // handleRegionWebSrcParameters

    function removeInteractiveGridProcesses ( regionId ) {
        _removeComponents (
            model.getComponents( model.COMP_TYPE.VALIDATION, {
                properties: [{ id: model.PROP.VALIDATION_REGION, value: regionId }]
            } )
        );
        _removeComponents (
            model.getComponents( model.COMP_TYPE.PAGE_PROCESS, {
                properties: [{ id: model.PROP.PROCESS_REGION, value: regionId }]
            } )
        );
    } // removeInteractiveGridProcesses

    function _setTemplateComponentRegionTemplate( region, templateComponentType ) {

        let regionTemplate = "";
        let landmarkType = "";

        // Set region template based on the selected display type
        if ( templateComponentType === "REPORT" ) {
            regionTemplate = model.getTheme().defaultTemplates.templateComponent;
            landmarkType = "region";
        }

        _setPropertyValue( region, model.PROP.REGION_TEMPLATE, regionTemplate );
        _setPropertyValue( region, model.PROP.LANDMARK_TYPE, landmarkType );

    } // _setTemplateComponentRegionTemplate


    function regionPluginAttr( pAction, pProperty ) {

        function removeValidationsProcesses( pRegionId ) {
            // Remove any region depending validation or process if we don't allow editing anymore
            _removeComponents (
                model.getComponents( model.COMP_TYPE.VALIDATION, {
                    properties: [{ id: model.PROP.VALIDATION_REGION, value: pRegionId }]
                } )
            );
            _removeComponents (
                model.getComponents( model.COMP_TYPE.PAGE_PROCESS, {
                    properties: [
                        { id: model.PROP.PAGE_PROCESS_TYPE,          value: "NATIVE_FORM_DML" },
                        { id: model.PROP.PROCESS_DATA_SOURCE_REGION, value: pRegionId }
                    ]
                } )
            );
        } // removeValidationsProcesses

        var lRegionId = this.parentId,
            lIsEditableProperty = this.getProperty( model.PROP.IS_EDITABLE );

        // Check if the component with an editable flag is getting created or if the editable flag has been changed
        if ( _hasChanged( lIsEditableProperty, pAction, pProperty ) ) {

            if ( lIsEditableProperty.getValue() === "Y" ) {

                // Always add the new DML process before any existing process. In most cases, especially if it's
                // a master detail this will guarantee the correct order where a form comes always first.
                _createComponent( {
                    typeId: model.COMP_TYPE.PAGE_PROCESS,
                    searchPropertyValues: [
                        { id: model.PROP.PAGE_PROCESS_TYPE,          value: "NATIVE_FORM_DML" },
                        { id: model.PROP.PROCESS_DATA_SOURCE_REGION, value: lRegionId }
                    ],
                    addPropertyValues: [
                        { id: model.PROP.NAME, value: lang.formatMessageNoEscape( "WIZARD.FORM.DML_PROCESS_NAME", this.getParent().getDisplayTitle() )}
                    ],
                    previousComponent: "first" } );

            } else {

                removeValidationsProcesses( lRegionId );

            }

            handleRegionWebSrcParameters( this );
        }

        // Special template component region handling
        //
        // We have to split the logic into two places (CREATED is handled by templateComponentPlugin),
        // because if REGION_PLUGIN_ATTR gets created, it can yet access this.getParent(), that's
        // why we can only cover the CHANGED case here.
        let templateComponentTypeProp = this.getProperty( model.PROP.TEMPLATE_COMPONENT_TYPE );

        if ( pAction === model.CALLBACK_ACTION.CHANGED && _hasChanged( templateComponentTypeProp, pAction, pProperty ) ) {
            let value = templateComponentTypeProp.getValue();
            _setTemplateComponentRegionTemplate( this.getParent(), value );
            // report template components must have a source
            let sourceLocProp = this.getParent().getProperty( model.PROP.SOURCE_LOCATION );
            if ( value === "REPORT" ) {
                if ( sourceLocProp.getValue() === "" ) {
                    sourceLocProp.setValue( "LOCAL", true );
                }
            } else {
                // if the region does not any have colums yet, set the location none
                if ( !this.getParent().getChilds( model.COMP_TYPE.REGION_TMPL_COLUMN ).length ) {
                    sourceLocProp.setValue( "", true );
                }
            }

        }

    } // regionPluginAttr


    function cardPlugin( pAction, pProperty ) {

        var lDefaultCardTemplate;

        if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            if ( pAction === model.CALLBACK_ACTION.CREATED ) {

                new model.Component( {
                    typeId:   model.COMP_TYPE.CARD,
                    parentId: this.id
                } );

                lDefaultCardTemplate = model.getTheme().defaultTemplates.cards;

                if ( lDefaultCardTemplate ) {
                    _setPropertyValue( this, model.PROP.REGION_TEMPLATE, lDefaultCardTemplate );
                }
            }

            // set "Show Total Row Count" property to "No" for web sources
            if ( this.getProperty( model.PROP.SOURCE_LOCATION ).getValue() === "WEB_SOURCE" ) {
                _setPropertyValue( this, model.PROP.SHOW_TOTAL_ROW_COUNT, "N" );
            }

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the card attributes if that hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.CARD );
            _removeChildren( this, model.COMP_TYPE.CARD_ACTION );

        }
    } // cardPlugin


    function classicRptTabularFormPlugin( pAction, pProperty, pRegion, pComponentTypeId, pColumnComponentTypeId, pPrintComponentTypeId, pOldValue ) {

        function removeAll( pRegion ) {

            // Remove the report attributes and columns if that hasn't already been done (i.e if the region is removed)
            _removeChildren( pRegion, pComponentTypeId );
            _removeChildren( pRegion, pColumnComponentTypeId );

        } // removeAll

        var lColumns,
            lSourceProperty;


        if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            if ( pAction === model.CALLBACK_ACTION.CREATED ) {

                new model.Component( {
                    typeId:   pComponentTypeId,
                    parentId: pRegion.id
                } );

                syncPrintPageHeaderText( pRegion, pAction, pPrintComponentTypeId, pOldValue );
            }

            manageColumns( pRegion, pRegion, pColumnComponentTypeId, model.PROP.COLUMN_NAME, {
                removeCheck: function( pReportColumn ) {
                    // Remove the existing report column if it isn't contained in the SQL anymore,
                    // but don't remove it if it's one of our "virtual" columns
                    return ( pReportColumn.getProperty( model.PROP.DERIVED_COLUMN ).getValue() === "N" );
                },
                add: function( pValues, pSqlColumn ) {

                    pValues.push( { id: model.PROP.COLUMN_NAME,     value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.QUERY_COLUMN_ID, value: pSqlColumn.no } );
                    if ( pSqlColumn.type === "BLOB" ) {
                        pValues.push( { id: model.PROP.CLASSIC_REPORT_COLUMN_TYPE, value: "IMAGE" } );
                    }

                    if ( pSqlColumn.type === "NUMBER" ) {
                        pValues.push( { id: model.PROP.COLUMN_ALIGNMENT, value: "RIGHT" } );
                        pValues.push( { id: model.PROP.HEADING_ALIGNMENT, value: "RIGHT" } );
                    }

                    pValues.push( { id: model.PROP.COLUMN_HEADING, value: initCapColumnName( pSqlColumn.name )} );

                },
                update: function( pReportColumn, pSqlColumn ) {

                    // Check if the query column id has changed
                    var lProperty = pReportColumn.getProperty( model.PROP.QUERY_COLUMN_ID );
                    if ( parseInt( lProperty.getValue(), 10 ) !== pSqlColumn.no ) {
                        lProperty.setValue( pSqlColumn.no );
                    }
                }
            } );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, [ model.PROP.HAS_GENERIC_COLUMNS, model.PROP.GENERIC_COLUMN_COUNT ] ) !== -1 ) {

            lSourceProperty = model.getSourceLocationProperty( pProperty.component );

            // Trigger a re-validation of the source property which will also set the _columns attribute.
            lSourceProperty.setValue( lSourceProperty.getValue(), true );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.TITLE ) {

            syncPrintPageHeaderText( pRegion, pAction, pPrintComponentTypeId, pOldValue );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            removeAll( pRegion );

        }

        if ( pAction === model.CALLBACK_ACTION.CREATED || ( pAction === model.CALLBACK_ACTION.CHANGED && ( $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 || SOURCE_QUERY_ORDER_BY_PROPS.includes( pProperty.id )  ) )
            && hasOrderBy( pRegion ) )
        {
            // No column heading sorting is allowed if the report query contains an order by.
            // Reset all existing sort properties
            if ( hasOrderBy( pRegion ) ) {
                lColumns = pRegion.getChilds( pColumnComponentTypeId, {
                    filterFunction: function() {
                        var lColumnSortSequence = this.getProperty( model.PROP.COLUMN_SORT_SEQUENCE ),
                            lDisableSortColumn  = this.getProperty( model.PROP.DISABLE_SORT_COLUMN );

                        return (  ( lColumnSortSequence && lColumnSortSequence.getValue() !== "" )
                            || ( lDisableSortColumn  && lDisableSortColumn.getValue() === "N" )
                        );
                    }
                } );
                for ( let i = 0; i < lColumns.length; i++ ) {
                    _setPropertyValue( lColumns[ i ], model.PROP.COLUMN_SORT_SEQUENCE, "" );
                    _setPropertyValue( lColumns[ i ], model.PROP.DISABLE_SORT_COLUMN,  "Y" );
                }
            }
        }


    } // classicRptTabularFormPlugin


    function classicRptTabularFormAttr( pAction, pProperty, pOldValue ) {

        var lPrintComponentTypeId;

        if ( this.typeId === model.COMP_TYPE.CLASSIC_REPORT ) {
            lPrintComponentTypeId = model.COMP_TYPE.CLASSIC_RPT_PRINT;
        } else {
            lPrintComponentTypeId = model.COMP_TYPE.TAB_FORM_PRINT;
        }

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            if ( this.getProperty( model.PROP.ENABLE_PRINTING ).getValue() === "Y" ) {
                new model.Component( {
                    typeId:   lPrintComponentTypeId,
                    parentId: this.id
                } );
                syncPrintPageHeaderText( this.getParent(), pAction, lPrintComponentTypeId );
                pd.getTab( "pePrintingTabPanel" ).show();
            }
        } else if (  pAction === model.CALLBACK_ACTION.CHANGED
            && pProperty.id === model.PROP.ENABLE_PRINTING
            && pProperty.getValue() !== pOldValue )
        {
            if ( pProperty.getValue() === "Y" ) {
                new model.Component( {
                    typeId:   lPrintComponentTypeId,
                    parentId: this.id
                } );
                syncPrintPageHeaderText( this.getParent(), model.CALLBACK_ACTION.CREATED, lPrintComponentTypeId );

            } else {
                _removeChildren( this, lPrintComponentTypeId );
            }
        }
    } // classicRptTabularFormAttr


    function interactiveReportPlugin( pAction, pProperty, pOldValue ) {

        var lIrAttributes,
            lDefaultIrTemplate;

        if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            if ( pAction === model.CALLBACK_ACTION.CREATED ) {

                lIrAttributes = new model.Component( {
                    typeId:   model.COMP_TYPE.IR_ATTRIBUTES,
                    parentId: this.id
                } );

                syncPrintPageHeaderText( this, pAction, model.COMP_TYPE.IR_PRINT_ATTR, pOldValue );

                lDefaultIrTemplate = model.getTheme().defaultTemplates.ir;

                if ( lDefaultIrTemplate ) {
                    _setPropertyValue( this, model.PROP.REGION_TEMPLATE, lDefaultIrTemplate );
                }

            } else {
                lIrAttributes = this.getChilds( model.COMP_TYPE.IR_ATTRIBUTES )[ 0 ];
            }

            manageColumns( this, lIrAttributes, model.COMP_TYPE.IR_COLUMN, model.PROP.COLUMN_NAME, {
                setSqlColumn: function( pSqlColumn ) {

                    // Normalize data types to just a few
                    pSqlColumn.isTzDependent = "N";
                    if ( pSqlColumn.type === "VARCHAR2" ) {
                        pSqlColumn.type = "STRING";
                    } else if ( pSqlColumn.type === "TIMESTAMP" || pSqlColumn.type === "TIMESTAMP_TZ" ) { // todo is TIMESTAMP_TZ really not TZ dependent?
                        pSqlColumn.type = "DATE";
                    } else if ( pSqlColumn.type === "TIMESTAMP_LTZ" ) {
                        pSqlColumn.type          = "DATE";
                        pSqlColumn.isTzDependent = "Y";
                    } else if ( pSqlColumn.type === "BOOLEAN" ) {
                        pSqlColumn.type = "BOOLEAN";
                    } else if ( pSqlColumn.type !== "NUMBER" && pSqlColumn.type !== "DATE" && pSqlColumn.type !== "CLOB" ) {
                        pSqlColumn.type = "OTHER";
                    }

                },
                compareCheck: function( pSqlColumn, pReportColumn ) {

                    return ( pSqlColumn.type === pReportColumn.getProperty( model.PROP.COLUMN_TYPE ).getValue() );

                },
                removeCheck: function( pReportColumn ) {
                    const lDisplayTypeProperty = pReportColumn.getProperty( model.PROP.IR_COLUMN_DISPLAY_TYPE );

                    // Keep the synthetic row selector column when source columns are synchronized.
                    return lDisplayTypeProperty?.getValue() !== ITEM_TYPE.ROW_SELECTOR;
                },
                add: function( pValues, pSqlColumn ) {

                    var lColumnFilterType = "D";

                    pValues.push( { id: model.PROP.COLUMN_NAME, value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.COLUMN_TYPE, value: pSqlColumn.type } );

                    if ( pSqlColumn.type === "DATE" ) {
                        pValues.push( { id: model.PROP.TZ_DEPENDENT, value: pSqlColumn.isTzDependent } );

                    } else if ( pSqlColumn.type === "NUMBER" ) {
                        pValues.push( { id: model.PROP.COLUMN_ALIGNMENT, value: "RIGHT" } );
                        pValues.push( { id: model.PROP.HEADING_ALIGNMENT, value: "RIGHT" } );

                    } else if ( pSqlColumn.type === "BOOLEAN" ) {
                        lColumnFilterType = "D";

                    } else if ( pSqlColumn.type === "CLOB" || pSqlColumn.type === "OTHER" ) {
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_SORT,          value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_CONTROL_BREAK, value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_AGGREGATE,     value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_COMPUTE,       value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_CHART,         value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_GROUP_BY,      value: "N" } );
                        pValues.push( { id: model.PROP.ALLOW_USERS_TO_PIVOT,         value: "N" } );
                        lColumnFilterType = "N";

                        if ( pSqlColumn.type === "OTHER" ) {
                            pValues.push( { id: model.PROP.ALLOW_USERS_TO_FILTER,    value: "N" } );
                            pValues.push( { id: model.PROP.ALLOW_USERS_TO_HIGHLIGHT, value: "N" } );
                        }
                    }

                    if ( pSqlColumn.isPrimaryKey ) {
                        pValues.push( { id: model.PROP.IS_PRIMARY_KEY, value: "Y" } );
                    }

                    pValues.push( { id: model.PROP.IR_COLUMN_FILTER_TYPE, value: lColumnFilterType } );
                    pValues.push( { id: model.PROP.COLUMN_HEADING, value: initCapColumnName( pSqlColumn.name )} );

                },
                update: function( pReportColumn, pSqlColumn ) {

                    var lProperty;

                    // Check if the TZ has changed, in that case we just update that flag
                    if ( pSqlColumn.type === "DATE" ) {
                        lProperty = pReportColumn.getProperty( model.PROP.TZ_DEPENDENT );
                        if ( pSqlColumn.isTzDependent !== lProperty.getValue() ) {
                            lProperty.setValue( pSqlColumn.isTzDependent );
                        }
                    }
                }
            } );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.TITLE )
        {

            syncPrintPageHeaderText( this, pAction, model.COMP_TYPE.IR_PRINT_ATTR, pOldValue );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the IR attributes if that hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.IR_ATTRIBUTES );

        }
    } // interactiveReportPlugin


    function interactiveReportAttr( pAction, pProperty, pOldValue ) {
        const irSelectorColumns = model.getComponents( model.COMP_TYPE.IR_COLUMN, {
                                      parentId:   this.id,
                                      properties: [{ id: model.PROP.IR_COLUMN_DISPLAY_TYPE, value: ITEM_TYPE.ROW_SELECTOR }]
                                  } ) || [];

        function hasPrintAttributes( pShowDownloadProperty, pDownloadFormatsProperty ) {
            const lIsShowDownload = pShowDownloadProperty.getValue() === "Y",
                  lDownloadFormats = ( lIsShowDownload ) ? pDownloadFormatsProperty.getValue().split( ":" ) : [];

            return ( lIsShowDownload &&
            (  $.inArray( "XLSX", lDownloadFormats ) !== -1
            || $.inArray( "PDF", lDownloadFormats ) !== -1 ) );
        }

        function hasRowSelection() {
            return irSelectorColumns.length > 0;
        }

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            if ( hasPrintAttributes( this.getProperty( model.PROP.SHOW_DOWNLOAD ),
                    this.getProperty( model.PROP.DOWNLOAD_FORMATS ) ) ) {
                new model.Component( {
                    typeId:   model.COMP_TYPE.IR_PRINT_ATTR,
                    parentId: this.id
                } );
                syncPrintPageHeaderText( this.getParent(), pAction, model.COMP_TYPE.IR_PRINT_ATTR );
            }

        } else if (  pAction === model.CALLBACK_ACTION.CHANGED
            && ( pProperty.id === model.PROP.DOWNLOAD_FORMATS ||
            pProperty.id === model.PROP.SHOW_DOWNLOAD )
            && pProperty.getValue() !== pOldValue )
        {
            if ( hasPrintAttributes( this.getProperty( model.PROP.SHOW_DOWNLOAD ),
                    this.getProperty( model.PROP.DOWNLOAD_FORMATS ) ) ) {

                // Only create the print component if it doesn't exist yet
                if ( model.getComponents( model.COMP_TYPE.IR_PRINT_ATTR, { parentId: this.id } ).length === 0 ) {
                    new model.Component( {
                        typeId:   model.COMP_TYPE.IR_PRINT_ATTR,
                        parentId: this.id
                    } );
                    syncPrintPageHeaderText( this.getParent(), model.CALLBACK_ACTION.CREATED, model.COMP_TYPE.IR_PRINT_ATTR );
                }
            } else {
                _removeChildren( this, model.COMP_TYPE.IR_PRINT_ATTR );
            }
        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE
             && ( hasRowSelection() &&
                  this.getProperty( model.PROP.SHOW_DETAIL_VIEW ).getValue() === "Y" &&
                  pProperty.id === model.PROP.DETAIL_VIEW_FOR_EACH_ROW ) )
        {
            // Show a error message when required selection placeholders
            // are not used inside "detail view for each row" property
            if ( irSelectorColumns[0].getProperty( model.PROP.IR_COLUMN_SELECTION_HIDE_CONTROL ).getValue() !== "Y" ) {
                if ( !( pOldValue.includes( "#APEX$SELECTOR#" ) || pOldValue.includes( `#${irSelectorColumns[0].getProperty( model.PROP.COLUMN_NAME ).getValue()}#` ) ) ) {
                    return { error: msg( "IR.MISSING_SELECTION_PLACEHOLDER" ) };
                }
            }
            if ( !pOldValue.includes( "#APEX$ROW_IDENTIFICATION#" ) ) {
                return { error: msg( "IR.MISSING_SELECTION_PLACEHOLDER" ) };
            }
        }
    } // interactiveReportAttr

    function irColumnGroup( action, property ) {
        syncStaticId( this, action, property );
    } // irColumnGroup

    function irColumn( action, property, oldValue ) {
        const region = this.getParent();
        const irSelectorColumns = model.getComponents( model.COMP_TYPE.IR_COLUMN, {
                                      parentId:   region.id,
                                      properties: [{ id: model.PROP.IR_COLUMN_DISPLAY_TYPE, value: ITEM_TYPE.ROW_SELECTOR }]
                                  } ) || [];
        // we need to validate the primary key is when we have triggered actions
        if (  _hasChanged( this.getProperty( model.PROP.IS_PRIMARY_KEY ), action, property, oldValue )
            && hasTriggeredActions.call( region ) ) {
             validateAlltriggeredActions.call( region );
        }
         // Remove dependent IR column actions if the column type has changed or the column has been removed
        if (  (  _hasChanged( this.getProperty( model.PROP.IR_COLUMN_DISPLAY_TYPE ), action, property, oldValue )
              && /^(TMPL)/.test( oldValue ) )
           || action === model.CALLBACK_ACTION.REMOVED )
        {

            _removeChildren( this, model.COMP_TYPE.IR_COLUMN_ACTION );

        } else if ( action === model.CALLBACK_ACTION.VALIDATE
            && ( oldValue === ITEM_TYPE.ROW_SELECTOR &&
                 irSelectorColumns.length >= 1 ) )
        {
           return { error: msg( "IR.COUNT_ROW_SELECTOR_COLUMNS" ) };
        }
    } // irColumn

    function interactiveGridColumnGroup( action, property ) {
        syncStaticId( this, action, property, this.getProperty( model.PROP.COLUMN_HEADING ) );
    } // interactiveGridColumnGroup

    function interactiveGridPlugin( pAction, pProperty, pOldValue, pSql ) {

        var lIgAttributes,
            lDefaultIgTemplate;

        if ( pAction === model.CALLBACK_ACTION.VALIDATE && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1  ) {

            // Don't allow ORDER BY because that can cause ORA-01733 during update and an ORDER BY would
            // not have an effect if users specify a column order.
            if ( pSql.hasOrderBy ) {
                return { error: format( "IG.HAS_ORDER_BY" ) };
            }

        } else if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            if ( pAction === model.CALLBACK_ACTION.CREATED ) {

                lIgAttributes = new model.Component( {
                    typeId:   model.COMP_TYPE.IG_ATTRIBUTES,
                    parentId: this.id
                } );

                lDefaultIgTemplate = model.getTheme().defaultTemplates.ir;

                if ( lDefaultIgTemplate ) {
                    _setPropertyValue( this, model.PROP.REGION_TEMPLATE, lDefaultIgTemplate );
                }

                syncPrintPageHeaderText( this, pAction, model.COMP_TYPE.IG_PRINT, pOldValue );

            } else {
                lIgAttributes = this.getChilds( model.COMP_TYPE.IG_ATTRIBUTES )[ 0 ];
            }

            // set "Show Total Row Count" property to "No" for web sources
            if ( this.getProperty( model.PROP.SOURCE_LOCATION ).getValue() === "WEB_SOURCE" ) {
                _setPropertyValue( lIgAttributes, model.PROP.SHOW_TOTAL_ROW_COUNT, "N" );
            }

            manageColumns( this, this, model.COMP_TYPE.IG_COLUMN, model.PROP.SOURCE_DB_COLUMN, {
                add: function( pValues, pSqlColumn ) {

                    var lIsVisible = true;

                    // *************************************************************************************************
                    // KEEP IN SYNC with wwv_flow_report_dev.plb / create_ig_region
                    // *************************************************************************************************

                    pValues.push( { id: model.PROP.COLUMN_NAME,        value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.COLUMN_SOURCE_TYPE, value: "DB_COLUMN" } );
                    pValues.push( { id: model.PROP.SOURCE_DB_COLUMN,   value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.DATA_TYPE,          value: pSqlColumn.type } );


                    if ( pSqlColumn.isPrimaryKey || pSqlColumn.type === "ROWID" ) {

                        lIsVisible = false;
                        pValues.push( { id: model.PROP.ITEM_TYPE,      value: ITEM_TYPE.HIDDEN } );
                        pValues.push( { id: model.PROP.IS_PRIMARY_KEY, value: "Y" } );
                        pValues.push( { id: model.PROP.IS_QUERY_ONLY,  value: ( pSqlColumn.isQueryOnly ? "Y" : "N" ) } );

                    } else if ( pSqlColumn.type === "VARCHAR2" ) {

                        if ( pSqlColumn.maxLen < ITEM_TYPE_TEXTAREA_THRESHOLD || pSqlColumn.isGeneric ) {
                            pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXT_FIELD } );
                        } else {
                            pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXTAREA } );
                        }
                        if ( pSqlColumn.maxLen ) {
                            pValues.push( { id: model.PROP.ELEMENT_MAX_CHARACTERS, value: pSqlColumn.maxLen + "" } );
                        }

                    } else if ( pSqlColumn.type === "CLOB" ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXTAREA } );
                        pValues.push( { id: model.PROP.REGION_COLUMN_SESSION_STATE_DATA_TYPE, value: "CLOB" } );

                    } else if ( pSqlColumn.type === "NUMBER" ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.NUMBER_FIELD } );

                    } else if ( $.inArray( pSqlColumn.type, [ "TIMESTAMP_TZ" ] ) !== -1 ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXT_FIELD } );
                        // $$$ date picker does not support time zones, so default TIMESTAMP_TZ data type to Text Field

                    } else if ( $.inArray( pSqlColumn.type, [ "DATE", "TIMESTAMP", "TIMESTAMP_LTZ" ] ) !== -1 ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.DATE_PICKER } );

                    } else if ( pSqlColumn.type === "BOOLEAN" ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.YES_NO } );
                        pValues.push( { id: model.PROP.REGION_COLUMN_SESSION_STATE_DATA_TYPE, value: "BOOLEAN" } );

                    }

                    if ( lIsVisible ) {
                        pValues.push( { id: model.PROP.COLUMN_HEADING,   value: initCapColumnName( pSqlColumn.name )} );
                        pValues.push( { id: model.PROP.VALUE_REQUIRED,   value: pSqlColumn.isRequired ? "Y" : "N" } );
                    }
                },
                update: updateColumnAttributes,
                // Bug 25673217 - Do not add BLOB columns on IG Columns because IG doesn't support it
                skipColumn: ( sqlColumn ) => {
                    return sqlColumn.type === "BLOB";
                }
            } );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.TITLE )
        {

            syncPrintPageHeaderText( this, pAction, model.COMP_TYPE.IG_PRINT, pOldValue );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the IG processes and attributes if that hasn't already been done
            // (i.e if the region is removed)

            removeInteractiveGridProcesses( this.id );
            _removeChildren( this, model.COMP_TYPE.IG_ATTRIBUTES );
            _removeChildren( this, model.COMP_TYPE.IG_COLUMN );
            _removeChildren( this, model.COMP_TYPE.IG_COLUMN_GROUP );

        }
    } // interactiveGridPlugin


    function interactiveGridAttr( pAction, pProperty, pOldValue ) {
        const lRegionId = this.parentId;

        function hasPrintAttributes( pEnableDownloadProperty, pDownloadFormatsProperty ) {
            var lEnableDownload  = pEnableDownloadProperty.getValue() === "Y",
                lDownloadFormats = ( lEnableDownload ) ? pDownloadFormatsProperty.getValue().split( ":" ) : [];

            return ( lEnableDownload &&
                (  $.inArray( "XLSX", lDownloadFormats ) !== -1
                    || $.inArray( "PDF", lDownloadFormats ) !== -1
                    )
                );
        }

        function addColumnIfNotExists( pParentId, pColumnName, pValues ) {
            var lValues = [{
                id: model.PROP.COLUMN_NAME,
                value: pColumnName
            }].concat( ( pValues ? pValues : [] ) );

            if ( model.getComponents( model.COMP_TYPE.IG_COLUMN, {
                parentId: pParentId,
                properties: [{ id: model.PROP.COLUMN_NAME, value: pColumnName }]
            } ).length === 0 )
            {
                new model.Component( {
                    typeId:   model.COMP_TYPE.IG_COLUMN,
                    parentId: pParentId,
                    values:   lValues
                } );
            }
        }

        function removeColumn( pParentId, pColumnName ) {
            _removeComponents (
                model.getComponents( model.COMP_TYPE.IG_COLUMN, {
                    parentId: pParentId,
                    properties: [{ id: model.PROP.COLUMN_NAME, value: pColumnName }]
                } )
            );
        }


        if ( pAction === model.CALLBACK_ACTION.CREATED ) {
            if ( hasPrintAttributes( this.getProperty( model.PROP.ENABLE_DOWNLOAD ), this.getProperty( model.PROP.IG_DOWNLOAD_FORMATS ) ) ) {
                new model.Component( {
                    typeId:   model.COMP_TYPE.IG_PRINT,
                    parentId: lRegionId
                } );
                syncPrintPageHeaderText( this.getParent(), pAction, model.COMP_TYPE.IG_PRINT );
            }
        } else if (  pAction === model.CALLBACK_ACTION.CHANGED
            && ( pProperty.id === model.PROP.IG_DOWNLOAD_FORMATS || pProperty.id === model.PROP.ENABLE_DOWNLOAD )
            && pProperty.getValue() !== pOldValue )
        {
            if ( hasPrintAttributes( this.getProperty( model.PROP.ENABLE_DOWNLOAD ), this.getProperty( model.PROP.IG_DOWNLOAD_FORMATS ) ) ) {

                // Only create the print component if it doesn't exist yet
                if ( model.getComponents( model.COMP_TYPE.IG_PRINT, { parentId: lRegionId } ).length === 0 ) {
                    new model.Component( {
                        typeId:   model.COMP_TYPE.IG_PRINT,
                        parentId: lRegionId
                    } );
                    syncPrintPageHeaderText( this.getParent(), model.CALLBACK_ACTION.CREATED, model.COMP_TYPE.IG_PRINT );
                }
            } else {
                _removeChildren( this, model.COMP_TYPE.IG_PRINT );
            }
        }

        // Check if the component is getting created or if the editable flag has been changed
        if (    pAction === model.CALLBACK_ACTION.CREATED
             || (    pAction === model.CALLBACK_ACTION.CHANGED
                  && pProperty.id === model.PROP.IS_EDITABLE
                  && pProperty.getValue() !== pOldValue ) )
        {
            if ( this.getProperty( model.PROP.IS_EDITABLE ).getValue() === "Y" ) {

                // If the grid is editable and no primary key hasn't been defined yet, we try to add a column of
                // type ROWID if available and make it the primary key
               if ( model.getComponents( model.COMP_TYPE.IG_COLUMN, {
                    parentId:   lRegionId,
                    properties: [ { id: model.PROP.IS_PRIMARY_KEY, value: "Y" } ]
                } ).length === 0 )
                {
                    const lSqlColumns = model.getSourceLocationProperty( this.getParent() ).getColumns( true );

                    for ( let i = 0; i < lSqlColumns.length; i++ ) {
                        if ( lSqlColumns[ i ].type === "ROWID" ) {
                            addColumnIfNotExists( lRegionId, lSqlColumns[ i ].name, [
                                { id: model.PROP.ITEM_TYPE,          value: ITEM_TYPE.HIDDEN },
                                { id: model.PROP.COLUMN_SOURCE_TYPE, value: "DB_COLUMN" },
                                { id: model.PROP.SOURCE_DB_COLUMN,   value: lSqlColumns[ i ].name },
                                { id: model.PROP.DATA_TYPE,          value: "ROWID" },
                                { id: model.PROP.IS_PRIMARY_KEY,     value: "Y" }
                            ] );
                            break;
                        }
                    }
                }

                addColumnIfNotExists( lRegionId, "APEX$ROW_ACTION", [
                    { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.ROW_ACTION }
                ] );

                addColumnIfNotExists( lRegionId, "APEX$ROW_SELECTOR", [
                    { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.ROW_SELECTOR }
                ] );

                // Always add the new DML process after any existing processes,
                // except for the Close Dialog process - this should always be the last one on the page
                const allProcesses = model.getComponents( model.COMP_TYPE.PAGE_PROCESS ),
                      closeDialogIndex = allProcesses.findIndex( comp => comp.getPropertyValue( model.PROP.PAGE_PROCESS_TYPE ) === "NATIVE_CLOSE_WINDOW" ),
                      // If there's a Close Dialog process on the page, the previous component is the one right before it.
                      prevComponent = closeDialogIndex > -1 ? allProcesses[ closeDialogIndex - 1 ] : "last";

                _createComponent( {
                    typeId: model.COMP_TYPE.PAGE_PROCESS,
                    searchPropertyValues: [
                        { id: model.PROP.PAGE_PROCESS_TYPE, value: "NATIVE_IG_DML" },
                        { id: model.PROP.PROCESS_REGION,    value: lRegionId }
                    ],
                    addPropertyValues: [
                        { id: model.PROP.NAME, value: lang.formatMessageNoEscape( "WIZARD.IG.DML_PROCESS_NAME", this.getParent().getDisplayTitle() ) }
                    ],
                    previousComponent: prevComponent } );

            } else {


                // Remove added columns and any region depending validation or process if we don't allow editing anymore,
                // but don't remove ROWID which might be used by the developer
                removeColumn( lRegionId, "APEX$ROW_SELECTOR" );
                removeColumn( lRegionId, "APEX$ROW_ACTION" );

                removeInteractiveGridProcesses( lRegionId );

            }

            handleRegionWebSrcParameters( this );
        }


    } // interactiveGridAttr


    function interactiveGridColumn( pAction, pProperty, pValue ) {
        const PLUGIN = model.getComponentType( model.COMP_TYPE.IG_COLUMN ).pluginConfig.plugins [ this.getProperty( model.PROP.ITEM_TYPE ).getValue() ],
              lItemTypeProperty = this.getProperty( model.PROP.ITEM_TYPE ),
              lDataTypeProperty = this.getProperty( model.PROP.DATA_TYPE ),
              lLovTypeProperty = this.getProperty( model.PROP.LOV_TYPE );

        // Trigger revalidation of SQL Query when column (item) type changed for LOV based columns (items)
        revalidateLovQuery( this, pAction, pProperty );

        // Automatically set columns which point to a "Parent Column" to hidden
        if ( _hasChangedNotEqualsTo( this.getProperty( model.PROP.MASTER_COLUMN ), pAction, pProperty, "" ) ) {
            _setPropertyValue( this, model.PROP.ITEM_TYPE, ITEM_TYPE.HIDDEN );
        }

        // Don't export and sort hidden items
        if ( _hasChangedEqualsTo( this.getProperty( model.PROP.ITEM_TYPE ), pAction, pProperty, ITEM_TYPE.HIDDEN ) ) {
            _setPropertyValue( this, model.PROP.ENABLE_SORT_GROUP,       "N" );
            _setPropertyValue( this, model.PROP.INCLUDE_IN_EXPORT_PRINT, "N" );
        }

        // LOV based and text item types should always be start (left) aligned
        if (  _hasChangedEqualsTo( lItemTypeProperty, pAction, pProperty, ITEM_TYPE.TEXT_FIELD )
           || _hasChangedEqualsTo( lItemTypeProperty, pAction, pProperty, ITEM_TYPE.TEXTAREA )
           || ( _hasChanged( lItemTypeProperty, pAction, pProperty ) && lLovTypeProperty )
           )
        {
            _setPropertyValue( this, model.PROP.COLUMN_ALIGNMENT,  "LEFT" );
            _setPropertyValue( this, model.PROP.HEADING_ALIGNMENT, "LEFT" );

            if  ( _hasChangedEqualsTo( lItemTypeProperty, pAction, pProperty, ITEM_TYPE.TEXTAREA ) ) {
                _setPropertyValue( this, model.PROP.FILTER_LOV_TYPE,   "NONE" );
                _setPropertyValue( this, model.PROP.ENABLE_SORT_GROUP, "N" );
            }

        } else if ( _hasChangedEqualsTo( lItemTypeProperty, pAction, pProperty, ITEM_TYPE.NUMBER_FIELD ) ) {
            _setPropertyValue( this, model.PROP.COLUMN_ALIGNMENT,  "RIGHT" );
            _setPropertyValue( this, model.PROP.HEADING_ALIGNMENT, "RIGHT" );
            _setPropertyValue( this, model.PROP.FILTER_LOV_TYPE,   "NONE" );

        }

        // toggle column filter and column filter LOV type based on the column data type
        if ( _hasChanged( lDataTypeProperty, pAction, pProperty ) ) {
            if ( $.inArray( lDataTypeProperty.getValue(), model.UNSORTABLE_COLUMN_DATA_TYPES ) !== -1 ) {
                if ( lDataTypeProperty.getValue() === "CLOB" ) {
                    // unsortable columns: Enable Column Filter only for CLOB columns, and use "NONE as the LOV type
                    _setPropertyValue( this, model.PROP.COLUMN_FILTER,   "Y" );
                    _setPropertyValue( this, model.PROP.FILTER_LOV_TYPE, "NONE" );
                } else {
                    // unsortable columns: Disable Column Filter for BLOB, BFILE and other columns
                    _setPropertyValue( this, model.PROP.COLUMN_FILTER, "N" );
                }
            } else {
                // enable Column Filter for simple columns
                _setPropertyValue( this, model.PROP.COLUMN_FILTER, "Y" );
            }
        }

        // If an LOV has been specified, use it for the filter as well
        if ( _hasChangedNotEqualsTo( this.getProperty( model.PROP.LOV_TYPE ), pAction, pProperty, "" ) ) {
            _setPropertyValue( this, model.PROP.FILTER_LOV_TYPE, "LOV" );
        }

        if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {
            if ( pProperty.id === model.PROP.REGION_COLUMN_SESSION_STATE_DATA_TYPE ) {

                // exception for data type NUMBER which is only allowed for builder apps
                // hack should be removed once NUMBER becomes a real session state data type
                if ( pValue === "NUMBER" ) {
                    return;
                }

                if( !PLUGIN.itemSessionStateDataTypes.includes( pValue ) ) {
                    return { error: lang.formatMessage(
                        "APEX.SESSION_STATE.DATA_TYPE_NOT_ALLOWED",
                        pValue,
                        this.getProperty( model.PROP.COLUMN_NAME ).getValue() )
                    };
                }
            }
        }

    } // interactiveGridColumn


    function checkColumnIsInOrderBy ( pPropertyId, pPropertyValue, pColumnName ) {
        let isInOrderByClause;

        function checkColumnIsInOrderByExpression ( pOrderBys, pColumnName ) {
            return pOrderBys.filter( o => o.toUpperCase().includes( pColumnName ) ).length > 0;
        }

        if ( [ model.PROP.SOURCE_QUERY_ORDER_BY_ITEM, model.PROP.SOURCE_GRAPH_ORDER_BY_ITEM ].includes( pPropertyId ) ) {
            const jsonValue = JSON.parse( pPropertyValue );

            isInOrderByClause = jsonValue.orderBys.every( ( pElement ) => {
                const orderBys = pElement.expr.split( "," );

                return checkColumnIsInOrderByExpression ( orderBys, pColumnName );
            } );
        } else if ( [ model.PROP.SOURCE_QUERY_ORDER_BY, model.PROP.SOURCE_GRAPH_ORDER_BY ].includes( pPropertyId ) ) {
            const orderBys = pPropertyValue.split( "," );

            isInOrderByClause = checkColumnIsInOrderByExpression ( orderBys, pColumnName );
        }
        return isInOrderByClause;
    } // checkColumnIsInOrderBy

    function regionTemplateComponentColumn( pAction, pProperty, oldValue ) {
        const region = this.getParent();
        if (    pAction === model.CALLBACK_ACTION.CHANGED
             && pProperty.id === model.PROP.IS_GROUP ) {
            const orderByType = region.getProperty( model.PROP.SOURCE_QUERY_ORDER_BY_TYPE ),
                  orderByProperty = region.getProperty( SOURCE_QUERY_ORDER_BY_PROPS ),
                  columnName = this.getProperty( model.PROP.SOURCE_DB_COLUMN ).getValue();

            if (    columnName
                 && pProperty.getValue() === "Y"
                 && orderByType.getValue() === ""
            ) {
                orderByType.setValue( "STATIC" );
                _setPropertyValue( region, [ model.PROP.SOURCE_QUERY_ORDER_BY, model.PROP.SOURCE_GRAPH_ORDER_BY ], columnName );
            }
            if ( orderByProperty ) {
                _revalidateProperty( null, orderByProperty );
            }
        }
        if (  _hasChanged( this.getProperty( model.PROP.IS_PRIMARY_KEY ), pAction, pProperty, oldValue )
           && hasTriggeredActions.call( region ) ) {
            validateAlltriggeredActions.call( region );
        }
    } // regionTemplateComponentColumn

    function templateComponentRegionPlugin( pAction, pProperty, pOldValue, pSql ) {
        let regionPluginAttributes;

        // Synchronize the region columns as soon as one of the source properties changes
        if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && model.SOURCE_LOCATION_PROPS.includes( pProperty.id ) ) )
        {

            if ( pAction === model.CALLBACK_ACTION.CREATED ) {
                const regionType             = this.getProperty( model.PROP.REGION_TYPE ).getValue();
                const templateComponentTypes = model.getComponentType( model.COMP_TYPE.REGION ).pluginConfig.plugins[ regionType ].templateTypes;
                // default TEMPLATE_COMPONENT_TYPE with a supported type, if both are supported, REPORT is the preferred one
                const templateComponentType  = templateComponentTypes.includes( "REPORT" ) ? "REPORT" :
                                               templateComponentTypes.includes( "PARTIAL" ) ?  "PARTIAL" :
                                               "REGION_ONLY";

                regionPluginAttributes =
                    new model.Component( {
                            typeId:   model.COMP_TYPE.REGION_PLUGIN_ATTR,
                            parentId: this.id,
                            values:   [ {
                                    id:    model.PROP.TEMPLATE_COMPONENT_TYPE,
                                    value: templateComponentType
                                } ]
                        } );

                const sourceLocationProp = this.getProperty( model.PROP.SOURCE_LOCATION ),
                      sourceLocation = sourceLocationProp.getValue(),
                      hasConfiguredSource = model.SOURCE_LOCATION_PROPS.some( propertyId => {
                                                const property = this.getProperty( propertyId );

                                                return property && property.getValue().trim() !== "";
                                            } );

                // don't override the default source location, if it's set to SAMPLE_DATA
                if ( sourceLocation !== "SAMPLE_DATA" ) {
                    if ( templateComponentType === "REPORT" ) {
                        sourceLocationProp.setValue( "LOCAL", true );
                    } else if ( templateComponentType === "REGION_ONLY" && !hasConfiguredSource ) {
                        sourceLocationProp.setValue( "", true );
                    }
                }

                // We have to split the logic into two places, CHANGED is handled by regionPluginAttr.
                _setTemplateComponentRegionTemplate( this, templateComponentType );

            } else {
                regionPluginAttributes = this.getChilds( model.COMP_TYPE.REGION_PLUGIN_ATTR )[ 0 ];
            }

            // set "Show Total Row Count" property to "No" for web sources
            if ( this.getProperty( model.PROP.SOURCE_LOCATION )?.getValue() === "WEB_SOURCE" ) {
                _setPropertyValue( regionPluginAttributes, model.PROP.SHOW_TOTAL_ROW_COUNT, "N" );
            }

            manageColumns( this, this, model.COMP_TYPE.REGION_TMPL_COLUMN, model.PROP.SOURCE_DB_COLUMN, {
                add: function( pValues, pSqlColumn ) {

                    pValues.push( { id: model.PROP.COLUMN_NAME_UPPER,              value: pSqlColumn.name.replace( / /g, "_" ).toUpperCase() } );
                    pValues.push( { id: model.PROP.COLUMN_SOURCE_TYPE,             value: "DB_COLUMN" } );
                    pValues.push( { id: model.PROP.SOURCE_DB_COLUMN,               value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.DATA_TYPE,                      value: pSqlColumn.type } );


                    if ( pSqlColumn.isPrimaryKey || pSqlColumn.type === "ROWID" ) {

                        pValues.push( { id: model.PROP.IS_PRIMARY_KEY, value: "Y" } );

/*
                    } else if ( pSqlColumn.type === "CLOB" ) {

                        // phase 2 $$$ pValues.push( { id: model.PROP.REGION_COLUMN_SESSION_STATE_DATA_TYPE, value: "CLOB" } );
*/
                    }
                },
                update: function( pRegionColumn, pSqlColumn ) {

                    let dataTypeProperty = pRegionColumn.getProperty( model.PROP.DATA_TYPE );

                    // Update the column type property if it has changed
                    if ( dataTypeProperty.getValue() !== pSqlColumn.type ) {
                        dataTypeProperty.setValue( pSqlColumn.type );
                    }
                }
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            _removeChildren( this, model.COMP_TYPE.REGION_TMPL_COLUMN );
            _removeChildren( this, model.COMP_TYPE.REGION_ACTION );
            // REGION_PLUGIN_ATTR is removed by the generic code in pe.model / _callPluginCallback

        }

        if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {
            // check if SQL Query has order by like we do it for the grid
            if ( model.SOURCE_LOCATION_PROPS.includes( pProperty.id ) && pSql.hasOrderBy ) {
                return { error: format( "TMPL_COMPONENT.HAS_ORDER_BY" ) };
            }

            // check if group by columns are included in order by
            if ( SOURCE_QUERY_ORDER_BY_PROPS.includes( pProperty.id ) ) {
                const tmplColumns = this.getChilds( model.COMP_TYPE.REGION_TMPL_COLUMN, {
                    properties: [ {
                        id: model.PROP.IS_GROUP,
                        value: "Y"
                    } ]
                } ),
                      orderByProperty = this.getProperty( SOURCE_QUERY_ORDER_BY_PROPS );
                let returnWarning;

                // check each single column
                tmplColumns.every( ( pElement ) => {
                    const columnName = pElement.getProperty( model.PROP.SOURCE_DB_COLUMN )?.getValue();

                    // only check columns that type is db column
                    if ( columnName ) {
                        returnWarning = !checkColumnIsInOrderBy ( orderByProperty?.id, pOldValue, columnName );
                        if ( returnWarning ) {
                            return false;
                        }
                    }
                    return true;
                } );

                if ( returnWarning ) {
                    return { warning: format( "TMPL_COMPONENTS_COLUMN_GROUP.COLUMN_IS_NOT_IN_ORDER_BY_CLAUSE" ) };
                }
            }
        }
    } // templateComponentRegionPlugin


    function classicReportPlugin( pAction, pProperty, pOldValue ) {

        classicRptTabularFormPlugin( pAction, pProperty, this, model.COMP_TYPE.CLASSIC_REPORT, model.COMP_TYPE.CLASSIC_RPT_COLUMN, model.COMP_TYPE.CLASSIC_RPT_PRINT, pOldValue );

    } // classicReportPlugin


    function tabularFormPlugin( pAction, pProperty, pOldValue ) {

        var lSelf = this,
            lTabForms;

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // eslint-disable-next-line no-alert
            alert( format( "TABFORM.WARNING" ) );

        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE && pProperty.id === model.PROP.REGION_TYPE ) {

            // Raise an error if there is already a tabular form on the page
            lTabForms = model.getComponents( model.COMP_TYPE.REGION, {
                properties: [{
                    id: model.PROP.REGION_TYPE,
                    value: "NATIVE_TABFORM" }
                ],
                filterFunction: function() {
                    return ( this.id !== lSelf.id );
                }
            } );

            if ( lTabForms.length > 0 ) {
                return { error: format( "TABFORM.ONLY_ONE_PER_PAGE" ) };
            }
        }
        classicRptTabularFormPlugin( pAction, pProperty, this, model.COMP_TYPE.TABULAR_FORM, model.COMP_TYPE.TAB_FORM_COLUMN, model.COMP_TYPE.TAB_FORM_PRINT, pOldValue );

    } // tabularFormPlugin


    function classicRptTabularFormColumn( pColumn, pComponentTypeId, pAction, pProperty, pValue ) {

        var lRegion = pColumn.getParent(),
            lHeadingProperty;

        // No sorting is allowed if the report query contains an order by
        if (  pAction === model.CALLBACK_ACTION.VALIDATE
            && (  ( pProperty.id === model.PROP.DISABLE_SORT_COLUMN  && pValue === "N" )
            || ( pProperty.id === model.PROP.COLUMN_SORT_SEQUENCE && pValue !== "" )
            )
            && hasOrderBy( lRegion )
        )
        {
            return { error: format( "CLASSIC_RPT_TABFORM_COLUMN.NO_SORTING" ) };

        } else if (  pAction === model.CALLBACK_ACTION.CHANGED
            && pProperty.id === model.PROP.COLUMN_SORT_SEQUENCE
            && pProperty.getValue() === ""
            && hasOrderBy( lRegion )
            && pColumn.getProperty( model.PROP.DISABLE_SORT_COLUMN ).getValue() === "N"
        )
        {
            _setPropertyValue( pColumn, model.PROP.DISABLE_SORT_COLUMN, "Y" );
        }

        if ( pAction === model.CALLBACK_ACTION.CHANGED
           && pProperty.id === model.PROP.CLASSIC_REPORT_COLUMN_TYPE
           && pValue  === "HIDDEN_COLUMN" ) // pValue contains the previous value
        {
            lHeadingProperty = pColumn.getProperty( model.PROP.COLUMN_HEADING );
            if ( lHeadingProperty && lHeadingProperty.getValue() === "" ) {
                lHeadingProperty.setValue( initCapColumnName( pColumn.getProperty( model.PROP.COLUMN_NAME ).getValue() ) );
            }
        }

    } // classicRptTabularFormColumn


    function classicReportColumn( pAction, pProperty, pValue ) {

        return classicRptTabularFormColumn( this, model.COMP_TYPE.CLASSIC_RPT_COLUMN, pAction, pProperty, pValue );

    } // classicReportColumn


    function tabularFormColumn( pAction, pProperty, pValue ) {

        return classicRptTabularFormColumn( this, model.COMP_TYPE.TAB_FORM_COLUMN, pAction, pProperty, pValue );

    } // tabularFormColumn

    function validateDateFormatMask( pThis, pAction, pProperty, pValue ) {
        if (   pAction === model.CALLBACK_ACTION.VALIDATE
            && pProperty?.id === model.PROP.FORMAT_MASK_DATE
            && !( "" + pValue ).match( REGEX_STRING_HAS_ITEM_SUBSTITUTION ) ) { // when substitution is used we cannot check now
            try {
                // create a date string with the given format mask that is needed to try the parse
                const dateString = date.format( new Date(), pValue );
                // now parse the date, parse function has less supported format mask parts
                date.parse( dateString, pValue );
            } catch ( e ) {
                return { error: format( "ITEM.ERROR_FORMAT_MASK_DATE", e?.cause ) };
            }
        }
    }

    function facetedSearchOrSmartFilters( pAction ) {

        const SEARCH_FIELD_NAME = "P" + model.getCurrentPageId() + "_SEARCH";

        let facetFilterTypeId;

        if ( this.getProperty( model.PROP.REGION_TYPE ).getValue() === REGION_TYPE.FACETED_SEARCH ) {
            facetFilterTypeId      = model.COMP_TYPE.FACET;
        } else {
            facetFilterTypeId      = model.COMP_TYPE.SFILTER;
        }

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // pre-create the Search facet / filter
            _createComponent( {
                typeId: facetFilterTypeId,
                parentId: this.id,
                searchPropertyValues: [
                    { id: model.PROP.ITEM_NAME, value: SEARCH_FIELD_NAME }
                ],
                addPropertyValues: [
                    { id: model.PROP.ITEM_NAME,  value: SEARCH_FIELD_NAME },
                    { id: model.PROP.ITEM_TYPE,  value: "NATIVE_SEARCH" },
                    { id: model.PROP.ITEM_LABEL, value: lang.getMessage( "SL.PLACEHOLDER" )}
                ],
                previousComponent: "first" } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove created Facets and Filter Controls.
            // We do delete both (Facets and Filters) component types, because when
            // reading an existing page with a Faceted Search or Smart Filters region,
            // the PD configuration will duplicate the same "page items" into the Facets
            // and Filters component types, because they do have the same where clause restriction.
            _removeChildren( this, model.COMP_TYPE.FACET );
            _removeChildren( this, model.COMP_TYPE.FACET_GROUP );
            _removeChildren( this, model.COMP_TYPE.SFILTER );
            _removeChildren( this, model.COMP_TYPE.SFILTER_GROUP );
        }
    } // facetedSearchOrSmartFilters


    function regionPluginWithColumns( pAction, pProperty ) {

        var PLUGIN               = model.getComponentType( model.COMP_TYPE.REGION ).pluginConfig.plugins [ this.getProperty( model.PROP.REGION_TYPE ).getValue() ],
            HAS_COLUMN_ALIGNMENT = ( $.inArray( "VALUE_ALIGNMENT", PLUGIN.features ) !== -1 );

        if (  pAction === model.CALLBACK_ACTION.CREATED
           || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            //
            // Note: Keep this code in sync with wwv_flow_wizard_api.create_region_columns!
            //
            manageColumns( this, this, model.COMP_TYPE.REGION_COLUMN, model.PROP.COLUMN_NAME, {
                add: function( pValues, pSqlColumn ) {

                    pValues.push( { id: model.PROP.COLUMN_NAME,        value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.COLUMN_TYPE,        value: pSqlColumn.type } );

                    if ( pSqlColumn.isPrimaryKey || pSqlColumn.type === "ROWID" ) {
                        pValues.push( { id: model.PROP.IS_VISIBLE, value: "N" } );
                    } else {
                        if ( $.inArray( "COLUMN_HEADING", PLUGIN.features ) !== -1 ) {
                            pValues.push( {
                                id:    model.PROP.COLUMN_HEADING,
                                value: initCapColumnName( pSqlColumn.name )
                            } );
                        }
                        if ( HAS_COLUMN_ALIGNMENT ) {

                            if ( pSqlColumn.type === "NUMBER" ) {
                                pValues.push( { id: model.PROP.COLUMN_ALIGNMENT, value: "RIGHT" } );
                                pValues.push( { id: model.PROP.HEADING_ALIGNMENT, value: "RIGHT" } );

                            } else {
                                pValues.push( { id: model.PROP.COLUMN_ALIGNMENT, value: "LEFT" } );
                                pValues.push( { id: model.PROP.HEADING_ALIGNMENT, value: "LEFT" } );

                            }
                        }
                    }

                },
                update: function( pRegionColumn, pSqlColumn ) {

                    var lProperty = pRegionColumn.getProperty( model.PROP.COLUMN_TYPE );

                    // Update the column type property if it has changed
                    // We intentionally don't set IS_VISIBLE or COLUMN_ALIGNMENT, because that might have already
                    // been changed by the developer
                    if ( lProperty.getValue() !== pSqlColumn.type ) {
                        lProperty.setValue( pSqlColumn.type );
                    }
                }
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove all region columns if that hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.REGION_COLUMN );

        }
    } // regionPluginWithColumns

    function cardAttributes( action, property, oldValue ) {

        if ( _hasChanged( this.getProperty( model.PROP.CARD_PK_COLUMN1 ), action, property, oldValue )
            && hasTriggeredActions.call( this ) ) {
            validateAlltriggeredActions.call( this );
        }

    } // cardAttributes

    function mapRegionAttributes( pAction, pProperty, pOldValue ) {
        const initPosZoomTypeProp = this.getProperty( model.PROP.INIT_POSITION_ZOOM_TYPE );

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Create the first layer
            new model.Component( {
                typeId:   model.COMP_TYPE.MAP_LAYER,
                parentId: this.id
            } );
        }
        // Use Vector Tiles is not allowed for Zoom "Based on Spatial Results"
        else if ( _hasChanged( initPosZoomTypeProp, pAction, pProperty, pOldValue ) ) {
            this.getChilds( model.COMP_TYPE.MAP_LAYER ).forEach( layer => {
                _revalidateProperty( layer, model.PROP.MAP_USE_VECTOR_TILES );
             } );
        }

    } // mapRegionAttributes

    function searchRegionPlugin( pAction ) {

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Create the first search source
            new model.Component( {
                typeId:   model.COMP_TYPE.SEARCH_REGION_SOURCE,
                parentId: this.id
            } );

            let defaultSearchRegionTemplate = model.getTheme().defaultTemplates.search;

                if ( defaultSearchRegionTemplate ) {
                    _setPropertyValue( this, model.PROP.REGION_TEMPLATE, defaultSearchRegionTemplate );
                }

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            _removeChildren( this, model.COMP_TYPE.SEARCH_REGION_SOURCE );

        }

    } // searchRegionPlugin

    function searchRegionSource ( action, property ) {
        syncStaticId( this, action, property, this.getProperty( model.PROP.NAME ) );
    } //searchRegionSource

    function mapRegionPlugin( pAction ) {

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Create the mapRegionPlugin attributes
            new model.Component( {
                typeId:   model.COMP_TYPE.MAP_REGION,
                parentId: this.id
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the chartPlugin attributes if it hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.MAP_REGION );

        }
    } // mapRegionPlugin


    function jetChartPlugin( pAction ) {

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Create the chartPlugin attributes
            new model.Component( {
                typeId:   model.COMP_TYPE.JET_CHART,
                parentId: this.id
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the chartPlugin attributes if it hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.JET_CHART );

        }
    } // jetChartPlugin

    function jetChartAttributes( pAction, pProperty ) {

        var C_AXES_SUPPORT = [ "area", "bar", "boxPlot", "bubble", "combo", "line", "lineWithArea", "range", "polar", "radar", "stock", "scatter", "gantt" ];

        var lSelf = this,
            lChartTypeProperty = lSelf.getProperty( model.PROP.JET_CHART_TYPE ),
            lChartType = lChartTypeProperty.getValue(),
            lSeries,
            lAxes,
            lOrientationProperty;

        function addAxes () {
            var axis_one, axis_two;

            if ( lSelf.getChilds( model.COMP_TYPE.JET_CHART_AXES ).length === 0 ) {

                if ( lChartType === "gantt" ) {
                    axis_one = "major";
                    axis_two = "minor";
                } else {
                    axis_one = "x";
                    axis_two = "y";
                }

                new model.Component( {
                    typeId:   model.COMP_TYPE.JET_CHART_AXES,
                    parentId: lSelf.id,
                    values: [{
                        id:    model.PROP.CHART_AXIS,
                        value: axis_one
                    }]
                } );
                new model.Component( {
                    typeId:   model.COMP_TYPE.JET_CHART_AXES,
                    parentId: lSelf.id,
                    values: [{
                        id:    model.PROP.CHART_AXIS,
                        value: axis_two
                    }]
                } );

            }
        }

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Create the first series
            new model.Component( {
                typeId:   model.COMP_TYPE.JET_CHART_SERIES,
                parentId: lSelf.id,
            } );

            // Create X and Y axis
            if ( $.inArray( lChartType, C_AXES_SUPPORT ) !== -1 ) {
                addAxes();
            }

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            lSeries = lSelf.getChilds( model.COMP_TYPE.JET_CHART_SERIES );

            if ( pProperty.id === model.PROP.JET_CHART_TYPE ) {

                // @todo temp solution, need to replace it with config.
                // trigger a change event on the series, so the series_column_mapping can be updated
                this.getChilds( model.COMP_TYPE.JET_CHART_SERIES ).forEach( c => _revalidateProperty( c, model.PROP.NAME ) );

                // Some chart types only support one series, remove all the others
                if ( $.inArray( lChartType, [ "dial", "stock", "gantt" ] ) !== -1 ) {
                    for ( let i = 1; i < lSeries.length; i++ ) {
                        lSeries [ i ].remove();
                    }
                }

                // Some chart types don't support series
                if ( $.inArray( lChartType, C_AXES_SUPPORT ) !== -1 ) {

                    lAxes = lSelf.getChilds ( model.COMP_TYPE.JET_CHART_AXES );
                    if ( lAxes.length !== 0 ) {
                        // Gantt Chart only supports major/minor axes - clear existing x/y/y2
                        if ( lAxes [0].getProperty( model.PROP.CHART_AXIS ).getValue() === "x" && lChartType === "gantt" ) {
                            _removeChildren( lSelf, model.COMP_TYPE.JET_CHART_AXES );
                        }
                        // All Other Chart Types support x/y/y2 axes - clear existing major/minor
                        if ( lAxes [0].getProperty( model.PROP.CHART_AXIS ).getValue() === "major" && lChartType !== "gantt" ) {
                            _removeChildren( lSelf, model.COMP_TYPE.JET_CHART_AXES );
                        }
                    }

                    addAxes();
                } else {
                    _removeChildren( lSelf, model.COMP_TYPE.JET_CHART_AXES );
                }

            }
        }

        // =================================================================================================
        // Defaults set depending on chart type. Keep in sync with Create App/Page Wizard (wizapi.plb)!
        // =================================================================================================

        if ( _hasChanged( lChartTypeProperty, pAction, pProperty ) ) {
            if ( lChartType === "pie" ) {
                _setPropertyValue( lSelf, model.PROP.LEGEND_RENDERED, "on" );
            }
            if ( lChartType === "pie" || lChartType === "donut" ) {
                _setPropertyValue( lSelf, model.PROP.VALUE_FORMAT_TYPE, "decimal" );
                _setPropertyValue( lSelf, model.PROP.VALUE_DECIMAL_PLACES, "0" );
                _setPropertyValue( lSelf, model.PROP.VALUE_FORMAT_SCALING, "none" );
            }
        }

        // Pie charts do show the labels, keep in sync with Create App and Page wizard
        if ( _hasChangedEqualsTo( lChartTypeProperty, pAction, pProperty, "pie" ) ) {
            lSelf.getChilds( model.COMP_TYPE.JET_CHART_SERIES ).forEach( series => _setPropertyValue( series, model.PROP.ITEMS_LABEL_RENDERED, "Y" ) );
        }

        // Default height/max width attribute depending on chart type

        // Dial/Status Meter Gauge chart type
        lOrientationProperty = lSelf.getProperty( model.PROP.JET_GAUGE_ORIENTATION );
        if ( _hasChangedEqualsTo( lChartTypeProperty, pAction, pProperty, "dial" ) ||
             _hasChanged( lOrientationProperty, pAction, pProperty ) )
        {

            if ( lOrientationProperty.getValue() === "circular" ) {
                _setPropertyValue( lSelf, model.PROP.CHART_HEIGHT,    "100" );
                _setPropertyValue( lSelf, model.PROP.CHART_MAX_WIDTH, "90" );
            } else if ( lOrientationProperty.getValue() === "vertical" ) {
                _setPropertyValue( lSelf, model.PROP.CHART_HEIGHT,    "200" );
                _setPropertyValue( lSelf, model.PROP.CHART_MAX_WIDTH, "21" );
            } else if ( lOrientationProperty.getValue() === "horizontal" ) {
                _setPropertyValue( lSelf, model.PROP.CHART_HEIGHT,    "" );
                _setPropertyValue( lSelf, model.PROP.CHART_MAX_WIDTH, "250" );
            }

        // all other chart types
        } else if ( _hasChangedNotEqualsTo( lChartTypeProperty, pAction, pProperty, "dial" ) ) {
            _setPropertyValue( lSelf, model.PROP.CHART_HEIGHT,    "400" );
            _setPropertyValue( lSelf, model.PROP.CHART_MAX_WIDTH, "" );
        }


    } // jetChartAttributes

    function jetChartSeries( pAction, pProperty, pOldValue ) {

        let lSelf = this;

        syncStaticId( lSelf, pAction, pProperty );
        // We only check CHANGED, because during create we can't access the parents yet
        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.CHILD_SOURCE_LOCATION ) {
            const lRegionSourceLocationProperty = lSelf.getParent( model.COMP_TYPE.REGION ).getProperty( model.PROP.SOURCE_LOCATION );
            if ( lSelf.getProperty( model.PROP.CHILD_SOURCE_LOCATION ).getValue() === "REGION_SOURCE" ) {
                lRegionSourceLocationProperty._isRequired = true;

                // Force a re-validation of the region source property if it's needed for the chart series and if it's currently empty
                if ( lRegionSourceLocationProperty.getValue() === "" ) {
                    lRegionSourceLocationProperty.setValue( "", true );
                }
            }  else {
                lRegionSourceLocationProperty._isRequired = false;
            }
        }

        const lResult = sourceLocationHandling( pAction, this, pProperty, pOldValue, model.COMP_TYPE.JET_CHART_WS_PARAM );
        if ( lResult ) {
            return lResult;
        }

        // Create Y2 axis when Series assigned to Y2
        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.ASSIGNED_TO_Y2 ) {
            if ( lSelf.getProperty( model.PROP.ASSIGNED_TO_Y2 ).getValue() === "on" ) {
                if ( lSelf.getParent().getChilds( model.COMP_TYPE.JET_CHART_AXES ).length === 2 ) {
                    new model.Component( {
                        typeId:   model.COMP_TYPE.JET_CHART_AXES,
                        parentId: lSelf.getParent().id,
                        values: [{
                            id:    model.PROP.CHART_AXIS,
                            value: "y2"
                        }]
                    } );
                }
            } // $$$ we should have an else where remove the y2 if no series is using it anymore
        }

    } // jetChartSeries

    function jetChartAxes( pAction, pProperty ) {

        var lSelf = this,
            lName;

        syncStaticId( lSelf, pAction, pProperty, this.getProperty( model.PROP.CHART_AXIS ) );
        // =================================================================================================
        // Defaults set depending on Axis type. Keep in sync with Create App/Page Wizard (wizapi.plb)!
        // =================================================================================================
        if (  pAction === model.CALLBACK_ACTION.CREATED ) {

            lName = lSelf.getProperty( model.PROP.CHART_AXIS ).getValue();

            if ( lName === "y" ) {
                _setPropertyValue( lSelf, model.PROP.VALUE_FORMAT_TYPE,    "decimal" );
                _setPropertyValue( lSelf, model.PROP.VALUE_DECIMAL_PLACES, "0" );
                _setPropertyValue( lSelf, model.PROP.VALUE_FORMAT_SCALING, "none" );
            } else if ( lName === "major" ) {
                _setPropertyValue( lSelf, model.PROP.JET_AXIS_SCALE, "months" );
            } else if ( lName === "minor" ) {
                _setPropertyValue( lSelf, model.PROP.VALUE_FORMAT_TYPE, "decimal" );
                _setPropertyValue( lSelf, model.PROP.JET_AXIS_SCALE,    "days" );
            }
        }

    } // jetChartAxes

    function mapLayerAttributes( pAction, pProperty, pOldValue ) {
        syncStaticId( this, pAction, pProperty, this.getProperty( model.PROP.NAME ) );
        var lSelf = this,
            lRegionSourceLocationProperty;

        // We only check CHANGED, because during create we can't access the parents yet
        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.CHILD_SOURCE_LOCATION ) {
            lRegionSourceLocationProperty = lSelf.getParent().getParent().getProperty( model.PROP.SOURCE_LOCATION );
            if ( lSelf.getProperty( model.PROP.CHILD_SOURCE_LOCATION ).getValue() === "REGION_SOURCE" ) {
                lRegionSourceLocationProperty._isRequired = true;

                // Force a re-validation of the region source property if it's needed for the chart series and if it's currently empty
                if ( lRegionSourceLocationProperty.getValue() === "" ) {
                    lRegionSourceLocationProperty.setValue( "", true );
                }
            }  else {
                lRegionSourceLocationProperty._isRequired = false;
            }
        }

        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.MAP_USE_VECTOR_TILES ) {
            for ( var att of MAP_LAYER_USE_VECTOR_TILES_ERR_PROPS ) {
                _revalidateProperty( lSelf, att );
            }
        }
        if ( pAction === model.CALLBACK_ACTION.CHANGED
            && [ model.PROP.MAP_FEATURE_POINT_STROKE_COLOR,
                 model.PROP.MAP_FEATURE_POINT_STROKE_WIDTH
               ].includes( pProperty.id ) )
        {
            _revalidateProperty( lSelf, model.PROP.MAP_FEATURE_POINT_FILL_COLOR );
        }

        // Use Vector Tiles is not allowed for Initial Position and Zoom "Based on Spatial Results"
        if ( pAction === model.CALLBACK_ACTION.VALIDATE
            && pProperty.id === model.PROP.MAP_USE_VECTOR_TILES
            && pOldValue === "Y" )
        {
            if ( lSelf.getParent().getPropertyValue( model.PROP.INIT_POSITION_ZOOM_TYPE ) === "QUERY_RESULTS" ) {
                return { error: msg( "MAP.ERROR_QUERY_RESULTS_WITH_USE_VECTOR_TILES" ) };
            }
        }

        // Column substitution limitations for Point Layers if Use Vector Tiles is enabled
        if ( pAction === model.CALLBACK_ACTION.VALIDATE
            && MAP_LAYER_USE_VECTOR_TILES_ERR_PROPS.includes( pProperty.id )
            && lSelf.getPropertyValue( model.PROP.MAP_USE_VECTOR_TILES ) === "Y"
            && lSelf.getPropertyValue( model.PROP.MAP_LAYER_TYPE ) === "POINT"
         )
        {
            if (    pProperty.id !== model.PROP.MAP_FEATURE_POINT_FILL_COLOR
                 && pOldValue.match( REGEX_STRING_HAS_ITEM_SUBSTITUTION ) )
            {
                return {
                    error: msg( "MAP.ERROR_USE_VECTOR_TILES_COLUMN_SUBSTITUTION" )
                };
            }
            // Stroke Color and Width disabled if Fill Color used with column substitution
            if ( pProperty.id === model.PROP.MAP_FEATURE_POINT_FILL_COLOR
                    && pOldValue.match( REGEX_STRING_HAS_ITEM_SUBSTITUTION )
                    && (   lSelf.getPropertyValue( model.PROP.MAP_FEATURE_POINT_STROKE_COLOR ) !== ""
                        || lSelf.getPropertyValue( model.PROP.MAP_FEATURE_POINT_STROKE_WIDTH ) !== "" ) )
                {
                    return {
                        error: msg( "MAP.ERROR_USE_VECTOR_TILES_COLUMN_SUBSTITUTION" )
                };
            }
        }

        return sourceLocationHandling( pAction, lSelf, pProperty, pOldValue, model.COMP_TYPE.MAP_LAYER_WS_PARAM );
    }

    function legacyCalendarPlugin( pAction, pProperty ) {

        var lSelf = this,
            lCalendars;

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            new model.Component( {
                typeId:   model.COMP_TYPE.CLASSIC_CALENDAR,
                parentId: this.id
            } );
            // eslint-disable-next-line no-alert
            alert( format( "LEGACY_CALENDAR.WARNING" ) );

        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE && pProperty.id === model.PROP.REGION_TYPE ) {

            // Raise an error if there is already a legacy calendar on the page
            lCalendars = model.getComponents( model.COMP_TYPE.REGION, {
                properties: [{
                    id: model.PROP.REGION_TYPE,
                    value: "NATIVE_CALENDAR" }
                ],
                filterFunction: function() {
                    return ( this.id !== lSelf.id );
                }
            } );

            if ( lCalendars.length > 0 ) {
                return { error: format( "LEGACY_CALENDAR.ONLY_ONE_PER_PAGE" ) };
            }

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove the calendar attributes if it hasn't already been done (i.e if the region is removed)
            _removeChildren( this, model.COMP_TYPE.CLASSIC_CALENDAR );

        }
    } // legacyCalendarPlugin


    function formPlugin( pAction, pProperty ) {

        var lSelf = this;

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Always add the Init process after any existing process.
            new model.Component( {
                previousComponent: "last",
                typeId: model.COMP_TYPE.PAGE_PROCESS,
                values: [
                    { id: model.PROP.PAGE_PROCESS_TYPE,          value: "NATIVE_FORM_INIT" },
                    { id: model.PROP.PROCESS_DATA_SOURCE_REGION, value: lSelf.id },
                    { id: model.PROP.PROCESS_POINT,              value: "BEFORE_HEADER" },
                    { id: model.PROP.NAME, value: lang.formatMessageNoEscape( "WIZARD.FORM.INIT_PROCESS_NAME", this.getParent().getDisplayTitle() )}
                ]
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Clean up after removing the region / changing the region type
            // remove the added page items, i.e. page items with the form region as source
            _removeComponents(
                model.getComponents( model.COMP_TYPE.PAGE_ITEM, {
                    properties: [ { id: model.PROP.DATA_SOURCE_REGION, value: lSelf.id } ]
                } )
            );

            // remove the added processes
            _removeComponents(
                model.getComponents( model.COMP_TYPE.PAGE_PROCESS, {
                    properties: [ { id: model.PROP.PROCESS_DATA_SOURCE_REGION, value: lSelf.id } ]
                } )
            );
        }

        if (  pAction === model.CALLBACK_ACTION.CREATED
            || ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, model.SOURCE_LOCATION_PROPS ) !== -1 ) )
        {
            manageColumns( lSelf, undefined, model.COMP_TYPE.PAGE_ITEM, model.PROP.DATA_SOURCE_COLUMN, {
                add: function( pValues, pSqlColumn ) {

                    var lIsVisible = true,
                        lItemName;

                    // *************************************************************************************************
                    // KEEP IN SYNC with wwv_flow_form_region_dev.plb
                    // *************************************************************************************************

                    lItemName = model.getUniquePropertyValue( null, model.COMP_TYPE.PAGE_ITEM, model.PROP.ITEM_NAME, "P" + model.getCurrentPageId() + "_" + pSqlColumn.name );
                    pValues.push( { id: model.PROP.ITEM_NAME,          value: lItemName } );
                    pValues.push( { id: model.PROP.REGION,             value: lSelf.id } );
                    pValues.push( { id: model.PROP.DATA_SOURCE_REGION, value: lSelf.id } );
                    pValues.push( { id: model.PROP.DATA_SOURCE_COLUMN, value: pSqlColumn.name } );
                    pValues.push( { id: model.PROP.DATA_TYPE,          value: pSqlColumn.type } );

                    if ( pSqlColumn.isPrimaryKey || pSqlColumn.type === "ROWID" ) {

                        lIsVisible = false;
                        pValues.push( {id: model.PROP.ITEM_TYPE,      value: ITEM_TYPE.HIDDEN} );
                        pValues.push( {id: model.PROP.IS_PRIMARY_KEY, value: "Y"} );
                        pValues.push( {id: model.PROP.IS_QUERY_ONLY,  value: ( pSqlColumn.isQueryOnly ? "Y" : "N" ) } );

                    } else if ( pSqlColumn.type === "VARCHAR2" ) {

                        if ( pSqlColumn.maxLen < ITEM_TYPE_TEXTAREA_THRESHOLD || pSqlColumn.isGeneric ) {
                            pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXT_FIELD } );
                        } else {
                            pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXTAREA } );
                        }
                        if ( pSqlColumn.maxLen ) {
                            pValues.push( { id: model.PROP.ELEMENT_MAX_CHARACTERS, value: pSqlColumn.maxLen + "" } );
                        }

                    } else if ( pSqlColumn.type === "CLOB" ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXTAREA } );
                        pValues.push( { id: model.PROP.PAGE_ITEM_DATA_TYPE, value: "CLOB" } );

                    } else if ( pSqlColumn.type === "NUMBER" ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.NUMBER_FIELD } );

                    } else if ( $.inArray( pSqlColumn.type, [ "TIMESTAMP_TZ" ] ) !== -1 ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.TEXT_FIELD } );
                        // $$$ date picker does not support time zones, so default TIMESTAMP_TZ data type to Text Field

                    } else if ( $.inArray( pSqlColumn.type, [ "DATE", "TIMESTAMP", "TIMESTAMP_LTZ" ] ) !== -1 ) {

                        pValues.push( { id: model.PROP.ITEM_TYPE, value: ITEM_TYPE.DATE_PICKER } );

                    }


                    if ( lIsVisible ) {
                        pValues.push( { id: model.PROP.ITEM_LABEL,     value: initCapColumnName( pSqlColumn.name )} );
                        pValues.push( { id: model.PROP.VALUE_REQUIRED, value: pSqlColumn.isRequired ? "Y" : "N" } );
                    }
                },
                update: updateColumnAttributes,
                filter: { properties: [{ id: model.PROP.DATA_SOURCE_REGION, value: lSelf.id }] }
            } );
        }

    } // formPlugin


    function setValuePlugin( pAction, pProperty ) {

        var SET_TYPE_ID     = model.getPluginProperty( model.PLUGIN_TYPE.DYNAMIC_ACTION, "NATIVE_SET_VALUE", "type" ).id,
            lFireOnPageLoad = this.getProperty( model.PROP.FIRE_ON_PAGE_LOAD );

        // By default, a set value operation of type "Dialog Return Item" should not fire during page load, because
        // it only works in a "Dialog Closed" event.
        if (  pAction === model.CALLBACK_ACTION.CHANGED
            && pProperty.id === SET_TYPE_ID
            && pProperty.getValue() === "DIALOG_RETURN_ITEM"
            && lFireOnPageLoad.getValue() === "Y" )
        {
            lFireOnPageLoad.setValue( "N" );
        }

    } // setValuePlugin


    function inputPlugin( pAction, pProperty, pValue ) {
        let lValidationResult;

        lValidationResult = validateDateFormatMask( this, pAction, pProperty, pValue );
        if ( lValidationResult ) {
            return lValidationResult;
        }

        if ( this.typeId === model.COMP_TYPE.SFILTER ) {
            const suggestionsTypeProp = this.getProperty( model.PROP.SUGGESTIONS_TYPE );

            // An "Input Field" facet/filter doesn't support DYNAMIC, always set it to None
            if ( _hasChangedEqualsTo( suggestionsTypeProp, pAction, pProperty, "DYNAMIC" ) ) {
                suggestionsTypeProp.setValue( "" );
            }
        }

    } // inputPlugin

    function rangePlugin( pAction, pProperty, pValue ) {
        let lValidationResult;

        lValidationResult = validateDateFormatMask( this, pAction, pProperty, pValue );
        if ( lValidationResult ) {
            return lValidationResult;
        }
    } // rangePlugin

    function radioGroupFilterPlugin( pAction /*, pProperty */ ) {

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {
            // For better UX, we should always show all LOV entries and just "Disable" instead of "Hide" them,
            // this will makes it a lot easier to switch between those values
            _setPropertyValue( this, model.PROP.FC_ZERO_COUNT_ENTRIES, "D" );
            _setPropertyValue( this, model.PROP.FC_SORT_BY_TOP_COUNTS, "N" );
        }

    } // radioGroupFilterPlugin

    function webServiceProcessPlugin( pAction, pProperty, pOldValue ) {

        var PLUGIN_NAME,
            WS_OPER_PROPERTY_ID,
            STORE_RESULT_PROPERTY_ID;

        var that           = this,
            lWsOperationId,
            lStoreResultIn;

        function removeAllParams() {
            _removeChildren( that, model.COMP_TYPE.PAGE_PROC_WS_P_I );
            _removeChildren( that, model.COMP_TYPE.PAGE_PROC_WS_P_O );
            _removeChildren( that, model.COMP_TYPE.PAGE_PROC_WS_P_A );
        }

        function addParams( pWsOperationId, pComponentTypeId, pNewComponentTypeId ) {

            // Get all parameters of that web service operation and attach them to the process
            var lParameters = model.getComponents( pComponentTypeId, { parentId: pWsOperationId } );

            for ( let i = 0; i < lParameters.length; i++ ) {
                new model.Component( {
                    typeId:   pNewComponentTypeId,
                    parentId: that.id,
                    values: [
                        {
                            id:    model.PROP.PARAMETER_ID,
                            value: lParameters[ i ].id
                        },
                        {
                            id:    model.PROP.NAME,
                            value: lParameters[ i ].getProperty( model.PROP.NAME ).getValue()
                        }
                    ]
                } );
            }
        } // addParams

        if ( pAction === model.CALLBACK_ACTION.VALIDATE && pProperty.id === model.PROP.PAGE_PROCESS_TYPE ) {
            PLUGIN_NAME = pOldValue; // That's actually not the old value, it will contain the new page type. And because
                                     // we do support NATIVE_WEB_SERVICE and NATIVE_WEB_SERVICE_LEGACY we can't just hardcode the plug-in.
        } else {
            PLUGIN_NAME = this.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue();
        }

        WS_OPER_PROPERTY_ID      = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PLUGIN_NAME, "web_service_operation_id" ).id;
        STORE_RESULT_PROPERTY_ID = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PLUGIN_NAME, "store_result_in" ).id;

        if ( pAction === model.CALLBACK_ACTION.CREATED || pAction === model.CALLBACK_ACTION.CHANGED ) {
            lWsOperationId = this.getProperty( WS_OPER_PROPERTY_ID ).getValue();
            lStoreResultIn = this.getProperty( STORE_RESULT_PROPERTY_ID ).getValue();
        }

        if (  ( pAction === model.CALLBACK_ACTION.CREATED && lWsOperationId !== "" )
            || ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === WS_OPER_PROPERTY_ID && lWsOperationId !== pOldValue ) )
        {
            // If the selected web service operation has been changed, remove all existing parameters
            if ( pAction === model.CALLBACK_ACTION.CHANGED ) {
                removeAllParams();
            }

            // Initialize the process specific in/out/auth parameters based on the web service operation parameters
            if ( lWsOperationId !== "" ) {
                addParams( lWsOperationId, model.COMP_TYPE.WS_REF_OPER_P_I, model.COMP_TYPE.PAGE_PROC_WS_P_I );
                addParams( lWsOperationId, model.COMP_TYPE.WS_REF_OPER_P_H, model.COMP_TYPE.PAGE_PROC_WS_P_I );
                if ( lStoreResultIn === "ITEMS" ) {
                    addParams( lWsOperationId, model.COMP_TYPE.WS_REF_OPER_P_O, model.COMP_TYPE.PAGE_PROC_WS_P_O );
                }
                addParams( lWsOperationId, model.COMP_TYPE.WS_REF_OPER_P_A, model.COMP_TYPE.PAGE_PROC_WS_P_A );
            }

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === STORE_RESULT_PROPERTY_ID && lStoreResultIn !== pOldValue ) {

            _removeChildren( that, model.COMP_TYPE.PAGE_PROC_WS_P_O );

            // Only initialize the output parameters if the result should be stored in items
            if ( lStoreResultIn === "ITEMS" ) {
                addParams( lWsOperationId, model.COMP_TYPE.WS_REF_OPER_P_O, model.COMP_TYPE.PAGE_PROC_WS_P_O );
            }

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove all parameters if that hasn't already been done (i.e if the region is removed)
            removeAllParams();

        }
    } // webServiceProcessPlugin

    function createTaskProcessPlugin( pAction, pProperty, pOldValue ) {

        const TASK_DEF_ID = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, "NATIVE_CREATE_TASK", "task_definition_id" ).id;

        let lSelf = this,
            lTaskDefId,
            lModelCompType;

        function removeAllTaskParams( pCompTypeId ) {
            _removeChildren( lSelf, pCompTypeId );
        }

        function addTaskParams( pTaskDefId , pCompTypeId ) {

            var lTaskParams,
                lValues;

            lTaskParams = model.getComponents( model.COMP_TYPE.TASK_DEF_PARAM, {
                parentId: pTaskDefId
            } );

            for ( let i = 0; i < lTaskParams.length; i++ ) {
                lValues = [{
                    id:    model.PROP.TASK_DEF_PARAM,
                    value: lTaskParams[ i ].id
                }];

               // Set the default value as static value or initialize it as static value if the parameter is required and the developer should enter something
                if ( lTaskParams[ i ].getProperty( model.PROP.PARAMETER_REQUIRED ).getValue() === "Y" ) {
                    lValues.push( {
                        id:    model.PROP.TASK_VALUE_TYPE,
                        value: "STATIC"
                    } );

                } else {
                    lValues.push( {
                        id:    model.PROP.TASK_VALUE_TYPE,
                        value: "NULL"
                    } );
                }

                new model.Component( {
                    typeId:   pCompTypeId,
                    parentId: lSelf.id,
                    values:   lValues
                } );
            }
        } // addTaskParams
        if ( this.typeId === model.COMP_TYPE.WORKFLOW_ACTIVITY ) {
            lModelCompType = model.COMP_TYPE.WF_ACTIVITY_TASK_PARAM;
        }
        else {
            lModelCompType = model.COMP_TYPE.PAGE_PROCESS_TASK_PARAM;
        }
        if ( _hasChanged( this.getProperty( TASK_DEF_ID ), pAction, pProperty, pOldValue ) ) {

            // If the selected task definition has been changed, remove all existing parameters
            if ( pAction === model.CALLBACK_ACTION.CHANGED ) {
                removeAllTaskParams( lModelCompType );
            }

            // Initialize the process specific  parameters based on the task definition parameters
            lTaskDefId = this.getProperty( TASK_DEF_ID ).getValue();
            if ( lTaskDefId !== "" ) {
                addTaskParams( lTaskDefId, lModelCompType );
            }

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            // Remove all parameters if that hasn't already been done (i.e if the region is removed)
            removeAllTaskParams( lModelCompType );

        }
    } // createTaskProcessPlugin

    function revalidateLovQuery( pThis, pAction, pProperty ) {
        const lSnippet = pThis.getProperty( model.PROP.LOV_SQL ),
              lvalue = lSnippet?.getValue();

        // Trigger revalidation of SQL Query when item type changed
        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty?.id === model.PROP.ITEM_TYPE && lvalue ) {
            lSnippet.setValue( lvalue, true );
        }
    } // revalidateLovQuery

    function selectListPlugin ( pAction, pProperty ) {
        const lMultiValueTypeProperty = this.getProperty( model.PROP.MULTI_VALUE_TYPE_OPTIONAL );

        // Only if the item type or the allow multi selection property has changed, we will change the height
        if (    pAction === model.CALLBACK_ACTION.CREATED
             || pProperty?.id === model.PROP.MULTI_VALUE_TYPE_OPTIONAL ) {
            let lHeight;

            if ( lMultiValueTypeProperty.getValue() ) {
                lHeight = 5;
            } else {
                lHeight = 1;
            }
            _setPropertyValue( this, model.PROP.ELEMENT_HEIGHT, lHeight );
        }
    } // selectListPlugin

    function workflowProcessPlugin( action, property/* , oldValue */ ) {
        const self = this;
        const typeProp = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.WORKFLOW, "type" ).id );
        const workflowProp = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.WORKFLOW, "workflow_definition_id" ).id );

        if ( action === model.CALLBACK_ACTION.REMOVED || _hasChangedNotEqualsTo( typeProp, action, property, "START" ) ) {
            _removeChildren( self, model.COMP_TYPE.PAGE_PROCESS_WF_PARAM );
        } else if ( _hasChanged( workflowProp, action, property ) ) {
            let params = self.getChilds( model.COMP_TYPE.PAGE_PROCESS_WF_PARAM );
            let workflowParams = model.getComponents( model.COMP_TYPE.WORKFLOW_PARAM, {
                parentId: workflowProp.getValue(),
                properties: [ {
                    id: model.PROP.API_DIRECTION,
                    value: new RegExp( "^(IN|IN_OUT)$" ),
                } ]
            } );

            if ( params.length > 0 ) {
                removeUnusedWorkflowParameters( workflowParams, params );
            }

            workflowParams.forEach( ( param ) => {
                addWorkflowParameterToComponent( param, self );
            } );
        }
    } // workflowProcessPlugin

    function removeUnusedWorkflowParameters( parameters, parameterComponents ) {

        for( let i = 0; i < parameterComponents.length; i++ ) {
            let currParams = parameters.filter( param => param.id === parameterComponents[ i ].getPropertyValue( model.PROP.WORKFLOW_PARAM ) );
            if ( currParams.length === 0 ) {
                parameterComponents[ i ].remove();
            }
        }
    } // removeUnusedParameters

    function invokeWorkflowProcessPlugin( action, property, oldValue ) {
        const self = this;
        const workflowProp          = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_WF, "workflow_definition_id" ).id );
        const waitForCompletionProp = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_WF, "wait_for_completion" ).id );

        if ( action === model.CALLBACK_ACTION.REMOVED ) {
            _removeChildren( self, model.COMP_TYPE.WF_ACTIVITY_WF_PARAM );
        // Validate in case the "Wait for Completion" property is enabled that it's not allowed to
        // start the owner workflow or any of its ancestors
        } else if ( action === model.CALLBACK_ACTION.VALIDATE && property.id === workflowProp?.id ) {
            let ownerWorkflow = self.getParent( model.COMP_TYPE.WORKFLOW );
            if ( waitForCompletionProp?.getValue() === "Y" && ownerWorkflow?.id ) {
                let ancestors = pd.getConnectedWorkflows( ownerWorkflow.id );
                if ( ownerWorkflow.id === oldValue || ancestors.some( parent => parent.workflowId === oldValue ) ) {
                    return { error: msg( "WF.ERROR_SELF_REFERENCE" ) };
                }
            }
        } else {
            if ( _hasChanged( workflowProp, action, property, oldValue ) || _hasChanged( waitForCompletionProp, action, property, oldValue ) ) {
                let activityParams = self.getChilds( model.COMP_TYPE.WF_ACTIVITY_WF_PARAM );
                let addOutParams = self.getPropertyValue( waitForCompletionProp.id ) === "Y";
                let workflowParams = model.getComponents( model.COMP_TYPE.WORKFLOW_PARAM, {
                    parentId: workflowProp.getValue(),
                    properties: [{
                        id:    model.PROP.API_DIRECTION,
                        value: new RegExp( "^(IN|IN_OUT" + ( addOutParams ? "|OUT" : "" ) + ")$" )
                    } ]
                } );

                if ( activityParams.length > 0 ) {
                    removeUnusedWorkflowParameters( workflowParams, activityParams );
                }

                activityParams = self.getChilds( model.COMP_TYPE.WF_ACTIVITY_WF_PARAM );

                workflowParams.forEach( param => {
                    let actParam = activityParams.filter( p => p.getPropertyValue( model.PROP.WORKFLOW_PARAM ) === param.id )[ 0 ];
                    if ( !actParam ) {
                        addWorkflowParameterToComponent( param, self );
                    }
                } );
            }
        }


    } // invokeWorkflowProcessPlugin

    function plsqlProcessPlugin( pAction, pProperty ) {

        var lSnippet = this.getProperty( model.SOURCE_SNIPPET_PROPS );

        // Trigger a re-validation of the code snippet property if the location or the remote database has been changed
        if ( (  _hasChangedEqualsTo( this.getProperty( model.PROP.PLSQL_PROCESS_LOCATION ), pAction, pProperty, "LOCAL" )
             || _hasChangedNotEqualsTo( this.getProperty( model.PROP.SOURCE_REMOTE_DATABASE ), pAction, pProperty, "" )
            )
           && lSnippet.getValue() !== "" )
        {
            lSnippet.setValue( lSnippet.getValue(), true );
        }

    } // plsqlProcessPlugin

    function sendEmailProcessPlugin( pAction, pProperty ) {
        var EMAIL_PLACEHOLDER_PROP_ID = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, "NATIVE_SEND_EMAIL", "placeholder_values" ).id,
            EMAIL_TEMPLATE_PROP       = this.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, "NATIVE_SEND_EMAIL", "email_template_id" ).id ),
            self = this,
            lEmailTemplateComponent, lEmailTemplatePlaceholders, lOldPlaceholders,
            lNewJson = {}, lOldJson;

        // if the email template has changed, and is not null (empty), when fetch the placeholder JSON from the
        // server.
        if ( _hasChangedNotEqualsTo( EMAIL_TEMPLATE_PROP, pAction, pProperty, "" ) ) {

            // look up the email template in Shared Components
            lEmailTemplateComponent = model.getComponents( model.COMP_TYPE.EMAIL_TEMPLATE, { id: EMAIL_TEMPLATE_PROP.getValue() } );

            // we should have exactly one email template, since we looked it up by ID
            if ( lEmailTemplateComponent && lEmailTemplateComponent.length === 1 ) {

                // get the email template placeholders
                lEmailTemplatePlaceholders = model.getEmailPlaceholders( EMAIL_TEMPLATE_PROP.getValue() );

                lEmailTemplatePlaceholders.forEach( function( pPlaceHolder ) {
                    if ( pPlaceHolder !== "" ) {
                        lNewJson[ pPlaceHolder ] = "";
                    }
                } );

                // let's now look into the old placeholders JSON and see if we have common placeholders. For those
                // we'll retain the assigned values.

                lOldPlaceholders = self.getProperty( EMAIL_PLACEHOLDER_PROP_ID ).getValue();
                if ( lOldPlaceholders !== "" ) {
                    try {
                        lOldJson = JSON.parse( lOldPlaceholders );
                        Object.keys( lOldJson ).forEach(
                            function( key ) {
                                if ( hasOwnProperty( lNewJson, key ) ) {
                                    lNewJson[ key ] = lOldJson[ key ];
                                }
                            } );
                    } catch ( e ) {
                        // fail safely if the old property value was invalid JSON.
                    }
                }
            }
            _setPropertyValue( self, EMAIL_PLACEHOLDER_PROP_ID, JSON.stringify( lNewJson, null, 4 ) ) ;
        }
    } // sendEmailProcessPlugin

    function nativeItemPlugins( pAction ) {
        const lItemType = this.getProperty( model.PROP.ITEM_TYPE ).getValue();

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // For some item types we automatically set the height to 5 because they are designed to be multi line
            if ( [ ITEM_TYPE.RICH_TEXT_EDITOR, ITEM_TYPE.TEXTAREA, ITEM_TYPE.SHUTTLE ].includes( lItemType ) ) {

                _setPropertyValue( this, model.PROP.ELEMENT_HEIGHT, "5" );

            // Markdown Editor shouldn't use the generic default values for width/height
            } else if ( lItemType === ITEM_TYPE.MARKDOWN_EDITOR ) {

                _setPropertyValue( this, model.PROP.ELEMENT_WIDTH, "" );
                _setPropertyValue( this, model.PROP.ELEMENT_HEIGHT, "" );

            } else if ( ( lItemType === ITEM_TYPE.FILE || lItemType === ITEM_TYPE.IMAGE_UPLOAD ) && ( !this.getProperty( model.PROP.DATA_SOURCE_COLUMN ) && getLegacyDmlProcesses().length === 0 ) ) {

                // Don't use "BLOB column specified..." storage type if page doesn't have a Fetch/DML process
                _setPropertyValue( this, model.getPluginProperty( model.PLUGIN_TYPE.ITEM, lItemType, "storage_type" ).id, "APEX_APPLICATION_TEMP_FILES" );
            }

        }

    } // nativeItemPlugins


    function _itemNameChanged( pComponent, pProperty, pOldValue ) {

        var PAGE_PREFIX = /^(P\d+_)/;

        var lOldDbColumnName,
            lNewDbColumnName,
            lItemLabel,
            lDbSourceColumn;

        lOldDbColumnName = pOldValue.replace( PAGE_PREFIX, "" );
        lNewDbColumnName = pProperty.getValue().replace( PAGE_PREFIX, "" );

        // Keep the "Label" property in sync if the label is empty or equal to the old facet name
        lItemLabel = pComponent.getProperty( model.PROP.ITEM_LABEL );
        if (  lItemLabel
            && ( initCapColumnName( lOldDbColumnName ) === lItemLabel.getValue() || lItemLabel.getValue() === "" ) )
        {
            lItemLabel.setValue( initCapColumnName( lNewDbColumnName ) );
        }

        // Keep the db column name in sync if the DB Column is empty or equal to the old facet name
        lDbSourceColumn = pComponent.getProperty( model.PROP.SOURCE_DB_COLUMN );
        if (  lDbSourceColumn
            && ( pOldValue.replace( PAGE_PREFIX, "" ) === lDbSourceColumn.getValue() || lDbSourceColumn.getValue() === "" ) )
        {
            lDbSourceColumn.setValue( pProperty.getValue().replace( PAGE_PREFIX, "" ) );
        }
    } // _itemNameChanged

    function pageMetaTag( pAction, pProperty ) {
        syncStaticId( this, pAction, pProperty, this.getProperty( model.PROP.META_TAG_NAME ) );
    } // pageMetaTag

    function page( pAction, pProperty, pValue ) {

        const enableMetaTags = this.getProperty( model.PROP.ENABLE_META_TAGS );

        // Check if the enable meta tags has been changed
        if ( _hasChanged( enableMetaTags, pAction, pProperty ) ) {

            if ( enableMetaTags.getValue() === "Y" ) {

                new model.Component( {
                    typeId:   model.COMP_TYPE.META_TAG,
                    parentId: this.id,
                    values:   [{
                        id:    model.PROP.META_TAG_NAME,
                        value: "description"
                    }]
                } );

            } else { // page requires authentication

                // Remove all page meta tags
                _removeChildren( this, model.COMP_TYPE.META_TAG );

            }

        }

        const pageAuthentication = this.getProperty( model.PROP.PAGE_AUTHENTICATION );

        // Check if the page authentication has been changed
        if ( _hasChanged( pageAuthentication, pAction, pProperty ) ) {

            // if page is not public
            if ( pageAuthentication.getValue() === "N" ) {

                // Remove all page meta tags
                _removeChildren( this, model.COMP_TYPE.META_TAG );

            }

        }

        // When changing the page mode, we must set the default page template (Normal or Modal)
        const pageMode = this.getProperty( model.PROP.PAGE_MODE );

        if ( _hasChanged( pageMode, pAction, pProperty ) ) {

            if ( pageMode.getValue() === "NORMAL" ) {
                _setPropertyValue( this, model.PROP.PAGE_TEMPLATE, model.getTheme().defaultTemplates.page );
            } else {
                _setPropertyValue( this, model.PROP.DIALOG_TEMPLATE, model.getTheme().defaultTemplates.dialog );
            }
        }

        if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {
            if ( [ model.PROP.CSS_FILE_URLS, model.PROP.JS_FILE_URLS ].includes( pProperty.id ) ) {

                // function to validate given file URLs
                // returns true, if all URLs are correct or if pUrls is empty
                // returns false, if any URL is invalid
                function validateFileUrls( pUrls, pPropertyId ) {
                    if ( pUrls.trim() === "" ) {
                        // empty pUrls, early exit
                        return true;
                    }

                    function removeBlockComments( pUrls ) {
                        // Note: We have similar server side regex in wwv_flow_javascript.normalize_file_urls
                        // Keep both the regex logic in sync

                        // /.../   start and end of regex pattern
                        // /*      start of block comment, \ is used to esacpe special characters / and *
                        // .*?     . matches any character, * for zero or more occurances, ? for non-greedy
                        // */      end of block, with escaping
                        // g       global flag
                        // s       DotAll flag, so that . (dot) can match new lines
                        return pUrls.replace( /\/\*.*?\*\//gs, "" );
                    }

                    const validLines = removeBlockComments( pUrls ).split( /\r?\n/ );

                    let fileTypes;
                    switch ( pPropertyId ) {
                        case model.PROP.CSS_FILE_URLS:
                            fileTypes = "css";
                            break;
                        case model.PROP.JS_FILE_URLS:
                            fileTypes = "js|mjs";
                            break;
                    }

                    // below pattern just checks whether line ends with allowed file types
                    // or follows by a query string (?)
                    // these are basic tests, we can extend them in future on need basis
                    const validPattern = new RegExp( "\\.(" + fileTypes + ")($|\\?)", "i" );

                    for ( let i = 0; i < validLines.length; i++ ) {
                        const line = validLines[i].trim();

                        if ( line === "" || line.startsWith( "--" ) ) {
                            // skip if the line is empty or if the line is commented
                            continue;
                        }

                        if ( !validPattern.test( line ) ) {
                            // invalid file URL detected
                            return false;
                        }
                    }
                    return true;
                }

                if ( pValue !== "" ) {
                    if ( !validateFileUrls( pValue, pProperty.id ) ) {
                        // using "warning" instead of "error" to prevent false positives stopping users from saving
                        // their changes. These checks are primarily added to warn users from accidentally using
                        // File URLs property to enter JavaScript or CSS code
                        return { warning: msg( "INVALID_FILE_URL" ) };
                    }
                }
            }
        }
    } // page

    function pageItem( pAction, pProperty, pValue ) {

        const PLUGIN = model.getComponentType( model.COMP_TYPE.PAGE_ITEM ).pluginConfig.plugins[ this.getProperty( model.PROP.ITEM_TYPE ).getValue() ];

        let lNewColumnName,
            lNewDbColumnName,
            lSourceUsed,
            lDmlProcesses,
            lColumns;

        // Trigger revalidation of SQL Query when item type changed for LOV based items
        revalidateLovQuery( this, pAction, pProperty );

        if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {
            if ( pProperty.id === model.PROP.PAGE_ITEM_DATA_TYPE ) {

                // exception for data type NUMBER which is only allowed for builder apps
                // hack should be removed once NUMBER becomes a real session state data type
                if ( pValue === "NUMBER" ) {
                    return;
                }

                if( !PLUGIN.itemSessionStateDataTypes.includes( pValue ) ) {
                    return { error: lang.formatMessage(
                        "APEX.SESSION_STATE.DATA_TYPE_NOT_ALLOWED",
                        pValue,
                        this.getProperty( model.PROP.ITEM_NAME ).getValue() )
                    };
                }
            }
        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            if ( pProperty.id === model.PROP.ITEM_NAME ) {
                // Has the item name changed?
                _itemNameChanged( this, pProperty, pValue );

            } else if ( pProperty.id === model.PROP.SOURCE_TYPE ) {
                // Always default "Used" to "Always, replacing any existing value in session state" if page item is based on a DB column
                lSourceUsed = this.getProperty( model.PROP.SOURCE_USED );
                if ( lSourceUsed && pProperty.getValue() === "DB_COLUMN" ) {
                    lSourceUsed.setValue( "NO" );
                } else {
                    lSourceUsed.setValue( "YES" );
                }

            } else if ( pProperty.id === model.PROP.SOURCE_DB_COLUMN ) {
                // Has the "DB column" property changed?

                lNewDbColumnName = pProperty.getValue();

                // Try to find the column definition based on the Fetch or DML process specified for the current page
                lDmlProcesses = getLegacyDmlProcesses();

                if ( lDmlProcesses.length > 0 ) {
                    if ( lDmlProcesses[ 0 ].getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue() === "NATIVE_FORM_FETCH" ) {
                        lColumns = lDmlProcesses[ 0 ].getProperty( model.PROP.FORM_FETCH_TABLE_NAME ).getColumns();
                    } else {
                        lColumns = lDmlProcesses[ 0 ].getProperty( model.PROP.FORM_PROCESS_TABLE_NAME ).getColumns();
                    }
                    // Try to lookup the entered DB column name and set the "Value Required" and "Maximum Characters" property based
                    // on the column specification.
                    for ( let i = 0; i < lColumns.length; i++ ) {
                        if ( lColumns[ i ].name === lNewDbColumnName ) {

                            // Set "Value Required" property if the page item has one
                            _setPropertyValue( this, model.PROP.VALUE_REQUIRED, lColumns[ i ].isRequired ? "Y" : "N" );

                            // Set "Maximum Characters" property if the page item has one
                            _setPropertyValue( this, model.PROP.ELEMENT_MAX_CHARACTERS, hasOwnProperty( lColumns[ i ], "maxLen" ) ? lColumns[ i ].maxLen + "" : "" );
                        }
                    }
                }

            } else if ( pProperty.id === model.PROP.DATA_SOURCE_COLUMN ) {
                // Has the "Data Source column" property changed?

                lNewColumnName = pProperty.getValue();
                lColumns = pProperty._getAvailableColumns( true );

                // Try to lookup the entered DB column name and set the "Value Required" and "Maximum Characters" property based
                // on the column specification.
                for ( let i = 0; i < lColumns.length; i++ ) {
                    if ( lColumns[i].name === lNewColumnName ) {

                        // Set "Value Required" property if the page item has one
                        _setPropertyValue( this, model.PROP.DATA_TYPE, lColumns[i].type );

                        // Set "Value Required" property if the page item has one
                        _setPropertyValue( this, model.PROP.VALUE_REQUIRED, lColumns[i].isRequired ? "Y" : "N" );

                        // Set "Maximum Characters" property if the page item has one
                        _setPropertyValue( this, model.PROP.ELEMENT_MAX_CHARACTERS, hasOwnProperty( lColumns[i], "maxLen" ) ? lColumns[i].maxLen + "" : "" );
                    }
                }
            } else if ( pProperty.id === model.PROP.PAGE_ITEM_DATA_TYPE ) {

                // update any computations tied to this item
                // for now, we don't revalidate any existing expressions, but update the data type for any future validations
                const newDataType = pProperty.getValue();

                model.getComponents( model.COMP_TYPE.PAGE_COMPUTATION, {
                    properties: [ {
                        id: model.PROP.COMPUTATION_ITEM_NAME,
                        value: this.getPropertyValue( model.PROP.ITEM_NAME )
                    } ]
                } ).forEach( pageComputation => {
                    pageComputation.getProperty( model.PROP.HIDDEN_ITEM_SESSION_STATE_DATA_TYPE ).setValue( newDataType );
                } );
            }
        }

        // Enable session state protection for Primary key items
        if ( _hasChangedEqualsTo( this.getProperty( model.PROP.IS_PRIMARY_KEY ), pAction, pProperty, "Y" ) ) {
            _setPropertyValue( this, model.PROP.SESSION_STATE_PROTECTION, "S" );
        }

        // Slot handling when this item region changes
        _setSlot( {
            componentTypeId: model.COMP_TYPE.PAGE_ITEM,
            action: pAction,
            property: pProperty,
            oldRegionId: pValue,
            component: this
        } );
    } // pageItem

    function pageComputation( pAction, pProperty /*, pOldValue */ ) {

        const itemDataTypeProp = this.getProperty( model.PROP.HIDDEN_ITEM_SESSION_STATE_DATA_TYPE );
        const itemNameProp = this.getProperty( model.PROP.COMPUTATION_ITEM_NAME );

        const getItemDataType = itemName => {
            return model.getComponents( model.COMP_TYPE.PAGE_ITEM, {
                properties: [ {
                    id: model.PROP.ITEM_NAME,
                    value: itemName
                } ]
            } )?.[0]?.getProperty( model.PROP.PAGE_ITEM_DATA_TYPE ).getValue() || "VARCHAR2";
        };

        if( pAction === model.CALLBACK_ACTION.CREATED ) {
            // if duplicated, there's already a data type. do nothing
            if( !itemDataTypeProp.getValue() ) {
                const itemName = itemNameProp.getValue();
                // if created for a specific item, get the data type
                // otherwise, if created from scratch, default to vc2
                itemDataTypeProp.setValue( itemName ? getItemDataType( itemName ) : "VARCHAR2" );
            }
        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {
            if( pProperty.id === model.PROP.COMPUTATION_ITEM_NAME ) {
                const itemName = pProperty.getValue();
                if( itemName ) {
                    itemDataTypeProp.setValue( getItemDataType( itemName ) );
                }
            }
        }

        syncStaticId( this, pAction, pProperty, this.getProperty( model.PROP.COMPUTATION_ITEM_NAME ) );
    } // pageComputation

    function pageValidation ( action, property ) {
        syncStaticId( this, action, property, this.getProperty( model.PROP.NAME ) );
    } //pageValidation

    function facet( pAction, pProperty, pValue ) {

        const FS_PLUGIN_SHOW_CHART_PROP_ID = model.getPluginProperty( model.PLUGIN_TYPE.REGION, REGION_TYPE.FACETED_SEARCH, "show_charts" ).id;
        let lFsRegionPluginAttributes,
            lFsRegionShowChart;

        if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            if ( pProperty.id === model.PROP.ITEM_NAME ) {
                // Has the item name changed?
                _itemNameChanged( this, pProperty, pValue );

            } else if ( pProperty.id === model.PROP.FC_SHOW_CHART && pValue === "N" && pProperty.getValue() === "Y" ) {

                // If charting of the Facets gets enabled, automatically set the region level attribute "Show Chart" to Popup
                // if it hasn't been turned on yet.
                lFsRegionPluginAttributes = this.getParent().getChilds( model.COMP_TYPE.REGION_PLUGIN_ATTR )[ 0 ];
                if ( lFsRegionPluginAttributes ) {
                    lFsRegionShowChart = lFsRegionPluginAttributes.getProperty( FS_PLUGIN_SHOW_CHART_PROP_ID );
                    if ( lFsRegionShowChart && lFsRegionShowChart.getValue() === "N" ) {
                        lFsRegionShowChart.setValue( "Y" );
                    }
                }
            }
        }
    } // facet

    function facetGroup( pAction, pProperty ) {

        syncStaticId( this, pAction, pProperty, this.getProperty( model.PROP.ITEM_LABEL ) );

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Immediately create a single checkbox to start with
            new model.Component( {
                typeId:   model.COMP_TYPE.FACET_GROUP_ITEM,
                parentId: this.id
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            _removeChildren( this, model.COMP_TYPE.FACET_GROUP_ITEM );

        }
    } // facetGroup


    function sFilter( pAction, pProperty, pOldValue ) {

        if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            if ( pProperty.id === model.PROP.ITEM_NAME ) {
                // Has the item name changed?
                _itemNameChanged( this, pProperty, pOldValue );
            }
        }
    } // sFilter


    function sFilterGroup( pAction /*, pProperty */ ) {

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Immediately create a single checkbox to start with
            new model.Component( {
                typeId:   model.COMP_TYPE.SFILTER_GROUP_ITEM,
                parentId: this.id
            } );

        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {

            _removeChildren( this, model.COMP_TYPE.SFILTER_GROUP_ITEM );

        }
    } // sFilterGroup


    function button( pAction, pProperty, pOldValue ) {

        const MENU_TYPE = "MENU";
        let lLabel = this.getProperty( model.PROP.BUTTON_LABEL ),
            lNameInitCap = initCapColumnName( this.getProperty( model.PROP.BUTTON_NAME ).getValue() );

        syncStaticId( this, pAction, pProperty, this.getProperty( model.PROP.BUTTON_NAME ) );

        function reValidateDynamicActionButtons( pButtonId, pComponentTypeId, pPropertyId ) {

            let lComponents,
                lProperty;

            lComponents = model.getComponents( pComponentTypeId, { properties: [{ id: pPropertyId, value: pButtonId }]} );
            for ( let i = 0; i < lComponents.length; i++ ) {
                lProperty = lComponents[ i ].getProperty( pPropertyId );
                lProperty.setValue( lProperty.getValue(), true );
            }
        } // reValidateDynamicActionButtons

        // Slot handling when this button region changes
        _setSlot( {
            componentTypeId: model.COMP_TYPE.BUTTON,
            action: pAction,
            property: pProperty,
            oldRegionId: pOldValue,
            component: this
        } );

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            lLabel.setValue( lNameInitCap );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            if ( pProperty.id === model.PROP.BUTTON_NAME ) {
                // Keep the "Label" property in sync if the label is empty or equal to the old button name
                lLabel = this.getProperty( model.PROP.BUTTON_LABEL );
                if ( initCapColumnName( pOldValue ) === lLabel.getValue() || lLabel.getValue() === "" ) {
                    lLabel.setValue( lNameInitCap );
                }

            } else if ( pProperty.id === model.PROP.BUTTON_TEMPLATE ) {

                // Re-validate all dynamic actions referencing this button to make sure that the button template does contain #BUTTON_ID#
                reValidateDynamicActionButtons( this.id, model.COMP_TYPE.DA_EVENT,  model.PROP.WHEN_BUTTON );
                reValidateDynamicActionButtons( this.id, model.COMP_TYPE.DA_ACTION, model.PROP.AFFECTED_BUTTON );

                // if the template changes, we need to revalidate the Button Type property,
                // as it might not be supported by the current template
                if ( _hasChanged( this.getProperty( model.PROP.BUTTON_TEMPLATE ), pAction, pProperty, pOldValue ) ) {
                    _revalidateProperty( this, model.PROP.BUTTON_TYPE );
                }

            } else if ( pProperty.id === model.PROP.BUTTON_TYPE ) {
                if ( pProperty.getValue() === MENU_TYPE ) {
                    if ( this.getChilds( model.COMP_TYPE.BUTTON_MENU_ENTRY ).length === 0 ) {
                        new model.Component( {
                            typeId: model.COMP_TYPE.BUTTON_MENU_ENTRY,
                            parentId: this.id
                        } );
                    }
                    if ( this.getChilds( model.COMP_TYPE.PAGE_BUTTON_ACTION ).length > 0 ) {
                        _removeChildren( this, model.COMP_TYPE.PAGE_BUTTON_ACTION );
                    }
                } else {
                    _removeChildren( this, model.COMP_TYPE.BUTTON_MENU_ENTRY );
                    _removeChildren( this, model.COMP_TYPE.BUTTON_ACTION_MENU_ENTRY_ACTION );
                }
            } else if ( pProperty.id === model.PROP.BUTTON_ACTION ) {
                if ( pProperty.getValue() === "DEFINED_BY_DA_ACTION" && this.getChilds( model.COMP_TYPE.PAGE_BUTTON_ACTION ).length === 0 ) {
                    new model.Component( {
                        typeId:   model.COMP_TYPE.PAGE_BUTTON_ACTION,
                        parentId: this.id,
                        values: [
                            { id: model.PROP.DA_ACTION_TYPE, value: "NATIVE_EXECUTE_PLSQL_CODE" }
                        ]
                    } );
                } else if ( pProperty.getValue() !== "DEFINED_BY_DA_ACTION" && this.getChilds( model.COMP_TYPE.PAGE_BUTTON_ACTION ).length > 0 ) {
                    _removeChildren( this, model.COMP_TYPE.PAGE_BUTTON_ACTION );
                }
            }
        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {
            _removeChildren( this, model.COMP_TYPE.PAGE_BUTTON_ACTION );
            _removeChildren( this, model.COMP_TYPE.BUTTON_ACTION_MENU_ENTRY_ACTION );
        }

        // When the button action changes:
        // - Set "Warn on Unsaved Changes" to "Do not Check" ("I") if the action is SUBMIT
        // - Set it to "Page Default" for all other actions
        let lbuttonActionProp = this.getProperty( model.PROP.BUTTON_ACTION );
        if ( _hasChanged( lbuttonActionProp, pAction, pProperty, pOldValue ) ) {
            _setPropertyValue (
                this,
                model.PROP.BUTTON_WARN_ON_UNSAVED_CHANGES,
                lbuttonActionProp.getValue() === "SUBMIT" ? "I" : "" );
        }


    } // button


    function sourceLocationHandling( pAction, pComponent, pProperty, pOldValue, pCompWsParamComponentTypeId ) {

        function addSqlQuery( pOptions ) {
            let lProperty = pComponent.getProperty( pOptions.id ),
                lValue = "",
                lQuote = ( lDatabaseType === "MYSQL" ? "\u0060" : "\"" );

            if ( pOptions.value ) {
                lValue = pOptions.value;
            } else if ( lProperty ) {
                lValue = lProperty.getValue() || "";
            }

            if ( lValue !== "" ) {
                if ( pOptions.prefix ) {
                    lSqlQuery += pOptions.prefix;
                }
                // Does the identifier contain special characters?
                if ( lDatabaseType === "MYSQL" ) {
                    if ( pOptions.identifier && !/^[A-Za-z]+[A-Za-z0-9_$]*$/.test( lValue ) ) {
                        lSqlQuery += lQuote + lValue.replace( /\u0060/, "\u0060\u0060" ) + lQuote;
                    } else {
                        lSqlQuery += lValue;
                    }

                } else {
                    if ( pOptions.identifier && !/^[A-Z]+[A-Z0-9_$]*$/.test( lValue ) ) {
                        lSqlQuery += lQuote + lValue + lQuote;
                    } else {
                        lSqlQuery += lValue;
                    }
                }
                if ( pOptions.postfix ) {
                    lSqlQuery += pOptions.postfix;
                }
            }
        } // addSqlQuery

        function propHasValue( pPropId ) {
            let lProperty = pComponent.getProperty( pPropId );
            return lProperty && lProperty.getValue().trim() !== "";
        }

        let lProperty,
            lArrayColumnProp,
            lArrayColumn,
            lSourceTypeProp,
            lRegionTypeProp,
            lUseLocalTableProp,
            lWebSrcModuleId,
            lRegionPluginAttrs,
            lQueryType,
            lGraphColumnsClause,
            lSqlColumns,
            lDatabaseType = "ORACLE",
            lSqlQuery     = "",
            lQueryTypeProp,
            lQueryOwnerProp,
            lQueryTypeTableProp,
            lSqlQueryProp;

        if ( pComponent.typeId === model.COMP_TYPE.WORKFLOW_VERSION ) {
            lQueryTypeProp = model.PROP.WF_SOURCE_QUERY_TYPE;
            lQueryOwnerProp = model.PROP.WF_SOURCE_QUERY_OWNER;
            lQueryTypeTableProp = model.PROP.WF_SOURCE_QUERY_TABLE;
            lSqlQueryProp = model.PROP.WF_SOURCE_SQL_QUERY;
        } else {
            lQueryTypeProp = model.PROP.SOURCE_QUERY_TYPE;
            lQueryOwnerProp = model.PROP.SOURCE_QUERY_OWNER;
            lQueryTypeTableProp = model.PROP.SOURCE_QUERY_TABLE;
            lSqlQueryProp = model.PROP.SOURCE_SQL_QUERY;
        }

        // Remove columns if the source location property is cleared
        if ( pComponent.typeId === model.COMP_TYPE.REGION && _hasChangedEqualsTo( pComponent.getProperty( model.PROP.SOURCE_LOCATION ), pAction, pProperty, "" ) ) {
            [ model.COMP_TYPE.REGION_COLUMN, model.COMP_TYPE.REGION_TMPL_COLUMN ].forEach( typeId => _removeChildren( pComponent, typeId ) );
        }

        // When switching from Table or SQL Query based query type, we do want to default the SQL query or Function based on SQL Query
        // property with the old table/sql query
        if ( pProperty && pProperty.id === lQueryTypeProp ) {
            lQueryType = pComponent.getProperty( lQueryTypeProp ).getValue();
            if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {

                lProperty = pComponent.getProperty( model.PROP.SOURCE_LOCATION );
                if ( lProperty && lProperty.getValue() === "REMOTE" ) {
                    lProperty = pComponent.getProperty( model.PROP.SOURCE_REMOTE_DATABASE );
                    if ( !lProperty || lProperty.hasFeatures( "IS_ORACLE" ) ) {
                        lDatabaseType = "ORACLE";
                    } else {
                        lDatabaseType = "MYSQL";
                    }
                }

                if ( lQueryType === "TABLE" && [ "SQL", "FUNC_BODY_RETURNING_SQL" ].includes( pOldValue ) /* it's actually the new value */ ) {

                    lSqlColumns = pComponent.getProperty( lQueryTypeTableProp ).getColumns();
                    if ( lSqlColumns.length > 0 ) {

                        lProperty = pComponent.getProperty( model.PROP.SOURCE_INCLUDE_ROWID_COLUMN );
                        if ( lProperty && lProperty.getValue() === "Y" && lDatabaseType === "ORACLE" ) {
                            addSqlQuery( {
                                value:      "ROWID",
                                postfix:    ",\n",
                                identifier: true
                            } );
                        }
                        for ( let i = 0; i < lSqlColumns.length; i++ ) {
                            addSqlQuery( {
                                value:      lSqlColumns[i].name,
                                prefix:     ( lSqlQuery === "" ) ? "" : "       ",
                                postfix:    ( i < lSqlColumns.length - 1 ) ? ",\n" : "",
                                identifier: true
                            } );
                        }
                        lSqlQuery = "select " + lSqlQuery + "\n  from ";
                        addSqlQuery( {id: lQueryOwnerProp, postfix: ".", identifier: true} );
                        addSqlQuery( {id: lQueryTypeTableProp, identifier: true} );
                        addSqlQuery( {id: model.PROP.SOURCE_QUERY_WHERE, prefix: "\n where " } );
                    }
                    gSavedSourceSqlQuery = lSqlQuery + "";

                } else if ( lQueryType === "GRAPH" && [ "SQL", "FUNC_BODY_RETURNING_SQL" ].includes( pOldValue ) /* it's actually the new value */ ) {
                    //
                    // only generate a SQL query, if we have a Graph Name, Match Clause and Columns Clause
                    //
                    if (    propHasValue( model.PROP.SOURCE_GRAPH_NAME )
                         && propHasValue( model.PROP.SOURCE_GRAPH_MATCH_CLAUSE )
                         && propHasValue( model.PROP.SOURCE_GRAPH_COLUMNS_CLAUSE ) )
                    {
                        //
                        // Change a declarative Graph query to SQL or Function Returning SQL
                        //
                        lSqlQuery = "select *\n  from graph_table (\n           ";
                        addSqlQuery( {id: lQueryOwnerProp, postfix: ".", identifier: true} );
                        addSqlQuery( {id: model.PROP.SOURCE_GRAPH_NAME,  identifier: true} );
                        addSqlQuery( {id: model.PROP.SOURCE_GRAPH_MATCH_CLAUSE,    prefix: "\n           match " } );
                        addSqlQuery( {id: model.PROP.SOURCE_GRAPH_WHERE_CLAUSE,    prefix: "\n           where " } );

                        lGraphColumnsClause = pComponent.getProperty( model.PROP.SOURCE_GRAPH_COLUMNS_CLAUSE ).getValue();
                        if ( lGraphColumnsClause.trim().substr( 0, 1 ) === "(" ) {
                            addSqlQuery( {value: lGraphColumnsClause,  prefix: "\n           columns" } );
                        } else {
                            addSqlQuery( {value: lGraphColumnsClause,  prefix: "\n           columns( ", postfix: " )" } );
                        }
                        lSqlQuery = lSqlQuery + "\n       )";
                        addSqlQuery( {id: model.PROP.SOURCE_GRAPH_STATIC_ORDER_BY, prefix: "\n order by "} );

                        gSavedSourceSqlQuery = lSqlQuery + "";
                    }

                } else if ( lQueryType === "SQL" && pOldValue === "FUNC_BODY_RETURNING_SQL" /* it's actually the new value */ ) {
                    gSavedSourceSqlQuery = pComponent.getProperty( lSqlQueryProp ).getValue() + "";

                } else {
                    gSavedSourceSqlQuery = "";
                }
            } else if ( pAction === model.CALLBACK_ACTION.CHANGED && [ "TABLE", "GRAPH", "SQL" ].includes( pOldValue ) && gSavedSourceSqlQuery !== "" ) {
                if ( lQueryType === "SQL" ) {
                    _setPropertyValue( pComponent, lSqlQueryProp, gSavedSourceSqlQuery );
                } else if ( lQueryType === "FUNC_BODY_RETURNING_SQL" ) {
                    _setPropertyValue( pComponent, model.PROP.SOURCE_QUERY_PLSQL_FUNC_BODY_SQL, "return q'~\n" + gSavedSourceSqlQuery + "\n~';" );
                }
                gSavedSourceSqlQuery = "";
            }
        }

        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.SOURCE_INCLUDE_ROWID_COLUMN ) {
            // revalidate the TABLE property to refresh the columns
            lProperty = pComponent.getProperty( lQueryTypeTableProp );
            lProperty.setValue( lProperty.getValue(), true );
        }

        // Recreate Web Source Parameters only for REST Source regions. JSON Sources and Duality Views
        // don't use REGION_WS_PARAM children and must not enter the REST parameter creation path.
        lSourceTypeProp    = pComponent.getProperty( [ model.PROP.SOURCE_LOCATION, model.PROP.CHILD_SOURCE_LOCATION ] );
        lRegionTypeProp    = pComponent.getProperty( model.PROP.REGION_TYPE );
        if ( lSourceTypeProp?.getValue() === model.LOCATION.WEB_SOURCE ) {
            lProperty          = pComponent.getProperty( model.PROP.SOURCE_WEB_SRC_QUERY );
        }

        // for REST Sources, we need to determine whether we have array columns and whether local synchronization
        // tables exist.
        lArrayColumnProp   = pComponent.getProperty( model.PROP.SOURCE_WEB_SRC_ARRAY_COL );
        lArrayColumn       = ( lArrayColumnProp ? lArrayColumnProp.getValue() : "" );

        lUseLocalTableProp = pComponent.getProperty( model.PROP.WEB_SRC_USE_LOCAL_TABLE );

        if ( _hasChanged( lProperty,          pAction, pProperty, pOldValue ) ||
             _hasChanged( lSourceTypeProp,    pAction, pProperty, pOldValue ) ||
             _hasChanged( lArrayColumnProp,   pAction, pProperty, pOldValue ) ||
             _hasChanged( lUseLocalTableProp, pAction, pProperty, pOldValue ) ) {

            _removeChildren( pComponent, pCompWsParamComponentTypeId );

            // do we have a REST Source set for the region ...?
            if ( lProperty ) {

                lWebSrcModuleId = lProperty.getValue();
                if ( lWebSrcModuleId !== "" ) {

                    if ( !pComponent.getProperty( model.PROP.WEB_SRC_USE_LOCAL_TABLE ) ||
                         pComponent.getProperty( model.PROP.WEB_SRC_USE_LOCAL_TABLE ).getValue() === "N" )
                    {

                        // Add the REST source module level parameters first
                        addRestParametersToComponent( pComponent, lWebSrcModuleId, pCompWsParamComponentTypeId );

                        // And now add the parameters of the "Fetch Rows" web source operation, as all regions
                        // use the Fetch Rows operation.
                        addRestParametersToComponent( pComponent, lWebSrcModuleId, pCompWsParamComponentTypeId, {
                            dbOperation: "FETCH_COLLECTION",
                            arrayColumnId: lArrayColumn
                        } );

                        //
                        // now get the Region Attributes Component (child of the region component). For editable regions,
                        // handleRegionWebSrcParameters() adds parameters for those REST Source operations which have a
                        // database operation assigned.
                        if ( lRegionTypeProp ) {
                            if ( lRegionTypeProp.getValue() === "NATIVE_IG" ) {
                                lRegionPluginAttrs = pComponent.getChilds( model.COMP_TYPE.IG_ATTRIBUTES );
                            } else if ( lRegionTypeProp.getValue() === "NATIVE_FORM" ) {
                                lRegionPluginAttrs = pComponent.getChilds( model.COMP_TYPE.REGION_PLUGIN_ATTR );
                            }

                            if ( lRegionPluginAttrs && lRegionPluginAttrs[ 0 ] ) {
                                handleRegionWebSrcParameters( lRegionPluginAttrs[ 0 ] );
                            }
                        }
                    }
                }
            }
        }

        // Default Post Processing SQL query and Function returning SQL query with the columns of the web source data profile
        lProperty = pComponent.getProperty( [ model.PROP.SOURCE_POST_PROCESSING,
                                              model.PROP.DUALITYVIEW_SOURCE_POST_PROCESSING,
                                              model.PROP.JSONCOLL_SOURCE_POST_PROCESSING ] );

        if ( _hasChangedEqualsTo( lProperty, pAction, pProperty, "SQL", pOldValue ) || _hasChangedEqualsTo( lProperty, pAction, pProperty, "FUNC_BODY_RETURNING_SQL", pOldValue ) ) {
            let lPostProcForSourceType = lProperty.id,
                lPostProcForSourcePropId,
                lPostProcSqlQueryPropId,
                lPostProcPlsqlFuncBodyPropId;

            if ( lPostProcForSourceType === model.PROP.SOURCE_POST_PROCESSING ) {
                lPostProcForSourcePropId     = model.PROP.SOURCE_WEB_SRC_QUERY;
                lPostProcSqlQueryPropId      = model.PROP.POST_PROC_SQL_QUERY;
                lPostProcPlsqlFuncBodyPropId = model.PROP.POST_PROC_PLSQL_FUNC_BODY_SQL;

            } else if ( lPostProcForSourceType === model.PROP.DUALITYVIEW_SOURCE_POST_PROCESSING ) {
                lPostProcForSourcePropId     = model.PROP.SOURCE_DUALITY_VIEW;
                lPostProcSqlQueryPropId      = model.PROP.DUALITYVIEW_POST_PROC_SQL_QUERY;
                lPostProcPlsqlFuncBodyPropId = model.PROP.DUALITYVIEW_POST_PROC_PLSQL_FUNC_BODY_SQL;

            } else if ( lPostProcForSourceType === model.PROP.JSONCOLL_SOURCE_POST_PROCESSING ) {
                lPostProcForSourcePropId     = model.PROP.SOURCE_JSON_COLLECTION;
                lPostProcSqlQueryPropId      = model.PROP.JSONCOLL_POST_PROC_SQL_QUERY;
                lPostProcPlsqlFuncBodyPropId = model.PROP.JSONCOLL_POST_PROC_PLSQL_FUNC_BODY_SQL;
            }

            lSqlQuery = "";
            lSqlColumns = pComponent.getProperty( lPostProcForSourcePropId ).getColumns();
            if ( lSqlColumns.length > 0 ) {
                for ( let i = 0; i < lSqlColumns.length; i++ ) {
                    addSqlQuery( {
                        value:      lSqlColumns[i].name,
                        prefix:     ( i === 0 ) ? "" : "       ",
                        postfix:    ( i < lSqlColumns.length - 1 ) ? ",\n" : "",
                        identifier: true
                    } );
                }
                lSqlQuery = "select " + lSqlQuery + "\n  from #APEX$SOURCE_DATA#";
                if ( lProperty.getValue() === "SQL" ) {
                    _setPropertyValue( pComponent, lPostProcSqlQueryPropId, lSqlQuery );
                } else if ( lProperty.getValue() === "FUNC_BODY_RETURNING_SQL" ) {
                    _setPropertyValue( pComponent, lPostProcPlsqlFuncBodyPropId, "return q'~\n" + lSqlQuery + "\n~';" );
                }
            }
        } else if ( _hasChangedEqualsTo( lProperty, pAction, pProperty, "", pOldValue ) ) {
            // if the Post Processing property is set to null, re-set the source property to get back the original list of columns
            _revalidateProperty( pComponent, model.getSourceLocationProperty( pComponent ).id );
        }

        //
        // Force a change on the REST Source property when the chosen Array Column was changed,
        // in order to get a new validation and to re-fetch the columns.
        //
        if ( _hasChanged( pComponent.getProperty( model.PROP.SOURCE_WEB_SRC_ARRAY_COL ), pAction, pProperty, pOldValue ) ) {
            _revalidateProperty( pComponent, model.PROP.SOURCE_WEB_SRC_QUERY );
        }

        if ( _hasChanged( pComponent.getProperty( model.PROP.SOURCE_DUALITY_VIEW_ARRAY_COL ), pAction, pProperty, pOldValue ) ) {
            _revalidateProperty( pComponent, model.PROP.SOURCE_DUALITY_VIEW );
        }

        if ( _hasChanged( pComponent.getProperty( model.PROP.SOURCE_JSON_COLLECTION_ARRAY_COL ), pAction, pProperty, pOldValue ) ) {
            _revalidateProperty( pComponent, model.PROP.SOURCE_JSON_COLLECTION );
        }


    } // sourceLocationHandling


    function region( pAction, pProperty, pOldValue ) {

        let lRegionColumns;

        syncStaticId( this, pAction, pProperty );

        // Slot handling when parent region changes
        _setSlot( {
            componentTypeId: model.COMP_TYPE.REGION,
            action: pAction,
            property: pProperty,
            oldRegionId: pOldValue,
            component: this
        } );

        // Don't show sub regions in a "Region Display Selector"
        if (  this.getProperty( model.PROP.PARENT_REGION ).getValue() !== ""
            && (  pAction === model.CALLBACK_ACTION.CREATED
               || ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.PARENT_REGION && pOldValue === "" )
               )
           )
        {
            _setPropertyValue( this, model.PROP.REGION_DISPLAY_SELECTOR, "N" );
        }

        // Reset the "Master Column" property of all IG columns if the "Master Region" property gets changed
        if ( pAction === model.CALLBACK_ACTION.CHANGED && pProperty.id === model.PROP.MASTER_REGION && pOldValue !== "" ) {
            lRegionColumns = this.getChilds( model.COMP_TYPE.IG_COLUMN, {
                filterFunction: function() {
                    var lMasterColumnProp = this.getProperty( model.PROP.MASTER_COLUMN );
                    return ( lMasterColumnProp && lMasterColumnProp.getValue() !== "" );
                }
            } );
            for ( let i = 0; i < lRegionColumns.length; i++ ) {
                _setPropertyValue( lRegionColumns[ i ], model.PROP.MASTER_COLUMN, "" );
            }
        }


        return sourceLocationHandling( pAction, this, pProperty, pOldValue, model.COMP_TYPE.REGION_WS_PARAM );

    } // region


    function printAttributes( pAction, pProperty ) {

        var DECIMAL_SEP = locale.getDecimalSeparator(),
            PAGE_SIZES = {
                "LETTER": {
                    units:  "INCHES",
                    width:  "8" + DECIMAL_SEP + "5",
                    height: "11"
                },
                "LEGAL": {
                    units:  "INCHES",
                    width:  "8" + DECIMAL_SEP + "5",
                    height: "14"
                },
                "TABLOID": {
                    units:  "INCHES",
                    width:  "8.5",
                    height: "17"
                },
                "A4": {
                    units:  "MILLIMETERS",
                    width:  "210",
                    height: "297"
                },
                "A3": {
                    units:  "MILLIMETERS",
                    width:  "297",
                    height: "420"
                }
            };

        var lPageSize,
            lWidth,
            lHeight;

        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            if ( $.inArray( model.getPrimaryLanguage(), [ "en", "en-us", "en-ca", "fr-ca" ] ) !== -1 ) {
                lPageSize = "LETTER";
            } else {
                lPageSize = "A4";
            }
            _setPropertyValue( this, model.PROP.PRINT_PAGE_SIZE, lPageSize );

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            if ( pProperty.id === model.PROP.PRINT_PAGE_SIZE && pProperty.getValue() !== "CUSTOM" ) {
                // Has the page size been changed changed?

                lPageSize = PAGE_SIZES[ pProperty.getValue() ];

                _setPropertyValue( this, model.PROP.PRINT_UNITS, lPageSize.units );
                if ( this.getProperty( model.PROP.PRINT_ORIENTATION ).getValue() === "VERTICAL" ) {
                    _setPropertyValue( this, model.PROP.PRINT_WIDTH,  lPageSize.width );
                    _setPropertyValue( this, model.PROP.PRINT_HEIGHT, lPageSize.height );
                } else {
                    _setPropertyValue( this, model.PROP.PRINT_WIDTH,  lPageSize.height );
                    _setPropertyValue( this, model.PROP.PRINT_HEIGHT, lPageSize.width );
                }

            } else if ( pProperty.id === model.PROP.PRINT_ORIENTATION ) {

                // Swap existing width and height values
                lWidth  = this.getProperty( model.PROP.PRINT_WIDTH  ).getValue();
                lHeight = this.getProperty( model.PROP.PRINT_HEIGHT ).getValue();

                _setPropertyValue( this, model.PROP.PRINT_WIDTH,  lHeight );
                _setPropertyValue( this, model.PROP.PRINT_HEIGHT, lWidth );

            }
        }
    } // printAttributes


    function validateDaButton( pButtonId ) {

        var lButton,
            lButtonTemplateId;

        // Make sure that the button template contains the #BUTTON_ID# or #DOM_ID# placeholder or that the button has
        // specified id="xxx" in the custom attributes. Without an id tag for a button, dynamic action will not fire
        if ( pButtonId !== "" ) {
            lButton           = model.getComponents( model.COMP_TYPE.BUTTON, { id: pButtonId } )[ 0 ];
            lButtonTemplateId = lButton.getProperty( model.PROP.BUTTON_TEMPLATE ).getValue();
            if (  lButtonTemplateId !== ""
                && !model.getButtonTemplates()[ lButtonTemplateId ].hasButtonId
                && !/id=/.test( lButton.getProperty( model.PROP.CUSTOM_ATTRIBUTES ).getValue() ) )
            {
                return { error: lang.formatMessage( "PD.PE.BUTTON_NO_ID_ERROR" ) }; // todo replace with format and rename PD.PE.BUTTON_NO_ID_ERROR to MODEL.CALLBACK.BUTTON...
            }
        }

    } // validateDaButton

    function validateTriggeredActions() {
        const c = model.COMP_TYPE,
              p = model.PROP;
        let parentType, propertyType;
        // since we're not sure which triggered action this is we need to validate each type which will check the parent type
        switch ( this.typeId ) {
            case c.REGION_ACTION_MENU_ENTRY_ACTION:
                parentType = c.REGION_ACTION_MENU_ENTRY;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            case c.REGION_ACTION_BUTTON_ACTION:
                parentType = c.REGION_ACTION;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            case c.IR_COL_ACTION_MENU_ENTRY_ACTION:
                parentType = c.IR_COL_ACTION_MENU_ENTRY;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            case c.IR_COL_ACTION_BUTTON_ACTION:
                parentType = c.IR_COLUMN_ACTION;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            case c.PAGE_BUTTON_ACTION:
                parentType = c.BUTTON;
                propertyType = p.BUTTON_ACTION;
                break;
            case c.BUTTON_ACTION_MENU_ENTRY_ACTION:
                parentType = c.BUTTON_MENU_ENTRY;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            case c.CARD_BUTTON_ACTION:
                parentType = c.CARD_ACTION;
                propertyType = p.ACTION_LINK_TARGET_TYPE;
                break;
            default:
                // not a valid action so lets ensure that no parent is found
                parentType = "-1";
        }
        const parentComponent = this.getParent( parentType );
        if ( parentComponent && !parentComponent._deleteInProgress ) {
            // note this will trigger the change event to fire which will automatically add a dynamic action if none exist
            try {
                _revalidateProperty( parentComponent, propertyType );
            } catch ( e ) {
                // an exception will be raised in command history undo since there is no transaction
                // we can safely ignore this error
            }
        }
    }

    function validateAlltriggeredActions() {
        const self = this,
              c = model.COMP_TYPE;

        const triggeredActionTypes = [ c.REGION_ACTION_MENU_ENTRY_ACTION,
                                       c.REGION_ACTION_BUTTON_ACTION,
                                       c.IR_COL_ACTION_MENU_ENTRY_ACTION,
                                       c.IR_COL_ACTION_BUTTON_ACTION,
                                       c.PAGE_BUTTON_ACTION,
                                       c.BUTTON_ACTION_MENU_ENTRY_ACTION,
                                       c.CARD_BUTTON_ACTION ];

        triggeredActionTypes.forEach( ( compType ) => {
            let triggeredActions;
            try {
                triggeredActions = self.getChildrenUntil( compType );
            } catch ( e ) {
                // ignore components that are not valid children types
                triggeredActions = [];
            }
            if ( Array.isArray( triggeredActions ) ) {
                triggeredActions.forEach( ( triggerAction ) => {
                    validateTriggeredActions.call( triggerAction );
                } );
            }
        } );
    }

    function primaryKeyIsSet( parentComp, compType ) {
        // if we can't locate the parent region then we will assume there are no columns to check
        if ( !parentComp ) {
            return true;
        }
        if ( compType === model.COMP_TYPE.CARD ) {
            return ( model.getComponents( compType, {
                id:   parentComp.id,
                properties: [{ id: model.PROP.CARD_PK_COLUMN1, value: new RegExp( ".+" ) }]
            } ).length > 0 );
        } else {
            // it's possible that this might be a partial with no data source, so we need to check the location to make sure it's not
            if ( parentComp.getPropertyValue( model.PROP.SOURCE_LOCATION ) || parentComp.typeId === model.COMP_TYPE.IR_ATTRIBUTES ) {
                return ( model.getComponents( compType, {
                    parentId: parentComp.id,
                    properties: [{ id: model.PROP.IS_PRIMARY_KEY, value: "Y" }]
                } ).length > 0 );
            }
        }
        return true;
    }

    function hasTriggeredActions() {
        const self = this, c = model.COMP_TYPE,
              performCheck = ( compType ) => {
                try {
                    return self.getChildrenUntil( compType ).length > 0;
                } catch( e ) {
                    // ignore components that are not valid children types
                    return false;
                }
              };

        return performCheck( c.REGION_ACTION_MENU_ENTRY_ACTION ) ||
               performCheck( c.REGION_ACTION_BUTTON_ACTION )     ||
               performCheck( c.IR_COL_ACTION_MENU_ENTRY_ACTION ) ||
               performCheck( c.IR_COL_ACTION_BUTTON_ACTION )     ||
               performCheck( c.PAGE_BUTTON_ACTION )              ||
               performCheck( c.BUTTON_ACTION_MENU_ENTRY_ACTION ) ||
               performCheck( c.CARD_BUTTON_ACTION );
    }

    function dynamicActionHasNoWhenCondition( pDynamicAction ) {

        var lWhenCondition;

        if ( pDynamicAction.getProperty( model.PROP.JS_CONDITION ) ) {

            lWhenCondition = pDynamicAction.getProperty( model.PROP.JS_CONDITION );

        } else if ( pDynamicAction.getProperty( model.PROP.JS_CONDITION_WHEN_IG ) ) {

            lWhenCondition = pDynamicAction.getProperty( model.PROP.JS_CONDITION_WHEN_IG );

        }

        return ( !lWhenCondition || lWhenCondition.getValue() === "" );

    } // dynamicActionHasNoWhenCondition


    function dynamicActionEvent( pAction, pProperty, pValue ) {

        syncStaticId( this, pAction, pProperty );

        // If the dynamic action sets the when condition to null, remove the corresponding FALSE actions
        if ( pAction === model.CALLBACK_ACTION.CHANGED && $.inArray( pProperty.id, [ model.PROP.JS_CONDITION, model.PROP.JS_CONDITION_WHEN_IG ] ) !== -1 ) {

            const lFalseActions = this.getChilds( model.COMP_TYPE.DA_ACTION, {
                properties: [{
                    id: model.PROP.FIRE_WHEN_EVENT_RESULT_IS,
                    value: "FALSE"
                }]
            } );

            if ( dynamicActionHasNoWhenCondition( this ) ) {

                // When removing a condition, remove the children that have a FALSE event result
                _removeComponents( lFalseActions );

            } else {

                // When setting a condition, set 'fire when result' action property to itself, to get rid of any false action errors
                for ( let i = 0; i < lFalseActions.length; i++ ) {
                    const lFalseActionResultProperty = lFalseActions[ i ].getProperty( model.PROP.FIRE_WHEN_EVENT_RESULT_IS );
                    lFalseActionResultProperty.setValue( lFalseActionResultProperty.getValue() );
                }
            }
        }


        // If client-side condition type changes to a type that requires and item or column be defined, or when > item or when > column changes
        // then we default this to the current when > item / column.
        if ( pAction === model.CALLBACK_ACTION.CREATED
             || ( pAction === model.CALLBACK_ACTION.CHANGED
                && [ model.PROP.JS_CONDITION, model.PROP.JS_CONDITION_WHEN_IG, model.PROP.WHEN_ITEMS, model.PROP.WHEN_COLUMNS ].includes( pProperty.id ) )
        ) {
            let lWhenItemsProperty     = this.getProperty( model.PROP.WHEN_ITEMS );
            let lConditionItemProperty = this.getProperty( model.PROP.JS_CONDITION_ITEM );
            let lIgRegionProperty = this.getProperty( [ model.PROP.WHEN_IG_REGION, model.PROP.WHEN_REGION ] );
            if ( lIgRegionProperty?.getValue() !== "" ) {
                lWhenItemsProperty     = this.getProperty( model.PROP.WHEN_COLUMNS );
                lConditionItemProperty = this.getProperty( model.PROP.JS_CONDITION_COLUMN_WHEN_IG );
            }

            if ( lWhenItemsProperty && lConditionItemProperty ) {

                /*
                 * We update the condition item value when any of the following are true:
                 * 1. If the condition item is currently null
                 * 2. If the when > item has changed, and the condition item value was the same as the old when > item value
                 */
                if (  lConditionItemProperty.getValue() === ""
                   || ( pProperty.id === lWhenItemsProperty.id && lConditionItemProperty.getValue() === pValue.split( "," )[ 0 ] ) /* old when item may be multiple, use first item */
                   )
                {
                    // Set the condition item value to the when item, or the 1st of the when items if there are multiple
                    lConditionItemProperty.setValue( lWhenItemsProperty.getValue().split( "," )[ 0 ] );
                }
            }
        }

        // If the dynamic action event is associated to a button, make sure that the button action is set to "Defined by Dynamic Action".
        const lWhenButtonProperty = this.getProperty( model.PROP.WHEN_BUTTON );
        if ( _hasChanged( lWhenButtonProperty, pAction, pProperty ) ) {
            if (  !/^apex/.test( this.getProperty( model.PROP.EVENT ).getValue() ) // apex events are listening event, no need to change the button execution
                && lWhenButtonProperty
                && !lWhenButtonProperty.getMetaData().isReadOnly
                && lWhenButtonProperty.getValue() !== "" )
            {
                const lButtonAction = model.getComponents( model.COMP_TYPE.BUTTON, { id: lWhenButtonProperty.getValue() } )[ 0 ].getProperty( model.PROP.BUTTON_ACTION );

                if ( lButtonAction && lButtonAction.getValue() !== "DEFINED_BY_DA" ) {
                    lButtonAction.setValue( "DEFINED_BY_DA" );
                }
            }

        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE && pProperty.id === model.PROP.WHEN_BUTTON ) {

            return validateDaButton( pValue );

        }

        // If the dynamic action event Execution Type property is Debounce or Throttle, set the value of the Immediate property accordingly
        const lExecutionTypeProperty = this.getProperty( model.PROP.DA_EXECUTION_TYPE );
        if ( _hasChangedEqualsTo( lExecutionTypeProperty, pAction, pProperty, "DEBOUNCE" ) ) {
            _setPropertyValue( this, model.PROP.DA_EXECUTION_IMMEDIATE, "N" );
        } else if ( _hasChangedEqualsTo( lExecutionTypeProperty, pAction, pProperty, "THROTTLE" ) ) {
            _setPropertyValue( this, model.PROP.DA_EXECUTION_IMMEDIATE, "Y" );
        }
    } // dynamicActionEvent


    function dynamicActionAction( pAction, pProperty, pValue ) {

        const ACTION_TYPE_PROPERTY = this.getProperty( model.PROP.DA_ACTION_TYPE );

        let igRegionProperty = this.getParent()?.getProperty( [ model.PROP.WHEN_IG_REGION, model.PROP.WHEN_REGION ] );
        let affectedTypeProperty = this.getProperty( model.PROP.AFFECTED_TYPE );


        if ( pAction === model.CALLBACK_ACTION.CREATED ) {

            // Default "Affected Elements - Type" to ITEM or COLUMN depending if it's an IG region and it's supported by the action
            if ( affectedTypeProperty && affectedTypeProperty.getValue() === "" && ACTION_TYPE_PROPERTY.getValue() !== "NATIVE_JAVASCRIPT_CODE" ) {
                if ( !igRegionProperty || igRegionProperty.getValue() === "" ) {
                    affectedTypeProperty.setValue( "ITEM" );
                } else {
                    affectedTypeProperty.setValue( "COLUMN" );
                }
            }

        } else if ( pAction === model.CALLBACK_ACTION.CHANGED ) {

            // When the action's event changes, if the action's event result is false, check if the parent DA
            // has a condition, and if not set the event result property to TRUE.
            if ( pProperty.id === model.PROP.DA_EVENT ) {

                if ( this.getProperty( model.PROP.FIRE_WHEN_EVENT_RESULT_IS ).getValue() === "FALSE" ) {

                    if ( dynamicActionHasNoWhenCondition( this.getParent() ) ) {

                        _setPropertyValue( this, model.PROP.FIRE_WHEN_EVENT_RESULT_IS, "TRUE" );

                    }
                }
            }

        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {

            if ( pProperty.id === model.PROP.AFFECTED_BUTTON ) {

                return validateDaButton( pValue );

            }

        }

        // If we switch to "Execute JavaScript code", most of the time we actually don't want to type in an Affected Element
        if ( _hasChangedEqualsTo( ACTION_TYPE_PROPERTY, pAction, pProperty, "NATIVE_JAVASCRIPT_CODE" ) ) {

            affectedTypeProperty.setValue( "" );
        }

        syncStaticId( this, pAction, pProperty, model.getDisplayProperty( this, true )  );

    } // dynamicActionAction

    function invokeApiPlugin( action, property, value, validationInfo ) {

        let self = this,
            typeProperty       = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "type" ).id ),
            methodProperty     = self.getProperty( [
                                     model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "package_method" ).id,
                                     model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "standalone_method" ).id ] ),
            restSourceProperty = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "rest_source_id" ).id ),
            restOperProperty   = self.getProperty( model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "rest_operation_id" ).id ),
            paramCompType,
            wsParamCompType;

        function removeUnusedParameters( parameters, parameterComponents ) {

            let i, j,
                found,
                type,
                name;

            // Remove all parameters which don't exist anymore or where the type has changed
            for ( i = 0; i < parameterComponents.length; i++ ) {
                found = false;
                type  = parameterComponents[ i ].getProperty( model.PROP.INVOKE_API_PARAM_TYPE ).getValue();
                name  = parameterComponents[ i ].getProperty( model.PROP.NAME )?.getValue().toLowerCase();

                for ( j = 0; j < parameters.length && !found; j++ ) {
                    if (    parameters[ j ].type === type
                         && parameters[ j ].name?.toLowerCase() === name ) {
                        parameters[ j ].parameterComponent = parameterComponents[ i ];
                        found = true;
                        break;
                    }
                }

                if ( !found ) {
                    parameterComponents[ i ].remove();
                }
            }
        } // removeUnusedParameters


        function addUpdateParameters( parameters, parameterComponents, pCompTypeId ) {

            let i,
                previousComponent;

            // New parameters should be added after the existing parameters
            if ( parameterComponents.length > 0 ) {
                previousComponent = parameterComponents[ parameterComponents.length - 1 ];
            }

            // Add all parameters where we don't have a parameter component yet or update where something has changed
            for ( i = 0; i < parameters.length; i++ ) {

                if ( parameters[ i ].parameterComponent ) {

                    // Parameter with that name does already exist, set the key properties of the parameter declaration again
                    let parameterComponent = parameters[ i ].parameterComponent;
                    if ( parameters[ i ].type === "PARAMETER" ) {
                        _setPropertyValue( parameterComponent, model.PROP.API_DIRECTION, parameters[ i ].direction );
                        _setPropertyValue( parameterComponent, model.PROP.HAS_DEFAULT,   parameters[ i ].hasDefault ? "Y" : "N" );
                    }
                    if ( parameters[ i ].isCustomDataType ) {
                        _setPropertyValue( parameterComponent, model.PROP.API_DATA_TYPE, "CUSTOM" );
                        _setPropertyValue( parameterComponent, model.PROP.API_CUSTOM_DATA_TYPE, parameters[ i ].dataType );
                    } else {
                        _setPropertyValue( parameterComponent, model.PROP.API_DATA_TYPE, parameters[ i ].dataType );
                    }

                } else {

                    // If the API contains a new parameter, add it at the end of the existing parameters.
                    previousComponent = new model.Component( {
                        previousComponent: previousComponent,
                        typeId:            pCompTypeId,
                        parentId:          self.id,
                        values:            [
                            {
                                id: model.PROP.INVOKE_API_PARAM_TYPE,
                                value: parameters[ i ].type
                            },
                            ...( parameters[ i ].type === "PARAMETER" ? [
                                {
                                    // We just need the name, the other properties will be set by the processInvokeApiParam callback
                                    id:    model.PROP.NAME,
                                    value: parameters[ i ].name
                                }]
                                : [] )]
                    } );
                }
            }
        } // addUpdateParameters
        if ( this.typeId === model.COMP_TYPE.WORKFLOW_ACTIVITY ) {
            paramCompType   = model.COMP_TYPE.WF_ACTIVITY_API_PARAM;
            wsParamCompType = model.COMP_TYPE.WF_ACTIVITY_WS_PARAM;
        }
        else {
            paramCompType   = model.COMP_TYPE.PAGE_PROC_API_PARAM;
            wsParamCompType = model.COMP_TYPE.PAGE_PROC_WS_PARAM;
        }
        if ( action === model.CALLBACK_ACTION.VALIDATE && methodProperty && methodProperty.id === property.id ) {

            // Show a warning if the function/procedure is overloaded
            if ( validationInfo.parameters && validationInfo.parameters.length > 1 ) {
                return { warning: format( "INVOKE_API.OVERLOADED_WARNING", value ) };
            }

        } else if ( action === model.CALLBACK_ACTION.REMOVED ) {

            _removeChildren( self, paramCompType );
            _removeChildren( self, wsParamCompType );

        } else {

            if ( _hasChanged( typeProperty, action, property ) ) {
                _removeChildren( self, paramCompType );
                _removeChildren( self, wsParamCompType );
            }

            // synchronize the parameters if the method has been changed
            if ( _hasChanged( methodProperty, action, property ) ) {

                let parameters          = methodProperty.getParameters(),
                    parameterComponents = self.getChilds( paramCompType );

                // Only if we have a valid method which has returned parameters, we try to add/modify the parameters
                if ( parameters.length > 0 ) {

                    // Remove all parameters which don't exist anymore
                    removeUnusedParameters( parameters, parameterComponents );

                    // Add or Update parameters
                    addUpdateParameters( parameters, parameterComponents, paramCompType );
                }

            } else {
                let moduleChanged    = _hasChanged( restSourceProperty, action, property ),
                    operationChanged = _hasChanged( restOperProperty, action, property ),
                    pageProcessWsParams, operationParam;

                if ( moduleChanged ) {
                    //
                    // If the REST Module changed, we cannot reuse any parameter. Even if it has the
                    // same name, the meaning and IN, OUT or IN/OUT semantics could be totally different.
                    // So we're removing everything and re-create anew.
                    //
                    _removeChildren( self, wsParamCompType );

                    addRestParametersToComponent( self, restSourceProperty.getValue(), wsParamCompType );

                } else if ( operationChanged ) {
                    //
                    // if only the operation changed, we can keep the module parameters, but
                    // we will delete and recreate operation parameters. Unlike PL/SQL, the
                    // meta data for IN, OUT or IN/OUT is defined at the Shared Component
                    // level; and semantics can change between operations, even if the
                    // parameter name is the same.
                    //
                    pageProcessWsParams = self.getChilds( wsParamCompType );

                    for ( let i = 0; i < pageProcessWsParams.length; i++ ) {

                        // is the parameter an operation parameter ...?
                        operationParam  = model.getComponents( model.COMP_TYPE.WEB_SRC_MOD_PARAM, {
                            id: pageProcessWsParams[ i ].getProperty( model.PROP.WEB_SRC_PARAM ).getValue(),
                            filterFunction: function(){
                                return this.getPropertyValue( model.PROP.WEB_SRC_OPERATION ) !== "";
                            }
                        } );

                        // ... delete it.
                        if ( operationParam[ 0 ] ) {
                            _removeComponents ( [ pageProcessWsParams[ i ] ] );
                        }
                    }

                    //
                    // add the Parameters for the chosen REST Operation to the component.
                    addRestParametersToComponent( self, restOperProperty.getValue(), wsParamCompType,
                        model.getComponents(
                            model.COMP_TYPE.WEB_SRC_OPERATION,
                            { id: restOperProperty.getValue() } )[0] );
                }
            }
        }

    } // invokeApiPlugin

    function executionChainPlugin( action, property, value ) {
        const allowedBackgroundPoints = [ "ON_SUBMIT_BEFORE_COMPUTATION", "AFTER_SUBMIT" ];

        let self                    = this,
            childProcessComponents,
            processPointProp        = self.getProperty( model.PROP.PROCESS_POINT ),
            processNameProp,
            executeBackgroundPropId = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.EXECUTION_CHAIN, "run_in_background" ).id,
            rootProcess,
            processPoint;

        function getRootProcessComponent( pComponent ) {
            let parentProcessProp = pComponent.getProperty( model.PROP.PARENT_PROCESS ),
                parentProcessComp;

            if ( parentProcessProp && parentProcessProp.getValue() !== "" ) {
                parentProcessComp = model.getComponents( model.COMP_TYPE.PAGE_PROCESS,
                                                         { id: parentProcessProp.getValue() } )[ 0 ];

                if ( parentProcessComp ) {
                    return getRootProcessComponent( parentProcessComp );
                }
            }
            return pComponent;
        }
        function getChildProcesses( pComponent, pFollowHierarchy ) {
            let foundComponents = [];

            function addChildComponents( pForComponent ) {
                let childComponents;

                if ( pForComponent.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue() === PROCESS_TYPE.EXECUTION_CHAIN ) {
                    childComponents = model.getComponents( model.COMP_TYPE.PAGE_PROCESS,
                                                           { properties: [{
                                                                 id:    model.PROP.PARENT_PROCESS,
                                                                 value: pForComponent.id } ]
                                                           } );

                    for ( let i = 0; i < childComponents.length; i++ ) {
                        foundComponents.push( childComponents[ i ] );
                        if ( pFollowHierarchy ) {
                            addChildComponents( childComponents[ i ] );
                        }
                    }
                }
            }

            addChildComponents( pComponent );
            return foundComponents;
        }

        function disableBackgroundForAllChilds( pComponent ) {

            //
            // disable execution in background
            //
            _setPropertyValue( pComponent, executeBackgroundPropId, "N" );

            //
            // get all child processes of this page process
            //
            childProcessComponents = getChildProcesses( pComponent, false );

            //
            // walk through all child processes, and for processes of the EXECUTION CHAIN type,
            // this function calls itself recursively to disable background processing also
            // for all child processes.
            //
            for ( let i = 0; i < childProcessComponents.length; i++ ) {
                if ( childProcessComponents[ i ].getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue() === PROCESS_TYPE.EXECUTION_CHAIN ) {
                    disableBackgroundForAllChilds( childProcessComponents[ i ] );
                }
            }
        }

        if (    action === model.CALLBACK_ACTION.CHANGED
             && property.id === model.PROP.PROCESS_POINT )
        {
            //
            // if the process point does not support background execution, disable it
            // and also for all child processes.
            //
            if ( !( allowedBackgroundPoints.includes( processPointProp.getValue() ) ) ) {
                disableBackgroundForAllChilds( self );
            }
        }

        if (    action      === model.CALLBACK_ACTION.VALIDATE
             && property.id === executeBackgroundPropId
             && value       === "Y" )
        {

            //
            // let's check whether the root process has a process point which does not
            // support background execution, and raise an error if that is the case.
            //
            rootProcess = getRootProcessComponent( self );
            processPointProp = rootProcess.getProperty( model.PROP.PROCESS_POINT );
            processNameProp  = rootProcess.getProperty( model.PROP.NAME );

            if ( processPointProp ) {
                processPoint = processPointProp.getValue();
                if ( !allowedBackgroundPoints.includes( processPoint ) ) {
                    return { error: format( "PROCESS_BACKGROUND.PAGE_RENDERING_NOT_SUPPORTED", processNameProp.getValue() ) };
                }
            }
        }
    } // executionChainPlugin


    function processInvokeApiParam( action, property, value ) {

        const VALUE_TYPE = {
                  API_DEFAULT: "API_DEFAULT",
                  ITEM:        "ITEM",
                  STATIC:      "STATIC"
              };

        let self = this,
            typeProperty         = self.getProperty( model.PROP.INVOKE_API_PARAM_TYPE ),
            nameProperty         = self.getProperty( model.PROP.NAME ),
            directionProperty    = self.getProperty( model.PROP.API_DIRECTION ),
            dataTypeProperty     = self.getProperty( model.PROP.API_DATA_TYPE ),
            ignoreOutputProperty = self.getProperty( model.PROP.IGNORE_OUTPUT );

        if ( action === model.CALLBACK_ACTION.CREATED || _hasChanged( nameProperty, action, property, value ) ) {

            let parentComponent = self.getParent(),
                methodProperty = parentComponent.getProperty( [
                    model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "package_method" ).id,
                    model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_API, "standalone_method" ).id ] ),
                editRegionId = "",
                editRegion,
                editRegionType = "",
                parameters = methodProperty.getParameters(),
                type = typeProperty.getValue(),
                name,
                i;
            if ( type === "PARAMETER" ) {
                name = nameProperty.getValue().toLowerCase();
            }
            if ( parentComponent.typeId !== model.COMP_TYPE.WORKFLOW_ACTIVITY ) {
                editRegionId = parentComponent.getPropertyValue( model.PROP.PROCESS_REGION );
            }
            if ( editRegionId !== "" ) {
                editRegion     = pe.getComponents( pe.COMP_TYPE.REGION, { id: editRegionId }, false )[ 0 ];
                editRegionType = editRegion.getProperty( pe.PROP.REGION_TYPE ).getValue();
            }

            // When a parameter is created, we try to look it up in the parameters of that method and
            // default as many properties as possible
            for ( i = 0; i < parameters.length; i++ ) {
                if (    parameters[ i ].type === type
                     && parameters[ i ].name?.toLowerCase() === name ) {
                    if ( parameters[ i ].type === "PARAMETER" ) {
                        directionProperty.setValue( parameters[ i ].direction );
                        _setPropertyValue( self, model.PROP.HAS_DEFAULT, parameters[ i ].hasDefault ? "Y" : "N" );
                    }

                    if ( parameters[ i ].isCustomDataType ) {

                        dataTypeProperty.setValue( "CUSTOM" );
                        _setPropertyValue( self, model.PROP.API_CUSTOM_DATA_TYPE, parameters[ i ].dataType );
                        if ( parameters[ i ].hasDefault ) {
                            _setPropertyValue( self, model.PROP.API_VALUE_TYPE, VALUE_TYPE.API_DEFAULT );
                        }

                    } else {

                        // Standard data type
                        dataTypeProperty.setValue( parameters[ i ].dataType );

                        if ( parameters[ i ].dataType !== "BLOB" ) {

                            let namePropertyId,
                                items = [];
                            if ( parameters[ i ].type === "PARAMETER" ) {
                                if ( editRegionType === REGION_TYPE.IG ) {
                                    // search for a column that matches the parameter name
                                    namePropertyId = model.PROP.COLUMN_NAME;
                                    items = editRegion.getChilds( model.COMP_TYPE.IG_COLUMN, {
                                        properties: [{
                                            id:    namePropertyId,
                                            value: parameters[ i ].name.replace( /^p_|pi_|po_/, "" ).toUpperCase()
                                        }]} );
                                }
                                if ( items.length === 0 ) {
                                    // search for a page item that matches the parameter name
                                    namePropertyId = model.PROP.ITEM_NAME;
                                    items = model.getComponents( model.COMP_TYPE.PAGE_ITEM, {
                                        properties: [{
                                            id:    namePropertyId,
                                            value: "P" + model.getCurrentPageId() + "_" + parameters[ i ].name.replace( /^p_|pi_|po_/, "" ).toUpperCase()
                                        }]} );
                                }
                            }
                            if ( items.length > 0 ) {
                                _setPropertyValue( self, model.PROP.API_VALUE_TYPE, VALUE_TYPE.ITEM );
                                _setPropertyValue( self, model.PROP.VALUE_ITEM, items[ 0 ].getProperty( namePropertyId ).getValue() );

                            } else if ( parameters[ i ].hasDefault ) {
                                _setPropertyValue( self, model.PROP.API_VALUE_TYPE, VALUE_TYPE.API_DEFAULT );

                            } else if ( parameters[ i ].dataType === "BOOLEAN" ) {
                                 // It's more likely that a boolean is just a programmatic flag to enable/disable something
                                _setPropertyValue( self, model.PROP.API_VALUE_TYPE, VALUE_TYPE.STATIC );
                            }

                        } else {

                            // Special handling for BLOB, because we don't support ITEM binding
                            if ( parameters[ i ].hasDefault ) {
                                _setPropertyValue( self, model.PROP.API_VALUE_TYPE, VALUE_TYPE.API_DEFAULT );
                            }
                        }
                    }
                }
            }
        }

        const valueType = self.getPropertyValue( model.PROP.API_VALUE_TYPE );
        // set the default "value-type" if needed
        if ( !valueType
            && ( _hasChanged( directionProperty, action, property )
                 || _hasChanged( dataTypeProperty, action, property )
                 || _hasChanged( typeProperty, action, property )
                 || _hasChanged( ignoreOutputProperty, action, property ) )
        ) {
            let direction    = typeProperty.getValue() === "FUNCTION_RESULT" ? "OUT" : directionProperty.getValue(),
                dataType     = dataTypeProperty.getValue(),
                ignoreOutput = ignoreOutputProperty ? ignoreOutputProperty.getValue() : "",
                defaultValue;

            if ( self.getPropertyValue( model.PROP.HAS_DEFAULT ) === "Y" ) {
                defaultValue = "API_DEFAULT";
            } else if ( [ "IN", "IN_OUT" ].includes( direction ) && dataType === "BLOB" ) {
                defaultValue = "SQL_QUERY";
            } else if ( [ "IN", "IN_OUT" ].includes( direction ) && dataType === "CUSTOM" ) {
                defaultValue = "FUNCTION_BODY";
            } else if ( direction === "IN" ) {
                defaultValue = "ITEM";
            } else if ( direction === "OUT" && [ "BLOB", "CUSTOM" ].includes( dataType ) ) {
                defaultValue = "";
            } else if ( direction === "OUT" && ignoreOutput === "Y" ) {
                defaultValue = "";
            } else if ( direction === "IN_OUT" && ignoreOutput === "Y" ) {
                defaultValue = "ITEM";
            }

            _setPropertyValue( self, model.PROP.API_VALUE_TYPE, defaultValue );
        }

    } // processInvokeApiParam

    function pageProcess( action, property, value ) {
        const self = this;
        let pointProperty         = self.getProperty( model.PROP.PROCESS_POINT ),
            typeProperty          = self.getProperty( model.PROP.PAGE_PROCESS_TYPE ),
            parentProcessProperty = self.getProperty( model.PROP.PARENT_PROCESS );

        syncStaticId( self, action, property );

        function findExecutionPoint( pProcessId ) {
            let processComp = model.getComponents( model.COMP_TYPE.PAGE_PROCESS, { id: pProcessId } )[ 0 ],
                parentProcessProp = processComp.getProperty( model.PROP.PARENT_PROCESS ),
                rootProcessPoint;

            if ( parentProcessProp && parentProcessProp.getValue() !== "" ) {
                //
                // there is a parent process ID, so walk up the hierarchy
                //
                rootProcessPoint = findExecutionPoint( parentProcessProp.getValue() );

            } else {

                //
                // there is no grant parent process ID, so let's get and return the execution point.
                //
                if ( processComp.getProperty( model.PROP.PROCESS_POINT ) ) {
                    rootProcessPoint = processComp.getProperty( model.PROP.PROCESS_POINT ).getValue();
                } else {
                    // fallback for the case we cannot find anything.
                    rootProcessPoint = "AFTER_SUBMIT";
                }

            }
            return rootProcessPoint;
        }

        function hasChildProcesses( pComponent ) {
            return model.getComponents( model.COMP_TYPE.PAGE_PROCESS,
                                        { properties: [{
                                                         id:    model.PROP.PARENT_PROCESS,
                                                         value: pComponent.id } ]
                                                       } )?.length > 0;
        }


        //
        // If the execution chain (Parent Process) is set to "None", then we need to look up
        // the process point of the former execution chain (wand walk up the hierarchy if reqiured).
        // Then set the process point to the found value, otherwise the default ("AFTER_SUBMIT") from
        // page designer meta data would be applied, which could lead to the process "vanishing" - bug #35362394
        //
        if (    action                           === model.CALLBACK_ACTION.CHANGED
             && property.id                      === model.PROP.PARENT_PROCESS
             && value                            !== ""
             && parentProcessProperty.getValue() === "" )
        {
            pointProperty.setValue( findExecutionPoint( value ) );
        }


        //
        // if an execution chain has child processes, do not allow changing the process type.
        //
        if (    action                  === model.CALLBACK_ACTION.VALIDATE
             && property.id             === model.PROP.PAGE_PROCESS_TYPE
             && value                   !== PROCESS_TYPE.EXECUTION_CHAIN
             && hasChildProcesses( self ) )
        {
                return { error: format( "PROCESS.CHILDREN_ONLY_ALLOWED_FOR_EXECUTION_CHAINS" ) };
        }

        if ( !property || !pointProperty || !typeProperty ) {
            return;
        }

    } // pageProcess

    function cardAction( action, property, oldValue ) {

        let self = this,
            actionLinkTargetProp = self.getProperty( model.PROP.ACTION_LINK_TARGET_TYPE ),
            parent = this.getParent( model.COMP_TYPE.CARD );

        if ( actionLinkTargetProp ) {
            if (  _hasChangedEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" )
               && this.getChilds( model.COMP_TYPE.CARD_BUTTON_ACTION ).length === 0 ) {
                // add default action
                new model.Component( {
                    typeId:   model.COMP_TYPE.CARD_BUTTON_ACTION,
                    parentId: this.id,
                    values: [
                        { id: model.PROP.DA_ACTION_TYPE, value: "NATIVE_EXECUTE_PLSQL_CODE" }
                    ]
                } );
            } else if (  _hasChangedNotEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" )
                      || action === model.CALLBACK_ACTION.REMOVED )
            {
                _removeChildren( self, model.COMP_TYPE.CARD_BUTTON_ACTION );
            } else if (  action === model.CALLBACK_ACTION.VALIDATE
                      && oldValue === "DEFINED_BY_DA_ACTION"
                      && !primaryKeyIsSet( parent, model.COMP_TYPE.CARD ) ) {
                return { error: msg( "MISSING_PRIMARY_KEY" ) };
            }
        }

        syncStaticId( this, action, property );

    } // cardAction

    function componentAction( action, property, oldValue ) {

        let self = this,
            actionPositionProp   = self.getProperty( model.PROP.ACTION_POSITION ),
            actionTemplateProp   = self.getProperty( model.PROP.ACTION_TEMPLATE ),
            actionLinkTargetProp = self.getProperty( model.PROP.ACTION_LINK_TARGET_TYPE ),
            actionTypeId, parent, columnTypeId;

        if ( self.typeId === model.COMP_TYPE.REGION_ACTION ) {
            actionTypeId = model.COMP_TYPE.REGION_ACTION_BUTTON_ACTION;
            columnTypeId = model.COMP_TYPE.REGION_TMPL_COLUMN;
            parent       = this.getParent( model.COMP_TYPE.REGION );
        } else if ( self.typeId === model.COMP_TYPE.IR_COLUMN_ACTION ) {
            actionTypeId = model.COMP_TYPE.IR_COL_ACTION_BUTTON_ACTION;
            columnTypeId = model.COMP_TYPE.IR_COLUMN;
            parent       = this.getParent( model.COMP_TYPE.IR_ATTRIBUTES );
        }

        if ( actionTypeId && actionLinkTargetProp ) {
            if (  action === model.CALLBACK_ACTION.VALIDATE
               && oldValue === "DEFINED_BY_DA_ACTION"
               && !primaryKeyIsSet( parent, columnTypeId ) ) {
                return { error: msg( "MISSING_PRIMARY_KEY" ) };
            }
            if (  _hasChangedEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" )
               && this.getChilds( actionTypeId ).length === 0 ) {
                // add default action
                new model.Component( {
                    typeId:   actionTypeId,
                    parentId: this.id,
                    values: [
                        { id: model.PROP.DA_ACTION_TYPE, value: "NATIVE_EXECUTE_PLSQL_CODE" }
                    ]
                } );
            } else if (  _hasChangedNotEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" )
                      || action === model.CALLBACK_ACTION.REMOVED ) {
                _removeChildren( self, actionTypeId );
            }
        }

        // Does the picked template support menus?
        if (   ( actionTemplateProp && _hasChanged( property, action, actionTemplateProp, oldValue ) )
            || ( !actionTemplateProp && _hasChanged( property, action, actionPositionProp, oldValue ) )
        ) {

            let menuEntryTypeId;

            if ( self.typeId === model.COMP_TYPE.REGION_ACTION ) {
                menuEntryTypeId = model.COMP_TYPE.REGION_ACTION_MENU_ENTRY;
            } else if ( self.typeId === model.COMP_TYPE.IR_COLUMN_ACTION ) {
                menuEntryTypeId = model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY;
            }

            if ( model.getActionPositionType( self ) === "MENU" ) {

                // if we don't have any menu entries so far, create a dummy one to guide the developer
                if ( self.getChilds( menuEntryTypeId ).length === 0 ) {

                    new model.Component( {
                        typeId:   menuEntryTypeId,
                        parentId: self.id
                    } );
                }

            } else {

                // if the new plugin action type isn't a MENU anymore, remove all menu entries
                _removeChildren( self, menuEntryTypeId );

            }
        }

        syncStaticId( self, action, property, self.getProperty( model.PROP.BUTTON_LABEL )  );

    } // componentAction


    function componentMenuEntry( action, property, oldValue ) {

        let self = this,
            parent, columnTypeId,
            parentMenuPropId,
            actionLinkTargetProp = self.getProperty( model.PROP.ACTION_LINK_TARGET_TYPE ),
            actionTypeId;

        if ( self.typeId === model.COMP_TYPE.REGION_ACTION_MENU_ENTRY ) {
            actionTypeId = model.COMP_TYPE.REGION_ACTION_MENU_ENTRY_ACTION;
            columnTypeId = model.COMP_TYPE.REGION_TMPL_COLUMN;
            parent = self.getParent( model.COMP_TYPE.REGION );
        } else if ( self.typeId === model.COMP_TYPE.BUTTON_MENU_ENTRY ) {
            actionTypeId = model.COMP_TYPE.BUTTON_ACTION_MENU_ENTRY_ACTION;
        } else if ( self.typeId === model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY ) {
            actionTypeId = model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY_ACTION;
            columnTypeId = model.COMP_TYPE.IR_COLUMN;
            parent = self.getParent( model.COMP_TYPE.IR_ATTRIBUTES );
        }

        if ( actionTypeId && actionLinkTargetProp ) {
            // add a default action when changing the link target type
            if (  _hasChangedEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" )
               && this.getChilds( actionTypeId ).length === 0 ) {
                new model.Component( {
                    typeId:   actionTypeId,
                    parentId: this.id,
                    values: [
                        { id: model.PROP.DA_ACTION_TYPE, value: "NATIVE_EXECUTE_PLSQL_CODE" }
                    ]
                } );
            } else if (  action === model.CALLBACK_ACTION.CHANGED
               && _hasChangedNotEqualsTo( property, action, actionLinkTargetProp, "DEFINED_BY_DA_ACTION" ) )
            {
                _removeChildren( self, actionTypeId );
            }
            // ensure the primary key is set for region columns
            if (   action === model.CALLBACK_ACTION.VALIDATE
               && property.id === model.PROP.ACTION_LINK_TARGET_TYPE
               && oldValue === "DEFINED_BY_DA_ACTION"
               && parent?.id
               && !primaryKeyIsSet( parent, columnTypeId ) ) {
                 return { error: msg( "MISSING_PRIMARY_KEY" ) };
            }
         }
        // if the menu entry isn't of type SUB_MENU anymore or it gets removed, we also have to clean up all sub menu entries
        if (  _hasChangedNotEqualsTo( property, action, self.getProperty( model.PROP.MENU_ENTRY_TYPE ), "SUB_MENU" )
           || action === model.CALLBACK_ACTION.REMOVED )
        {
            _removeChildren( self, actionTypeId );

            if ( self.typeId === model.COMP_TYPE.REGION_ACTION_MENU_ENTRY ) {
                parentMenuPropId = model.PROP.REGION_ACTION_PARENT_MENU;
            } else if ( self.typeId === model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY ) {
                parentMenuPropId = model.PROP.IR_COLUMN_ACTION_PARENT_MENU;
            } else if ( self.typeId === model.COMP_TYPE.BUTTON_MENU_ENTRY ) {
                parentMenuPropId = model.PROP.BUTTON_ACTION_PARENT_MENU;
            }

            _removeComponents(
                model.getComponents(
                    self.typeId, {
                        parentId: self.parentId,
                        properties: [{
                            id:    parentMenuPropId,
                            value: self.id
                        }]},
                    false ) );
        }

        syncStaticId( self, action, property, self.getProperty( model.PROP.BUTTON_LABEL ) );

    } // componentMenuEntry

    function toggleWorkflowComponents( version ) {
        let state = version.getProperty( model.PROP.STATE ).getValue();
        switch ( state ) {
            case "ACTIVE":
                this.enable();
                this.getProperties().forEach( prop => prop.id !== model.PROP.DIAGRAM && prop.disable() );
                break;
            case "DEVELOPMENT":
                this.enable();
                this.getProperties().forEach( ( prop ) => {
                    if ( ![ model.PROP.CHANGED_ON, model.PROP.CHANGED_BY ].includes( prop.id ) ) {
                        prop.enable();
                    }
                } );
                break;
            case "INACTIVE":
                this.disable();
        }
    }

    function componentWorkflowParam( action , property, oldValue ) {
        const self = this;
        const workflowPropId = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_WF, "workflow_definition_id" ).id;
        const waitForCompletionPropId = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, PROCESS_TYPE.INVOKE_WF, "wait_for_completion" ).id;
        const paramDirection = self.getPropertyValue( model.PROP.API_DIRECTION );
        const dataTypeProp = this.getProperty( model.PROP.WORKFLOW_DATA_TYPE );
        const defaultValueProp = this.getProperty( model.PROP.PARAMETER_DEFAULT_VALUE );
        const isRequiredProp = this.getProperty( model.PROP.PARAMETER_REQUIRED );
        const getConnectedParams = () => {
            return  model.getComponents( model.COMP_TYPE.WF_ACTIVITY_WF_PARAM, {
                properties: [ {
                    id: model.PROP.WORKFLOW_PARAM,
                    value: self.id
                } ],
                filterFunction: function() {
                    // we don't want to update the activity parameters in inactive versions
                    return this.getParent( model.COMP_TYPE.WORKFLOW_VERSION )?.getProperty( model.PROP.STATE ).getValue() !== "INACTIVE";
                }
           } );
        };
        // when a new workflow parameter is created, we need to look up all the activities that invokes the current workflow and add them a workflow-parameter component
        // and also when the "direction" changes, we have to go through all activities to see if we only need to update a property or actually create/remove the workflow-parameter
        if ( action === model.CALLBACK_ACTION.CREATED || _hasChanged( this.getProperty( model.PROP.API_DIRECTION ), action, property/* , oldValue */ ) ) {
            // look up all invokeWorkflow activities that references the current workflow
            model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                properties: [ {
                    id: model.PROP.PAGE_PROCESS_TYPE,
                    value: PROCESS_TYPE.INVOKE_WF
                }, {
                    id: workflowPropId,
                    value: self.getParent().id
                } ]
            } ).forEach( activity => {
                let activityParameters = activity.getChilds( model.COMP_TYPE.WF_ACTIVITY_WF_PARAM );
                let activityParameter = activityParameters.filter( actParam => actParam.getPropertyValue( model.PROP.WORKFLOW_PARAM ) === self.id )[ 0 ];
                let waitForCompletion = activity.getPropertyValue( waitForCompletionPropId );
                // if it's creation action or the activity does not have the parameter yet, we add it
                if ( action === model.CALLBACK_ACTION.CREATED || !activityParameter ) {
                    // only add an "out" parameter, if the activity's "Wait for Completion" is enabled
                    if ( paramDirection !== "OUT" || ( paramDirection === "OUT" && waitForCompletion === "Y" ) ) {
                        addWorkflowParameterToComponent( self, activity );
                    }
                // if the activity has this parameter already
                } else if ( activityParameter ) {
                    if ( waitForCompletion === "N" && paramDirection === "OUT" ) {
                        activityParameter.remove();
                    } else {
                        // don't update activity parameters in inactive versions
                        if ( activity.getParent( model.COMP_TYPE.WORKFLOW_VERSION )?.getProperty( model.PROP.STATE ).getValue() !== "INACTIVE" ) {
                            updateWorkflowActivityParameter( self, activityParameter );
                        }
                    }
                }
            } );
        } else if ( _hasChanged( dataTypeProp, action, property, oldValue ) ) {
            getConnectedParams().forEach( param => param.getProperty( model.PROP.WORKFLOW_DATA_TYPE ).setValue( dataTypeProp.getValue(), { checkReadOnly: false } ) );
        } else if ( _hasChanged( defaultValueProp, action, property, oldValue ) && isRequiredProp?.getValue() === "Y" ) {
            getConnectedParams().forEach( param => {
                if ( param.getPropertyValue( model.PROP.PARAMETER_VALUE_TYPE ) === "NULL" ) {
                    _setPropertyValue( param, model.PROP.PARAMETER_VALUE_TYPE, "DEFAULT" );
                }
            } );
        } else if ( _hasChanged( isRequiredProp, action, property, "N" ) && defaultValueProp?.getValue() === "" ) {
            getConnectedParams().forEach( param => {
                if ( param.getPropertyValue( model.PROP.PARAMETER_VALUE_TYPE ) === "NULL" ) {
                    _setPropertyValue( param, model.PROP.PARAMETER_VALUE_TYPE, "ITEM" );
                }
            } );
        }
    } // componentWorkflowParam

    function componentWorkflowActivityVariable( pAction /* , pProperty, pValue */ ) {
        let version = this.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
        if ( [ model.CALLBACK_ACTION.PARENT_UPDATE, model.CALLBACK_ACTION.INIT ].includes( pAction ) && version ) {
            toggleWorkflowComponents.call( this, version );
        }
    } // componentWorkflowActivityVariable

    function componentWorkflowVariable( pAction /* , pProperty, pValue */ ) {
        let version = this.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
        if ( [ model.CALLBACK_ACTION.PARENT_UPDATE, model.CALLBACK_ACTION.INIT ].includes( pAction ) && version ) {
            toggleWorkflowComponents.call( this, version );
        }
    } // componentWorkflowVariable

    function componentWorkflowBranch( pAction, pProperty, pValue ) {
        const OTHERWISE = "OTHERWISE";
        let version = this.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
        if ( [ model.CALLBACK_ACTION.PARENT_UPDATE, model.CALLBACK_ACTION.INIT ].includes( pAction ) && version ) {
            toggleWorkflowComponents.call( this, version );
        } else if ( pAction === model.CALLBACK_ACTION.VALIDATE ) {
            if ( pProperty.id === model.PROP.OPERATOR || pProperty.id === model.PROP.EXECUTION_SEQUENCE ) {
                const otherBranches = this.getParent().getChilds( model.COMP_TYPE.WORKFLOW_BRANCH, {}, true );
                if ( pProperty.id === model.PROP.OPERATOR ) {
                    if ( pValue === OTHERWISE && pProperty.getValue() !== OTHERWISE ) {
                        if ( otherBranches.some( c => c.getPropertyValue( model.PROP.OPERATOR ) === OTHERWISE ) ) {
                            return { error: msg( "WF.ERROR_MAX_ONE_OTHERWISE" ) };
                        }
                    }
                } else if ( this.getPropertyValue( model.PROP.OPERATOR ) ) {
                    // if the execution sequence changes on a "otherwise" branch, make sure it's still the highest number
                    const isOtherwise = this.getPropertyValue( model.PROP.OPERATOR ) === OTHERWISE;
                    if ( isOtherwise ) {
                        if ( parseFloat( otherBranches.at( -1 ).getPropertyValue( model.PROP.EXECUTION_SEQUENCE ) ) > parseFloat( pValue ) ) {
                            return { error: msg( "WF.ERROR_OTHERWISE_MUST_BE_LAST" ) };
                        }
                    } else {
                        // if it's not an "otherwise" branch, ensure the value is lower than that of the "otherwise" branch
                        const otherwiseBranch = otherBranches.filter( c => c.getPropertyValue( model.PROP.OPERATOR ) === OTHERWISE )[ 0 ];
                        if ( otherwiseBranch && parseFloat( pValue ) > parseFloat( otherwiseBranch.getPropertyValue( model.PROP.EXECUTION_SEQUENCE ) ) ) {
                            return { error: msg( "WF.ERROR_OTHERWISE_MUST_BE_LAST" ) };
                        }
                    }
                }

                return {};
            } else if ( model.PROP.TO_WORKFLOW_ACTIVITY ===  pProperty.id ) {
                if ( pValue && pProperty.id === model.PROP.TO_WORKFLOW_ACTIVITY ) {
                    let comp = model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, { id: pValue } );
                    if ( comp.length === 1 && comp[ 0 ].getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue() === "NATIVE_WORKFLOW_START" ) {
                        return { error: msg( "WF.ERROR_START_AS_TARGET" ) };
                    }
                }
            }
        } else if ( pAction === model.CALLBACK_ACTION.REMOVED ) {
            if ( !this.isReadOnly() ) {
                this.getParent().getChilds( model.COMP_TYPE.WORKFLOW_BRANCH, {
                    properties: [ {
                        id: model.PROP.OPERATOR,
                        value: OTHERWISE
                    } ]
                } ).forEach( ( branch ) => {
                    let prop = branch.getProperty( model.PROP.OPERATOR );
                    prop.setValue( prop.getValue(), true );
                } );
            }
        }
    } // componentWorkflowBranch

    function componentWorkflowTransition( pAction, pProperty, pValue ) {
        const TYPE_NORMAL = "NORMAL",
            TYPE_ERROR = "ERROR",
            TYPE_TIMEOUT = "TIMEOUT";
        const TOGGLE_PROPS = [ model.PROP.FROM_WORKFLOW_ACTIVITY, model.PROP.TO_WORKFLOW_ACTIVITY, model.PROP.TRANSITION_TYPE ];
        let self = this, prop, transitions, version, state, comp;
        switch( pAction ) {
            case model.CALLBACK_ACTION.VALIDATE:
                if ( pProperty.id === model.PROP.TRANSITION_TYPE ) {
                    // there can be unlimited number of error transitions
                    if ( pValue === TYPE_ERROR || !self.getParent() ) {
                        return {};
                    }

                    transitions = self.getParent().getChilds( model.COMP_TYPE.WORKFLOW_TRANS, {
                        parentId: self.parentId,
                        properties: [ {
                            id: model.PROP.TRANSITION_TYPE,
                            value: TYPE_NORMAL
                        } ]
                    } );

                    if ( pValue === TYPE_NORMAL && transitions.length > 0 && self.id !== transitions[ 0 ].id ) {
                        return { error: msg( "WF.ERROR_MAX_ONE_NORMAL" ) };
                    }

                    transitions = self.getParent().getChilds( model.COMP_TYPE.WORKFLOW_TRANS, {
                        parentId: self.parentId,
                        properties: [ {
                            id: model.PROP.TRANSITION_TYPE,
                            value: TYPE_TIMEOUT
                        } ]
                    } );

                    if ( pValue === TYPE_TIMEOUT && transitions.length > 0 && self.id !== transitions[ 0 ].id ) {
                        return { error: msg( "WF.ERROR_MAX_ONE_TIMEOUT" ) };
                    }
                }

                if ( [ model.PROP.FROM_WORKFLOW_ACTIVITY, model.PROP.TO_WORKFLOW_ACTIVITY ].includes( pProperty.id ) ) {
                    if ( ( pProperty.id === model.PROP.FROM_WORKFLOW_ACTIVITY && pValue === self.getProperty( model.PROP.TO_WORKFLOW_ACTIVITY ).getValue() )
                        || ( pProperty.id === model.PROP.TO_WORKFLOW_ACTIVITY && pValue === self.getProperty( model.PROP.FROM_WORKFLOW_ACTIVITY ).getValue() ) ) {
                        return { error: msg( "WF.ERROR_SAME_FROM_TO" ) };
                    }

                    if ( pValue && pProperty.id === model.PROP.TO_WORKFLOW_ACTIVITY ) {
                        comp = model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, { id: pValue } );
                        if ( comp.length === 1 && comp[ 0 ].getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue() === "NATIVE_WORKFLOW_START" ) {
                            return { error: msg( "WF.ERROR_START_AS_TARGET" ) };
                        }
                    }
                }

                break;
            case model.CALLBACK_ACTION.CREATED:
                // re-set the value of the transition type in order to trigger a validation on the value
                prop = self.getProperty( model.PROP.TRANSITION_TYPE );
                prop.setValue( prop.getValue(), true );
                break;
            case model.CALLBACK_ACTION.REMOVED:
                if ( !self.isReadOnly() ) {
                    self.getParent().getChilds( model.COMP_TYPE.WORKFLOW_TRANS ).forEach( ( transition ) => {
                        if ( transition.id !== self.id ) {
                            prop = transition.getProperty( model.PROP.TRANSITION_TYPE );
                            if ( !prop.isReadOnly() ) {
                                prop.setValue( prop.getValue(), true );
                            }
                        }
                    } );
                }
                break;
            case model.CALLBACK_ACTION.CHANGED:
                // on change of "to" we re-set "from" - and the other way around too
                if ( [ model.PROP.FROM_WORKFLOW_ACTIVITY, model.PROP.TO_WORKFLOW_ACTIVITY ].includes( pProperty.id ) && pValue !== pProperty.getValue() ) {
                    prop = self.getProperty( ( pProperty.id === model.PROP.FROM_WORKFLOW_ACTIVITY ? model.PROP.TO_WORKFLOW_ACTIVITY : model.PROP.FROM_WORKFLOW_ACTIVITY ) );
                    if ( !prop.isReadOnly() ) {
                        prop.setValue( prop.getValue(), true );
                    }
                }
                break;
            case model.CALLBACK_ACTION.INIT:
            case model.CALLBACK_ACTION.PARENT_UPDATE:
                version = this.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
                if ( !version ) {
                    return;
                }
                state = version.getProperty( model.PROP.STATE ).getValue();
                if ( state === "INACTIVE" ) {
                    this.disable();
                } else if ( state === "ACTIVE" ) {
                    this.getProperties().forEach( ( prop ) => {
                        if ( TOGGLE_PROPS.includes( prop.id ) ) {
                            prop.disable();
                        } else if ( !prop.isReadOnly() ) {
                            prop.enable();
                        }
                    } );
                } else {
                    this.getProperties().forEach( ( prop ) => {
                        if ( TOGGLE_PROPS.includes( prop.id ) ) {
                            prop.enable();
                        }
                    } );
                    this.enable(); // enable everything
                }
        }
    } // componentWorkflowTransition

    function componentWorkflowActivity( action, property, value ) {
        const SWITCH = "NATIVE_WORKFLOW_SWITCH",
            WF_START = "NATIVE_WORKFLOW_START",
            WF_END = "NATIVE_WORKFLOW_END",
            CREATE_TASK = "NATIVE_CREATE_TASK",
            WAIT = "NATIVE_WORKFLOW_WAIT",
            TASK_VAR_OUTCOME = "TASK_OUTCOME",
            TASK_VAR_APPROVAL = "APPROVER",
            PARALLEL_FLOW = "NATIVE_PARALLEL_WF",
            NULL = "NULL",
            TIMEOUT = "TIMEOUT";
        let self = this,
            switchTypeProperty = model.getPluginProperty( model.PLUGIN_TYPE.PROCESS, SWITCH, "type" ).id,
            version, state, activityType, activities;
        const TOGGLE_PROPS = [
            model.PROP.PAGE_PROCESS_TYPE,
            model.PROP.WF_SOURCE_SQL_QUERY,
            model.PROP.STATIC_ID,
            model.PROP.DUE_ON_TYPE,
            model.PROP.DUE_ON_INTERVAL_VALUE,
            model.PROP.DUE_ON_SCHEDULER_VALUE,
            model.PROP.DUE_ON_QUERY_VALUE,
            model.PROP.PARALLEL_BRANCH,
            switchTypeProperty ];
        const createTaskVariables = function() {
            let version = self.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
            let vars = version.getChilds( model.COMP_TYPE.WORKFLOW_VARIABLE );
            if ( !vars.filter( wfvar => wfvar.getProperty( model.PROP.IDENTIFICATION_STATIC_ID_UPPER ).getValue() === TASK_VAR_APPROVAL ).length ) {
                new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_VARIABLE,
                    parentId: version.id,
                    values: [ {
                        id: model.PROP.IDENTIFICATION_STATIC_ID_UPPER,
                        value: TASK_VAR_APPROVAL
                    }, {
                        id: model.PROP.ITEM_LABEL,
                        value: "Approver"
                    }, {
                        id: model.PROP.WORKFLOW_VALUE_TYPE,
                        value: NULL
                    } ]
                } );
            }
            if ( !vars.filter( wfvar => wfvar.getProperty( model.PROP.IDENTIFICATION_STATIC_ID_UPPER ).getValue() === TASK_VAR_OUTCOME ).length ) {
                new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_VARIABLE,
                    parentId: version.id,
                    values: [ {
                        id: model.PROP.IDENTIFICATION_STATIC_ID_UPPER,
                        value: TASK_VAR_OUTCOME
                    }, {
                        id: model.PROP.ITEM_LABEL,
                        value: "TaskOutcome"
                    }, {
                        id: model.PROP.WORKFLOW_VALUE_TYPE,
                        value: NULL
                    } ]
                } );
            }
        };
        const createFlowContainers = () => {
            let currentContainers = self.getChilds( model.COMP_TYPE.WF_PARALLEL_BRANCH );
            while ( currentContainers.length < 2 ) {
                // create a container with one default activity
                const container = new model.Component( {
                    typeId: model.COMP_TYPE.WF_PARALLEL_BRANCH,
                    parentId: self.id,
                } );
                currentContainers.push( container );
            }
        };
        const validateComponent = function( activityType ) {
            let errors = [];
            const parallelBranch = self.getPropertyValue( model.PROP.PARALLEL_BRANCH );
            // inside of a parallel branch we have different requirements regarding the activity links
            if ( parallelBranch !== "" ) {
                const acts = model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, { properties: [ {
                    id: model.PROP.PARALLEL_BRANCH,
                    value: parallelBranch,
                } ] } );
                if ( acts.length > 1 ) {
                    let isTarget = self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_TRANS ).some( transition => {
                        return transition.getProperty( model.PROP.TO_WORKFLOW_ACTIVITY ).getValue() === self.id;
                    } );
                    isTarget ||= self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_BRANCH ).some( branch => {
                        return branch.getProperty( model.PROP.TO_WORKFLOW_ACTIVITY ).getValue() === self.id;
                    } );
                    if ( !isTarget ) {
                        let isSource = self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_TRANS ).some( transition => {
                            return transition.getProperty( model.PROP.FROM_WORKFLOW_ACTIVITY ).getValue() === self.id;
                        } );
                        isSource ||= self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_BRANCH ).some( branch => {
                            return branch.parentId === self.id;
                        } );
                        if ( !isSource ) {
                            errors.push( msg( "WF.ERROR_NOT_CONNECTED" ) );
                        }
                    }
                }
            } else {
                // each activity - except end - must have at least one incoming transition / branch
                if ( WF_END !== activityType ) {
                    if( !self.getChilds( activityType === SWITCH ? model.COMP_TYPE.WORKFLOW_BRANCH : model.COMP_TYPE.WORKFLOW_TRANS )?.length ) {
                        errors.push( msg( "WF.ERROR_NO_OUTGOING_CONN" ) );
                    }
                }
                // each activity - except start - must have at least one outgoing transition / branch
                if ( WF_START !== activityType ) {
                    let isTarget = self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_TRANS ).some( transition => {
                        return transition.getProperty( model.PROP.TO_WORKFLOW_ACTIVITY ).getValue() === self.id;
                    } );
                    isTarget ||= self.getParent()?.getChildrenUntil( model.COMP_TYPE.WORKFLOW_BRANCH ).some( branch => {
                        return branch.getProperty( model.PROP.TO_WORKFLOW_ACTIVITY ).getValue() === self.id;
                    } );
                    if ( !isTarget ) {
                        errors.push( msg( "WF.ERROR_NO_INCOMING_CONN" ) );
                    }
                }

                if ( PARALLEL_FLOW === activityType ) {
                    const branches = model.getComponents( model.COMP_TYPE.WF_PARALLEL_BRANCH );
                    if ( branches.length < 2 ) {
                        errors.push( msg( "WF.ERROR_MIN_BRANCHES" ) );
                    }
                }
            }
            return errors;
        };
        const reValidateStartActs = () => {
            model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                parentId: self.parentId,
                properties: [ {
                    id: model.PROP.PAGE_PROCESS_TYPE,
                    value: WF_START
                } ]
            } ).forEach( comp => {
                if ( comp.hasErrors() ) {
                    comp.getProperty( model.PROP.PAGE_PROCESS_TYPE ).setValue( WF_START, true );
                }
            } );
        };

        const cleanUpParallelBranches = () => {
            model.getComponents( model.COMP_TYPE.WF_PARALLEL_BRANCH, { parentId: self.id } ).forEach( branch => {
                model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                    properties: [ { id: model.PROP.PARALLEL_BRANCH, value: branch.id } ]
                } ).forEach( activity => {
                    activity.remove();
                } );
                branch.remove();
            } );
        };

        syncStaticId( this, action, property );

        switch( action ) {
            case model.CALLBACK_ACTION.CREATED:
                activityType = this.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue();
                if ( activityType === CREATE_TASK ) {
                    createTaskVariables();
                } else if ( activityType === PARALLEL_FLOW ) {
                    createFlowContainers();
                }
                // dummy setValue call to trigger the component validation
                this.getProperty( model.PROP.NAME ).setValue( this.getProperty( model.PROP.NAME ).getValue(), true );
                break;
            case model.CALLBACK_ACTION.VALIDATE:
                activityType = this.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue();
                if ( property.id === model.PROP.PAGE_PROCESS_TYPE ) {
                    if ( activityType === WF_START || value === WF_START ) {
                        activities = model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                            parentId: self.parentId,
                            properties: [ {
                                id: model.PROP.PAGE_PROCESS_TYPE,
                                value: WF_START
                            } ]
                        } );

                        if ( activities.length > 0 ) {
                            if ( !activities.some( a => a.id === this.id || activities.length > 1 ) ) {
                                return { error: msg( "WF.ERROR_ONE_START" ) };
                            }
                        }
                    }
                }
                break;
            case model.CALLBACK_ACTION.CHANGED:
                activityType = self.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue();
                // changing type from switch to something else, or changing the switch type property
                if ( ( value === SWITCH && _hasChanged( this.getProperty( model.PROP.PAGE_PROCESS_TYPE ), action, property, value ) )
                    || _hasChanged( self.getProperty( switchTypeProperty ),  action, property, value
                ) ) {
                    // remove every branch of the activity (link)
                    _removeChildren( self, model.COMP_TYPE.WORKFLOW_BRANCH );
                }
                // simple type change
                if ( _hasChanged( self.getProperty( model.PROP.PAGE_PROCESS_TYPE ), action, property, value ) ) {
                    // if we change to anything other than parallel flow, remove the child flow branches
                    if ( activityType !== PARALLEL_FLOW ) {
                        cleanUpParallelBranches();
                    }
                    // switch and end cannot have outgoing transitions
                    if ( [ SWITCH, WF_END, WF_START ].includes( activityType ) ) {
                        _removeChildren( self, model.COMP_TYPE.WORKFLOW_TRANS );
                    // wait cannot have timeout connections
                    } else if ( activityType === WAIT ) {
                        self.getChilds( model.COMP_TYPE.WORKFLOW_TRANS, {
                            properties: [ {
                                id: model.PROP.TRANSITION_TYPE,
                                value: TIMEOUT
                            } ]
                        } ).forEach( comp => comp.remove() );
                    } else {

                        if ( activityType === CREATE_TASK ) {
                            createTaskVariables();
                        } else if ( activityType === PARALLEL_FLOW ) {
                            createFlowContainers();
                        }
                        const branchId = self.getPropertyValue( model.PROP.PARALLEL_BRANCH );
                        const compType = branchId !== "" ? "WF_PARALLEL_BRANCH" : "WORKFLOW_VERSION";
                        model.getComponents( model.COMP_TYPE[ compType ] )[ 0 ]?.getChilds( model.COMP_TYPE.WORKFLOW_ACTIVITY ).forEach( ( activity ) => {
                            activityType = activity.getProperty( model.PROP.PAGE_PROCESS_TYPE );
                            // reset the type to remove/show errors
                            if ( activityType.errors.length ) {
                                activityType.setValue( activityType.getValue(), true );
                            }
                        } );
                    }

                    if ( value === WF_START || activityType === WF_START ) {
                        reValidateStartActs();
                    }
                // if the activity does not have "due-on-type" defined remove the "timeout" transitions
                } else if ( _hasChanged( self.getProperty( model.PROP.DUE_ON_TYPE ), action, property, value ) ) {
                    if ( self.getProperty( model.PROP.DUE_ON_TYPE ).getValue() === "" ) {
                        self.getChilds( model.COMP_TYPE.WORKFLOW_TRANS, {
                            properties: [ {
                                id: model.PROP.TRANSITION_TYPE,
                                value: TIMEOUT
                            } ]
                        } ).forEach( comp => comp.remove() );
                    }
                } else if ( _hasChanged( self.getProperty( model.PROP.PARALLEL_BRANCH ), action, property, value  ) ) {
                    _removeChildren( self, model.COMP_TYPE.WORKFLOW_BRANCH );
                    _removeChildren( self, model.COMP_TYPE.WORKFLOW_TRANS );
                    // trigger validation on the parallel branches
                    model.getComponents( model.COMP_TYPE.WF_PARALLEL_BRANCH, { id: value } ).forEach( c => {
                        if ( !c.isReadOnly() ) {
                            c.getProperty( model.PROP.NAME ).setValue( c.getPropertyValue( model.PROP.NAME ), true );
                        }
                    } );
                    // reset the incoming links
                    model.getComponents( model.COMP_TYPE.WORKFLOW_TRANS, { properties: [ { id: model.PROP.TO_WORKFLOW_ACTIVITY, value: this.id } ] } ).forEach( link => {
                        _setPropertyValue( link, model.PROP.TO_WORKFLOW_ACTIVITY, "" );
                    } );
                }
                break;
            case model.CALLBACK_ACTION.VALIDATE_COMPONENT:
                activityType = this.getProperty( model.PROP.PAGE_PROCESS_TYPE ).getValue();
                return { error: validateComponent( activityType ) };
            case model.CALLBACK_ACTION.INIT:
            case model.CALLBACK_ACTION.PARENT_UPDATE:
                version = this.getParent( model.COMP_TYPE.WORKFLOW_VERSION );
                if ( !version ) {
                    return;
                }
                state = version.getProperty( model.PROP.STATE ).getValue();
                if ( state === "ACTIVE" ) {
                    this.getProperties().forEach( prop => {
                        if ( TOGGLE_PROPS.includes( prop.id ) ) {
                            prop.disable();
                        }
                    } );
                    this.enable();
                } else if ( state === "DEVELOPMENT" ) {
                    this.getProperties().forEach( prop => {
                        if ( TOGGLE_PROPS.includes( prop.id ) ) {
                            prop.enable();
                        }
                    } );
                } else if ( state === "INACTIVE" ) {
                    this.disable();
                }
                break;
            case model.CALLBACK_ACTION.REMOVED:
                reValidateStartActs();
        }
    } // componentWorkflowActivity

    function componentWorkflowParallelBranch( action, /* property, value */ ) {
        let errors = [], parentActivity = null, components = [];
        switch( action ) {
            case model.CALLBACK_ACTION.VALIDATE_COMPONENT:
                // there must be at least one activity
                components = model.getComponents( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                    properties: [ {
                        id: pe.PROP.PARALLEL_BRANCH,
                        value: this.id
                    } ]
                } );

                if ( components.length < 1 ) {
                    errors.push( msg( "WF.ERROR_BRANCH_MIN_ACT" ) );
                } else if ( components.length > 1 ) {
                    const links = components.flatMap( c => [
                            ...c.getChilds( model.COMP_TYPE.WORKFLOW_TRANS ),
                            ...c.getChilds( model.COMP_TYPE.WORKFLOW_BRANCH )
                        ] ),
                        linkTargets = links.map( l => l.getPropertyValue( model.PROP.TO_WORKFLOW_ACTIVITY ) );
                    const noTargetActs = components.filter( c => !linkTargets.includes( c.id ) );
                    if ( noTargetActs.length !== 1 ) {
                        errors.push( msg( "WF.ERROR_BRANCH_NO_START" ) );
                    }
                }

                return { error: errors };
            case model.CALLBACK_ACTION.CREATED:
                parentActivity = this.getParent();
                if ( parentActivity ) {
                    new model.Component( {
                        typeId: model.COMP_TYPE.WORKFLOW_ACTIVITY,
                        parentId: this.getParent( model.COMP_TYPE.WORKFLOW_VERSION ).id,
                        previousComponent: "last",
                        values: [ {
                            id: model.PROP.STATIC_ID,
                            value: `${parentActivity.getPropertyValue( model.PROP.STATIC_ID )}_${this.getPropertyValue( model.PROP.NAME )}`,
                        }, {
                            id: model.PROP.PARALLEL_BRANCH,
                            value: this.id,
                        } ],
                    } );
                }
                break;
        }
    }

    function componentWorkflowVersion( action, property, newValue ) {
        const STATE_DEV = "DEVELOPMENT",
            STATE_ACTIVE = "ACTIVE",
            STATE_INACTIVE = "INACTIVE",
            WF_START = "NATIVE_WORKFLOW_START",
            WF_END = "NATIVE_WORKFLOW_END";
        const SOURCE_PROPS = [
            model.PROP.WF_SOURCE_QUERY_TYPE,
            model.PROP.WF_SOURCE_QUERY_OWNER,
            model.PROP.COLUMN_MAPPING_PK_COLUMN,
            model.PROP.WF_SOURCE_QUERY_TABLE,
            model.PROP.WF_SOURCE_SQL_QUERY
        ];
        let self = this, errors = [], start, middle, end;

        const toggleWorkflowVersionProps = function() {
            // enable/disable properties based on the stat value
            let state = self.getProperty( model.PROP.STATE ).getValue();
            // everything disabled
            if ( state === STATE_INACTIVE ) {
                self.disable();
                self.getAllChildren().forEach( component => component.disable() );
            } else if ( state === STATE_ACTIVE ) {
                // only the source properties disabled, everything else enabled
                SOURCE_PROPS.forEach( prop => self.getProperty( prop )?.disable() );
            }
        };

        switch( action ) {
            case model.CALLBACK_ACTION.VALIDATE_COMPONENT:
                // there must be exactly one start activity
                start = this.getChilds( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                    properties: [ {
                        id: model.PROP.PAGE_PROCESS_TYPE,
                        value: WF_START
                    } ]
                } );

                if ( start.length !== 1 ) {
                    errors.push( msg( "WF.ERROR_ONE_START" ) );
                }

                // there must be at least one end activity
                end = this.getChilds( model.COMP_TYPE.WORKFLOW_ACTIVITY, {
                    properties: [ {
                        id: model.PROP.PAGE_PROCESS_TYPE,
                        value: WF_END
                    } ]
                } );

                if ( end.length < 1 ) {
                    errors.push( msg( "WF.ERROR_NO_END" ) );
                }

                return { error: errors };
            case model.CALLBACK_ACTION.VALIDATE:
                // only one version can be in development
                if ( property?.id === model.PROP.STATE ) {
                    let comps = model.getComponents( self.typeId, {
                        parentId: self.parentId,
                        properties: [ {
                            id: model.PROP.STATE,
                            value: STATE_DEV
                        } ]
                    } );
                    if ( comps.length && property.getValue() !== "DEVELOPMENT" && newValue === STATE_DEV ) {
                        return { error: msg( "WF.ERROR_DUP_DEV" ) };
                    }
                } else if ( property.id === model.PROP.WF_SOURCE_QUERY_TYPE ) {
                    sourceLocationHandling( action, self, property, newValue );
                }
                break;
            case model.CALLBACK_ACTION.CHANGED:
                if ( property.id === model.PROP.STATE ) {
                    // there can be only one active version at the time, setting one to active must deactivate other(s)
                    if ( newValue === STATE_DEV && property.getValue() === STATE_ACTIVE ) {
                        model.getComponents( self.typeId, {
                            parentId: self.parentId,
                            properties: [ {
                                id: model.PROP.STATE,
                                value: STATE_ACTIVE
                            } ]
                        } ).forEach( ( component ) => {
                            if ( component.id === self.id ) {
                                return;
                            }
                            component.getProperty( model.PROP.STATE ).setValue( STATE_INACTIVE );
                        } );

                        // reassign the state value of versions in development, to remove the error message ( in case there's any )
                        model.getComponents( self.typeId, {
                            parentId: self.parentId,
                            properties: [ {
                                id: model.PROP.STATE,
                                value: STATE_DEV
                            } ]
                        } ).forEach( ( component ) => {
                            if ( component.id === self.id ) {
                                return;
                            }
                            component.getProperty( model.PROP.STATE ).setValue( STATE_DEV );
                        } );

                    }
                    // on state version change always update the compnent properties availability
                    toggleWorkflowVersionProps();
                } else if ( property.id === model.PROP.WF_SOURCE_QUERY_TYPE ) {
                    sourceLocationHandling( action, self, property, newValue );
                }
                break;
            case model.CALLBACK_ACTION.CREATED:
                // when a version is created, we immediately create three activities ( type: start, default, end )
                start = new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_ACTIVITY,
                    parentId: self.id,
                    values: [ {
                        id: model.PROP.PAGE_PROCESS_TYPE,
                        value: WF_START
                    }, {
                        id: model.PROP.NAME,
                        value: msg( "WF.START_ACT" )
                    }, {
                        id: model.PROP.DISPLAY_SEQUENCE,
                        value: 10
                    } ]
                } );
               middle = new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_ACTIVITY,
                    parentId: self.id,
                    previousComponent: start,
                    values: [ {
                        id: model.PROP.DISPLAY_SEQUENCE,
                        value: 20
                    }, {
                        id: model.PROP.NAME,
                        value: msg( "WF.ACT" )
                    } ]
                } );
                end = new model.Component( {
                    previousComponent: middle,
                    typeId: model.COMP_TYPE.WORKFLOW_ACTIVITY,
                    parentId: self.id,
                    values: [ {
                        id: model.PROP.PAGE_PROCESS_TYPE,
                        value: WF_END
                    }, {
                        id: model.PROP.NAME,
                        value: msg( "WF.END_ACT" )
                    }, {
                        id: model.PROP.DISPLAY_SEQUENCE,
                        value: 30
                    } ]
                } );

                // create links between the activities: start -> middle -> end
                new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_TRANS,
                    parentId: start.id,
                    previousComponent: start,
                    values: [ {
                        id: model.PROP.FROM_WORKFLOW_ACTIVITY,
                        value: start.id
                    }, {
                        id: model.PROP.TO_WORKFLOW_ACTIVITY,
                        value: middle.id
                    } ]
                } );
                new model.Component( {
                    typeId: model.COMP_TYPE.WORKFLOW_TRANS,
                    parentId: middle.id,
                    previousComponent: middle,
                    values: [ {
                        id: model.PROP.FROM_WORKFLOW_ACTIVITY,
                        value: middle.id
                    }, {
                        id: model.PROP.TO_WORKFLOW_ACTIVITY,
                        value: end.id
                    } ]
                } );

                break;
            case model.CALLBACK_ACTION.REMOVED:
                // re-set the state value of all other version components to trigger the validation ( so the error added / cleared )
                model.getComponents( self.typeId, {
                    parentId: self.parentId,
                    properties: [ {
                        id: model.PROP.STATE,
                        value: STATE_DEV
                    } ]
                } ).forEach( ( component ) => {
                    let prop = component.getProperty( model.PROP.STATE );
                    prop.setValue( prop.getValue() );
                } );
                break;
            case model.CALLBACK_ACTION.INIT:
                toggleWorkflowVersionProps.call( this );

        }
    } // componentWorkflowVersion

    function componentWorkflow( action, property ) {
        let self = this;
        syncStaticId( self, action, property );
        if ( action === model.CALLBACK_ACTION.CREATED ) {
            new model.Component( {
                typeId: model.COMP_TYPE.WORKFLOW_VERSION,
                parentId: self.id
            } );
        }
    } // componentWorkflow

    $( document ).on( "modelConfigLoaded", function() {

        const REGION_PLUGINS = model.getComponentType( model.COMP_TYPE.REGION ).pluginConfig.plugins;
        let name;

        // Some component types have to execute additional code if they are created/modified/deleted
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE,                     page );
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE_ITEM,                pageItem );
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE_COMPUTATION,         pageComputation );
        model.setComponentTypeCallback( model.COMP_TYPE.META_TAG,                 pageMetaTag );
        model.setComponentTypeCallback( model.COMP_TYPE.FACET,                    facet );
        model.setComponentTypeCallback( model.COMP_TYPE.FACET_GROUP,              facetGroup );
        model.setComponentTypeCallback( model.COMP_TYPE.FACET_GROUP_ITEM,         facet );
        model.setComponentTypeCallback( model.COMP_TYPE.SFILTER,                  sFilter );
        model.setComponentTypeCallback( model.COMP_TYPE.SFILTER_GROUP,            sFilterGroup );
        model.setComponentTypeCallback( model.COMP_TYPE.SFILTER_GROUP_ITEM,       sFilter );
        model.setComponentTypeCallback( model.COMP_TYPE.BUTTON,                   button );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION,                   region );
        model.setComponentTypeCallback( model.COMP_TYPE.DA_EVENT,                 dynamicActionEvent );
        model.setComponentTypeCallback( model.COMP_TYPE.DA_ACTION,                dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_ACTION_MENU_ENTRY_ACTION, dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_ACTION_BUTTON_ACTION,     dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE_BUTTON_ACTION,              dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.BUTTON_ACTION_MENU_ENTRY_ACTION, dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COL_ACTION_BUTTON_ACTION,     dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY_ACTION, dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_PLUGIN_ATTR,       regionPluginAttr );
        model.setComponentTypeCallback( model.COMP_TYPE.CARD,                     cardAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.CARD_ACTION,              cardAction );
        model.setComponentTypeCallback( model.COMP_TYPE.CARD_BUTTON_ACTION,       dynamicActionAction );
        model.setComponentTypeCallback( model.COMP_TYPE.JET_CHART,                jetChartAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.JET_CHART_SERIES,         jetChartSeries );
        model.setComponentTypeCallback( model.COMP_TYPE.JET_CHART_AXES,           jetChartAxes );
        model.setComponentTypeCallback( model.COMP_TYPE.CLASSIC_REPORT,           classicRptTabularFormAttr );
        model.setComponentTypeCallback( model.COMP_TYPE.CLASSIC_RPT_COLUMN,       classicReportColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.TABULAR_FORM,             classicRptTabularFormAttr );
        model.setComponentTypeCallback( model.COMP_TYPE.TAB_FORM_COLUMN,          tabularFormColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.IG_ATTRIBUTES,            interactiveGridAttr );
        model.setComponentTypeCallback( model.COMP_TYPE.IG_COLUMN,                interactiveGridColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_ATTRIBUTES,            interactiveReportAttr );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_PRINT_ATTR,            printAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COLUMN_GROUP,          irColumnGroup );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COLUMN,                irColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.IG_COLUMN_GROUP,          interactiveGridColumnGroup );
        model.setComponentTypeCallback( model.COMP_TYPE.CLASSIC_RPT_PRINT,        printAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.TAB_FORM_PRINT,           printAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.IG_PRINT,                 printAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.MAP_REGION,               mapRegionAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.MAP_LAYER,                mapLayerAttributes );
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE_PROC_API_PARAM,      processInvokeApiParam );
        model.setComponentTypeCallback( model.COMP_TYPE.PAGE_PROCESS,             pageProcess );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_ACTION,            componentAction );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_ACTION_MENU_ENTRY, componentMenuEntry );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COLUMN_ACTION,         componentAction );
        model.setComponentTypeCallback( model.COMP_TYPE.IR_COL_ACTION_MENU_ENTRY, componentMenuEntry );
        model.setComponentTypeCallback( model.COMP_TYPE.WF_ACTIVITY_API_PARAM,    processInvokeApiParam );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_TMPL_COLUMN,       regionTemplateComponentColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_BRANCH, componentWorkflowBranch,
            [ model.CALLBACK_ACTION.PARENT_UPDATE,
              model.CALLBACK_ACTION.INIT,
              model.CALLBACK_ACTION.PARENT_UPDATE ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_TRANS, componentWorkflowTransition,
            [ model.CALLBACK_ACTION.VALIDATE_COMPONENT,
              model.CALLBACK_ACTION.INIT,
              model.CALLBACK_ACTION.PARENT_UPDATE ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_ACT_VAR, componentWorkflowActivityVariable,
            [ model.CALLBACK_ACTION.PARENT_UPDATE,
              model.CALLBACK_ACTION.INIT ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, componentWorkflowActivity,
            [ model.CALLBACK_ACTION.VALIDATE_COMPONENT,
              model.CALLBACK_ACTION.INIT,
              model.CALLBACK_ACTION.PARENT_UPDATE ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WF_PARALLEL_BRANCH, componentWorkflowParallelBranch,
                [ model.CALLBACK_ACTION.PARENT_UPDATE,
                  model.CALLBACK_ACTION.VALIDATE_COMPONENT,
                  model.CALLBACK_ACTION.INIT ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_PARAM, componentWorkflowParam,
            [ model.CALLBACK_ACTION.PARENT_UPDATE,
              model.CALLBACK_ACTION.INIT ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_VARIABLE, componentWorkflowVariable,
            [ model.CALLBACK_ACTION.PARENT_UPDATE,
              model.CALLBACK_ACTION.INIT ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW_VERSION, componentWorkflowVersion,
            [ model.CALLBACK_ACTION.VALIDATE_COMPONENT,
              model.CALLBACK_ACTION.INIT ] );
        model.setComponentTypeCallback( model.COMP_TYPE.WORKFLOW, componentWorkflow );
        model.setComponentTypeCallback( model.COMP_TYPE.REGION_TMPL_COLUMN, regionTemplateComponentColumn );
        model.setComponentTypeCallback( model.COMP_TYPE.BUTTON_MENU_ENTRY, componentMenuEntry );
        model.setComponentTypeCallback( model.COMP_TYPE.SEARCH_REGION_SOURCE, searchRegionSource );
        model.setComponentTypeCallback( model.COMP_TYPE.VALIDATION, pageValidation );

        // Register a default handling for region types which use columns
        for ( name in REGION_PLUGINS ) {
            if ( hasOwnProperty( REGION_PLUGINS, name ) && $.inArray( "COLUMNS", REGION_PLUGINS[ name ].features ) !== -1 ) {
                model.setPluginCallback( model.COMP_TYPE.REGION, name, regionPluginWithColumns );
            }
        }

        // Register a default handling for template component region plug-ins
        for ( name in REGION_PLUGINS ) {
            if ( hasOwnProperty( REGION_PLUGINS, name ) && /^(TMPL)/.test( name ) ) {
                model.setPluginCallback( model.COMP_TYPE.REGION, name, templateComponentRegionPlugin );
            }
        }

        // Some plug-ins need extra handling if the region type or source property gets changed
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_CARDS",                cardPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, REGION_TYPE.IG,                interactiveGridPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_IR",                   interactiveReportPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_SQL_REPORT",           classicReportPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_TABFORM",              tabularFormPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_JET_CHART",            jetChartPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_MAP_REGION",           mapRegionPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_CALENDAR",             legacyCalendarPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, REGION_TYPE.FORM,              formPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, "NATIVE_SEARCH_REGION",        searchRegionPlugin );
        model.setPluginCallback( model.COMP_TYPE.REGION, REGION_TYPE.FACETED_SEARCH,    facetedSearchOrSmartFilters );
        model.setPluginCallback( model.COMP_TYPE.REGION, REGION_TYPE.SMART_FILTERS,     facetedSearchOrSmartFilters );

        model.setPluginCallback( model.COMP_TYPE.DA_ACTION, "NATIVE_SET_VALUE",         setValuePlugin );

        // Some plug-ins need extra handling if the item type gets changed
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.RICH_TEXT_EDITOR, nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.TEXTAREA,         nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.SHUTTLE,          nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.MARKDOWN_EDITOR,  nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.FILE,             nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.IMAGE_UPLOAD,     nativeItemPlugins );
        model.setPluginCallback( model.COMP_TYPE.PAGE_ITEM, ITEM_TYPE.SELECT_LIST,      selectListPlugin );

        // Some plug-ins need extra handling if the smart filter type gets changed
        model.setPluginCallback( model.COMP_TYPE.SFILTER,   ITEM_TYPE.INPUT,            inputPlugin );
        model.setPluginCallback( model.COMP_TYPE.SFILTER,   ITEM_TYPE.RANGE,            rangePlugin );
        model.setPluginCallback( model.COMP_TYPE.SFILTER,   ITEM_TYPE.RADIOGROUP,       radioGroupFilterPlugin );

        // Some plug-ins need extra handling if the facet type gets changed
        model.setPluginCallback( model.COMP_TYPE.FACET,     ITEM_TYPE.INPUT,            inputPlugin );
        model.setPluginCallback( model.COMP_TYPE.FACET,     ITEM_TYPE.RANGE,            rangePlugin );
        model.setPluginCallback( model.COMP_TYPE.FACET,     ITEM_TYPE.RADIOGROUP,       radioGroupFilterPlugin );

        // Some plug-ins need extra handling if the process type gets changed
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, "NATIVE_WEB_SERVICE",         webServiceProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, "NATIVE_WEB_SERVICE_LEGACY",  webServiceProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, "NATIVE_PLSQL",               plsqlProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, "NATIVE_SEND_EMAIL",          sendEmailProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, "NATIVE_CREATE_TASK",         createTaskProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, PROCESS_TYPE.INVOKE_API,      invokeApiPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, PROCESS_TYPE.EXECUTION_CHAIN, executionChainPlugin );
        model.setPluginCallback( model.COMP_TYPE.PAGE_PROCESS, PROCESS_TYPE.WORKFLOW,        workflowProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, "NATIVE_CREATE_TASK",    createTaskProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, PROCESS_TYPE.INVOKE_API, invokeApiPlugin );
        model.setPluginCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, "NATIVE_SEND_EMAIL",     sendEmailProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, "NATIVE_PLSQL",          plsqlProcessPlugin );
        model.setPluginCallback( model.COMP_TYPE.WORKFLOW_ACTIVITY, PROCESS_TYPE.INVOKE_WF,  invokeWorkflowProcessPlugin );

    } );

    $( document ).on( "modelReady modelSaved", function() {
        const COMPONENTS = [ {
            typeId: model.COMP_TYPE.WORKFLOW_VERSION
        }, {
            typeId: model.COMP_TYPE.WORKFLOW_VARIABLE
        }, {
            typeId: model.COMP_TYPE.WORKFLOW_ACTIVITY
        }, {
            typeId: model.COMP_TYPE.WORKFLOW_ACT_VAR
        }, {
            typeId: model.COMP_TYPE.WORKFLOW_PARAM
        }, {
            typeId: model.COMP_TYPE.WORKFLOW_TRANS
        } ];
        model.getComponentsAdvanced( COMPONENTS ).forEach( component => {
            component._callComponentTypeCallback( { action: model.CALLBACK_ACTION.INIT } );
        } );

    } );

} )( window.pe, apex.jQuery, apex.util, apex.locale, apex.lang, window.pageDesigner, apex.date, apex.builder );

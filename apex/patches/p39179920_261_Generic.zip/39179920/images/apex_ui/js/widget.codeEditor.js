(() => {
  // images/apex_ui/js/code-editor/languages/fileurls.mjs
  var registerCommon = (langId5) => {
    monaco.languages.register({ id: langId5 });
    monaco.languages.setLanguageConfiguration(langId5, {
      // needed by the Comment Out shortcuts
      comments: {
        lineComment: "--",
        blockComment: ["/*", "*/"]
      },
      brackets: [["[", "]"]]
    });
    monaco.languages.setMonarchTokensProvider(langId5, {
      tokenizer: {
        root: [
          { include: "@whitespace" },
          [/^\[.+?\]/, "variable"]
          // highlight the url hints [...]
        ],
        whitespace: [
          [/\/\*/, "comment", "@comment"],
          [/^--.*$/, "comment"],
          [/#(MIN|MIN_DIRECTORY)#/, "string"],
          [/#(APEX|APP|WORKSPACE|PLUGIN|THEME|THEME_DB)_FILES#/, "string"],
          [/#APP_VERSION#/, "string"]
        ],
        comment: [
          // slightly over-escaping on purpose
          // else the syntax highlighting for this file would be broken in some IDEs
          // eslint-disable-next-line no-useless-escape
          [/[^\/\*]+/, "comment"],
          [/\*\//, "comment", "@pop"],
          // eslint-disable-next-line no-useless-escape
          [/[\/\*]/, "comment"]
        ]
      }
    });
    monaco.languages.registerCompletionItemProvider(langId5, {
      triggerCharacters: ["#"],
      provideCompletionItems: function(model, position, context) {
        if (context.triggerCharacter === "#") {
          const wordUntilPosition = model.getWordUntilPosition(position);
          return {
            suggestions: [
              "#MIN#",
              "#MIN_DIRECTORY#",
              "#APEX_FILES#",
              "#APP_FILES#",
              "#WORKSPACE_FILES#",
              "#PLUGIN_FILES#",
              "#THEME_FILES#",
              "#THEME_DB_FILES#",
              "#APP_VERSION#"
            ].map((sub) => {
              return {
                label: sub,
                insertText: sub,
                kind: monaco.languages.CompletionItemKind.Keyword,
                range: {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: wordUntilPosition.startColumn - 1,
                  endColumn: wordUntilPosition.endColumn
                }
              };
            })
          };
        } else {
          return void 0;
        }
      }
    });
  };
  var registerUrlHintsCallback = (langId5, callback) => {
    monaco.languages.registerCompletionItemProvider(langId5, {
      triggerCharacters: ["[", ",", " "],
      provideCompletionItems: function(model, position) {
        const lineContent = model.getLineContent(position.lineNumber), wordUntilPosition = model.getWordUntilPosition(position);
        if (!lineContent.slice(0, position.column - 1).startsWith("[") || !lineContent.slice(position.column - 1).includes("]")) {
          return void 0;
        }
        const suggestions = callback(lineContent);
        return {
          suggestions: suggestions.map((suggestion) => {
            return {
              ...suggestion,
              range: {
                startLineNumber: position.lineNumber,
                endLineNumber: position.lineNumber,
                startColumn: wordUntilPosition.startColumn,
                endColumn: wordUntilPosition.endColumn
              }
            };
          })
        };
      }
    });
  };

  // images/apex_ui/js/code-editor/languages/fileurls-js.mjs
  var langId = "file-urls-javascript";
  var register = () => {
    registerCommon(langId);
    registerUrlHintsCallback(langId, (lineContent) => {
      let currentHints = [];
      const match = lineContent.match(/^\[(.*)\].*/);
      if (match) {
        currentHints = match[1].split(",").map((hint) => hint.trim());
      }
      const suggestions = [
        { label: "module", insertText: "module" },
        { label: "async", insertText: "async" },
        { label: "defer", insertText: "defer" },
        { label: "require requirejs", insertText: "require requirejs" },
        { label: "require jet", insertText: "require jet" },
        { label: "define", insertText: "define ${1:moduleName}=${2:globalObject}" }
      ].filter((hint) => !currentHints.includes(hint.label));
      return suggestions.map((suggestion) => {
        return {
          label: suggestion.label,
          insertText: suggestion.insertText,
          kind: monaco.languages.CompletionItemKind.Keyword,
          insertTextRules: suggestion.insertText.includes("${") ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : void 0
        };
      });
    });
  };

  // images/apex_ui/js/code-editor/languages/fileurls-css.mjs
  var langId2 = "file-urls-css";
  var register2 = () => {
    registerCommon(langId2);
    registerUrlHintsCallback(langId2, () => {
      return [{
        label: "media",
        insertText: 'media="${1}"',
        kind: monaco.languages.CompletionItemKind.Keyword,
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet
      }];
    });
  };

  // images/apex_ui/js/code-editor/languages/sql.mjs
  var langId3 = "sql";
  var register3 = () => {
    monaco.languages.register({ id: langId3 });
    monaco.languages.setLanguageConfiguration(langId3, {
      comments: {
        lineComment: "--",
        blockComment: ["/*", "*/"]
      },
      brackets: [
        ["{", "}"],
        ["[", "]"],
        ["(", ")"]
      ],
      autoClosingPairs: [
        { open: "{", close: "}" },
        { open: "[", close: "]" },
        { open: "(", close: ")" },
        { open: '"', close: '"' },
        { open: "'", close: "'" }
      ],
      surroundingPairs: [
        { open: "{", close: "}" },
        { open: "[", close: "]" },
        { open: "(", close: ")" },
        { open: '"', close: '"' },
        { open: "'", close: "'" }
      ]
    });
    monaco.languages.setMonarchTokensProvider(langId3, {
      defaultToken: "",
      tokenPostfix: ".sql",
      ignoreCase: true,
      brackets: [
        { open: "[", close: "]", token: "delimiter.square" },
        { open: "(", close: ")", token: "delimiter.parenthesis" }
      ],
      // keywords without duplicated of atoms, datatypes or builtinFunctions
      keywords: [
        // all keywords from v$reserved_words with length > 1
        "CASE",
        "SYS_OP_TRTB",
        "INTERVAL",
        "CALL",
        "RULE",
        "CSCONVERT",
        "ENQUEUE",
        "NORELOCATE",
        "ADG_REDIRECT_PLSQL",
        "ANALYZE",
        "NO_GBY_PUSHDOWN",
        "RANDOM",
        "LOBS",
        "QUEUE_CURR",
        "PATH_PREFIX",
        "UNIXTIME",
        "APPROX_COUNT",
        "OR",
        "NOMINVALUE",
        "GLOBAL_NAME",
        "CUBE_AJ",
        "QUORUM",
        "XMLINDEX_REWRITE",
        "SYSBACKUP",
        "NEVER",
        "STATS_F_TEST",
        "CLASS",
        "ARRAYS",
        "CREATE",
        "NO_DIST_AGG_PROLLUP_PUSHDOWN",
        "SORT",
        "AVRO",
        "REDACTION",
        "ENABLE_PRESET",
        "FROM",
        "CLONE",
        "CONTINUE",
        "SEQUENCED",
        "SYS_XMLINSTR",
        "NO_USE_CUBE",
        "BACKUP",
        "FORCE",
        "TRANSITION",
        "TO_ACLID",
        "NOMINIMIZE",
        "NLJ_PREFETCH",
        "FETCH",
        "NO_BIND_AWARE",
        "SYS_XQERRH",
        "REMOVE",
        "DATA",
        "SYS_XQFTCONTAIN",
        "ACTIVE_DATA",
        "MERGE_AJ",
        "PUBLIC",
        "SYS_OP_CSX_PATCH",
        "AUTOALLOCATE",
        "CPU_COUNT",
        "TO_BLOB",
        "PERCENT_RANK",
        "SYS_OP_PARGID",
        "TABLESPACE",
        "SYS_XMLNODEID_GETCID",
        "NO_SET_TO_JOIN",
        "XID",
        "REFTORAW",
        "USE_HASH_GBY_FOR_PUSHDOWN",
        "DATA_SECURITY_REWRITE_LIMIT",
        "WITH_PLSQL",
        "SYS_XQEXSTWRP",
        "TRACE",
        "LIFECYCLE",
        "ACTIVE",
        "PURGE",
        "NO_PQ_CONCURRENT_UNION",
        "STATS_T_TEST_ONE",
        "SOURCE_FILE_DIRECTORY",
        "UNION",
        "XMLTOKENSET",
        "CURRENT_SCHEMA",
        "UTF16LE",
        "CROSSEDITION",
        "JSON_SERIALIZE",
        "ENCRYPTION",
        "NO_RESULT_CACHE",
        "CASCADE",
        "NO_PLACE_GROUP_BY",
        "SYS_OP_ENFORCE_NOT_NULL$",
        "GROUP_BY",
        "BITMAP_AND",
        "AUTHID",
        "DEDUPLICATE",
        "VERSIONS_STARTSCN",
        "SYS_OP_VREF",
        "UNTIL",
        "LOG_READ_ONLY_VIOLATIONS",
        "LIST",
        "NO_PULL_PRED",
        "NLJ_BATCHING",
        "LINK",
        "BUFFER_POOL",
        "NO_USE_SCALABLE_GBY_INVDIST",
        "DISABLE_CONTAINER_MAP",
        "ACTIONS",
        "LEAF",
        "DML_UPDATE",
        "SYS_OP_BLOOM_FILTER",
        "NOSORT",
        "RECOVERABLE",
        "SYS_OP_VECBIT",
        "DISCONNECT",
        "V2",
        "PATHS",
        "TRUSTED",
        "DATASTORE",
        "TO_APPROX_PERCENTILE",
        "SUBSTRC",
        "DATAOBJ_TO_MAT_PARTITION",
        "KEYSTORE",
        "SYS_SC_2_XMLT",
        "PHV",
        "NATIVE",
        "MINIMUM",
        "NO_CPU_COSTING",
        "MAXSIZE",
        "AUTO_LOGIN",
        "NO_SUBQUERY_PRUNING",
        "SYS_OP_UNDESCEND",
        "STANDBY_MAX_DATA_DELAY",
        "JSONGET",
        "STATS_T_TEST_INDEPU",
        "PLSQL_WARNINGS",
        "SAVE",
        "TIMEZONE_REGION",
        "SYS_OP_VECOR",
        "LAST",
        "SUBSTR4",
        "SYS_OP_ROWIDTOOBJ",
        "NO_USE_HASH_AGGREGATION",
        "NOENTITYESCAPING",
        "BYTE",
        "CUBE_SJ",
        "ELIM_GROUPBY",
        "INDEX_SS",
        "NOWAIT",
        "FLOB",
        "NOGUARANTEE",
        "NO_BAND_JOIN",
        "FEATURE",
        "SYS_XQEXLOBVAL",
        "SID",
        "ENCRYPT",
        "SYS_XQESHTMLURI",
        "APPEND_VALUES",
        "XMLTOJSON",
        "SYS_OP_NII",
        "RETRY_ON_ROW_CHANGE",
        "MATERIALIZE",
        "LOGMINING",
        "DOMAIN_INDEX_NO_SORT",
        "SYS_XQSEQDEEPEQ",
        "FINE",
        "FBTSCAN",
        "MEMOPTIMIZE_WRITE",
        "TO",
        "SYS_OP_HCS_TABLE",
        "POOL_16K",
        "SYS_XQ_ATOMCNVCHK",
        "SUBSTR2",
        "STORAGE",
        "VALIDATE",
        "MERGE",
        "CLUSTER_DISTANCE",
        "BINARY_DOUBLE_NAN",
        "RESOLVE",
        "NO_USE_NL",
        "COMMON",
        "SYS_XQPOLYMOD",
        "XMLISVALID",
        "REFERENCED",
        "ANYSCHEMA",
        "OLD",
        "QUARANTINE",
        "PIV_SSF",
        "APPROX_PERCENTILE_AGG",
        "ORA_INVOKING_XS_USER_GUID",
        "MODEL_DONTVERIFY_UNIQUENESS",
        "PCTFREE",
        "BEGIN",
        "NO_DOMAIN_INDEX_FILTER",
        "TIMEZONE_MINUTE",
        "CON_ID",
        "RESIZE",
        "ANSI_REARCH",
        "INDEXES",
        "SYS_OP_PART_ID",
        "RECONNECT",
        "RDBA",
        "SHARD",
        "SYS_OP_RMTD",
        "LINEAR",
        "FAILGROUP",
        "FTP",
        "SYS_XQPOLYSUB",
        "BINARY_DOUBLE_INFINITY",
        "ANTIJOIN",
        "VALUES",
        "WRAPPER",
        "VECTOR",
        "ADD_COLUMN",
        "PARALLEL",
        "FOLLOWING",
        "MAXIMIZE",
        "DAY",
        "NO_DST_UPGRADE_INSERT_CONV",
        "EQUIPART",
        "NEW",
        "REJECT",
        "INDICATOR",
        "OFFSET",
        "RANKM",
        "DEFAULT",
        "INDEX_COMBINE",
        "DDL",
        "SERVICES",
        "UPDATEXML",
        "NO_CLUSTERING",
        "PLSQL_CODE_TYPE",
        "XS",
        "CRASH",
        "NLJ_INDEX_FILTER",
        "CONNECT_BY_FILTERING",
        "JSON_OBJECTAGG",
        "BITMAP_BIT_POSITION",
        "HIGH",
        "STARTUP",
        "RBA",
        "IMPACT",
        "HIDE",
        "REGR_AVGY",
        "ERROR_ARGUMENT",
        "SYS_XQRYVARGET",
        "GRANT",
        "LOB",
        "WITH",
        "ISOLATION",
        "HOST",
        "REDUNDANCY",
        "NO_XML_DML_REWRITE",
        "SYS_OP_MAKEOID",
        "PARTITION_RANGE",
        "NO_UNNEST",
        "RECORDS_PER_BLOCK",
        "VISIBILITY",
        "USE_HASH",
        "ESCAPE",
        "REF",
        "FEATURE_ID",
        "NLS_SPECIAL_CHARS",
        "OMIT",
        "MISSING",
        "SCRUB",
        "SYS_PXQEXTRACT",
        "COMMIT",
        "MATCH_NUMBER",
        "DETERMINED",
        "BATCHSIZE",
        "ISOLATION_LEVEL",
        "FREELIST",
        "NOREVERSE",
        "CAPTION",
        "COARSE",
        "SYS_OP_COUNTCHG",
        "TABLE",
        "MANAGEMENT",
        "SYS_OP_GROUPING",
        "HOUR",
        "NO_FILTERING",
        "ORDER_SUBQ",
        "NO_BUSHY_JOIN",
        "DENSE_RANKM",
        "NOMAPPING",
        "MODIFY",
        "SYS_XMLTRANSLATE",
        "ACCOUNT",
        "CORRUPTION",
        "CLAUSE",
        "LOGICAL_READS_PER_CALL",
        "LEAD_DIFF",
        "IO_REQUESTS",
        "CONFIRM",
        "PUSH_HAVING_TO_GBY",
        "OTHER",
        "SD_SHOW",
        "INDEX_STATS",
        "RESTART",
        "SYS_CHECK_PRIVILEGE",
        "INDEX_ASC",
        "COLUMNS",
        "ROWDEPENDENCIES",
        "ALTER",
        "OR_PREDICATES",
        "LOCALTIME",
        "CHECK_ACL_REWRITE",
        "CPU_COSTING",
        "NL_AJ",
        "STREAM",
        "XMLDIFF",
        "SERVERERROR",
        "DEFERRED",
        "AVCACHE_OP",
        "COMPILE",
        "PASSWORD_REUSE_MAX",
        "DELETEXML",
        "DATAMOVEMENT",
        "ORA_CHECK_PRIVILEGE",
        "APPROX_RANK",
        "PRECOMPUTE_SUBQUERY",
        "SELECT",
        "NO_REF_CASCADE",
        "DISABLE_PRESET",
        "NO_SQL_TUNE",
        "COLUMN_AUTHORIZATION_INDICATOR",
        "SYS_FILTER_ACLS",
        "VECTOR_READ_TRACE",
        "CLUSTER_BY_ROWID",
        "SHARDS",
        "SYS_OP_PAR_1",
        "NOPARALLEL_INDEX",
        "DEALLOCATE",
        "NO_MULTIMV_REWRITE",
        "EXPORT",
        "NLSSORT",
        "SWITCH",
        "APPLY",
        "BEFORE",
        "ORA_INVOKING_USER",
        "SYS_XMLNODEID",
        "IDLE_TIME",
        "STATEMENT_QUEUING",
        "FREELISTS",
        "ROUND_TIES_TO_EVEN",
        "WORK",
        "OUTLINE",
        "WEEK",
        "JSON_OBJECT",
        "FRESH",
        "PREVIOUS",
        "SYS_OP_NTCIMG$",
        "OBJ_ID",
        "INTERPRETED",
        "PERCENTILE_DISC",
        "UNDROP",
        "ROLLUP",
        "MODEL_PUSH_REF",
        "COPY",
        "FLASH_CACHE",
        "MAXTRANS",
        "SB4",
        "SYS_XQDOC",
        "TIES",
        "STANDBY",
        "PASSWORD_LIFE_TIME",
        "SYS_OP_LBID",
        "ANY",
        "RESPECT",
        "MAPPER",
        "ROLESET",
        "FORCE_XML_QUERY_REWRITE",
        "HIER_WINDOW",
        "CFILE",
        "UNDER",
        "SKIP_EXT_OPTIMIZER",
        "MINUTE",
        "UNNEST_NOSEMIJ_NODISTINCTVIEW",
        "ROWS",
        "BITMAP_TREE",
        "OCCURRENCES",
        "COLLECT",
        "MIGRATE",
        "LOBNVL",
        "CPU_PER_SESSION",
        "ORA_GET_ACLIDS",
        "SMALLFILE",
        "SYS_DL_CURSOR",
        "ASSEMBLY",
        "NO_ROOT_SW_FOR_LOCAL",
        "PRIVILEGE",
        "SKIP",
        "DEGREE",
        "ZONEMAP",
        "ANALYTIC",
        "STATE",
        "REPAIR",
        "SYS_OP_COMBINED_HASH",
        "STRUCTURE",
        "CRITICAL",
        "NO_TEMP_TABLE",
        "ENTERPRISE",
        "STRIPE_COLUMNS",
        "PATCH",
        "LDAP_REGISTRATION_ENABLED",
        "ORA_DM_PARTITION_NAME",
        "VERIFY",
        "NO_STATS_GSETS",
        "XMLCONCAT",
        "MERGE$ACTIONS",
        "ELIMINATE_JOIN",
        "SYS_XQFNDATIM",
        "FUNCTIONS",
        "FIRST_ROWS",
        "GROUP",
        "COMPONENT",
        "APPLICATION",
        "PACKAGES",
        "CONNECT_BY_COMBINE_SW",
        "DISASSOCIATE",
        "UB2",
        "PUSH_SUBQ",
        "SITE",
        "UNCONDITIONAL",
        "ORA_RAWCONCAT",
        "AUTOEXTEND",
        "CONTROLFILE",
        "DEREF_NO_REWRITE",
        "COMPOUND",
        "SYS_MAKE_XMLNODEID",
        "COLD",
        "DISABLE_PARALLEL_DML",
        "CORRUPT_XID",
        "UPGRADE",
        "DISABLE_CONTAINERS_DEFAULT",
        "TEST",
        "SUBQUERY_PRUNING",
        "EXPIRE",
        "NAN",
        "IDENTIFIED",
        "CLUSTER_SET",
        "TO_NCHAR",
        "ELIMINATE_OUTER_JOIN",
        "ENCODE",
        "SYS_ET_RAW_TO_BFILE",
        "COLUMN_AUTH_INDICATOR",
        "MODIFICATION",
        "MAX_PDB_SNAPSHOTS",
        "IMPORT",
        "USE_CONCAT",
        "COOKIE",
        "REGISTER",
        "LABEL",
        "SYS_XMLGEN",
        "CLOSE",
        "INITRANS",
        "NO_VECTOR_TRANSFORM",
        "SYS_OP_VECXOR",
        "SYS_OP_XPTHIDX",
        "PASSWORD_REUSE_TIME",
        "SYS_ET_IMAGE_TO_BLOB",
        "HELP",
        "COMPUTE",
        "KEEP_DUPLICATES",
        "SIBLINGS",
        "TO_BINARY_FLOAT",
        "EXEMPT",
        "INCLUDE_VERSION",
        "NO_ELIMINATE_OUTER_JOIN",
        "SYS_OP_DUMP",
        "CURSOR",
        "JSON_MERGEPATCH",
        "SYS_XQSEQINSB",
        "NO_INDEX",
        "IGNORE_OPTIM_EMBEDDED_HINTS",
        "FEATURE_VALUE",
        "RAWTOREF",
        "PROFILE",
        "LIKEC",
        "SYS_ET_BLOB_TO_IMAGE",
        "CONST",
        "EXCLUDING",
        "NETWORK",
        "ORA_DST_CONVERT",
        "XML",
        "REGR_AVGX",
        "NO_BATCH_TABLE_ACCESS_BY_ROWID",
        "UNLOAD",
        "MAP",
        "NLS_LANGUAGE",
        "CONTAINER_MAP_OBJECT",
        "FULL_OUTER_JOIN_TO_OUTER",
        "JSONPARSE",
        "PREV",
        "SYS_CHECKACL",
        "STATS_T_TEST_PAIRED",
        "NO_ADAPTIVE_PLAN",
        "SOME",
        "HTTP",
        "NO_REWRITE",
        "NO_INMEMORY_PRUNING",
        "REGR_R2",
        "NO_LOAD",
        "MODIFY_COLUMN_TYPE",
        "CHOOSE",
        "SYS_XQFORMATNUM",
        "GATHER_OPTIMIZER_STATISTICS",
        "NO_GATHER_OPTIMIZER_STATISTICS",
        "SYS_TYPEID",
        "WALLET",
        "HINTSET_END",
        "ELEMENT",
        "NEXT",
        "INDEX_DESC",
        "INDENT",
        "RESTRICT_ALL_REF_CONS",
        "SCHEMA",
        "ASYNCHRONOUS",
        "OVERFLOW_NOMOVE",
        "CANCEL",
        "SYS_RAW_TO_XSID",
        "CO_AUTH_IND",
        "WITHIN",
        "NATIONAL",
        "OID",
        "SYS_XMLNODEID_GETSVAL",
        "SYS_XQPOLYCST",
        "BITMAPS",
        "NO_BUFFER",
        "SAVE_AS_INTERVALS",
        "SYS_OP_PIVOT",
        "CLEAN",
        "RETENTION",
        "CON_ID_TO_CON_NAME",
        "UTF16BE",
        "ORA_CONCAT_RWKEY",
        "DEFERRABLE",
        "MANAGER",
        "TAG",
        "PULL_PRED",
        "SYS_XMLNODEID_GETLOCATOR",
        "UNUSABLE",
        "QUIESCE",
        "REMOTE_MAPPED",
        "SYS_XQSEQ2CON",
        "CURSOR_SPECIFIC_SEGMENT",
        "OUTLINE_LEAF",
        "CONDITIONAL",
        "CPU_TIME",
        "USING",
        "AUTO_REOPTIMIZE",
        "DIRECT_LOAD",
        "SYS_MKXTI",
        "PACKAGE",
        "SYS_OP_BL2R",
        "SYS_OP_CONVERT",
        "LEAD_CDB_URI",
        "REFRESH",
        "READ_OR_WRITE",
        "NUM_INDEX_KEYS",
        "OLAP",
        "FIXED_VIEW_DATA",
        "LAX",
        "PQ_MAP",
        "DML",
        "NOLOGGING",
        "INITIAL",
        "SUBSTITUTABLE",
        "SYS_XQFNNSURI",
        "AV_CACHE",
        "CONNECT",
        "SYS_OP_PARGID_1",
        "PRECEDES",
        "PROGRAM",
        "MEMBER",
        "GET",
        "OLD_PUSH_PRED",
        "SUSPEND",
        "NO_USE_PARTITION_WISE_DISTINCT",
        "VIEW",
        "SYS_CTX_CONTAINS2",
        "INDEX_JOIN",
        "PROXY",
        "SEG_FILE",
        "SYS_XQPFXFRMQNM",
        "MAX_DIAG_SIZE",
        "SYS_CTX_MKIVIDX",
        "PRECEDING",
        "NESTED_TABLE_ID",
        "PQ_DISTRIBUTE",
        "UNPLUG",
        "USE",
        "MASTER",
        "VERIFIER",
        "DISTINCT",
        "ITERATION_NUMBER",
        "PASSWORDFILE_METADATA_CACHE",
        "UNPROTECTED",
        "SPFILE",
        "BAND_JOIN",
        "SYS_XQFNPREDTRUTH",
        "ALIAS",
        "SIGNAL_COMPONENT",
        "NOAUDIT",
        "SYS_XMLTYPE2SQL",
        "SET",
        "USE_HIDDEN_PARTITIONS",
        "SYS_XMLCONTAINS",
        "NOARCHIVELOG",
        "NO_SQL_TRANSLATION",
        "SHUTDOWN",
        "STATS_MODE",
        "SDO_GEOM_MAX_X",
        "ADG_REDIRECT_DML",
        "AS_JSON",
        "NO_FULL_OUTER_JOIN_TO_OUTER",
        "SYS_XQRESVURI",
        "END_OUTLINE_DATA",
        "COMMON_DATA_MAP",
        "HIER_ANCESTOR",
        "SESSIONS_PER_USER",
        "SOURCE",
        "NAV",
        "ESTIMATE",
        "BY",
        "WHITESPACE",
        "NOCYCLE",
        "NLS_NUMERIC_CHARACTERS",
        "NLS_COLLATION_ID",
        "CREATE_STORED_OUTLINES",
        "FAILOVER",
        "JSON",
        "FORCE_SPATIAL",
        "ALL_ROWS",
        "MEASURES",
        "END",
        "SYS_PLSQL_IO",
        "SYS_OP_MAP_NONNULL",
        "ABSENT",
        "DV",
        "SYS_XQPOLYUPLS",
        "PARTITION_CONTAINED",
        "SDO_GEOM_MAX_Z",
        "TEXT",
        "SYS_DM_RXFORM_NUM",
        "BUFFER_CACHE",
        "MINING",
        "SHARE_OF",
        "MONTH",
        "OIDINDEX",
        "PRIMARY",
        "EMPTY",
        "NLS_TERRITORY",
        "ERROR_ON_OVERLAP_TIME",
        "KILL",
        "TABLE_STATS",
        "DEFINED",
        "XMLTSET_DML_ENABLE",
        "OVER",
        "JSON_EXISTS",
        "SIMPLE",
        "RANDOM_LOCAL",
        "RULES",
        "CALLBACK",
        "INSERTCHILDXMLAFTER",
        "TENANT_ID",
        "NO_EXPAND_TABLE",
        "CURRENT_INSTANCE",
        "REGR_SLOPE",
        "STATS_CROSSTAB",
        "SERIALIZABLE",
        "OWN",
        "TO_BINARY_DOUBLE",
        "INHERIT",
        "OPCODE",
        "SYS_OP_KEY_VECTOR_FILTER",
        "SEG_BLOCK",
        "ENTRY",
        "NO_DATA_SECURITY_REWRITE",
        "SYS_XQPOLYVNE",
        "SYS_OP_VVD",
        "SYS_FNMATCHES",
        "NO_COST_XML_QUERY_REWRITE",
        "NONBLOCKING",
        "AUDIT",
        "ROW",
        "TIME",
        "CLUSTER_PROBABILITY",
        "PORT",
        "SUBSET",
        "METHOD",
        "COMPACT",
        "CLUSTER_DETAILS",
        "ORDER",
        "XMLFOREST",
        "TOKEN",
        "SHRINK",
        "SYS_XQNSP4PFX",
        "NO_USE_VECTOR_AGGREGATION",
        "SCHEMACHECK",
        "PCTINCREASE",
        "ADAPTIVE_PLAN",
        "USE_PARTITION_WISE_GBY",
        "GLOBAL_TOPIC_ENABLED",
        "REWRITE_OR_ERROR",
        "SECUREFILE_DBA",
        "ARRAY",
        "OPT_PARAM",
        "ORA_CLUSTERING",
        "SDO_GEOM_MIN_Y",
        "MINUS",
        "INSERTCHILDXML",
        "FACTORIZE_JOIN",
        "PRIOR",
        "ASC",
        "USERGROUP",
        "NO_XML_QUERY_REWRITE",
        "RESTORE",
        "ALTERNATE",
        "DOMAIN_INDEX_SORT",
        "NLS_CALENDAR",
        "SYS_ROW_DELTA",
        "SEQUENTIAL",
        "HIER_MEMBER_UNIQUE_NAME",
        "GROUPS",
        "INFINITE",
        "INSERTXMLBEFORE",
        "WRITE",
        "INDEX_ROWS",
        "CREATE_FILE_DEST",
        "PCTTHRESHOLD",
        "SYS_XQ_PKSQL2XML",
        "NOSCHEMACHECK",
        "VERSIONS",
        "SYS_XQPOLYDIV",
        "ORA_ROWSCN_RAW",
        "NO_MONITOR",
        "ROLLBACK",
        "SYS_PATHID_LASTNMSPC",
        "TIMEZONE_HOUR",
        "SHELFLIFE",
        "SYS_XQENDSWITH",
        "INCLUDE",
        "SYS_XQINSERT",
        "FAR",
        "BITMAP_COUNT",
        "REGR_SXX",
        "ALL",
        "EXPLOSION",
        "DOWNGRADE",
        "RELOCATE",
        "MONITORING",
        "POWERMULTISET",
        "ARCHIVELOG",
        "LIFE",
        "PROPERTY",
        "GUARANTEED",
        "RECYCLEBIN",
        "MAXLOGFILES",
        "DST_UPGRADE_INSERT_CONV",
        "JSON_TEXTCONTAINS2",
        "TRIGGERS",
        "ORGANIZATION",
        "XMLCOMMENT",
        "MULTIDIMENSIONAL",
        "TIER",
        "INCREMENT",
        "REQUIRED",
        "RELY",
        "FREE",
        "PROCEDURAL",
        "CLOSE_CACHED_OPEN_CURSORS",
        "DIRECTORY",
        "NLS_CHARSET_DECL_LEN",
        "SHARDSPACE",
        "LOW",
        "BINARY_FLOAT_INFINITY",
        "SPLIT",
        "DROP",
        "DISABLE",
        "UNQUIESCE",
        "HIERARCHICAL",
        "NO_SWAP_JOIN_INPUTS",
        "SUBPARTITION",
        "SYSASM",
        "REKEY",
        "SYS_XQSTRJOIN",
        "EXPAND",
        "WITH_EXPRESSION",
        "RESTRICT",
        "SYS_XQNSPFRMQNM",
        "SYS_XQINDXOF",
        "FACTOR",
        "SYS_OP_REF",
        "LOGICAL",
        "SYS_OP_XMLCONS_FOR_CSX",
        "INPLACE",
        "ID",
        "DATE_MODE",
        "NULLS",
        "DISALLOW",
        "AND",
        "SYS_FNREPLACE",
        "SYS_XMLI_LOC_ISTEXT",
        "TYPE",
        "ADD",
        "NO_OR_EXPAND",
        "OLS",
        "NO_INMEMORY",
        "NO_TABLE_LOOKUP_BY_NL",
        "NO_NLJ_BATCHING",
        "LOCK",
        "JAVA",
        "!=",
        "SYS_XQMKNODEREF",
        "DIRECT_PATH",
        "ENABLE",
        "KEYS",
        "BLOCK",
        "BLOCKSIZE",
        "XMLEXISTS2",
        "MODEL_NO_ANALYSIS",
        "HIER_MEMBER_NAME",
        "VARRAY",
        "XDB_FASTPATH_INSERT",
        "INACTIVE_ACCOUNT_TIME",
        "SYS_XMLCONV",
        "COMPOSITE_LIMIT",
        "ACTIVITY",
        "NO_SUBSTRB_PAD",
        "SEVERE",
        "DATAPUMP",
        "NO",
        "SCOPE",
        "COST",
        "OR_EXPAND",
        "COMPLIANCE",
        "INTERSECT",
        "ADD_GROUP",
        "XMLPI",
        "TIME_ZONE",
        "MODEL",
        "STATS_BINOMIAL_TEST",
        "NLS_LOWER",
        "DYNAMIC_SAMPLING_EST_CDN",
        "SYS_XQBASEURI",
        "HAVING",
        "INDEX_RS_ASC",
        "ON",
        "ROLES",
        "NO_COALESCE_SQ",
        "SCHEDULER",
        "PARTITIONS",
        "SYS_OP_DV_CHECK",
        "DELEGATE",
        "LIKE2",
        "INMEMORY",
        "PAST",
        "JSON_ARRAYAGG",
        "INDEXED",
        "LEVEL",
        "SYS_OP_BLOOM_FILTER_LIST",
        "UPDATABLE",
        "SYS_ORDERKEY_DEPTH",
        "CONTEXT",
        "UPD_INDEXES",
        "RETURNING",
        "NO_ORDER_ROLLUPS",
        "ALGORITHM",
        "UPDATE",
        "BETWEEN",
        "NLS_INITCAP",
        "PRESENT",
        "USERS",
        "SYS_OP_BITVEC",
        "UNARCHIVED",
        "SYS_XQXFORM",
        "ADVANCED",
        "EXISTS",
        "REBALANCE",
        "LOCAL",
        "DECRYPT",
        "LIBRARY",
        "BUSHY_JOIN",
        "NESTED_TABLE_GET_REFS",
        "ENCODING",
        "NO_PARTIAL_COMMIT",
        "SYS_CONNECT_BY_PATH",
        "NO_EXPAND",
        "EDITIONING",
        "SYS_OP_NOEXPAND",
        "SYS_PATHID_IS_NMSPC",
        "ORDINALITY",
        "CURSOR_SHARING_EXACT",
        "PIKEY",
        "RATIO_TO_REPORT",
        "FILEGROUP",
        "PRECISION",
        "LOGFILES",
        "LESS",
        "HALF_YEARS",
        "PRESERVE_OID",
        "STATIC",
        "LOAD",
        "NL_SJ",
        "FILE_NAME_CONVERT",
        "EXCHANGE",
        "FACT",
        "SYS_OP_CL2C",
        "HYBRID",
        "VECTOR_READ",
        "AVMDX_OP",
        "PX_FAULT_TOLERANCE",
        "SQL_TRANSLATION_PROFILE",
        "MINVALUE",
        "ORA_INVOKING_USERID",
        "DB_VERSION",
        "UNUSED",
        "HASH_AJ",
        "OBJECT",
        "INTERNAL_CONVERT",
        "SYS_XQFNLNAME",
        "EDITION",
        "NO_PQ_SKEW",
        "MEASURE",
        "BEGIN_OUTLINE_DATA",
        "LIFETIME",
        "SECRET",
        "TIMESTAMP_TO_NUMBER",
        "SYSOPER",
        "ADJ_DATE",
        "ASSOCIATE",
        "SYS_OP_RDTM",
        "COLLATE",
        "UNBOUNDED",
        "EDITIONS",
        "SYS_OP_BIN2ADT",
        "DB_UNIQUE_NAME",
        "CPU_PER_CALL",
        "V1",
        "STOP",
        "LEAD_CDB",
        "NO_ANSI_REARCH",
        "XS_SYS_CONTEXT",
        "KEY_LENGTH",
        "LAG_DIFF",
        "SUBQUERIES",
        "ORA_PARTITION_VALIDATION",
        "CHILD",
        "NODELAY",
        "UPD_JOININDEX",
        "SUPPLEMENTAL",
        "SYS_ORDERKEY_PARENT",
        "BEQUEATH",
        "NO_ANSWER_QUERY_USING_STATS",
        "HASH",
        "NO_USE_MERGE",
        "PRIVILEGES",
        "SYS_OP_DISTINCT",
        "SYS_EXTPDTXT",
        "WHEN",
        "NO_OUTER_JOIN_TO_ANTI",
        "NO_ACCESS",
        "MODEL_DYNAMIC_SUBQUERY",
        "NO_CROSS_CONTAINER",
        "DEMAND",
        "CAPACITY",
        "ROLE",
        "BROADCAST",
        "NAMED",
        "STATEMENTS",
        "NO_VECTOR_TRANSFORM_FACT",
        "ACL",
        "XML2OBJECT",
        "STANDARD_HASH",
        "ORA_SEARCH_RWKEY",
        "ABORT",
        "SYS_XQRNDHALF2EVN",
        "PERMANENT",
        "UNISTR",
        "SYS_OP_KEY_VECTOR_FILTER_LIST",
        "GLOBALLY",
        "FAILED",
        "PFILE",
        "SYS_XQIRI2URI",
        "INSERT",
        "CONFORMING",
        "INDEX_SCAN",
        "SWAP_JOIN_INPUTS",
        "NONE",
        "BINARY",
        "LOGICAL_READS_PER_SESSION",
        "PATH",
        "USAGE",
        "LIKE4",
        "FAILED_LOGIN_ATTEMPTS",
        "ORDERED_PREDICATES",
        "SHARDED",
        "QUARTERS",
        "MATCHES",
        "FOR",
        "XMLELEMENT",
        "SYS_OP_KEY_VECTOR_USE",
        "XMLPATCH",
        "CONDITION",
        "NO_CONNECT_BY_COST_BASED",
        "DETERMINES",
        "NO_SEMIJOIN",
        "INSTEAD",
        "DATAOBJNO",
        "CHANGE",
        "FOREIGN",
        "SYS_OP_DECOMP",
        "FOLLOWS",
        "INITIALLY",
        "NESTED_TABLE_SET_SETID",
        "SYS_GET_ACLIDS",
        "IMMEDIATE",
        "REGR_COUNT",
        "GLOBAL",
        "NOMONITORING",
        "THROUGH",
        "NLS_SORT",
        "SYS_OP_VECAND",
        "ORA_TABVERSION",
        "SOURCE_FILE_NAME_CONVERT",
        "MIGRATION",
        "DG_GATHER_STATS",
        "SELF",
        "NO_CARTESIAN",
        "UNSUBSCRIBE",
        "TIV_GB",
        "PARTIAL_ROLLUP_PUSHDOWN",
        "SERVICE_NAME_CONVERT",
        "JSON_ARRAY",
        "DECR",
        "PQ_FILTER",
        "DOMAIN_INDEX_FILTER",
        "USE_SEMI",
        "CURRENT",
        "SYS_XMLNODEID_GETOKEY",
        "NO_CHECK_ACL_REWRITE",
        "ACTIVE_FUNCTION",
        "SYS_XQ_NRNG",
        "SYS_XMLEXNSURI",
        "SYS_PATHID_IS_ATTR",
        "PARAMETERS",
        "SYS_XQPOLYCEL",
        "NLS_CHARSET_ID",
        "CON_DBID_TO_ID",
        "EXTENTS",
        "PQ_DISTRIBUTE_WINDOW",
        "APPROX_COUNT_DISTINCT_DETAIL",
        "TEMPORARY",
        "SYS_XQREPLACE",
        "REGR_INTERCEPT",
        "MONTHS",
        "UNPACKED",
        "MEMORY",
        "DECREMENT",
        "MOVEMENT",
        "OUTER_JOIN_TO_ANTI",
        "CON_ID_TO_DBID",
        "ACCESS",
        "STANDBYS",
        "SYS_XQCONCAT",
        "SYS_XQNODENAME",
        "DANGLING",
        "MAXEXTENTS",
        "VARRAYS",
        "HASH_SJ",
        "SYS_XQNORMSPACE",
        "REDEFINE",
        "NO_CONNECT_BY_FILTERING",
        "MODULE",
        "SYS_XQNORMUCODE",
        "STREAMS",
        "STANDALONE",
        "XMLEXISTS",
        "SYS_OP_RAWTONUM",
        "ENFORCE",
        "BEHALF",
        "NO_ZONEMAP",
        "NOOVERRIDE",
        "DYNAMIC",
        "DOCFIDELITY",
        "SYS_XQRSLVQNM",
        "DIST_AGG_PROLLUP_PUSHDOWN",
        "OPTIMIZER_FEATURES_ENABLE",
        "OPAQUE",
        "SYS_OP_EXTRACT",
        "DBSTR2UTF8",
        "PCTUSED",
        "PRETTY",
        "OCCURENCES",
        "EXTEND",
        "REPLICATION",
        "FACILITY",
        "SUCCESSFUL",
        "COMPONENTS",
        "NO_FACT",
        "SYS_PATHID_LASTNAME",
        "ERROR",
        "ONLY",
        "SYS_OP_PAR",
        "INSERTCHILDXMLBEFORE",
        "COLLATION",
        "PREDICTION_SET",
        "SYS_DM_RXFORM_LAB",
        "DICTIONARY",
        "NO_AUTO_REOPTIMIZE",
        "CACHE_CB",
        "OWNER",
        "SYS_OP_VECTOR_GROUP_BY",
        "SYSTEM",
        "MIRROR",
        "SYS_XQSEQRVS",
        "CORRUPT_XID_ALL",
        "INDEX_FFS",
        "SYSAUX",
        "ACTION",
        "UNITE",
        "RIGHT",
        "VALIDATION",
        "HIDDEN",
        "NO_CONNECT_BY_CB_WHR_ONLY",
        "FRESH_MV",
        "REDO",
        "NO_MONITORING",
        "SDO_GEOM_MBR",
        "BITMAP_CONSTRUCT_AGG",
        "CALCULATED",
        "SYS_XQRENAME",
        "SYSDG",
        "CLEAR",
        "NLS_LANG",
        "LIMIT",
        "INSERTXMLAFTER",
        "OUTER_JOIN_TO_INNER",
        "BSON",
        "USE_NL",
        "MODE",
        "NO_USE_PARTITION_WISE_GBY",
        "FAMILY",
        "INCLUDES",
        "SCAN_INSTANCES",
        "USE_MERGE_CARTESIAN",
        "TRAILING",
        "CLOSEST",
        "BODY",
        "ROLLING",
        "XMLISNODE",
        "REVOKE",
        "PERCENTILE_CONT",
        "ONE",
        "HASHKEYS",
        "DISTINGUISHED",
        "NO_USE_PARTITION_WISE_WIF",
        "MISMATCH",
        "DETERMINISTIC",
        "NORESETLOGS",
        "ITERATE",
        "TABLE_LOOKUP_BY_NL",
        "BITMAP_OR_AGG",
        "FAST",
        "ACROSS",
        "FRAGMENT_NUMBER",
        "METADATA",
        "XMLPARSE",
        "NLS_UPPER",
        "SYS_OP_NICOMBINE",
        "NOSEGMENT",
        "SYS_XQSUBSTRAFT",
        "USE_HASH_GBY_FOR_DAGGPSHD",
        "SDO_GEOM_MBB",
        "GRANULAR",
        "AUTO",
        "CELLMEMORY",
        "CURRENT_TIME",
        "INTERLEAVED",
        "ELAPSED_TIME",
        "NO_PUSH_PRED",
        "OVERLAPS",
        "APPROX_SUM",
        "SYS_XQTREATAS",
        "FEATURE_SET",
        "ADMINISTER",
        "ASIS",
        "PROJECT",
        "SYS_REMAP_XMLTYPE",
        "SYS_XQFNNM",
        "NO_BASETABLE_MULTIMV_REWRITE",
        "MAXARCHLOGS",
        "POLICY",
        "SYS_OP_NIX",
        "MBRC",
        "MATCH_RECOGNIZE",
        "CV",
        "SYS_AUDIT",
        "UNRECOVERABLE",
        "SYS_OP_NUMTORAW",
        "RECYCLE",
        "MAKE_REF",
        "TEMPFILE",
        "INVALIDATION",
        "TREAT",
        "NO_USE_HASH_GBY_FOR_PUSHDOWN",
        "NOSCALE",
        "SECURITY",
        "SYS_OP_ITR",
        "SYS_OP_DSB_SERIALIZE",
        "SYS_XQDOCURI",
        "NO_USE_INVISIBLE_INDEXES",
        "PROCESS",
        "UBA",
        "VERSIONS_ENDTIME",
        "PLSQL_OPTIMIZE_LEVEL",
        "SYS_DM_RXFORM_CHR",
        "CACHING",
        "FAILURE",
        "THAN",
        "IO_LOGICAL",
        "SYS_SYNRCIREDO",
        "READS",
        "LOGON",
        "PARTITION",
        "VOLUME",
        "SEMI_TO_INNER",
        "SYS_XQDFLTCOLATION",
        "ELSE",
        "SCAN",
        "SYS_OP_XTXT2SQLT",
        "CONTAINERS_DEFAULT",
        "INFORMATIONAL",
        "IGNORE_WHERE_CLAUSE",
        "GENERATED",
        "NO_QKN_BUFF",
        "UCS2",
        "PREDICTION_COST",
        "ENFORCED",
        "HIERARCHIES",
        "HINTSET_BEGIN",
        "NESTED_TABLE_SET_REFS",
        "DESCENDANT",
        "ACTIVE_TAG",
        "PERCENT_RANKM",
        "UNLOCK",
        "HIERARCHY",
        "RESTRICTED",
        "SYS_XQPOLYABS",
        "NO_PX_JOIN_FILTER",
        "NO_USE_HASH_GBY_FOR_DAGGPSHD",
        "REPEAT",
        "QUALIFY",
        "SYS_XQRYENVPGET",
        "EACH",
        "OFF",
        "NO_CONTAINERS",
        "EXPLAIN",
        "IN",
        "INDEX_SS_DESC",
        "STRIP",
        "PARTITION_HASH",
        "SCALE",
        "SUCCESS",
        "EXCLUDE",
        "NLS_NCHAR_CONV_EXCP",
        "XMLTRANSFORMBLOB",
        "CROSS",
        "TRUST",
        "OBJNO_REUSE",
        "POST_TRANSACTION",
        "RESETLOGS",
        "DIGEST",
        "INDEX_RRS",
        "DISKS",
        "WIDTH_BUCKET",
        "LOCKDOWN",
        "SYS_XQPOLYFLR",
        "REGULAR",
        "USE_SCALABLE_GBY_INVDIST",
        "ROW_NUMBER",
        "SYS_XQFNQNM",
        "RENAME",
        "NLS_LENGTH_SEMANTICS",
        "PREBUILT",
        "PIV_GB",
        "SYS_CTXINFOPK",
        "SETTINGS",
        "SDO_TOLERANCE",
        "BINDING",
        "SYS_OP_DESCEND",
        "ADVISOR",
        "USE_ANTI",
        "LOST",
        "SYS_XQPOLYADD",
        "DEREF",
        "PARENT",
        "ROW_LENGTH",
        "TRIGGER",
        "SNAPSHOT",
        "TRACKING",
        "IN_MEMORY_METADATA",
        "ALLOCATE",
        "EVENTS",
        "QUOTA",
        "DB_ROLE_CHANGE",
        "INTRA_CDB",
        "RAWTONHEX",
        "EVAL",
        "TUNING",
        "INSTANCES",
        "NLS_DATE_LANGUAGE",
        "SYNONYM",
        "INDEX_RS",
        "BASIC",
        "PARAM",
        "DEFAULT_PDB_HINT",
        "RESULT_CACHE",
        "OLTP",
        "SECONDS",
        "NO_CLUSTER_BY_ROWID",
        "COMPOSITE",
        "COMMENT",
        "SYS_XQRYWRP",
        "SYS_OP_MSR",
        "NO_ELIMINATE_JOIN",
        "SYS_OP_ADTCONS",
        "PARTIAL",
        "NO_TRANSFORM_DISTINCT_AGG",
        "NO_STAR_TRANSFORMATION",
        "USABLE",
        "NO_NLJ_PREFETCH",
        "STORAGE_INDEX",
        "SYSTEM_STATS",
        "HIER_CHILD_COUNT",
        "LDAP_REG_SYNC_INTERVAL",
        "GROUPING",
        "SYS_XQNILLED",
        "SCN",
        "NO_CONNECT_BY_ELIM_DUPS",
        "SYS_PARALLEL_TXN",
        "SYS_FBT_INSDEL",
        "HIER_PARENT",
        "INDEX_FILTER",
        "NTILE",
        "USE_PRIVATE_OUTLINES",
        "ANCILLARY",
        "SYNC",
        "BECOME",
        "BUILD",
        "MATERIALIZED",
        "REF_CASCADE_CURSOR",
        "SYS_OP_TOSETID",
        "NOREWRITE",
        "SYS_XQFNBOOL",
        "DATAOBJ_TO_PARTITION",
        "DATA_VALIDATE",
        "TEMPLATE",
        "AFD_DISKSTRING",
        "NO_USE_DAGG_UNION_ALL_GSETS",
        "CREDENTIALS",
        "NO_INDEX_FFS",
        "DEBUG",
        "ONLINE",
        "ORA_DST_ERROR",
        "BITS",
        "INDEX_RS_DESC",
        "PASSWORD_GRACE_TIME",
        "INCREMENTAL",
        "SUBPARTITIONING",
        "BOUND",
        "USE_INVISIBLE_INDEXES",
        "HIER_CHILDREN",
        "RESERVOIR_SAMPLING",
        "VECTOR_ENCODE",
        "UNNEST",
        "IF",
        "SYS_XQREF2VAL",
        "PQ_SKEW",
        "CLUSTER",
        "SYS_OP_TPR",
        "ACTIVE_COMPONENT",
        "OPEN",
        "PER",
        "WEEKS",
        "NLS_CURRENCY",
        "EVERY",
        "NOCOPY",
        "USE_HASH_AGGREGATION",
        "BEGINNING",
        "JSON_TRANSFORM",
        "SYS_OP_NIEXTRACT",
        "IOTFRSPEED",
        "ILM",
        "USE_MERGE",
        "LOCAL_INDEXES",
        "PLUGGABLE",
        "START",
        "SYS_XQTOKENIZE",
        "VERSIONS_STARTTIME",
        "FLUSH",
        "CERTIFICATE",
        "PREDICTION_DETAILS",
        "SPACE",
        "ROWID_MAPPING_TABLE",
        "MOUNTPATH",
        "SET_TO_JOIN",
        "MANAGE",
        "NO_PARTIAL_ROLLUP_PUSHDOWN",
        "SYS_MAKEXML",
        "SYS_OP_LOBLOC2NCLOB",
        "NO_PARTIAL_JOIN",
        "OBJNO",
        "HWM_BROKERED",
        "FEATURE_COMPARE",
        "SYS_OP_XPTHOP",
        "PREDICATE_REORDERS",
        "ENABLE_PARALLEL_DML",
        "SYNCHRONOUS",
        "NO_REORDER_WIF",
        "SAVEPOINT",
        "COLUMNAR",
        "FLASHBACK",
        "LAG_DIFF_PERCENT",
        "SYS_XQEXVAL",
        "ORA_SHARD_ID",
        "SHARE",
        "BULK",
        "NO_XDB_FASTPATH_INSERT",
        "XMLTABLE",
        "CONTAINER_MAP",
        "PX_GRANULE",
        "PLSQL_DEBUG",
        "SYS_XQSTARTSWITH",
        "DAYS",
        "UNLIMITED",
        "OF",
        "IGNORE",
        "PQ_CONCURRENT_UNION",
        "TIMEZONE_ABBR",
        "NO_COMMON_DATA",
        "=>",
        "FREEPOOLS",
        "OPTION",
        "OPERATIONS",
        "SYS_XQDURDIV",
        "NOFORCE",
        "ORADEBUG",
        "SYS_XQPOLYVGE",
        "SYS_OP_IIX",
        "NO_PLACE_DISTINCT",
        "SINGLE",
        "XMLCAST",
        "SYS_RID_ORDER",
        "XMLCDATA",
        "SYS_EXTRACT_UTC",
        "SUPPRESS_LOAD",
        ">=",
        "THE",
        "PRESENTNNV",
        "TIV_SSF",
        "CACHE_TEMP_TABLE",
        "TO_TIME",
        "OPERATOR",
        "MOVE",
        "READ",
        "USE_PARTITION_WISE_DISTINCT",
        "SYS_XQCASTABLEERRH",
        "PIVOT",
        "BITMAP",
        "NCHAR_CS",
        "JSON_LENGTH",
        "HOT",
        "NOCPU_COSTING",
        "PRIVILEGED",
        "WELLFORMED",
        "SYS_OP_ADT2BIN",
        "AUTOMATIC",
        "OPTIMAL",
        "NORMAL",
        "INTO",
        "LDAP_REGISTRATION",
        "COMPRESS",
        "UTF8",
        "SYS_XQPOLYVLT",
        "XMLINDEX_REWRITE_IN_SELECT",
        "SEED",
        "MERGE_CONST_ON",
        "NO_PUSH_SUBQ",
        "CURRENTV",
        "BIND_AWARE",
        "NO_ELIMINATE_OBY",
        "OUT_OF_LINE",
        "XMLATTRIBUTES",
        "KEEP",
        "ANCESTOR",
        "APPROX_COUNT_DISTINCT",
        "PERMISSION",
        "CORR_S",
        "UNDO",
        "CONSISTENT",
        "LOGGING",
        "RANGE",
        "QUEUE",
        "BATCH",
        "MAX_SHARED_TEMP_SIZE",
        "SECOND",
        "MIRRORCOLD",
        "KEYSIZE",
        "IGNORE_ROW_ON_DUPKEY_INDEX",
        "PROPAGATE",
        "GUARD",
        "TYPENAME",
        "TRANSACTION",
        "NOMAXVALUE",
        "MAIN",
        "SDO_GEOM_KEY",
        "SYS_XQED4URI",
        "FILESYSTEM_LIKE_LOGGING",
        "EXTRA",
        "ELIMINATE_SQ",
        "SETS",
        "ACCESSED",
        "WHERE",
        "MINUTES",
        "XMLSERIALIZE",
        "MINIMIZE",
        "UPDATED",
        "KEY",
        "SEMIJOIN",
        "PUSH_PRED",
        "VECTOR_TRANSFORM_DIMS",
        "AUTHENTICATION",
        "NONPARTITIONED",
        "INNER",
        "DIMENSION",
        "NO_PX_FAULT_TOLERANCE",
        "NO_OUTER_JOIN_TO_INNER",
        "SEARCH",
        "PARTITIONSET",
        "CONSTRAINTS",
        "GBY_CONC_ROLLUP",
        "MAXDATAFILES",
        "USE_VECTOR_AGGREGATION",
        "TIMEOUT",
        "SYS_GETXTIVAL",
        "NEG",
        "MAPPING",
        "USER_TABLESPACES",
        "TRANSLATION",
        "BYPASS_UJVC",
        "NO_MERGE",
        "TABNO",
        "LEAD_DIFF_PERCENT",
        "SYS_XQLANG",
        "PLACE_GROUP_BY",
        "WRAPPED",
        "PERMUTE",
        "BIGFILE",
        "SDO_GEOM_MIN_X",
        "DECLARE",
        "NORELY",
        "SYS_XQSTATBURI",
        "INDEXTYPES",
        "CYCLE",
        "INLINE",
        "ORA_CHECK_ACL",
        "UNIFORM",
        "REFERENCES",
        "MAXINSTANCES",
        "NOEXTEND",
        "RESUME",
        "SYS_OP_CAST",
        "QUERY",
        "HIER_LAG",
        "PRIVATE",
        "SCALE_ROWS",
        "SHOW",
        "POOL_8K",
        "SYS_DST_PRIM2SEC",
        "LOCATOR",
        "OFFLINE",
        "SYS_XQSTR2CODEP",
        "SYS_OPTLOBPRBSC",
        "IOSEEKTIM",
        "SYSGUID",
        "ORA_INVOKING_XS_USER",
        "SYS_XQSEQTYPMATCH",
        "EVALUATION",
        "PERFORMANCE",
        "STATS_KS_TEST",
        "UNMATCHED",
        "CDB_HTTP_HANDLER",
        "SYS_XQFNROOT",
        "FOREVER",
        "DEFAULTS",
        "SEQUENCE",
        "DEFINER",
        "OPAQUE_XCANONICAL",
        "PQ_NOMAP",
        "DBA_RECYCLEBIN",
        "SYS_OP_R2O",
        "EXTERNALLY",
        "SYS_GET_COL_ACLIDS",
        "PENDING",
        "PASSWORD_VERIFY_FUNCTION",
        "CHECK",
        "INDEXTYPE",
        "CONNECT_TIME",
        "PASSWORD",
        "RELATIONAL",
        "ASYNC",
        "TBL$OR$IDX$PART$NUM",
        "USE_PARTITION_WISE_WIF",
        "APPROX_PERCENTILE_DETAIL",
        "NONEDITIONABLE",
        "USE_DAGG_UNION_ALL_GSETS",
        "PASSWORD_LOCK_TIME",
        "SYS_GET_PRIVILEGES",
        "SYS_XQSEQSUB",
        "SYS_OP_CSR",
        "CHUNK",
        "ARCHIVAL",
        "JOIN",
        "INACTIVE",
        "SELECTIVITY",
        "SYS_OP_OPNSIZE",
        "PROTECTED",
        "ISOLATE",
        "ASSIGN",
        "SYS_OP_GUID",
        "SYS_OP_KEY_VECTOR_CREATE",
        "INVALIDATE",
        "PLAN",
        "LEVELS",
        "NO_INDEX_SS",
        "MATCH",
        "MONITOR",
        "SKIP_UNUSABLE_INDEXES",
        "RAPIDLY",
        "HEAP",
        "DECORRELATE",
        "SYS_XQFNCMP",
        "CONSTRAINT",
        "AT",
        "SYS_OP_XPTHATG",
        "METADATA_SOURCE_PDB",
        "SAMPLE",
        "DISK",
        "HOURS",
        "AGGREGATES",
        "EDITIONABLE",
        "THEN",
        "CLUSTERING_FACTOR",
        "GUARANTEE",
        "PREDICTION",
        "BLOCK_RANGE",
        "NAME",
        "JSON_EQUAL",
        "AS",
        "LEAVES",
        "SYS_OP_C2C",
        "INITIALIZED",
        "SYS_XQPOLYRND",
        "COALESCE_SQ",
        "PROTOCOL",
        "ANOMALY",
        "UNIQUE",
        "APPROX_MEDIAN",
        "ORA_ROWVERSION",
        "OBJECT2XML",
        "UNINSTALL",
        "TYPES",
        "HEADER",
        "MANAGED",
        "INVISIBLE",
        "VECTOR_TRANSFORM",
        "ORDERED",
        "SYS_PATH_REVERSE",
        "SYS_OP_CSCONVTEST",
        "UNNEST_SEMIJ_VIEW",
        "REUSE",
        "SYS_OP_COMP",
        "ALLOW",
        "BACKGROUND",
        "REMOTE",
        "VERSIONS_OPERATION",
        "NO_XMLINDEX_REWRITE_IN_SELECT",
        "TO_UTC_TIMESTAMP_TZ",
        "COMMITTED",
        "POWERMULTISET_BY_CARDINALITY",
        "CON_GUID_TO_ID",
        "SYS_XQFUNCR",
        "INSTANTLY",
        "XMLSCHEMA",
        "EVALNAME",
        "SYS_XQPOLYCSTBL",
        "SYS_XQLLNMFRMQNM",
        "LEFT",
        "RUNNING",
        "BREADTH",
        "CONNECT_BY_ISCYCLE",
        "SKIP_PROXY",
        "INTERMEDIATE",
        "SPECIFICATION",
        "NLS_CHARSET_NAME",
        "NOREPLAY",
        "VARYING",
        "EXTENDS",
        "USE_WEAK_NAME_RESL",
        "SYS_XQDELETE",
        "TO_TIME_TZ",
        "APPEND",
        "BYPASS_RECURSIVE_CHECK",
        "UNRESTRICTED",
        "APPENDCHILDXML",
        "OVERFLOW",
        "FLEX",
        "ORA_RAWCOMPARE",
        "EXTERNAL",
        "SYS_MKXMLATTR",
        "NO_PQ_EXPAND_TABLE",
        "CREDENTIAL",
        "PCTVERSION",
        "NO_XMLINDEX_REWRITE",
        "JSON_QUERY",
        "NESTED_TABLE_FAST_INSERT",
        "USE_NL_WITH_INDEX",
        "HIER_COLUMN",
        "NOSTRICT",
        "SYS_OP_ALSCRVAL",
        "NOSWITCH",
        "INSTANTIABLE",
        "NOTHING",
        "SQL",
        "YES",
        "STAR",
        "SYS_XQINSPFX",
        "RESET",
        "STORE",
        "REALM",
        "EM",
        "VALIDATE_CONVERSION",
        "EXISTSNODE",
        "SYS_ZMAP_FILTER",
        "DATABASE",
        "MODEL_PBY",
        "MIGRATE_CROSS_CON",
        "NOCACHE",
        "SYS_XMLNODEID_GETPATHID",
        "VECTOR_TRANSFORM_FACT",
        "NO_NATIVE_FULL_OUTER_JOIN",
        "RECOVER",
        "QB_NAME",
        "SUBPARTITION_REL",
        "DISABLE_RPKE",
        "USER_DATA",
        "STATEMENT",
        "LOGOFF",
        "VERSION",
        "NOPARALLEL",
        "FINAL",
        "MEDIUM",
        "MAXLOGHISTORY",
        "THREAD",
        "ZONE",
        "SYSKM",
        "PROCEDURE",
        "PBL_HS_END",
        "HIER_CAPTION",
        "NO_PARALLEL_INDEX",
        "RLS_FORCE",
        "MINEXTENTS",
        "CLUSTERING",
        "MINUS_NULL",
        "APPROX_COUNT_DISTINCT_AGG",
        "NOROWDEPENDENCIES",
        "ARCHIVE",
        "JSON_TABLE",
        "SYS_XQPOLYMUL",
        "OPAQUE_TRANSFORM",
        "FORWARD",
        "SYS_ORDERKEY_MAXCHILD",
        "MEMCOMPRESS",
        "PARTIAL_JOIN",
        "PBL_HS_BEGIN",
        "SYS_XQEXTRREF",
        "SYS_OP_OIDVALUE",
        "SYSDBA",
        "EXCEPTIONS",
        "ORA_HASH",
        "SYS_DBURIGEN",
        "PHYSICAL",
        "INSTALL",
        "SYS_XQ_UPKXML2SQL",
        "DISTRIBUTED",
        "SIZE",
        "CELL_FLASH_CACHE",
        "UNNEST_INNERJ_DISTINCT_VIEW",
        "GROUPING_ID",
        "SYS_OP_CYCLED_SEQ",
        "PQ_EXPAND_TABLE",
        "NOVALIDATE",
        "ENABLE_ALL",
        "COST_XML_QUERY_REWRITE",
        "CONTAINER_DATA",
        "NESTED",
        "OPTIMIZER_GOAL",
        "YEARS",
        "TOPLEVEL",
        "AND_EQUAL",
        "DELETE",
        "NOAPPEND",
        "CONTAINERS",
        "FULL",
        "BRANCH",
        "STATS_MW_TEST",
        "IDENTIFIER",
        "POOL_32K",
        "SUBPARTITIONS",
        "WHENEVER",
        "NOT",
        "STDDEV_SAMP",
        "USE_TTT_FOR_GSETS",
        "XMLCOLATTVAL",
        "TO_APPROX_COUNT_DISTINCT",
        "VALID_TIME_END",
        "ADMINISTRATOR",
        "EXPAND_GSET_TO_UNION",
        "DESC",
        "QUOTAGROUP",
        "ALWAYS",
        "CONSIDER",
        "NOLOCAL",
        "AW",
        "SIGNAL_FUNCTION",
        "SQL_TRACE",
        "PERIOD",
        "DISABLE_ALL",
        "PREDICTION_BOUNDS",
        "SYS_XMLANALYZE",
        "EXISTING",
        "TABLESPACE_NO",
        "BOTH",
        "QUEUE_ROWP",
        "CUME_DISTM",
        "CON_NAME_TO_ID",
        "SYS_GETTOKENID",
        "CON_UID_TO_ID",
        "PRINTBLOBTOCLOB",
        "TIMES",
        "SYS_OP_RPB",
        "REGEXP_LIKE",
        "BUFFER",
        "DESCRIPTION",
        "DISMOUNT",
        "JSON_TEXTCONTAINS",
        "PARITY",
        "PRUNING",
        "SHARED",
        "CATEGORY",
        "PROTECTION",
        "SUBSTRB",
        "DUPLICATED",
        "REFERENCING",
        "STRIPE_WIDTH",
        "NO_USE_HASH",
        "DEFAULT_COLLATION",
        "DEQUEUE",
        "REGR_SYY",
        "HIER_ORDER",
        "HIER_DESCRIPTION",
        "PERSISTABLE",
        "COLUMN_VALUE",
        "MOUNT",
        "NOORDER",
        "SYS_OP_LSVI",
        "AUTHENTICATED",
        "XMLTRANSFORM",
        "SYS_ET_BFILE_TO_RAW",
        "SESSIONTZNAME",
        "VERSIONING",
        "MAX_AUDIT_SIZE",
        "PQ_REPLICATE",
        "NO_ELIMINATE_SQ",
        "RECOVERY",
        "USE_CUBE",
        "STATISTICS",
        "SYS_XQEXTRACT",
        "DIMENSIONS",
        "VERSIONS_ENDSCN",
        "ANSWER_QUERY_USING_STATS",
        "DBMS_STATS",
        "<<",
        "SUBSCRIBE",
        "INCLUDING",
        "CLASSIFIER",
        "NLS_COMP",
        "RESTORE_AS_INTERVALS",
        "ADVISE",
        "INMEMORY_PRUNING",
        "IN_XQUERY",
        "ORA_BRANCH",
        "SESSION",
        "DBA",
        "SYS_OP_DSB_DESERIALIZE",
        "DROP_COLUMN",
        "RBO_OUTLINE",
        "FEATURE_DETAILS",
        "STATS_ONE_WAY_ANOVA",
        "CACHE",
        "CONTAINER_DATA_ADMIT_NULL",
        "IDGENERATORS",
        "RESOURCE",
        "FILTER",
        "MV_MERGE",
        "HIER_LEVEL",
        "UNPIVOT",
        "CONVERSION",
        "OSON",
        "NO_PQ_MAP",
        "HIER_DEPTH",
        "SYS_XMLNODEID_GETTID",
        "VISIBLE",
        "SECUREFILE",
        "TX",
        "FLAGGER",
        "CUBE",
        "SYS_XMLLOCATOR_GETSVAL",
        "STALE",
        "SYS_PLSQL_COUNT",
        "AFTER",
        "NLS_COLLATION_NAME",
        "SYS_OP_ATG",
        "FIRST",
        "REORDER_WIF",
        "MAXVALUE",
        "NO_OBJECT_LINK",
        "INDEX_SKIP_SCAN",
        "ARCHIVED",
        "CONNECT_BY_CB_WHR_ONLY",
        "NO_ELIM_GROUPBY",
        "NOSHARD",
        "DISKGROUP",
        "MODEL_SV",
        "JSON_EXISTS2",
        "ORA_CHECK_SYS_PRIVILEGE",
        "FEDERATION",
        "NLJ_INDEX_SCAN",
        "PATTERN",
        "IO_MEGABYTES",
        "CONNECT_BY_ELIM_DUPS",
        "INTERNAL_USE",
        "TIMEZONE_OFFSET",
        "SYS_ZMAP_REFRESH",
        "PREDICTION_PROBABILITY",
        "ACTIVATE",
        "COLUMN_STATS",
        "REGR_SXY",
        "FILE",
        "CLASSIFICATION",
        "STATEMENT_ID",
        "DECOMPRESS",
        "SKIP_UNQ_UNUSABLE_IDX",
        "SYS_DST_SEC2PRIM",
        "SYS_XQCODEPEQ",
        "BATCH_TABLE_ACCESS_BY_ROWID",
        "DATA_LINK_DML",
        "FOLDER",
        "SYS_XQPOLYUMUS",
        "MERGE_SJ",
        "IS",
        "DEFINITION",
        "INLINE_XT",
        "UTF32",
        "TRACING",
        "USER_RECYCLEBIN",
        "LANGUAGE",
        "SPREADSHEET",
        "POSITION",
        "SYS_OP_VERSION",
        "LATERAL",
        "SYS_UMAKEXML",
        "OWNERSHIP",
        "CACHE_INSTANCES",
        "OPTIMIZE",
        "FUNCTION",
        "PASSING",
        "PARTIALLY",
        "NO_CONNECT_BY_COMBINE_SW",
        "LIKE",
        "NO_QUERY_TRANSFORMATION",
        "FINISH",
        "XMLNAMESPACES",
        "SD_ALL",
        "ORA_ROWSCN",
        "INDEXING",
        "INSTANCE",
        "REFERENCE",
        "INCR",
        "REFTOHEX",
        "PX_JOIN_FILTER",
        "ELIMINATE_OBY",
        "EXCLUSIVE",
        "PLACE_DISTINCT",
        "JSONTOXML",
        "SUBMULTISET",
        "SYS_XMLNODEID_GETRID",
        "HIER_LEAD",
        "XMLROOT",
        "SYS_OP_CEG",
        "DATAFILES",
        "SYS_OP_DRA",
        "PRELOAD",
        "DEFINE",
        "SEMIJOIN_DRIVER",
        "CONTENT",
        "SINGLETASK",
        "DELAY",
        "IDENTITY",
        "CONNECT_BY_COST_BASED",
        "DESTROY",
        "ATTRIBUTE",
        "NO_PUSH_HAVING_TO_GBY",
        "POOL_4K",
        "ROWIDTOCHAR",
        "NLS_DATE_FORMAT",
        "SYS_OP_LOBLOC2CLOB",
        "COLUMN",
        "MULTISET",
        "SYS_OP_LOBLOC2BLOB",
        "AFFINITY",
        "SYS_OP_ZONE_ID",
        "INLINE_XMLTYPE_NT",
        "DEPENDENT",
        "DUPLICATE",
        "SYSTEM_DEFINED",
        "CHECKPOINT",
        "SYS_XQCODEP2STR",
        "BITMAP_BUCKET_NUMBER",
        "EXPAND_TABLE",
        "SYS_GUID",
        "KERBEROS",
        "TRANSITIONAL",
        "MATCHED",
        "ANY_VALUE",
        "SYS_XQPOLYSQRT",
        "SYS_XQSEQ2CON4XC",
        "REVERSE",
        "MIRRORHOT",
        "STRICT",
        "SQL_SCOPE",
        "EXPR_CORR_CHECK",
        "SERVICE",
        "SYS_PLSQL_CPU",
        "SYS_XQSEQRM",
        "TRUNCATE",
        "CHANGE_DUPKEY_ERROR_INDEX",
        "OUTER",
        "USE_STORED_OUTLINES",
        "NLS_ISO_CURRENCY",
        "EXTENT",
        "SYS_OPTXQCASTASNQ",
        "SDO_GEOM_MIN_Z",
        "SD_INHIBIT",
        "GATHER_PLAN_STATISTICS",
        "ENTITYESCAPING",
        "COMPATIBILITY",
        "LOCKED",
        "LEADING",
        "CHAR_CS",
        "QUERY_BLOCK",
        "NOTIFICATION",
        "EXTENDED",
        "NO_DECORRELATE",
        "REDUCED",
        "PRIORITY",
        "BASICFILE",
        "VERSIONS_XID",
        "<=",
        "CONTENTS",
        "POOL_2K",
        "ORA_GET_PRIVILEGES",
        "ADMIN",
        "COMPUTATION",
        "LOCKING",
        "EXECUTE",
        "NEEDED",
        "RETURN",
        "XML_DML_RWT_STMT",
        "APPROX_PERCENTILE",
        "CONSTANT",
        "INDEX_SS_ASC",
        "GRANTED",
        "DOCUMENT",
        "UPSERT",
        "SYS_OP_KEY_VECTOR_SUCCEEDED",
        "SESSION_CACHED_CURSORS",
        "SYS_OP_HASH",
        "NO_VECTOR_TRANSFORM_DIMS",
        "PRESENTV",
        "EVALUATE",
        "NO_STATEMENT_QUEUING",
        "ROOT",
        "EXTRACTVALUE",
        "RESOLVER",
        "SYSRAC",
        "CUBE_GB",
        "NOREPAIR",
        "XMLQUERYVAL",
        "YEAR",
        "ROWIDTONCHAR",
        "INSENSITIVE",
        "NO_PRUNE_GSETS",
        "MANUAL",
        "DELETE_ALL",
        "MAXLOGMEMBERS",
        "SALT",
        "NO_PQ_REPLICATE",
        "FIRSTM",
        "NO_FACTORIZE_JOIN",
        "ORA_WRITE_TIME",
        "DEPTH",
        "PARTITION_LIST",
        "TARGET",
        "SERIAL",
        "SUMMARY",
        "XMLINDEX_SEL_IDX_TBL",
        "AVAILABILITY",
        "NO_EXPAND_GSET_TO_UNION",
        "BINARY_FLOAT_NAN",
        "PREPARE",
        "AVERAGE_RANK",
        "STDDEV_POP",
        "DETACHED",
        "PRIVATE_SGA",
        "NO_MODEL_PUSH_REF",
        "SYS_XQPOLYVLE",
        "UNBOUND",
        "CDB$DEFAULT",
        "SYS_OP_LOBLOC2ID",
        "VALUE",
        "XPATHTABLE",
        "PDB_LOCAL_ONLY",
        "AGGREGATE",
        "LOGFILE",
        "CONTAINER",
        "SYS_XQCON2SEQ",
        "SHARING",
        "PART$NUM$INST",
        "NOCOMPRESS",
        "SYS_XQGETCONTENT",
        "WAIT",
        "PARALLEL_INDEX",
        "SQLLDR",
        "RESUMABLE",
        "SYS_XMLT_2_SC",
        "STAR_TRANSFORMATION",
        "SYS_XSID_TO_RAW",
        "NOKEEP",
        "CURRENT_USER",
        "JSON_HASH",
        "HIER_HAS_CHILDREN",
        "JSON_VALUE",
        "XMLQUERY",
        "GBY_PUSHDOWN",
        "SYS_XQSUBSTRBEF",
        "DOUBLE",
        "MATRIX",
        "NO_PARALLEL",
        "REWRITE",
        "NATIVE_FULL_OUTER_JOIN",
        "LAYER",
        "COMPLETE",
        "CLUSTER_ID",
        "SEGMENT",
        "SYS_OP_LOBLOC2TYP",
        "TEMP_TABLE",
        "VIRTUAL",
        "PERCENT",
        "NLS_CHARACTERSET",
        "MODEL_NB",
        "JSON_PATCH",
        "HEXTOREF",
        "DATAFILE",
        "PARTITIONING",
        "INDEX",
        "DISTRIBUTE",
        "ORA_DST_AFFECTED",
        "NAMESPACE",
        "VIOLATION",
        "SCN_ASCENDING",
        "DYNAMIC_SAMPLING",
        "SYS_XMLNODEID_GETPTRID",
        "USER_DEFINED",
        "CONNECT_BY_ISLEAF",
        "USING_NO_EXPAND",
        "SYS_DOM_COMPARE",
        "DRIVING_SITE",
        "EXPRESS",
        "SYSOBJ",
        "X_DYN_PRUNE",
        "PRESERVE",
        "MEMOPTIMIZE",
        "TRANSFORM_DISTINCT_AGG",
        "DEBUGGER",
        "FORMAT",
        "SHARED_POOL",
        "SYS_XMLI_LOC_ISNODE",
        "LOCATION",
        "MODEL_MIN_ANALYSIS",
        "AUTHORIZATION",
        "STATS_WSR_TEST",
        "EXTRACTCLOBXML",
        "STATS_T_TEST_INDEP",
        "CHAINED",
        "BLOCKS",
        "PLSCOPE_SETTINGS",
        "CON_ID_FILTER",
        "SYS_XQFB2STR",
        "SWITCHOVER",
        "CREATION",
        "PLSQL_CCFLAGS",
        "NO_SEMI_TO_INNER",
        "SDO_GEOM_MAX_Y",
        "DROP_GROUP",
        "SYS_OP_KEY_VECTOR_PAYLOAD",
        "CLEANUP",
        "MODEL_COMPILE_SUBQUERY",
        "SYS_XQPOLYVGT",
        "OPT_ESTIMATE",
        "CLIENT",
        "CONNECT_BY_ROOT",
        "EXCEPT",
        "SYS_OP_XTNN",
        "SYS_OP_LVL",
        "SYS_XQPOLYVEQ",
        "NONSCHEMA",
        "SYS_XQERR",
        "SYS_OPTXICMP",
        "SYS_OP_CSCONV",
        "ERRORS",
        "REBUILD",
        "SYS_XQ_ASQLCNV",
        "NOW",
        "TABLES",
        "CORR_K",
        "WITHOUT",
        "DISCARD",
        "SIBLING",
        // all PL/SQL reserved words and keywords that are not present in above view
        "A",
        "ACCESSIBLE",
        "AGENT",
        "BFILE_BASE",
        "BLOB_BASE",
        "C",
        "CALLING",
        "CHARSET",
        "CHARSETFORM",
        "CHARSETID",
        "CHAR_BASE",
        "CLOB_BASE",
        "CLUSTERS",
        "COLAUTH",
        "COMPILED",
        "CONSTRUCTOR",
        "CUSTOMDATUM",
        "DATE_BASE",
        "DURATION",
        "ELSIF",
        "EXCEPTION",
        "EXIT",
        "FIXED",
        "FORALL",
        "GENERAL",
        "GOTO",
        "IMMUTABLE",
        "INDICES",
        "INTERFACE",
        "LARGE",
        "LIMITED",
        "LOOP",
        "MAXLEN",
        "MUTABLE",
        "NUMBER_BASE",
        "OCICOLL",
        "OCIDATE",
        "OCIDATETIME",
        "OCIDURATION",
        "OCIINTERVAL",
        "OCILOBLOCATOR",
        "OCINUMBER",
        "OCIRAW",
        "OCIREF",
        "OCIREFCURSOR",
        "OCIROWID",
        "OCISTRING",
        "OCITYPE",
        "ORACLE",
        "ORADATA",
        "ORLANY",
        "ORLVARY",
        "OTHERS",
        "OUT",
        "OVERLAPSPROCEDURE",
        "OVERRIDING",
        "PARALLEL_ENABLE",
        "PARAMETER",
        "PASCAL",
        "PIPE",
        "PIPELINED",
        "POLYMORPHIC",
        "PRAGMA",
        "RAISE",
        "RECORD",
        "RELIES_ON",
        "REM",
        "RESULT",
        "SB1",
        "SB2",
        "SEPARATE",
        "SHORT",
        "SIZE_T",
        "SPARSE",
        "SQLDATA",
        "SQLNAME",
        "SQLSTATE",
        "STANDARD",
        "STORED",
        "STRUCT",
        "STYLE",
        "SUBTYPE",
        "TABAUTH",
        "TDO",
        "TRANSACTIONAL",
        "UB1",
        "UB4",
        "UNSIGNED",
        "UNTRUSTED",
        "VALIST",
        "VARIABLE",
        "VIEWS",
        "VOID",
        "WHILE"
      ],
      atoms: [
        "TRUE",
        "FALSE",
        "NULL"
      ],
      datatypes: [
        // manually added
        "BOOLEAN",
        // all valid keywords that are also datatypes
        // minus "EXCEPTION" as this is better suited to be highlighted as a keyword
        "BINARY_DOUBLE",
        "DECIMAL",
        "RAW",
        "VARCHAR",
        "CLOB",
        "ROWID",
        "NVARCHAR2",
        "VARCHAR2",
        "BINARY_FLOAT",
        "INTEGER",
        "NCLOB",
        "CHAR",
        "POINT",
        "SMALLINT",
        "BLOB",
        "BFILE",
        "NCHAR",
        "TIMESTAMP",
        "JOB",
        "NUMBER",
        "REAL",
        "INT",
        "NATURAL",
        "UROWID",
        "LONG",
        "DEC",
        "XMLTYPE",
        "CHARACTER",
        "DATE",
        "FLOAT",
        "NUMERIC",
        "STRING",
        "MLSLABEL",
        // apex-specific data types
        // select listagg('''' || synonym_name || ''',') from all_synonyms where owner = 'PUBLIC' and synonym_name like 'APEX_T\_%' escape '\' order by synonym_name;
        "APEX_T_APPROVAL_LOG_TABLE",
        "APEX_T_APPROVAL_TASK",
        "APEX_T_PARSER_WORKSHEET",
        "APEX_T_PARSER_ROW",
        "APEX_T_HUMAN_TASK",
        "APEX_T_APPROVAL_LOG_ROW",
        "APEX_T_CLOB",
        "APEX_T_APPROVAL_TASKS",
        "APEX_T_EXPORT_FILE",
        "APEX_T_NUMBER",
        "APEX_T_PARSER_COLUMN",
        "APEX_T_VARCHAR2",
        "APEX_T_HUMAN_TASKS",
        "APEX_T_HUMAN_TASK_LOG_TABLE",
        "APEX_T_PARSER_WORKSHEETS",
        "APEX_T_LDAP_ATTRIBUTE",
        "APEX_T_LDAP_ATTRIBUTES",
        "APEX_T_HUMAN_TASK_LOG_ROW",
        "APEX_T_EXPORT_FILES",
        "APEX_T_PARSER_TABLE",
        "APEX_T_PARSER_COLUMNS"
      ],
      builtinFunctions: [
        // source: techonthenet.com/oracle/functions/index.php
        // String/Char Functions
        "ASCII",
        "ASCIISTR",
        "CHR",
        "COMPOSE",
        "CONCAT",
        "CONVERT",
        "DECOMPOSE",
        "DUMP",
        "INITCAP",
        "INSTR",
        "INSTR2",
        "INSTR4",
        "INSTRB",
        "INSTRC",
        "LENGTH",
        "LENGTH2",
        "LENGTH4",
        "LENGTHB",
        "LENGTHC",
        "LOWER",
        "LPAD",
        "LTRIM",
        "NCHR",
        "REGEXP_INSTR",
        "REGEXP_REPLACE",
        "REGEXP_SUBSTR",
        "REPLACE",
        "RPAD",
        "RTRIM",
        "SOUNDEX",
        "SUBSTR",
        "TRANSLATE",
        "TRIM",
        "UPPER",
        "VSIZE",
        // Numeric/Math Functions
        "ABS",
        "ACOS",
        "ASIN",
        "ATAN",
        "ATAN2",
        "AVG",
        "BITAND",
        "CEIL",
        "COS",
        "COSH",
        "COUNT",
        "EXP",
        "FLOOR",
        "GREATEST",
        "LEAST",
        "LN",
        "LOG",
        "MAX",
        "MEDIAN",
        "MIN",
        "MOD",
        "POWER",
        "REGEXP_COUNT",
        "REMAINDER",
        "ROUND",
        "ROWNUM",
        "SIGN",
        "SIN",
        "SINH",
        "SQRT",
        "SUM",
        "TAN",
        "TANH",
        "TRUNC",
        // Date/Time Functions
        "ADD_MONTHS",
        "CURRENT_DATE",
        "CURRENT_TIMESTAMP",
        "DBTIMEZONE",
        "EXTRACT",
        "LAST_DAY",
        "LOCALTIMESTAMP",
        "MONTHS_BETWEEN",
        "NEW_TIME",
        "NEXT_DAY",
        "ROUND",
        "SESSIONTIMEZONE",
        "SYSDATE",
        "SYSTIMESTAMP",
        "TRUNC",
        "TZ_OFFSET",
        // Conversion Functions
        "BIN_TO_NUM",
        "CAST",
        "CHARTOROWID",
        "FROM_TZ",
        "HEXTORAW",
        "NUMTODSINTERVAL",
        "NUMTOYMINTERVAL",
        "RAWTOHEX",
        "TO_CHAR",
        "TO_CLOB",
        "TO_DATE",
        "TO_DSINTERVAL",
        "TO_LOB",
        "TO_MULTI_BYTE",
        "TO_NCLOB",
        "TO_NUMBER",
        "TO_SINGLE_BYTE",
        "TO_TIMESTAMP",
        "TO_TIMESTAMP_TZ",
        "TO_YMINTERVAL",
        // Analytic Functions
        "CORR",
        "COVAR_POP",
        "COVAR_SAMP",
        "CUME_DIST",
        "DENSE_RANK",
        "FIRST_VALUE",
        "LAG",
        "LAST_VALUE",
        "LEAD",
        "LISTAGG",
        "NTH_VALUE",
        "RANK",
        "STDDEV",
        "VAR_POP",
        "VAR_SAMP",
        "VARIANCE",
        // Advanced Functions
        "BFILENAME",
        "CARDINALITY",
        "COALESCE",
        "DECODE",
        "EMPTY_BLOB",
        "EMPTY_CLOB",
        "GROUP_ID",
        "LNNVL",
        "NANVL",
        "NULLIF",
        "NVL",
        "NVL2",
        "SYS_CONTEXT",
        "UID",
        "USER",
        "USERENV",
        "SQLCODE",
        "SQLERRM"
      ],
      builtinVariables: [],
      operators: [],
      tokenizer: {
        root: [
          { include: "@comments" },
          { include: "@whitespace" },
          { include: "@numbers" },
          { include: "@strings" },
          [/[;,.]/, "delimiter"],
          [/[()]/, "@brackets"],
          [/[\w@#$]+/, {
            cases: {
              "@atoms": "atom",
              "@datatypes": "predefined",
              "@builtinFunctions": "function",
              "@builtinVariables": "predefined",
              "@keywords": "keyword",
              "@operators": "operator",
              "@default": "identifier"
            }
          }],
          [/[<>=!%&+\-*/|~^]/, "operator"]
        ],
        whitespace: [
          [/\s+/, "white"]
        ],
        comments: [
          [/--+.*/, "comment"],
          [/\/\*/, { token: "comment.quote", next: "@comment" }]
        ],
        comment: [
          [/[^*/]+/, "comment"],
          [/\/\*/, { token: "comment.quote", next: "@push" }],
          [/\*\//, { token: "comment.quote", next: "@pop" }],
          [/./, "comment"]
        ],
        numbers: [
          [/0[xX][0-9a-fA-F]*/, "number"],
          [/[$][+-]*\d*(\.\d*)?/, "number"],
          [/((\d+(\.\d*)?)|(\.\d+))([eE][-+]?\d+)?/, "number"]
        ],
        strings: [
          [/N'/, { token: "string", next: "@string" }],
          [/'/, { token: "string", next: "@string" }],
          // caters for the Alternative Quoting Mechanism (q'[...]') for String Literals
          // the start and end tokens will be highlighted as keywords, to make it more clear what the actual string is
          [/q'\[/, { token: "keyword", next: "@qStringSquareBracket" }],
          [/q'</, { token: "keyword", next: "@qStringAngleBracket" }],
          [/q'{/, { token: "keyword", next: "@qStringCurlyBracket" }],
          [/q'\(/, { token: "keyword", next: "@qStringParentheses" }],
          // same character start and end delimiter
          [/q'(.)/, { token: "keyword", next: "@qStringCustom.$1" }]
        ],
        // basic string ending
        string: [
          [/[^']+/, "string"],
          [/''/, "string"],
          [/'/, { token: "string", next: "@pop" }]
        ],
        // q'[foobar]'
        qStringSquareBracket: [
          [/[^\]']+/, "string"],
          [/'/, "string"],
          [/\](?!')/, "string"],
          [/]'/, { token: "keyword", next: "@pop" }]
        ],
        // q'<foobar>'
        qStringAngleBracket: [
          [/[^>']+/, "string"],
          [/'/, "string"],
          [/>(?!')/, "string"],
          [/>'/, { token: "keyword", next: "@pop" }]
        ],
        // q'{foobar}'
        qStringCurlyBracket: [
          [/[^}']+/, "string"],
          [/'/, "string"],
          [/}(?!')/, "string"],
          [/}'/, { token: "keyword", next: "@pop" }]
        ],
        // q'(foobar)'
        qStringParentheses: [
          [/[^)']+/, "string"],
          [/'/, "string"],
          [/\)(?!')/, "string"],
          [/\)'/, { token: "keyword", next: "@pop" }]
        ],
        // q'!foobar!'
        qStringCustom: [
          [/(.)(?!')/, "string"],
          [/(.)'/, {
            cases: {
              "$1==$S2": { token: "keyword", next: "@pop" },
              "$1!=$S2": { token: "string" }
            }
          }]
        ]
      }
    });
  };

  // images/apex_ui/js/code-editor/languages/quicksql.mjs
  var { jQuery: $, lang, util } = apex;
  var langId4 = "quicksql";
  var register4 = () => {
    let gKeywords = [
      "/api",
      "/audit",
      "/auditcols",
      "/audit columns",
      "/between",
      "/cascade",
      "/check",
      "/constant",
      "cols",
      "columns",
      "/colprefix",
      "/compress",
      "/compressed",
      "drop",
      "/default",
      "/fk",
      "genpk",
      "/invisible",
      "/hidden",
      "/history",
      "/idx",
      "/index",
      "/indexed",
      "/insert",
      "/lower",
      "pk",
      "prefix",
      "/pk",
      "/references",
      "/reference",
      "/rest",
      "schema",
      "/select",
      "/unique",
      "/upper",
      "verbose",
      "view",
      "/values",
      "/nn",
      "/not null",
      "and"
    ];
    let gTypes = ["d", "date", "ts", "time", "timestamp", "tstz", "tswtz", "local", "with", "blob", "char", "clob", "file", "int", "integer", "json", "num", "number", "string", "varchar", "varchar2", "vc", "vc32k"];
    let msg2 = function(key) {
      return util.stripHTML(lang.getMessage(key));
    };
    let colTypeHints = [
      {
        label: "num, number",
        insertText: "num",
        detail: "NUMBER"
      },
      {
        label: "int, integer",
        insertText: "int",
        detail: "INTEGER"
      },
      {
        label: "d, date",
        insertText: "date",
        detail: "DATE"
      },
      {
        label: "ts, timestamp",
        insertText: "timestamp",
        detail: "TIMESTAMP"
      },
      {
        label: "tstz, tswtz, timestamp with local time zone",
        insertText: "tstz",
        detail: "TIMESTAMP WITH LOCAL TIMEZONE"
      },
      {
        label: "char, vc, varchar, varchar2, string",
        insertText: "vc",
        detail: "VARCHAR2(4000)"
      },
      {
        label: "vcNNN, vc(NNN)",
        insertText: "vc${0:NNN}",
        detail: msg2("QUICKSQL.HELP.NNN")
      },
      {
        label: "vc32k",
        detail: "VARCHAR2(32767)"
      },
      {
        label: "clob",
        detail: "CLOB"
      },
      {
        label: "blob",
        detail: "BLOB"
      },
      {
        label: "json",
        detail: "CLOB CHECK (<" + msg2("QUICKSQL.HELP.COLUMN_NAME") + "> IS JSON)"
      },
      {
        label: "file",
        detail: msg2("QUICKSQL.HELP.FILE_DATATYPE")
      }
    ];
    let tableDirHints = [
      {
        label: "/api",
        detail: msg2("QUICKSQL.HELP.API")
      },
      {
        label: "/audit",
        detail: msg2("QUICKSQL.HELP.AUDIT")
      },
      {
        label: "/auditcols",
        detail: msg2("QUICKSQL.HELP.AUDITCOLS")
      },
      {
        label: "/cascade",
        insertText: "/cascade",
        detail: msg2("QUICKSQL.HELP.CASCADE")
      },
      {
        label: "/colprefix",
        insertText: "/colprefix ${0:prefix}",
        detail: msg2("QUICKSQL.HELP.COLPREFIX")
      },
      {
        label: "/compress",
        detail: msg2("QUICKSQL.HELP.COMPRESSED")
      },
      {
        label: "/history",
        detail: msg2("QUICKSQL.HELP.HISTORY")
      },
      {
        label: "/insert",
        insertText: "/insert ${0:NNN}",
        detail: msg2("QUICKSQL.HELP.INSERT")
      },
      {
        label: "/rest",
        detail: msg2("QUICKSQL.HELP.REST")
      },
      {
        label: "/select",
        detail: msg2("QUICKSQL.HELP.SELECT")
      },
      {
        label: "/unique",
        detail: msg2("QUICKSQL.HELP.TABLE_UNIQUE")
      }
    ];
    let colDirHints = [
      {
        label: "/index /idx /indexed",
        insertText: "/index",
        detail: msg2("QUICKSQL.HELP.INDEX")
      },
      {
        label: "/unique",
        detail: msg2("QUICKSQL.HELP.UNIQUE")
      },
      {
        label: "/cascade",
        insertText: "/cascade",
        detail: msg2("QUICKSQL.HELP.CASCADE")
      },
      {
        label: "/check",
        insertText: "/check ${0:val1,val2,...}",
        detail: msg2("QUICKSQL.HELP.CHECK")
      },
      {
        label: "/constant",
        insertText: "/constant ${0:value}",
        detail: msg2("QUICKSQL.HELP.CONSTANT")
      },
      {
        label: "/default",
        insertText: "/default ${0:value}",
        detail: msg2("QUICKSQL.HELP.DEFAULT")
      },
      {
        label: "/values",
        insertText: "/values ${0:dummy1,dummy2,...}",
        detail: msg2("QUICKSQL.HELP.VALUES")
      },
      {
        label: "/upper",
        detail: msg2("QUICKSQL.HELP.UPPER")
      },
      {
        label: "/lower",
        detail: msg2("QUICKSQL.HELP.LOWER")
      },
      {
        label: "/nn /not null",
        insertText: "/nn",
        detail: msg2("QUICKSQL.HELP.NOTNULL")
      },
      {
        label: "/between",
        insertText: "/between ${0:min and max}",
        detail: msg2("QUICKSQL.HELP.BETWEEN")
      },
      {
        label: "/invisible /hidden",
        insertText: "/invisible",
        detail: msg2("QUICKSQL.HELP.HIDDEN")
      },
      {
        label: "/fk /reference /references",
        insertText: "/fk ${0:table name}",
        detail: msg2("QUICKSQL.HELP.FK")
      },
      {
        label: "/pk",
        detail: msg2("QUICKSQL.HELP.PK")
      }
    ];
    function getLineType(model, lineNumber) {
      let lineContent = model.getLineContent(lineNumber).toLowerCase(), hasText = /\w/.test(lineContent), spaces = lineContent.search(/\S|$/), lineCount = model.getLineCount(), hasNextLine = lineNumber < lineCount, hasPreviousLine = lineNumber > 1, lineType;
      if (lineContent.length === 0) {
        lineType = "blank";
      } else if (lineContent.startsWith("#")) {
        lineType = "comment";
      } else if (lineContent.startsWith("view")) {
        lineType = "view";
      } else if (hasText && spaces === 0) {
        lineType = "table";
      } else if (hasText && hasNextLine) {
        let nextLineContent = model.getLineContent(lineNumber + 1), nextLineSpaces = nextLineContent.search(/\S|$/);
        lineType = nextLineSpaces > spaces ? "table" : "column";
      } else if (hasText && hasPreviousLine) {
        let previousLineContent = model.getLineContent(lineNumber - 1), previousLineSpaces = previousLineContent.search(/\S|$/);
        lineType = previousLineSpaces <= spaces ? "column" : "unknown";
      }
      return lineType || "unknown";
    }
    function getTableNames(model) {
      let tables = [];
      for (let i = 1; i <= model.getLineCount(); i++) {
        let lineContent = model.getLineContent(i);
        if (getLineType(model, i) === "table") {
          tables.push(lineContent.trim().split(" ")[0]);
        }
      }
      return tables;
    }
    monaco.languages.register({ id: langId4 });
    monaco.languages.setMonarchTokensProvider(langId4, {
      keywords: gKeywords,
      atoms: [],
      types: gTypes,
      dates: [],
      ignoreCase: true,
      tokenizer: {
        root: [
          // highlighting view lines
          [/(view)(\s+)([^\s]+)(\s+)(.+)/, ["keywords", "whitespace", "view", "whitespace", "table"]],
          /* highlights top level table names to avoid flickering
              * lower level table names must unfortunately be highlighted via javascript
              * and will therefore flicker as you type around them
              */
          [/^\w+/, "table"],
          // highlighting table names as arguments of /fk, /references, or /reference
          [/(\/fk|\/reference|\/references)(\s+)(\w+)/, ["keywords", "whitepace", "table"]],
          [/\s{1}/, "whitespace"],
          [/[0-9]/, "number"],
          [/(vc\d*k?)/, "types"],
          // highlights list values after /values or /check but stops at comments
          // todo: allow for other valid tokens to come after
          [/(\/values|\/check)(\s+)(.+)(\s+)(\[[a-zA-Z 0-9:]+\])/, ["keywords", "whitespace", "list", "whitespace", "comment"]],
          [/(\/values|\/check)(\s+)(.+)/, ["keywords", "whitespace", "list"]],
          // allows for comments to follow the above rule
          [/(#.*)/, "comment"],
          // quicksql comment
          [/--.*$/, "comment"],
          // table or column comment
          [/\[[a-zA-Z 0-9:]+\]/, "comment"],
          // table or column comment
          [/[/a-z_$][\w$]*/, {
            cases: {
              "@keywords": "keywords",
              "@types": "types",
              "@default": "default"
            }
          }]
        ]
      }
    });
    monaco.languages.registerCompletionItemProvider(langId4, {
      triggerCharacters: ["/"],
      provideCompletionItems: function(model, position) {
        let lineContent = model.getLineContent(position.lineNumber), lineContentUpToPos = lineContent.slice(0, position.column - 1), currentWord = model.getWordAtPosition(position), previousWords, previousWord, wordStartChar, wordStartColumn, wordEndColumn, suggestions = [];
        let lineType = getLineType(model, position.lineNumber);
        if (!currentWord) {
          currentWord = {
            word: "",
            startColumn: position.column,
            endColumn: position.column
          };
        }
        wordStartChar = lineContent.charAt(currentWord.startColumn - 2);
        if (wordStartChar === ",") {
          return [];
        }
        if (wordStartChar === "/") {
          wordStartColumn = currentWord.startColumn - 1;
        } else {
          wordStartColumn = currentWord.startColumn;
        }
        wordEndColumn = currentWord.endColumn;
        previousWords = lineContentUpToPos.split(/\s+/);
        previousWord = previousWords[previousWords.length - 2];
        if (["/fk", "/references", "/reference"].includes(previousWord) || lineType === "view" && previousWords.length >= 3) {
          suggestions = getTableNames(model).map(function(tableName) {
            return {
              label: tableName
            };
          });
        } else if (["/values", "/check", "/between", "/default", "/constant", "/colprefix", "/insert"].includes(previousWord)) {
          return;
        } else if (["table", "column"].includes(lineType)) {
          if (!/\w+\s/.test(lineContentUpToPos)) {
            suggestions = [];
          } else if (lineType === "table") {
            suggestions = tableDirHints;
          } else if (lineType === "column") {
            suggestions = colDirHints.concat(colTypeHints);
          }
        }
        let newSuggestions = [];
        for (let i = 0; i < suggestions.length; i++) {
          newSuggestions.push({
            label: suggestions[i].label,
            insertText: suggestions[i].insertText || suggestions[i].label,
            detail: suggestions[i].detail,
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            kind: monaco.languages.CompletionItemKind.Keyword,
            range: {
              startLineNumber: position.lineNumber,
              endLineNumber: position.lineNumber,
              startColumn: wordStartColumn,
              endColumn: wordEndColumn
            }
          });
        }
        return { suggestions: newSuggestions };
      }
    });
    $.apex.codeEditor = $.apex.codeEditor || {};
    $.apex.codeEditor.performExtraQuicksqlHighlight = function(editor) {
      function highlightTables(model, lineNumber, line$) {
        if (getLineType(model, lineNumber) === "table") {
          line$.children().filter(function() {
            return $(this).text().trim();
          }).first().addClass("quicksql-table");
        }
      }
      function customHighlight(editor2) {
        let lines$ = $("div.view-line", editor2.getDomNode()), line$, viewportStartLine = Math.max(editor2._modelData.viewModel.viewportStartLine, 1), lines = [];
        lines$.each(function() {
          line$ = $(this);
          let topValue = line$.get(0).style.top.replace("px", "");
          lines.push({
            top: parseInt(topValue, 10),
            line$: line$.children().first()
          });
        });
        lines.sort(function(a, b) {
          if (a.top > b.top) {
            return 1;
          }
          if (a.top < b.top) {
            return -1;
          }
          return 0;
        });
        for (let i = 0; i < lines.length; i++) {
          highlightTables(editor2.getModel(), viewportStartLine + i, lines[i].line$);
        }
      }
      let debouncedHighlight = util.debounce(function() {
        customHighlight(editor);
      }, 100);
      editor.onDidChangeModelContent(function() {
        debouncedHighlight();
      });
      editor.onDidScrollChange(function() {
        debouncedHighlight();
      });
      debouncedHighlight();
    };
  };

  // images/apex_ui/js/code-editor/languages/td.mjs
  var langIdTdPlainText = "td-plaintext";
  var langIdTdHtml = "td-html";
  var DISPOSABLE_SUBSTITUTIONS = "td_subs";
  var DISPOSABLE_LOOP_SUBSTITUTIONS = "td_loop_subs";
  var register5 = (langId5) => {
    monaco.languages.register({ id: langId5 });
    const EMPTY_ELEMENTS = [
      "area",
      "base",
      "br",
      "col",
      "embed",
      "hr",
      "img",
      "input",
      "keygen",
      "link",
      "menuitem",
      "meta",
      "param",
      "source",
      "track",
      "wbr"
    ];
    if (langId5 === langIdTdPlainText) {
      monaco.languages.setLanguageConfiguration(langId5, {
        comments: {
          blockComment: ["{!", "/}"]
        },
        brackets: [
          ["{", "/}"],
          ["{!", "/}"]
          // should work, but doesn't
        ],
        autoClosingPairs: [
          { open: "{!", close: "/}", notIn: ["string", "comment", "td-comment"] }
        ]
      });
    } else {
      monaco.languages.setLanguageConfiguration(langId5, {
        wordPattern: /(-?\d*\.\d\w*)|([^`~!@^&*()=+[{\]}\\|;:'",.<>/\s#]+)/g,
        comments: {
          // wraps the selection in a block comment when performing Toggle Block Comment (Shift+Alt+A)
          // Toggle Line Comment also works (CMD+/)
          blockComment: ["{!", "/}"]
        },
        // When you move the cursor to a bracket defined here,
        //  Monaco will highlight that bracket together with its matching pair.
        // Moreover, when you run Go to Bracket or Select to Bracket,
        //  Monaco will use the definition above to find the nearest bracket and its matching pair.
        brackets: [
          // New for Template Directives
          ["{", "/}"],
          ["{!", "/}"],
          // should work, but doesn't
          // Inherited from HTML:
          ["<!--", "-->"],
          // should work, but doesn't
          ["<", ">"],
          ["{", "}"],
          ["(", ")"]
        ],
        // The language's auto closing pairs.
        // The 'close' character is automatically inserted with the 'open' character is typed.
        // If not set, the configured brackets will be used.
        autoClosingPairs: [
          { open: "{!", close: "/}", notIn: ["string", "comment", "td-comment"] },
          //{ open: "{", close: "}" },    // disabling as it interferes with template directive syntax
          { open: "[", close: "]", notIn: ["string", "comment", "td-comment"] },
          { open: "(", close: ")", notIn: ["string", "comment", "td-comment"] },
          { open: '"', close: '"', notIn: ["string", "comment", "td-comment"] }
          //{ open: "'", close: "'" },    // disabling as it interferes with English typing
        ],
        // The language's surrounding pairs.
        // When the 'open' character is typed on a selection, the selected string is surrounded by the open and close characters.
        // If not set, the autoclosing pairs settings will be used.
        surroundingPairs: [
          { open: '"', close: '"' },
          { open: "'", close: "'" },
          { open: "{", close: "}" },
          { open: "[", close: "]" },
          { open: "(", close: ")" },
          { open: "<", close: ">" }
        ],
        // Inherited from HTML.
        // Nothing to add for Template Directives.
        onEnterRules: [{
          beforeText: new RegExp(
            `<(?!(?:${EMPTY_ELEMENTS.join("|")}))([_:\\w][_:\\w-.\\d]*)([^/>]*(?!/)>)[^<]*$`,
            "i"
          ),
          afterText: /^<\/([_:\w][_:\w-.\d]*)\s*>$/i,
          action: {
            indentAction: monaco.languages.IndentAction.IndentOutdent
          }
        }, {
          beforeText: new RegExp(
            `<(?!(?:${EMPTY_ELEMENTS.join("|")}))(\\w[\\w\\d]*)([^/>]*(?!/)>)[^<]*$`,
            "i"
          ),
          action: { indentAction: monaco.languages.IndentAction.Indent }
        }]
      });
    }
    monaco.languages.setMonarchTokensProvider(langId5, {
      defaultToken: "",
      tokenPostfix: ".td-html",
      //ignoreCase: true,
      includeLF: true,
      // allows us to match line endings
      modifier: /!|\?|=|!\?|!=/,
      name: /[a-zA-Z0-9$%_.!&]+/,
      whitespace: /\s+/,
      openBracket: /\{/,
      closeBracket: /\/\}/,
      tokenizer: {
        root: [
          { include: "@tdTag" },
          { include: "@htmlTag" }
        ],
        tdTag: [
          // if with modifier
          [
            /(@openBracket)(if)(@whitespace)(@modifier)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-modifier", "td-condition", { token: "delimiter.html", next: "@if.$S2" }]
          ],
          // if without modifier
          [
            /(@openBracket)(if)(@whitespace)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-condition", { token: "delimiter.html", next: "@if.$S2" }]
          ],
          // case
          [
            /(@openBracket)(case)(@whitespace)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-condition", { token: "delimiter.html", next: "@case.$S2" }]
          ],
          // loop
          [
            /(@openBracket)(loop)(@whitespace)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "string", { token: "delimiter.html", next: "@loop.$S2" }]
          ],
          // loop with separator
          [
            /(@openBracket)(loop)(@whitespace)(")([^"]+)(")(@whitespace)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "delimiter.html", "td-modifier", "delimiter.html", "", "string", { token: "delimiter.html", next: "@loop.$S2" }]
          ],
          // loop with detail
          [
            /(@openBracket)(loop)(@whitespace)(\[)(.*)(,\s*)(.*)(\])(@closeBracket)/,
            [
              "delimiter.html",
              "td-tag",
              "",
              "delimiter.square.js",
              "string.js",
              "delimiter.js",
              "string.js",
              "delimiter.js",
              { token: "delimiter.html", next: "@loop.$S2" }
            ]
          ],
          // with apply
          [
            /(@openBracket)(with)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@with.$S2" }]
          ],
          // comment
          [
            /({!)/,
            [{ token: "comment.html", next: "@comment" }]
          ]
        ],
        text: [
          [/./, {
            cases: {
              "$S2==td-with-val": { token: "attribute.value.html" },
              "$S2==html-attr": { token: "attribute.name.html" },
              "$S2==html-attr-val": { token: "attribute.value.html" },
              "@default": ""
            }
          }]
        ],
        if: [
          [
            /(@openBracket)(elseif)(@whitespace)(@modifier)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-modifier", "td-condition", "delimiter.html"]
          ],
          [
            /(@openBracket)(elseif)(@whitespace)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-condition", "delimiter.html"]
          ],
          [
            /(@openBracket)(else)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", switchTo: "@ifElse.$S2" }]
          ],
          [
            /(@openBracket)(endif)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@pop" }]
          ],
          { include: "@tdTag" },
          { include: "@htmlTag" },
          { include: "@text" }
        ],
        // same as "if", but without "elseif" and "else" as they cannot occur after "else"
        ifElse: [
          [
            /(@openBracket)(endif)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@pop" }]
          ],
          { include: "@tdTag" },
          { include: "@htmlTag" },
          { include: "@text" }
        ],
        case: [
          [
            /(@openBracket)(when)(@whitespace)(.+?)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-condition", "delimiter.html"]
          ],
          [
            /(@openBracket)(otherwise)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", switchTo: "@caseOtherwise.$S2" }]
          ],
          [
            /(@openBracket)(endcase)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@pop" }]
          ],
          { include: "@tdTag" },
          { include: "@htmlTag" },
          { include: "@text" }
        ],
        // same as "case", but without "when" and "otherwise" as they cannot occur after "else"
        caseOtherwise: [
          [
            /(@openBracket)(endcase)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@pop" }]
          ],
          { include: "@tdTag" },
          { include: "@htmlTag" },
          { include: "@text" }
        ],
        loop: [
          [
            /(@openBracket)(endloop)(@closeBracket)/,
            ["delimiter.html", "td-tag", { token: "delimiter.html", next: "@pop" }]
          ],
          { include: "@tdTag" },
          { include: "@htmlTag" },
          { include: "@text" }
        ],
        with: [
          [
            /(@openBracket)(apply)(\s+)(@name)(@closeBracket)/,
            ["delimiter.html", "td-tag", "", "td-condition", { token: "delimiter.html", next: "@pop" }]
          ],
          [
            /(@whitespace)/,
            [""]
          ],
          [
            /(@name\s*)(:=)(\n)/,
            ["attribute.name.html", "delimiter.html", ""]
          ],
          [
            /(@name\s*)(:=)(.)/,
            ["attribute.name.html", "delimiter.html", { token: "@rematch", switchTo: "@withValue.td-with-val" }]
          ]
        ],
        withValue: [
          { include: "@tdTag" },
          { include: "@htmlTag" },
          [/\n/, { token: "", switchTo: "@with" }],
          [/(.)/, "attribute.value.html"]
        ],
        comment: [
          [/\/}/, "comment.html", "@pop"],
          [/./, "comment.content.html"]
        ],
        ...langId5 === langIdTdHtml ? {
          htmlTag: [
            [/<!--/, "comment.html", "@htmlComment"],
            [/(<)((?:[\w-]+:)?[\w-]+)(\s*)(\/>)/, ["delimiter.html", "tag.html", "", "delimiter.html"]],
            [/(<)((?:[\w-]+:)?[\w-]+)/, ["delimiter.html", { token: "tag.html", next: "@htmlTagAttributes.html-attr" }]],
            [/(<\/)((?:[\w-]+:)?[\w-]+)/, ["delimiter.html", { token: "tag.html", next: "@htmlTagAttributes.html-attr" }]]
          ],
          htmlComment: [
            [/-->/, "comment", "@pop"],
            [/[^-]+/, "comment.content.html"],
            [/./, "comment.content.html"]
          ],
          htmlTagAttributes: [
            { "include": "@tdTag" },
            [/\/?>/, "delimiter.html", "@pop"],
            [/(["'])/, { token: "attribute.value.html", switchTo: "@htmlTagAttributeValue.html-attr-val.$1" }],
            [/[\w-]+/, "attribute.name.html"],
            [/=/, "delimiter.html"]
          ],
          htmlTagAttributeValue: [
            { include: "@tdTag" },
            [/(["'])/, {
              cases: {
                "$S3==$1": { token: "attribute.value.html", switchTo: "@htmlTagAttributes.html-attr" },
                "@default": "attribute.value.html"
              }
            }],
            [/./, "attribute.value.html"]
          ]
        } : {
          htmlTag: []
        }
      }
    });
    monaco.languages.registerCompletionItemProvider(langId5, {
      triggerCharacters: ["{"],
      provideCompletionItems: (model, position, context) => {
        if (context.triggerCharacter === "{") {
          const list = [{
            label: "{if/}{endif/}",
            insertText: [
              "{if ${1:condition}/}",
              "{endif/}"
            ].join("\n")
          }, {
            label: "{if/}{else/}{endif/}",
            insertText: [
              "{if ${1:NAME}/}",
              "{else/}",
              "{endif/}"
            ].join("\n")
          }, {
            label: "{if/}{elseif/}{endif/}",
            insertText: [
              "{if ${1:NAME}/}",
              "{elseif ${2:NAME}/}",
              "{endif/}"
            ].join("\n")
          }, {
            label: "{if/}{elseif/}{else/}{endif/}",
            insertText: [
              "{if ${1:NAME}/}",
              "{elseif ${2:NAME}/}",
              "{else/}",
              "{endif/}"
            ].join("\n")
          }, {
            label: "{if/}",
            insertText: "{if ${1:NAME}/}"
          }, {
            label: "{elseif/}",
            insertText: "{elseif ${1:NAME}/}"
          }, {
            label: "{else/}",
            insertText: "{else/}"
          }, {
            label: "{endif/}",
            insertText: "{endif/}"
          }, {
            label: "{case/}{when/}{when/}{endcase/}",
            insertText: [
              "{case ${1:NAME}/}",
              "{when ${2:VAL1}/}",
              "{when ${3:VAL2}/}",
              "{endcase/}"
            ].join("\n")
          }, {
            label: "{case/}{when/}{when/}{otherwise/}{endcase/}",
            insertText: [
              "{case ${1:NAME}/}",
              "{when ${2:VAL1}/}",
              "{when ${3:VAL2}/}",
              "{otherwise/}",
              "{endcase/}"
            ].join("\n")
          }, {
            label: "{case/}",
            insertText: "{case ${1:NAME}/}"
          }, {
            label: "{when/}",
            insertText: "{when ${1:VALUE}/}"
          }, {
            label: "{otherwise/}",
            insertText: "{otherwise/}"
          }, {
            label: "{endcase/}",
            insertText: "{endcase/}"
          }, {
            label: "{loop/}{endloop/}",
            insertText: [
              "{loop ${1:NAME}/}",
              "{endloop/}"
            ].join("\n")
          }, {
            label: '{loop "SEP"/}{endloop/}',
            insertText: [
              '{loop "${1:SEP}" ${2:NAME}/}',
              "{endloop/}"
            ].join("\n")
          }, {
            label: "{loop/}",
            insertText: "{loop/}"
          }, {
            label: "{endloop}/}",
            insertText: "{endloop/}"
          }, {
            label: "{with/}{apply/}",
            insertText: [
              "{with/}",
              "ARG1:=VAL1",
              "ARG2:=VAL2",
              "{apply ${1:NAME}/}"
            ].join("\n")
          }, {
            label: "{!comment/}",
            insertText: "{!comment/}"
          }];
          return {
            suggestions: list.map((suggestion, i) => {
              return {
                label: suggestion.label,
                insertText: suggestion.insertText,
                kind: monaco.languages.CompletionItemKind.Constant,
                insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                // keep items in the same order as above
                sortText: i.toString().padStart(3, "0"),
                additionalTextEdits: [{
                  range: {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: position.column - 1,
                    // removes triggering character
                    endColumn: position.column
                  },
                  text: null
                }]
              };
            })
          };
        }
      }
    });
    if (langId5 === langIdTdHtml) {
      monaco.html.registerHTMLLanguageService(langId5, {}, {
        foldingRanges: false,
        links: false
      });
    }
  };
  var isWithinLoop = (model, position) => {
    const before = model.getValueInRange({
      startLineNumber: 1,
      startColumn: 1,
      endLineNumber: position.lineNumber,
      endColumn: position.column - 1
    });
    const loopCount = before.match(/{loop .*?(\/})/g)?.length || 0;
    const endloopCount = before.match(/{endloop\/}/g)?.length || 0;
    return loopCount > endloopCount;
  };
  var isWithinDirective = (model, position) => {
    return /{(if|elseif|case|loop)[^(/})\n]+$/.test(model.getLineContent(position.lineNumber).substring(0, position.column - 1));
  };
  var registerTdCompletions = function() {
    const editor = this._editor, tdOptions = this.options.tdOptions, langId5 = this.options.language;
    const prepareSub = (substitution, type, wrap) => {
      let label = {};
      let insertText;
      if (typeof substitution === "string") {
        label.label = substitution;
      } else if (typeof substitution === "object") {
        label.label = substitution.name;
        label.category = substitution.category;
      }
      insertText = label.label;
      if (!/^[a-zA-Z0-9_$%]+$/.test(insertText)) {
        insertText = `"${insertText.replaceAll('"', '""')}"`;
      }
      if (wrap) {
        if (type === "&") {
          insertText = `&${insertText}.`;
        } else if (type === "#") {
          insertText = `#${insertText}#`;
        }
      }
      return {
        label,
        insertText
      };
    };
    this._registerDisposable(DISPOSABLE_SUBSTITUTIONS, monaco.languages.registerCompletionItemProvider(langId5, {
      triggerCharacters: ["&", "#", " "],
      provideCompletionItems: (model, position, context) => {
        const GROUP = "A";
        const list = [];
        let wrapSuggestion;
        let removeTriggeringCharacter;
        if (!editor.hasTextFocus()) {
          return;
        }
        if (!tdOptions) {
          return;
        }
        if (isWithinDirective(model, position)) {
          wrapSuggestion = false;
        } else if (["&", "#"].includes(context.triggerCharacter)) {
          wrapSuggestion = true;
          removeTriggeringCharacter = true;
        } else {
          return;
        }
        tdOptions.substitutions?.items?.forEach((substitution) => {
          list.push(prepareSub(substitution, "&", wrapSuggestion));
        });
        tdOptions.substitutions?.columns?.forEach((substitution) => {
          list.push(prepareSub(substitution, "&", wrapSuggestion));
        });
        tdOptions.substitutions?.custom?.forEach((substitution) => {
          list.push(prepareSub(substitution, "&", wrapSuggestion));
        });
        tdOptions.placeholders?.forEach((substitution) => {
          list.push(prepareSub(substitution, "#", wrapSuggestion));
        });
        return {
          suggestions: list.map((item, i) => {
            return {
              label: {
                label: item.label.label,
                description: item.label.category
              },
              insertText: item.insertText,
              kind: monaco.languages.CompletionItemKind.Constant,
              // keep items in the same order as above
              sortText: GROUP + i.toString().padStart(3, "0"),
              additionalTextEdits: [{
                range: {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: position.column + (removeTriggeringCharacter ? -1 : 0),
                  endColumn: position.column
                },
                text: null
              }]
            };
          })
        };
      }
    }));
    this._registerDisposable(DISPOSABLE_LOOP_SUBSTITUTIONS, monaco.languages.registerCompletionItemProvider(langId5, {
      triggerCharacters: ["&", " "],
      provideCompletionItems: (model, position, context) => {
        const GROUP = "B";
        let wrapSuggestion;
        let removeTriggeringCharacter;
        if (!editor.hasTextFocus()) {
          return;
        }
        if (!tdOptions) {
          return;
        }
        if (!isWithinLoop(model, position)) {
          return;
        }
        if (isWithinDirective(model, position)) {
          wrapSuggestion = false;
        } else if (context.triggerCharacter === "&") {
          wrapSuggestion = true;
          removeTriggeringCharacter = true;
        } else {
          return;
        }
        const list = [
          "APEX$ITEM",
          "APEX$I"
        ];
        if (tdOptions.scope === "C") {
          list.push(
            "APEX$ID",
            "APEX$META%valid",
            "APEX$META%state",
            "APEX$META%allowedOperations",
            "APEX$META%agg",
            "APEX$META%highlight",
            "APEX$META%endControlBreak",
            "APEX$META%grandTotal",
            "APEX$META%errorMessage",
            "APEX$META%warningMessage"
          );
        }
        return {
          suggestions: list.map((suggestion, i) => {
            return {
              label: suggestion,
              insertText: wrapSuggestion ? `&${suggestion}.` : suggestion,
              kind: monaco.languages.CompletionItemKind.Constant,
              sortText: GROUP + i.toString().padStart(3, "0"),
              additionalTextEdits: [{
                range: {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: position.column + (removeTriggeringCharacter ? -1 : 0),
                  endColumn: position.column
                },
                text: null
              }]
            };
          })
        };
      }
    }));
  };
  var mixins = {
    registerTdCompletions
  };
  var registerTdPlainText = () => {
    register5(langIdTdPlainText);
  };
  var registerTdHtml = () => {
    register5(langIdTdHtml);
  };

  // images/apex_ui/js/code-editor/languages/apexlang.mjs
  var LANG_ID = "apexlang";
  var COMPONENT = "component";
  var PROPERTY_NAME = "property.name";
  var PROPERTY_VALUE = "property.value";
  var COMPONENT_NAME = PROPERTY_VALUE;
  var DELIMITER = "delimiter";
  var INVALID = "invalid";
  var THEME_RULES = {
    LIGHT: [
      // background: fffffe
      { token: `${COMPONENT}.${LANG_ID}`, foreground: "0451a5" },
      // 7.7:1    dark blue
      { token: `${PROPERTY_NAME}.${LANG_ID}`, foreground: "008080" },
      // 4.8:1    blue
      { token: `${PROPERTY_VALUE}.${LANG_ID}`, foreground: "a31515" },
      // 7.8:1    brown
      { token: `${DELIMITER}.${LANG_ID}`, foreground: "000000" },
      // 21:1     black
      { token: `${INVALID}.${LANG_ID}`, foreground: "cd3131" }
      // 5.1:1    red
    ],
    DARK: [
      // background: 1e1e1e
      { token: `${COMPONENT}.${LANG_ID}`, foreground: "569cd6" },
      // 5.7:1    dark blue
      { token: `${PROPERTY_NAME}.${LANG_ID}`, foreground: "9cdcfe" },
      // 11.2:1   blue
      { token: `${PROPERTY_VALUE}.${LANG_ID}`, foreground: "ce9178" },
      // 6.3:1    brown
      { token: `${DELIMITER}.${LANG_ID}`, foreground: "969696" },
      // 7.1:1    gray
      { token: `${INVALID}.${LANG_ID}`, foreground: "f44747" }
      // 4.6:1    red
    ],
    HC_DARK: [
      // background: 000000
      { token: `${COMPONENT}.${LANG_ID}`, foreground: "6796E6" },
      // 7.1:1    blue
      { token: `${PROPERTY_NAME}.${LANG_ID}`, foreground: "1aebff" },
      // 14.4:1   light blue
      { token: `${PROPERTY_VALUE}.${LANG_ID}`, foreground: "3ff23f" },
      // 14:1     green
      { token: `${DELIMITER}.${LANG_ID}`, foreground: "ffff00" },
      // 19.6:1   yellow
      { token: `${INVALID}.${LANG_ID}`, foreground: "ffffff" }
      // 21:1     white
    ]
  };
  var register6 = () => {
    monaco.languages.register({ id: LANG_ID });
    monaco.languages.setLanguageConfiguration(LANG_ID, {
      brackets: [
        ["(", ")"],
        ["{", "}"],
        ["[", "]"]
      ],
      autoClosingPairs: [
        { open: "(", close: ")" },
        { open: "{", close: "}" },
        { open: "[", close: "]" }
      ]
    });
    monaco.languages.setMonarchTokensProvider(LANG_ID, {
      defaultToken: "invalid",
      // makes it easier to catch untokenized content
      ignoreCase: false,
      includeLF: true,
      IDEN: /[^"`:{}()[\] \t\r\n]+/,
      QUOTED_STRING: /"(?:\\\\|\\"|[^"\\\r\n])*"/,
      tokenizer: {
        root: [
          { include: "@component" }
        ],
        component: [
          // component with a name
          [/(@IDEN)( +)(@IDEN|@QUOTED_STRING)( +)(\()/, [
            COMPONENT,
            "",
            COMPONENT_NAME,
            "",
            { token: DELIMITER, next: "@componentContent" }
          ]],
          // component without a name
          [/(@IDEN)( +)(\()/, [
            COMPONENT,
            "",
            { token: DELIMITER, next: "@componentContent" }
          ]]
        ],
        componentContent: [
          { include: "@whitespace" },
          { include: "@popOnClosingParentheses" },
          { include: "@properties" },
          { include: "@propertyGroup" },
          { include: "@component" }
        ],
        propertyGroup: [
          [/(@IDEN)( +)(\{)/, [
            COMPONENT,
            "",
            { token: DELIMITER, next: "@properties" }
          ]]
        ],
        properties: [
          { include: "@whitespace" },
          { include: "@popOnClosingCurlyBracket" },
          [/(@IDEN|@QUOTED_STRING)(:)( +)(\{)/, [
            PROPERTY_NAME,
            DELIMITER,
            "",
            { token: DELIMITER, next: "@properties" }
          ]],
          [/(@IDEN|@QUOTED_STRING)(:)( +)(\[)/, [
            PROPERTY_NAME,
            DELIMITER,
            "",
            { token: DELIMITER, next: "@propertyArray" }
          ]],
          [/(@IDEN|@QUOTED_STRING)(:)(?=$)/, [
            PROPERTY_NAME,
            DELIMITER
          ]],
          [/(@IDEN|@QUOTED_STRING)(:)(\n)/, [
            PROPERTY_NAME,
            DELIMITER,
            { token: "", next: "@possibleMultiLineValue" }
          ]],
          [/(@IDEN|@QUOTED_STRING)(:)( +)(.*)/, [
            PROPERTY_NAME,
            DELIMITER,
            "",
            PROPERTY_VALUE
          ]]
        ],
        possibleMultiLineValue: [
          [/( +)(```)/, [
            "",
            { token: DELIMITER, next: "@propertyMultiLineValue" }
          ]],
          [/(.)/, [
            { token: "@rematch", next: "@pop" }
          ]]
        ],
        propertyMultiLineValue: [
          { include: "@whitespace" },
          [/\\```/, PROPERTY_VALUE],
          { include: "@popOnTripleBackticks" },
          [/.+/, PROPERTY_VALUE]
        ],
        propertyArray: [
          { include: "@whitespace" },
          [/@QUOTED_STRING/, PROPERTY_VALUE],
          { include: "@popOnClosingSquareBracket" },
          [/[^\]"\r\n]+/, PROPERTY_VALUE]
        ],
        whitespace: [
          [/[ \t\r\n]+/, ""]
        ],
        popOnClosingParentheses: [
          [/\)/, DELIMITER, "@pop"]
        ],
        popOnClosingCurlyBracket: [
          [/\}/, DELIMITER, "@pop"]
        ],
        popOnClosingSquareBracket: [
          [/\]/, DELIMITER, "@pop"]
        ],
        popOnTripleBackticks: [
          [/```/, DELIMITER, "@pop"]
        ]
      }
    });
  };

  // images/apex_ui/js/code-editor/codeEditor.mjs
  var { jQuery: $2, util: util2, lang: lang2, locale, debug, actions, env, libVersions, message } = apex;
  var msg = (key) => lang2.getMessage("CODE_EDITOR." + key);
  var debugTrace = function() {
    debug.trace("Code Editor:", ...arguments);
  };
  var debugWarn = function() {
    debug.warn("Code Editor:", ...arguments);
  };
  var debugError = function() {
    debug.error("Code Editor:", ...arguments);
  };
  var C_ACTIVE = "is-active";
  var C_TOOLBAR_GROUP = "a-Button--toolbarOutline";
  var EVENT_CLICK = "click";
  var LANG_SQL = "sql";
  var LANG_PLSQL = "plsql";
  var LANG_JAVASCRIPT = "javascript";
  var LANG_JAVASCRIPT_MLE_SNIPPET = "mle-javascript-snippet";
  var LANG_JAVASCRIPT_MLE_MODULE = "mle-javascript-module";
  var LANG_CSS = "css";
  var LANG_HTML = "html";
  var LANG_XML = "xml";
  var LANG_PLAINTEXT = "plaintext";
  var LANG_YAML = "yaml";
  var LANG_JSON = "json";
  var LANG_SYSTEM_PROMPT = "ai-system-prompt";
  var LANG_MARKDOWN = "markdown";
  var MONACO_LANG_JAVASCRIPT = "javascript";
  var MONACO_LANG_MARKDOWN = "markdown";
  var JS_LANGS = [
    LANG_JAVASCRIPT,
    LANG_JAVASCRIPT_MLE_SNIPPET,
    LANG_JAVASCRIPT_MLE_MODULE
  ];
  var AI_LANGS = [
    LANG_SQL,
    LANG_PLSQL,
    LANG_JAVASCRIPT,
    LANG_CSS,
    LANG_HTML,
    LANG_JAVASCRIPT_MLE_SNIPPET,
    LANG_JAVASCRIPT_MLE_MODULE,
    LANG_SYSTEM_PROMPT
  ];
  var CONTEXT_KEY_VALIDATE = "validate";
  var CONTEXT_KEY_DBHINT = "dbHint";
  var ACTION_SAVE_PAGE = "save-page";
  var ACTION_SAVE_AND_RUN_PAGE = "save-and-run-page";
  var ACTION_SWITCH_PANE_FOCUS = "switch-pane-focus";
  var ACTION_AI = "ai-enable-assistant";
  var ACTION_AI_MODE = "ai-mode-selector";
  var ACTION_AI_NL2SQL = "ai-nl2sql-assistant";
  var ACTION_AI_GENERAL = "ai-general-assistance";
  var ACTION_AI_SEND_SELECTION = "ai-send-selection";
  var ACTION_AI_SEND_CODE_MESSAGE = "ai-send-code-message";
  var ACTION_AI_CLEAR_CHAT = "ai-clear-history";
  var MSG_CLOSE = msg("CLOSE");
  var MSG_FIND = msg("FIND");
  var MSG_HINT = msg("HINT");
  var MSG_FONT_SIZE = msg("FONT_SIZE");
  var MSG_INDENTATION = msg("INDENTATION");
  var MSG_INDENT_SIZE = msg("INDENT_SIZE");
  var MSG_INDENT_WITH_TABS = msg("INDENT_WITH_TABS");
  var MSG_MINIMAP = msg("MINIMAP");
  var MSG_MINIMAP_CONDITIONAL = msg("MINIMAP_CONDITIONAL");
  var MSG_QUERY_BUILDER = msg("QUERY_BUILDER");
  var MSG_REDO = msg("REDO");
  var MSG_SETTINGS = msg("SETTINGS");
  var MSG_SHOW_LINE_NUMBERS = msg("SHOW_LINE_NUMBERS");
  var MSG_SHOW_RULER = msg("SHOW_RULER");
  var MSG_SUGGESTIONS = msg("SUGGESTIONS");
  var MSG_TAB_SIZE = msg("TAB_SIZE");
  var MSG_THEMES = msg("THEMES");
  var MSG_THEME_AUTOMATIC = msg("THEME_AUTOMATIC");
  var MSG_THEME_LIGHT = msg("THEME_LIGHT");
  var MSG_THEME_DARK = msg("THEME_DARK");
  var MSG_THEME_HIGH_CONTRAST_DARK = msg("THEME_HIGH_CONTRAST_DARK");
  var MSG_TRANSFORM_CODE_CASE = msg("TRANSFORM_CODE_CASE");
  var MSG_UNDO = msg("UNDO");
  var MSG_UTIL_OFF = msg("UTIL_OFF");
  var MSG_UTIL_ON = msg("UTIL_ON");
  var MSG_VALIDATE = msg("VALIDATE");
  var MSG_VALIDATION_SUCCESS = msg("VALIDATION_SUCCESS");
  var MSG_WHITESPACE = msg("WHITESPACE");
  var MSG_BRACKET_PAIR_COLORIZATION = msg("BRACKET_PAIR_COLORIZATION");
  var MSG_ROLE_DESC = msg("ROLE_DESCRIPTION");
  var MSG_ROLE_DESC_READONLY = msg("ROLE_DESCRIPTION_READONLY");
  var MSG_PREVIOUS_CHANGE = msg("PREVIOUS_CHANGE");
  var MSG_NEXT_CHANGE = msg("NEXT_CHANGE");
  var MSG_IMPROVE_SEL_TITLE = msg("CHAT.IMPROVE_SELECTION");
  var MSG_IMPROVE_TITLE = msg("CHAT.IMPROVE");
  var MSG_IMPROVE_MSG = msg("CHAT.IMPROVE_MSG");
  var MSG_EXPLAIN_SEL_TITLE = msg("CHAT.EXPLAIN_SELECTION");
  var MSG_EXPLAIN_TITLE = msg("CHAT.EXPLAIN");
  var MSG_EXPLAIN_MSG = msg("CHAT.EXPLAIN_MSG");
  var MSG_USE_SELECTION = msg("CHAT.USE_SELECTION");
  var MSG_AI_QUICK_ACTION_QUESTION = msg("CHAT.QUICK_ACTION_QUESTION");
  var MSG_AI_USE_THIS_WARNING = msg("CHAT.USE_THIS_WARNING");
  var MSG_AI_GENERAL_WELCOME = msg("CHAT.GENERAL_WELCOME");
  var MSG_AI_QUERY_BUILDER_WELCOME = msg("CHAT.QUERY_BUILDER_WELCOME");
  var MSG_AI_DEBUG_MESSAGE = msg("CHAT.AI_DEBUG_MESSAGE");
  var MSG_AI_GENERAL_ASSISTANCE = msg("CHAT.GENERAL_ASSISTANCE");
  var MSG_AI_QUERY_BUILDER = msg("CHAT.QUERY_BUILDER");
  var MSG_INSERT = msg("CHAT.INSERT");
  var MSG_INSERTED = msg("CHAT.INSERTED");
  var MSG_APEX_ASSISTANT = msg("CHAT.APEX_ASSISTANT");
  var MSG_DISCLAIMER = msg("CHAT.DISCLAIMER");
  var MSG_AI_DEBUG_HELP_LABEL = msg("CHAT.DEBUG_HELP_LABEL");
  var MSG_DEBUG_MESSAGE = msg("CHAT.DEBUG_MESSAGE");
  var MSG_CONTENT_TOO_LONG = msg("CHAT.CONTENT_TOO_LONG");
  var MSG_AI_ERROR_MESSAGE = msg("CHAT.ERROR_CODE_MESSAGE");
  var MSG_AI_WARNING_MESSAGE = msg("CHAT.WARNING_CODE_MESSAGE");
  var MSG_NEW_CONVERSATION = msg("CHAT.NEW_CONVERSATION");
  var MSG_CLEAR_CHAT = msg("CHAT.CLEAR_CHAT");
  var MSG_SAVE_AND_RUN_PAGE = lang2.getMessage("PD.SAVE_AND_RUN_PAGE");
  var MSG_SAVE_PAGE = lang2.getMessage("PD.SAVE");
  var currentTheme;
  var hasSelection = false;
  var lastSelection = null;
  var chatLocked = false;
  var isConversation = false;
  var suppressCursorPositionChange = false;
  var isSave = false;
  var PREF = {
    FONT_SIZE: "fontSize",
    THEME: "theme",
    TABS_INSERT_SPACES: "tabsInsertSpaces",
    INDENT_SIZE: "indentSize",
    TAB_SIZE: "tabSize",
    RULER: "ruler",
    MINIMAP: "minimap",
    LINE_NUMBERS: "lineNumbers",
    WHITESPACE: "whitespace",
    SHOW_SUGGESTIONS: "showSuggestions",
    BRACKET_PAIR_COLORIZATION: "bracketPairColorization"
    // SEMANTIC_HIGHLIGHTING: "semanticHighlighting",
  };
  var OPTIONS_THEME = [
    // automatic will be either vs or vs-dark depending on the builder setting
    { label: MSG_THEME_AUTOMATIC, value: "automatic" },
    { label: MSG_THEME_LIGHT, value: "vs" },
    { label: MSG_THEME_DARK, value: "vs-dark" },
    { label: MSG_THEME_HIGH_CONTRAST_DARK, value: "hc-black" }
  ];
  var MINIMAP_OFF = "off";
  var MINIMAP_ON = "on";
  var MINIMAP_CONDITIONAL = "conditional";
  var OPTIONS_FONT_SIZE = [
    { label: "10", value: 10 },
    { label: "12", value: 12 },
    { label: "14", value: 14 },
    { label: "16", value: 16 },
    { label: "18", value: 18 }
  ];
  var OPTIONS_MINIMAP = [
    { label: MSG_UTIL_ON, value: MINIMAP_ON },
    { label: MSG_UTIL_OFF, value: MINIMAP_OFF },
    { label: MSG_MINIMAP_CONDITIONAL, value: MINIMAP_CONDITIONAL }
  ];
  var OPTIONS_TAB_SIZE = [
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "8", value: "8" }
  ];
  var OPTIONS_INDENT_SIZE = [
    { label: "2", value: "2" },
    { label: "3", value: "3" },
    { label: "4", value: "4" },
    { label: "8", value: "8" }
  ];
  var minified = document.currentScript.src.includes(".min.");
  var ABSOLUTE_PATH = (() => {
    const location = window.location, firstChar = env.APEX_FILES[0];
    if (firstChar === "/") {
      return location.protocol + "//" + location.host + env.APEX_FILES;
    } else if (firstChar === ".") {
      return location.href.slice(0, location.href.lastIndexOf("/") + 1) + env.APEX_FILES;
    } else {
      return env.APEX_FILES;
    }
  })();
  var LIBRARY_ROOT = `${ABSOLUTE_PATH}libraries/monaco-editor/${libVersions.monacoEditor}`;
  var MONACO_EDITOR_FILE = `${LIBRARY_ROOT}/monaco-editor${minified ? ".min" : ""}.js?v=${env.APEX_VERSION}`;
  var MONACO_EDITOR_NLS_FILE = `${LIBRARY_ROOT}/nls/nls.messages.#LANG#.js?v=${env.APEX_VERSION}`;
  var DISP_MLE_ENV = "mle-env";
  var DISP_MINIMAP = "minimap";
  var DTS_TYPES = {
    ITEM: {
      NATIVE_NUMBER_FIELD: "numberFieldItem"
    },
    REGION: {
      NATIVE_FACETED_SEARCH: "facetsRegion",
      NATIVE_SMART_FILTERS: "facetsRegion",
      NATIVE_MAP_REGION: "mapRegion",
      NATIVE_CARDS: "cardsRegion",
      NATIVE_IR: "interactiveReportRegion",
      // template components have special handling in CONTEXT_MANAGER
      NATIVE_TEMPLATE_COMPONENT: "templateReportRegion"
    }
  };
  var DISPOSABLE_MANAGER = /* @__PURE__ */ (() => {
    const DISPOSABLES = {
      GLOBAL: {}
      // for disposables shared across all instances, eg. javascript language defaults
      // other keys will be added as editors are created
    };
    return {
      // global disposables
      existsGlobally: (key) => {
        return DISPOSABLES.GLOBAL[key] !== void 0;
      },
      registerGlobally: (key, disposable) => {
        DISPOSABLES.GLOBAL[key] = disposable;
      },
      disposeGlobally: (key) => {
        if (DISPOSABLES.GLOBAL[key]) {
          DISPOSABLES.GLOBAL[key].dispose();
          delete DISPOSABLES.GLOBAL[key];
        }
      },
      // editor specific disposables
      deregisterEditor: (editorId) => {
        if (DISPOSABLES[editorId]) {
          for (let key of Object.keys(DISPOSABLES[editorId])) {
            DISPOSABLES[editorId][key].dispose();
            delete DISPOSABLES[editorId][key];
          }
          delete DISPOSABLES[editorId];
        }
      },
      existsForEditor: (editorId, key) => {
        return DISPOSABLES[editorId] && DISPOSABLES[editorId][key] !== void 0;
      },
      registerForEditor: (editorId, key, disposable) => {
        DISPOSABLES[editorId] = DISPOSABLES[editorId] || {};
        if (DISPOSABLES[editorId][key]) {
          DISPOSABLES[editorId][key].dispose();
        }
        DISPOSABLES[editorId][key] = disposable;
      },
      disposeForEditor: (editorId, key) => {
        if (DISPOSABLES[editorId] && DISPOSABLES[editorId][key]) {
          DISPOSABLES[editorId][key].dispose();
          delete DISPOSABLES[editorId][key];
        }
      }
    };
  })();
  var JAVASCRIPT_MANAGER = (() => {
    const CONTEXT_MANAGER = /* @__PURE__ */ (() => {
      const contexts = {};
      let managerLang;
      const _verifyLang = (lang3) => {
        if (!JS_LANGS.includes(lang3)) {
          throw new Error("Only JavaScript and MLE JavaScript are supported");
        }
      };
      const setContext = (name, code, lang3) => {
        _verifyLang(lang3);
        if (!contexts[name]) {
          contexts[name] = {
            code: null,
            model: null,
            lang: lang3
          };
        }
        contexts[name].code = code;
        if (managerLang === lang3) {
          if (contexts[name].model) {
            contexts[name].model.setValue(code);
          } else {
            contexts[name].model = monaco.editor.createModel(code, MONACO_LANG_JAVASCRIPT);
          }
        }
        debugTrace("CONTEXT_MANAGER added context", name);
      };
      const dropContext = (name) => {
        if (contexts[name]) {
          if (contexts[name].model) {
            contexts[name].model.dispose();
            contexts[name].model = null;
          }
          contexts[name] = void 0;
        }
        debugTrace("CONTEXT_MANAGER dropped context", name);
      };
      const _reevaluate = (lang3) => {
        _verifyLang(lang3);
        managerLang = lang3;
        Object.keys(contexts).forEach((name) => {
          const context = contexts[name];
          if (managerLang !== context.lang) {
            if (context.model) {
              context.model.dispose();
              context.model = null;
            }
          } else {
            if (context.model) {
              context.model.setValue(context.code);
            } else {
              context.model = monaco.editor.createModel(contexts[name].code, MONACO_LANG_JAVASCRIPT);
            }
          }
        });
        debugTrace("CONTEXT_MANAGER contexts reevaluated");
      };
      return {
        setContext,
        dropContext,
        _reevaluate
      };
    })();
    const LOAD = {
      ONCE: "once",
      FRESH: "fresh"
    };
    let latestJsLanguage;
    const DTS_DATA = {
      [LANG_JAVASCRIPT]: {
        contexts: [{
          key: "DTS_JS",
          contentPath: ABSOLUTE_PATH + "apex_ui/js/code-editor/types/browser/types.d.ts?v=" + env.APEX_VERSION,
          load: LOAD.ONCE,
          isLoaded: false
        }, {
          key: "JS_EXTRAS",
          contentFunction: (pageInfo) => {
            return pageInfo ? `
                    declare namespace apex {
                        var items: {
                            ${pageInfo.items.map((item) => {
              let type = "item";
              if (DTS_TYPES.ITEM[item.type]) {
                type = DTS_TYPES.ITEM[item.type];
              }
              return `${JSON.stringify(item.name)}: ${type};`;
            }).join("\n")}
                        };
                        var regions: {
                            ${pageInfo.regions.map((region) => {
              let type = "region";
              if (DTS_TYPES.REGION[region.type]) {
                type = DTS_TYPES.REGION[region.type];
              } else if (region.type.startsWith("TMPL_")) {
                type = DTS_TYPES.REGION.NATIVE_TEMPLATE_COMPONENT;
              }
              return `${JSON.stringify(region.domId)}: ${type};`;
            }).join("\n")}
                        };
                    }` : null;
          },
          // used in PD, where items and regions change often, so we wish to load it on each edior focus
          load: LOAD.FRESH
        }]
      },
      [LANG_JAVASCRIPT_MLE_SNIPPET]: {
        contexts: [{
          // both DB 21c and 26ai have their own types.d.ts file
          key: "DTS_JS_MLE_SNIPPET_1",
          condition: env.DB_VERSION >= 21,
          contentPath: `${ABSOLUTE_PATH}apex_ui/js/code-editor/types/mle/${env.DB_VERSION}/types.d.ts?v=${env.APEX_VERSION}`,
          load: LOAD.ONCE,
          isLoaded: false
        }, {
          // for 21c, the apex namespace is already defined in the dts file
          // for 26ai, we have it here inline for more flexibility
          // todo. in the future, it should be its own static file generated from our typescript sources
          key: "DTS_JS_MLE_SNIPPET_2",
          condition: env.DB_VERSION >= 23,
          content: `
                    import { defaultConnection, default as oracledb } from "mle-js-oracledb";
                    globalThis.apex = {
                        db: oracledb,
                        conn: oracledb.defaultConnection(),
                        env: {}
                    };
                `,
          load: LOAD.ONCE,
          isLoaded: false
        }]
      },
      [LANG_JAVASCRIPT_MLE_MODULE]: {
        contexts: [{
          key: "DTS_JS_MLE_MODULE",
          condition: env.DB_VERSION >= 23,
          contentPath: `${ABSOLUTE_PATH}apex_ui/js/code-editor/types/mle/${env.DB_VERSION}/types.d.ts?v=${env.APEX_VERSION}`,
          load: LOAD.ONCE,
          isLoaded: false
        }]
      }
    };
    const reevaluate = (language, pageInfo) => {
      DTS_DATA[language].contexts.forEach((context) => {
        if (context.condition === void 0 || context.condition) {
          if (context.load === LOAD.ONCE && !context.isLoaded || context.load === LOAD.FRESH) {
            (async () => {
              let finalContent;
              if (context.content) {
                finalContent = context.content;
              } else if (context.contentPath) {
                const response = await fetch(context.contentPath);
                if (!response.ok) {
                  debugError("Could not fetch file", response);
                  return;
                }
                finalContent = await response.text();
              } else if (context.contentFunction) {
                finalContent = context.contentFunction(pageInfo);
              }
              CONTEXT_MANAGER.setContext(context.key, finalContent, language);
            })();
            if (context.load === LOAD.ONCE) {
              context.isLoaded = true;
            }
          }
        }
      });
      if (latestJsLanguage !== language) {
        latestJsLanguage = language;
        monaco.typescript.javascriptDefaults.setCompilerOptions({
          target: monaco.typescript.ScriptTarget.Latest,
          allowJs: true,
          allowNonTsExtensions: true,
          // for MLE JavaScript, browser globals like window should be hidden
          noLib: [LANG_JAVASCRIPT_MLE_SNIPPET, LANG_JAVASCRIPT_MLE_MODULE].includes(language)
        });
        monaco.typescript.javascriptDefaults.setDiagnosticsOptions({
          // do not mark nameless functions as errors
          // needed for Init JS Code
          diagnosticCodesToIgnore: [1003]
        });
        CONTEXT_MANAGER._reevaluate(language);
      }
    };
    return {
      "reevaluate": reevaluate,
      "setContext": CONTEXT_MANAGER.setContext,
      "dropContext": CONTEXT_MANAGER.dropContext
    };
  })();
  function loadLanguageDependencies(language, options) {
    return new Promise((resolve) => {
      if (JS_LANGS.includes(language)) {
        JAVASCRIPT_MANAGER.reevaluate(language, options.pageInfo);
        resolve();
      } else {
        resolve();
      }
    });
  }
  function configureMonacoPostLoad() {
    register();
    register2();
    register3();
    register4();
    registerTdPlainText();
    registerTdHtml();
    register6();
    monaco.editor.defineTheme("apex-vs", {
      inherit: true,
      base: "vs",
      rules: [
        // background color: fffffe
        { token: "attribute.name.html", foreground: "E50000" },
        // 4.84 AA  // source: "entity.other.attribute-name"
        { token: "attribute.name.css", foreground: "E50000" },
        // 4.84 AA  // source: "source.css variable"
        { token: "comment", foreground: "008000" },
        // 8.58 AA  // source: "comment"
        // sql
        { token: "string.sql", foreground: "b26100" },
        // 4.56  AA
        { token: "keyword.sql", foreground: "c74634" },
        // 4.82  AA
        { token: "predefined.sql", foreground: "7e5e8a" },
        // 5.44  AA
        { token: "operator.sql", foreground: "000000" },
        // 20.99 AAA
        { token: "atom.sql", foreground: "398459" },
        // 4.54  AA
        { token: "function.sql", foreground: "795E26" },
        // 6.10  AA
        { token: "pageitem.sql", foreground: "008080", fontStyle: "bold" },
        // quicksql
        { token: "table.quicksql", foreground: "0000FF", fontStyle: "bold" },
        // 8.58 AA
        { token: "view.quicksql", foreground: "008855", fontStyle: "bold" },
        // 4.51 AA
        { token: "list.quicksql", foreground: "b26100" },
        // 4.56 AA
        { token: "keywords.quicksql", foreground: "c74634" },
        // 4.82 AA
        { token: "types.quicksql", foreground: "398459" },
        // 4.54 AA
        // td-html
        { token: "td-tag.td-html", foreground: "AF00DB" },
        // 5.45 AA
        { token: "td-modifier.td-html", foreground: "800000" },
        // 10.94 AA // source: "punctuation.definition.tag"
        ...THEME_RULES.LIGHT
      ],
      colors: {
        // bracket pair colorization
        "editorBracketHighlight.foreground1": "#0431FA",
        // 7.42
        "editorBracketHighlight.foreground2": "#008000",
        // 5.13
        "editorBracketHighlight.foreground3": "#7B3814"
        // 8.67
      }
    });
    monaco.editor.defineTheme("apex-vs-dark", {
      inherit: true,
      base: "vs-dark",
      rules: [
        // to be enabled in a future APEX version
        // semantic tokens. for now only JavaScript makes use of them
        /*
        // TODO add to other 2 themes
        { token: "function", foreground: "DCDCAA" },
        { token: "method", foreground: "DCDCAA" },
        { token: "keyword", foreground: "C586C0" },
        { token: "variable", foreground: "4FC1FF" },
        { token: "parameter", foreground: "9CDCFE" },
        { token: "class", foreground: "4EC9B0" },
        { token: "namespace", foreground: "9CDCFE" },
        { token: "property", foreground: "9CDCFE" },
        */
        // background color: 1e1e1e
        { token: "comment", foreground: "6A9955" },
        // 5.1 AA
        // sql
        { token: "string.sql", foreground: "ecbb76" },
        // 9.48  AAA
        { token: "keyword.sql", foreground: "f14840" },
        // 4.56  AA
        { token: "predefined.sql", foreground: "a687b3" },
        // 5.35  AA
        { token: "operator.sql", foreground: "D4D4D4" },
        // 11.25 AAA
        { token: "atom.sql", foreground: "259856" },
        // 4.53  AA
        { token: "function.sql", foreground: "DCDCAA" },
        // 11.80 AAA
        { token: "pageitem.sql", foreground: "3dc9b0", fontStyle: "bold" },
        // quicksql
        { token: "table.quicksql", foreground: "569CD6", fontStyle: "bold" },
        // 5.65 AA  // source: "constant.language"
        { token: "view.quicksql", foreground: "259856", fontStyle: "bold" },
        // 4.53 AA
        { token: "list.quicksql", foreground: "ecbb76" },
        // 9.48 AAA
        { token: "keywords.quicksql", foreground: "f14840" },
        // 4.56 AA
        { token: "types.quicksql", foreground: "A3CDFF" },
        // 4.53 AA
        // td-html
        { token: "td-tag.td-html", foreground: "C586C0" },
        // 5.98 AA
        { token: "td-modifier.td-html", foreground: "CE9178" },
        // 6.3
        //{ token: "substitution.td-html", foreground: "d7ba7d" }
        ...THEME_RULES.DARK
      ],
      colors: {
        // bracket pair colorization
        "editorBracketHighlight.foreground1": "#ffd700",
        // 11.88
        "editorBracketHighlight.foreground2": "#da70d6",
        // 5.77
        "editorBracketHighlight.foreground3": "#179fff"
        // 5.9
      }
    });
    monaco.editor.defineTheme("apex-hc-black", {
      inherit: true,
      base: "hc-black",
      rules: [
        // background color: 000000
        { token: "comment", foreground: "7CA668" },
        // 7.51 AAA
        // sql
        { token: "string.sql", foreground: "ecbb76" },
        // 11.94 AAA
        { token: "keyword.sql", foreground: "f14840" },
        // 5.74  AA
        { token: "predefined.sql", foreground: "a687b3" },
        // 6.74  AA
        { token: "operator.sql", foreground: "D4D4D4" },
        // 14.17 AAA
        { token: "atom.sql", foreground: "259856" },
        // 5.70  AA
        { token: "function.sql", foreground: "DCDCAA" },
        // 14.86 AAA
        { token: "pageitem.sql", foreground: "3dc9b0", fontStyle: "bold" },
        // quicksql
        { token: "table.quicksql", foreground: "569CD6", fontStyle: "bold" },
        // 7.12  AA
        { token: "view.quicksql", foreground: "259856", fontStyle: "bold" },
        // 5.73  AA
        { token: "list.quicksql", foreground: "ecbb76" },
        // 11.94 AAA
        { token: "keywords.quicksql", foreground: "f14840" },
        // 5.74  AA
        { token: "types.quicksql", foreground: "259856" },
        // 5.73  AA
        // td-html
        { token: "td-tag.td-html", foreground: "C586C0" },
        // 5.98 AA
        { token: "td-modifier.td-html", foreground: "CE9178" },
        // 7.94 AA
        ...THEME_RULES.HC_DARK
      ],
      colors: {
        // bracket pair colorization
        "editorBracketHighlight.foreground1": "#ffd700",
        // 14.97
        "editorBracketHighlight.foreground2": "#da70d6",
        // 7.26
        "editorBracketHighlight.foreground3": "#87cefa"
        // 12.23
      }
    });
  }
  var loadEditorDependenciesPromise;
  function loadEditorDependencies() {
    if (!loadEditorDependenciesPromise) {
      loadEditorDependenciesPromise = (async () => {
        let lang3 = locale.getLanguage().toLowerCase();
        let monacoLang;
        if (["zh-tw", "zh-cn"].includes(lang3)) {
          monacoLang = lang3;
        } else if (["pt-br", "pt"].includes(lang3)) {
          monacoLang = "pt-br";
        } else {
          lang3 = lang3.split("-")[0];
          if (["cs", "de", "es", "fr", "it", "ja", "ko", "pl", "ru", "tr"].includes(lang3)) {
            monacoLang = lang3;
          }
        }
        const nlsImportPromise = monacoLang ? import(MONACO_EDITOR_NLS_FILE.replace("#LANG#", monacoLang)) : Promise.resolve();
        const [{ monaco: monaco2 }] = await Promise.all([
          import(MONACO_EDITOR_FILE),
          nlsImportPromise
        ]);
        window.monaco = monaco2;
        configureMonacoPostLoad();
      })().catch((error) => {
        loadEditorDependenciesPromise = null;
        throw error;
      });
    }
    return loadEditorDependenciesPromise;
  }
  loadEditorDependencies();
  function getThemeForAutomatic() {
    if (apex.builder) {
      return apex.builder.isBuilderDarkMode() ? "vs-dark" : "vs";
    } else {
      return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "vs-dark" : "vs";
    }
  }
  function setTheme(theme) {
    currentTheme = theme;
    let themeToSet;
    if (theme === "automatic") {
      themeToSet = getThemeForAutomatic();
    } else if (["vs", "vs-dark", "hc-black"].includes(theme)) {
      themeToSet = theme;
    } else {
      themeToSet = getThemeForAutomatic();
      debugTrace(theme + " is not a valid Monaco theme. Using automatic instead.");
    }
    loadEditorDependencies().then(() => {
      monaco.editor.setTheme("apex-" + themeToSet);
    });
  }
  if (apex.builder) {
    $2("body").on("apex-builder-theme-changed", () => {
      if (currentTheme === "automatic") {
        setTheme("automatic");
      }
    });
  } else {
    if (window.matchMedia) {
      window.matchMedia("(prefers-color-scheme: dark)").addListener(() => {
        if (currentTheme === "automatic") {
          setTheme("automatic");
        }
      });
    }
  }
  function isMac() {
    return util2.hasMacKeyboard();
  }
  function getUniversalCtrlKey() {
    return isMac() ? monaco.KeyMod.WinCtrl : monaco.KeyMod.CtrlCmd;
  }
  function transformCodeCase(str) {
    if (!str) {
      return str;
    }
    function getRangesToIgnore(str2) {
      let arr = [];
      let matches = str2.matchAll(/('|")[\s\S]*?(\1)/gm);
      for (let match of matches) {
        arr.push({ start: match.index, end: match.index + match[0].length, ignore: true });
      }
      return arr;
    }
    function completeRanges(ranges, lastIndex) {
      let finalRanges = [];
      let currentIndex = 0;
      function addRange(start, end, ignore) {
        finalRanges.push({ start, end, ignore });
      }
      if (ranges.length === 0) {
        addRange(0, lastIndex, false);
      } else {
        for (let i = 0; i < ranges.length; i++) {
          let range = ranges[i];
          if (currentIndex < range.start) {
            addRange(currentIndex, range.start - 1, false);
          }
          addRange(range.start, range.end, true);
          currentIndex = range.end + 1;
        }
        if (currentIndex < lastIndex - 1) {
          addRange(currentIndex, lastIndex, false);
        }
      }
      return finalRanges;
    }
    function applyFunction(ranges, func) {
      let i, range, strPart, result = "";
      for (i = 0; i < allRanges.length; i++) {
        range = allRanges[i];
        strPart = str.slice(range.start, range.end + 1);
        result += range.ignore ? strPart : func(strPart);
      }
      return result;
    }
    function toLowerCase(ranges) {
      return applyFunction(ranges, function(str2) {
        return str2.toLocaleLowerCase();
      });
    }
    function toUpperCase(ranges) {
      return applyFunction(ranges, function(str2) {
        return str2.toLocaleUpperCase();
      });
    }
    let rangesToIgnore = getRangesToIgnore(str);
    let allRanges = completeRanges(rangesToIgnore, str.length - 1);
    let strLowerCase = toLowerCase(allRanges);
    if (str !== strLowerCase) {
      return strLowerCase;
    } else {
      return toUpperCase(allRanges);
    }
  }
  var editorLangToMonacoLang = (editorLang) => {
    if ([LANG_SQL, LANG_PLSQL].includes(editorLang)) {
      return langId3;
    } else if (JS_LANGS.includes(editorLang)) {
      return MONACO_LANG_JAVASCRIPT;
    } else if (editorLang === LANG_SYSTEM_PROMPT) {
      return MONACO_LANG_MARKDOWN;
    }
    return editorLang;
  };
  var reevaluateFonts = (() => {
    let fontHash;
    const getFreshFontHash = () => [
      "font-family",
      "font-size",
      "line-height",
      "word-spacing",
      "letter-spacing"
    ].map((prop) => {
      return $2("body").css(prop);
    }).join("-");
    fontHash = getFreshFontHash();
    return () => {
      const newFontHash = getFreshFontHash();
      if (fontHash !== newFontHash) {
        fontHash = newFontHash;
        debugTrace("New font values detected. Remeasuring Monaco fonts.");
        monaco.editor.remeasureFonts();
      }
    };
  })();
  $2.widget("apex.codeEditor", {
    widgetEventPrefix: "codeEditor",
    options: {
      language: MONACO_LANG_JAVASCRIPT,
      // in non diff-mode: the value is a string
      // in diff mode: the value is a JSON of type: {"original":"...","modified":"..."}
      value: "",
      readOnly: false,
      autofocus: false,
      ariaLabel: "",
      /*
       * errors & warnings: an array of either strings, or objects of type:
       * {
       *      message string required
       *      line    number optional
       *      column  number optional
       * }
       */
      errors: [],
      warnings: [],
      /*
       * Editor specific suggestions
       * Can be an array of objects:
       *  [ {
       *      label: {
       *          label: "P1_FIRST_NAME (First Name), // required
       *          detail: "VARCHAR2",                 // optional
       *          description: "Page Item"            // optional
       *      }
       *      insertText: "P1_FIRST_NAME",            // optional
       *      documentation: "some text"              // optional
       *  } ]
       *
       * Or a callback function that will be invoked on widget load and on language change
       * It must return the same kind of array
       * function(language){
       *      if(language == "sql"){ return [...];}
       *      else if(language == "javascript"){ return [...];}
       *      else { return []; }
       * }
       */
      suggestions: null,
      /*
       * pageInfo should provided only if in Page Designer
       * {
       *    pageId: 1,
       *    items: [{
       *      name: "P1_ID",
       *      type: "NATIVE_NUMBER_FIELD"
       *    }]
       *    regions: [{
       *      staitcId: "myFacetRegion",
       *      type: "NATIVE_FACETED_SEARCH"
       *    }]
       * }
       *
       * pageId is used by the item name validator
       * items and regions are used by the apex.items and apex.regions autocomplete
       * items.name is also used for the item name validator
       */
      pageInfo: {
        pageId: null,
        isPageDesigner: true,
        isGlobalPage: false,
        isDialogPage: false,
        applicationMessages: null,
        shortMsgSyntaxSupported: false,
        items: [],
        regions: []
      },
      showSuggestions: true,
      // should be passed as true in Page Designer, while also assuring the page items are returned by the suggestions function
      validatePageItems: false,
      // monaco options: exposing them here as opposed to arbitrarily passing them forward
      // to keep a list of all options used
      // "on", "off", "conditional" (only show when content >= 100 lines)
      minimap: MINIMAP_CONDITIONAL,
      lineNumbers: true,
      wordWrap: false,
      scrollBeyondLastLine: true,
      // wordBasedSuggestions are not scope-limited, so they can be more disturbing than useful
      wordBasedSuggestions: false,
      // toolbar is always available in the builder, but can be disabled for theme roller
      toolbar: true,
      whitespace: false,
      // settings which can be overridden by user preference
      theme: "automatic",
      tabsInsertSpaces: true,
      fontSize: 12,
      indentSize: "4",
      tabSize: "4",
      ruler: false,
      bracketPairColorization: false,
      // to be enabled in a future APEX version when they are stable enough
      //semanticHighlighting: true, // currently for JS only. might change with the SQL lang server
      // callback functions
      onInitialized: null,
      // optional. function that runs after the editor is initialized. function(editor){}
      codeComplete: null,
      // optional. function( options, callback )
      validateCode: null,
      // optional. function( code, callback ) callback: function( {errors:[],warnings:[]} )
      queryBuilder: null,
      // optional. function( editor, code )
      heightFn: null,
      // optional. function returning editor height
      // optional. function that enables the save function(s) from the codeEditor dialog
      // if it's provided save/save-and-run action is created
      // function ( event, focusElement, isRun )
      dialogSave: null,
      // if provided, it will be called on initialization and subsequently at window resize
      // events/callbacks
      preferencesChanged: null,
      // function( event )
      // async loading mechanism
      // render the initial div or textarea with data attribute "load-stop" to delay the editor loading
      // trigger "load-resume" on said div to resume it
      lazyLoad: false,
      // diff mode
      diffEditor: false,
      // APEX Assistant
      ai: null
      // optional. object that MUST have ajax.ajaxId or ajax.ajaxCallback property
    },
    /*
     * Lifecycle methods
     */
    _editorLoaded: false,
    _tempValue: void 0,
    _create: function() {
      const self = this, o = this.options, editor$ = $2(self.element[0]).addClass("a-MonacoEditor"), monacoLanguage = editorLangToMonacoLang(o.language);
      editor$.append($2(`
            <div class="a-MonacoEditorContent">
                <div class="a-MonacoEditorContent-left">
                    <div class="a-MonacoEditor-toolbar"></div>
                    <div class="a-MonacoEditor-notification u-DisplayNone">
                        <div class="a-MonacoEditor-message"></div>
                        <button title="${util2.escapeHTMLAttr(MSG_CLOSE)}" aria-label="${util2.escapeHTMLAttr(MSG_CLOSE)}" class="a-Button a-Button--noLabel a-Button--withIcon a-Button--small a-CodeEditor-searchBar-closeButton" type="button">
                            <span class="a-Icon ui-icon-closethick" aria-hidden="true"></span>
                        </button>
                    </div>
                    <div class="a-MonacoEditor-editor" dir="ltr"></div>
                </div>
            </div>
        `));
      self.baseId = self.element[0].id;
      self._editor$ = editor$;
      self._toolbar$ = editor$.find(".a-MonacoEditor-toolbar").first();
      self._notification$ = editor$.find(".a-MonacoEditor-notification").first();
      self._monacoEditor$ = editor$.find(".a-MonacoEditor-editor").first();
      self._container$ = editor$.find(".a-MonacoEditorContent");
      self._leftPanel$ = editor$.find(".a-MonacoEditorContent-left");
      if (o.ai) {
        self._container$.append($2(`
                <div class="a-MonacoEditorContent-right">
                    <div class="a-MonacoEditor-toolbar"></div>
                    <div class="a-MonacoEditor-ai"></div>
                </div>
            `));
        self._rightPanel$ = editor$.find(".a-MonacoEditorContent-right");
        self._chatEl$ = self._rightPanel$.find(".a-MonacoEditor-ai");
        self._chatToolbar$ = self._rightPanel$.find(".a-MonacoEditor-toolbar");
        self._rightPanelId = util2.getTopApex().jQuery({}).uniqueId()[0].id;
        self._rightPanel$.attr("id", self._rightPanelId);
        self._aiEnabled = false;
        self._currentAssistant = ACTION_AI_GENERAL;
      }
      (async () => {
        if (o.lazyLoad) {
          debugTrace("Loading halted", editor$);
          await new Promise((resolve) => {
            editor$.one("load-resume", () => {
              debugTrace("Loading resumed", editor$);
              resolve();
            });
          });
        }
        await loadEditorDependencies();
        await loadLanguageDependencies(self.options.language, self.options);
        self._notification$.find("button").on(EVENT_CLICK, () => {
          self.resetNotification();
        });
        setTheme(o.theme);
        const editorOptions = {
          fontSize: o.fontSize,
          detectIndentation: false,
          insertSpaces: o.tabsInsertSpaces,
          indentSize: o.indentSize,
          tabSize: o.tabSize,
          rulers: o.ruler ? [80] : [],
          scrollBeyondLastLine: o.scrollBeyondLastLine,
          lineNumbers: o.lineNumbers,
          // slightly narrower line number column
          lineNumbersMinChars: 4,
          scrollbar: {
            // allows page to scroll if bottom of editor was reached
            alwaysConsumeMouseWheel: false
          },
          stickyScroll: {
            enabled: false
          },
          fixedOverflowWidgets: true,
          ariaLabel: o.ariaLabel,
          wordBasedSuggestions: o.wordBasedSuggestions ? "currentDocument" : "off",
          quickSuggestions: o.showSuggestions,
          // as of 24.1, accessibilityMode is always on and no longer dependent on a user preference
          accessibilitySupport: "on",
          accessibilityVerbose: false,
          inlineCompletionsAccessibilityVerbose: false,
          renderWhitespace: o.whitespace ? "all" : "none",
          // content should be copied plaintext for clean pasting in rich text contexts (Word, Jira etc)
          copyWithSyntaxHighlighting: false,
          // semanticHighlighting and bracket pair colorization to be enabled in a future APEX version
          // enabled for all, but only JavaScript has the smarts to make use of it
          // "semanticHighlighting.enabled": o.semanticHighlighting,
          "bracketPairColorization.enabled": o.bracketPairColorization,
          // TODO. could not get this option to work. either way it should be based on an editor setting
          // "guides.bracketPairs.enabled": true,
          // automatically matches the size of its container
          automaticLayout: true,
          // This flag is currently documented as
          // "Sets whether the new experimental edit context should be used instead of the text area."
          // Additionally to being "experimental", it only works on Chrome & Edge, due to the limited availability of the EditContext API.
          // To keep things consistent across browsers, we'll be disabling it for now.
          // What's more, certain security browser extensions which intercept and scan the paste event,
          //  would otherwise have trouble reapplying it via document.executeCommand("paste") on non input/textarea elements.
          editContext: false,
          ...self._getLanguageDependentMonacoOptions()
        };
        let editor, model, modelOriginal;
        if (o.diffEditor) {
          const diffEditor = monaco.editor.createDiffEditor(self._monacoEditor$[0], {
            ...editorOptions,
            // diffEditor specific options:
            renderSideBySide: true,
            renderGutterMenu: false
          });
          const originalModel = monaco.editor.createModel(o.value.original, monacoLanguage), modifiedModel = monaco.editor.createModel(o.value.modified, monacoLanguage);
          diffEditor.setModel({
            original: originalModel,
            modified: modifiedModel
          });
          diffEditor.revealFirstDiff();
          editor = diffEditor.getModifiedEditor();
          modelOriginal = originalModel;
          model = modifiedModel;
          this._diffEditor = diffEditor;
        } else {
          model = monaco.editor.createModel(o.value, monacoLanguage);
          editor = monaco.editor.create(self._monacoEditor$[0], editorOptions);
          editor.setModel(model);
        }
        self._model = model;
        self._modelOriginal = modelOriginal;
        self._modelId = model.id;
        self._editor = editor;
        self._editorId = editor.getId();
        self._editorLoaded = true;
        if (self._tempValue !== void 0) {
          self.setValue(self._tempValue);
          self._tempValue = void 0;
        }
        editor.updateOptions({
          ariaLabel: editorOptions.ariaLabel
        });
        self._setReadOnly(!!o.readOnly);
        editor.onDidDispose(() => {
          self._disposeAllDisposables();
          model.dispose();
          modelOriginal?.dispose();
        });
        self._evaluateContextKeys(o.language);
        if (o.toolbar) {
          self._context = actions.createContext("codeEditor", this.element[0]);
          self._populateContext();
          self._initToolbar(self._toolbar$);
          self._updateNotifications();
        }
        window.addEventListener("resize", util2.debounce(() => {
          self.resize();
        }, 200));
        editor$.on("resize", function(pEvent) {
          self.resize();
          pEvent.stopPropagation();
        });
        if (o.autofocus) {
          self.focus();
        }
        editor.onKeyDown((event) => {
          self.element.children("textarea").trigger("keypress", event);
        });
        let oldValue;
        editor.onDidFocusEditorWidget(function() {
          oldValue = model.getValue();
        });
        editor.onDidBlurEditorWidget(function() {
          let textarea$ = self.element.children("textarea"), newValue = model.getValue();
          textarea$.trigger("blur");
          if (oldValue !== newValue) {
            textarea$.val(newValue).trigger("change");
          }
        });
        if (o.validatePageItems && o.pageInfo.pageId) {
          self._initializeItemValidator();
        }
        self._configureCustomSuggestionProvider();
        self._initializeCustomActions();
        self._setupMinimap();
        self._monacoEditor$.on("change", function(e) {
          e.stopPropagation();
        });
        editor.onDidFocusEditorWidget(() => {
          if (JS_LANGS.includes(o.language)) {
            JAVASCRIPT_MANAGER.reevaluate(o.language, o.pageInfo);
          }
          reevaluateFonts();
        });
        self._on(self._eventHandlers);
        self.resetUndoRedoStack();
        if ([langIdTdPlainText, langIdTdHtml].includes(monacoLanguage) && o.tdOptions) {
          self.registerTdCompletions();
        }
        if (o.onInitialized) {
          o.onInitialized(editor);
        }
        editor.onDidChangeConfiguration(() => {
          const readOnly = !!o.readOnly;
          const textbox = this._getTextBox(editor);
          if (textbox) {
            textbox.ariaReadOnly = readOnly;
            textbox.ariaRoleDescription = readOnly ? MSG_ROLE_DESC_READONLY : MSG_ROLE_DESC;
          }
        });
        this._updateAccessibleValue();
        self._monacoEditor$[0].addEventListener("beforeinput", self._fixBackwardSelectionBug.bind(self), true);
      })();
    },
    _eventHandlers: {
      resize: function(event) {
        this.resize();
        event.stopPropagation();
      },
      focusin: function() {
        this.element.addClass(C_ACTIVE);
      },
      focusout: function() {
        this.element.removeClass(C_ACTIVE);
      }
    },
    _destroy: function() {
      if (this._editor) {
        this._editor.dispose();
      }
      if (this._chat) {
        this._chat.destroy();
        this._chat = null;
      }
      if (this._chatView) {
        this._chatView.destroy();
        this._chatView = null;
      }
      hasSelection = false;
      lastSelection = null;
      isConversation = false;
      chatLocked = false;
      suppressCursorPositionChange = false;
    },
    _setOption: function(key, value) {
      let self = this, o = self.options, editor = self._editor;
      self._super(key, value);
      if (!self._editorLoaded) {
        return;
      }
      if (key === "readOnly") {
        self._setReadOnly(!!value);
      } else if (["errors", "warnings"].includes(key)) {
        self._updateNotifications();
      } else if (key === "language") {
        self._setLanguage(value);
      } else if (key === "fontSize") {
        editor.updateOptions({ fontSize: value });
      } else if (key === "suggestions") {
        self._configureCustomSuggestionProvider();
      } else if (key === "tabsInsertSpaces") {
        editor.updateOptions({ insertSpaces: value });
      } else if (key === "ruler") {
        editor.updateOptions({ rulers: value ? [80] : [] });
      } else if (key === "theme") {
        o.theme = value;
        setTheme(value);
      } else if (key === "minimap") {
        self._setupMinimap();
      } else if (key === "lineNumbers") {
        editor.updateOptions({ lineNumbers: !!value });
      } else if (key === "whitespace") {
        editor.updateOptions({ renderWhitespace: value ? "all" : "none" });
      } else if (key === "showSuggestions") {
        editor.updateOptions({ quickSuggestions: !!value });
      } else if (key === "bracketPairColorization") {
        editor.updateOptions({ "bracketPairColorization.enabled": !!value });
      } else if (key === "diffEditor") {
        throw new Error("Switching between regular editor and diffEditor is not supported.");
      }
    },
    _getTextBox: function(editor) {
      if (editor.getOption(monaco.editor.EditorOption.effectiveEditContext)) {
        return editor.getDomNode().querySelector("div.native-edit-context");
      } else {
        return editor.getDomNode().querySelector("textarea.inputarea");
      }
    },
    _updateAccessibleValue: function() {
      if (!this._editor.getOption(monaco.editor.EditorOption.effectiveEditContext)) {
        return;
      }
      const value = this.getValue();
      if (this.options.diffEditor) {
        this._getTextBox(this._diffEditor.getOriginalEditor()).textContent = value.original;
        this._getTextBox(this._diffEditor.getModifiedEditor()).textContent = value.modified;
      } else {
        this._getTextBox(this._editor).textContent = value;
      }
    },
    // Fix for issue:
    //  - https://github.com/microsoft/monaco-editor/issues/5207
    //  - https://github.com/microsoft/vscode/issues/273146
    //  - https://github.com/microsoft/vscode/pull/273150
    //
    // Remove this fix after upgrading Monaco to 0.56.0 or higher.
    //
    // Due to this bug, selecting "backwards", either via mouse or keyboard,
    //  and replacing the selection with any key, will fail to do so on the first press.
    //
    // This fix normalizes Monaco's cached fallback textarea selection state for backward selections
    //  just before typing, so beforeinput computes the correct replacement diff.
    //
    // Note that this only happens when EditContext is disabled, which we have to
    //  keep disabled due to other regressions it would introduce.
    _fixBackwardSelectionBug: function() {
      const editor = this._editor, selection = editor.getSelection(), textarea = this._getTextBox(editor), textAreaInput = editor._modelData?.view?._editContext?._textAreaInput, textAreaState = textAreaInput?._textAreaState ?? textAreaInput?.textAreaState;
      if (editor.getOption(monaco.editor.EditorOption.effectiveEditContext) || !editor.hasTextFocus() || !selection || selection.isEmpty() || selection.getDirection() !== 1 || !(textarea instanceof HTMLTextAreaElement) || !textAreaState) {
        return;
      }
      const selectionStart = Math.min(textarea.selectionStart, textarea.selectionEnd), selectionEnd = Math.max(textarea.selectionStart, textarea.selectionEnd);
      textAreaState.selectionStart = selectionStart;
      textAreaState.selectionEnd = selectionEnd;
      textAreaState.newlineCountBeforeSelection = textarea.value.substring(0, selectionStart).split("\n").length - 1;
    },
    setValue: function(value) {
      if (this._editorLoaded) {
        if (this.options.diffEditor) {
          this._modelOriginal.setValue(value.original);
          this._model.setValue(value.modified);
          this._diffEditor.revealFirstDiff();
        } else {
          this._model.setValue(value);
        }
        this._updateAccessibleValue();
      } else {
        this._tempValue = value;
      }
    },
    getValue: function() {
      if (this._editorLoaded) {
        if (this.options.diffEditor) {
          return {
            original: this._modelOriginal.getValue(),
            modified: this._model.getValue()
          };
        } else {
          return this._model.getValue();
        }
      } else {
        return this._tempValue || this.options.value;
      }
    },
    getValidity() {
      const validationStatus = {
        valid: true,
        valueMissing: false,
        tooLong: false
      };
      const value = this.getValue();
      if (this.options.required && value === "") {
        validationStatus.valid = false;
        validationStatus.valueMissing = true;
        return validationStatus;
      }
      if (this.options.maxLength && value.length > this.options.maxLength) {
        validationStatus.valid = false;
        validationStatus.tooLong = true;
        return validationStatus;
      }
      return validationStatus;
    },
    getValidationMessage() {
      const validity = this.getValidity();
      if (validity.valueMissing) {
        return lang2.getMessage("APEX.PAGE_ITEM_IS_REQUIRED");
      } else if (validity.tooLong) {
        return lang2.formatMessage(
          "APEX.CODE_EDITOR.MAXIMUM_LENGTH_EXCEEDED",
          this.getValue().length,
          this.options.maxLength
        );
      }
      return "";
    },
    getEditor: function() {
      return this._editor;
    },
    resize: function() {
      let self = this;
      if (self.options.ai && self._aiEnabled) {
        let editorWidth = self._editor$.width();
        self._leftPanel$.width(editorWidth * 0.6);
        self._rightPanel$.width(editorWidth * 0.4);
      }
      if (self.options.heightFn) {
        self._editor$.outerHeight(self.options.heightFn());
      }
    },
    getSelection: function() {
      return this._model.getValueInRange(this._editor.getSelection());
    },
    /**
     * The caller is responsible for making sure that pMessage is escaped as needed.
     * @param pMessage may contain markup
     */
    showNotification: function(message2) {
      let container$ = this._notification$.show().children().first().empty();
      if (typeof message2 === "string") {
        container$.html(message2);
      } else if (typeof message2 === "object" && message2 instanceof jQuery) {
        container$.empty();
        const hasErrorOrWarning = this._hasSQLErrors();
        if (this.options.ai && hasErrorOrWarning && this.options.language === LANG_SQL) {
          let link = $2(`<button class="apex-assistant-link">
                                    <span aria-hidden="true" class="a-Icon icon-apex-assistant"></span>
                                    <span class="a-Button-label">${util2.escapeHTML(MSG_AI_DEBUG_HELP_LABEL)}</span>
                                </button>`);
          link.on("click keyup", (e) => {
            e.preventDefault();
            if (e.type === "click" || e.type === "keyup" && e.code === "Enter") {
              if (this._aiEnabled) {
                this._sendDebugMessage();
              } else {
                this._context.set(ACTION_AI, true);
              }
            }
          });
          message2.find("li").append(link);
        }
        container$.append(message2);
      } else {
        debugError("The notification message must be a string or a jQuery object");
      }
      this.resize();
    },
    // removes the message content and hides the container
    resetNotification: function() {
      this.errors = [];
      this.warnings = [];
      this._notification$.hide().children().first().empty();
      this.resize();
    },
    // the message must be escaped externally
    showSuccessNotification: function(message2) {
      this.showNotification(`<ul><li role="alert" class="is-success">${message2}</li></ul>`);
    },
    focus: function() {
      this.element.addClass(C_ACTIVE);
      this._editor.focus();
    },
    // note that lineNumber and column are 1-based indexes
    setCursor: function(lineNumber, column) {
      this._editor.setPosition({
        lineNumber,
        column
      });
    },
    setCursorToEnd: function(revealLine) {
      let editor = this._editor, model = this._model, lastLine = model.getLineCount(), lastColumn = model.getLineMaxColumn(lastLine);
      this.setCursor(lastLine, lastColumn);
      if (revealLine) {
        editor.revealLine(lastLine);
      }
    },
    changeGeneration: function() {
      return this._model.getAlternativeVersionId();
    },
    isClean: function(pGeneration) {
      return this._model.getAlternativeVersionId() === pGeneration;
    },
    getPreferencesString: function() {
      let o = this.options, obj = {}, prefKeys = Object.values(PREF);
      for (let i = 0; i < prefKeys.length; i++) {
        let key = prefKeys[i];
        obj[key] = o[key];
      }
      return JSON.stringify(obj);
    },
    _undoRedoDisposable: void 0,
    resetUndoRedoStack: function() {
      const self = this, editor = self._editor, model = self._model, context = self._context;
      if (self._undoRedoDisposable) {
        self._undoRedoDisposable.dispose();
        self._undoRedoDisposable = void 0;
      }
      context?.disable("undo");
      context?.disable("redo");
      let initialVersion = model.getAlternativeVersionId(), currentVersion = initialVersion, lastVersion = initialVersion;
      self._undoRedoDisposable = editor.onDidChangeModelContent(() => {
        const versionId = model.getAlternativeVersionId();
        if (versionId < currentVersion) {
          context?.enable("redo");
          if (versionId === initialVersion) {
            context?.disable("undo");
          }
        } else {
          if (versionId <= lastVersion) {
            if (versionId === lastVersion) {
              context?.disable("redo");
            }
          } else {
            context?.disable("redo");
            if (currentVersion > lastVersion) {
              lastVersion = currentVersion;
            }
          }
          context?.enable("undo");
        }
        currentVersion = versionId;
      });
    },
    diffPrevious: function() {
      this._diffEditor.goToDiff("previous");
    },
    diffNext: function() {
      this._diffEditor.goToDiff("next");
    },
    /*
     * Private functions
     */
    // readOnly logic
    _setReadOnly: function(readOnly) {
      const self = this, editor = self._editor;
      if (editor) {
        editor.updateOptions({ readOnly });
      }
    },
    // editor-specific disposable logic
    _disposableExists: function(key) {
      return DISPOSABLE_MANAGER.existsForEditor(this._editorId, key);
    },
    _registerDisposable: function(key, disposable) {
      DISPOSABLE_MANAGER.registerForEditor(this._editorId, key, disposable);
    },
    _disposeDisposable: function(key) {
      DISPOSABLE_MANAGER.disposeForEditor(this._editorId, key);
    },
    _disposeAllDisposables: function() {
      DISPOSABLE_MANAGER.deregisterEditor(this._editorId);
    },
    // triggers an internal monaco action
    _triggerMonacoAction: function(actionName) {
      const editor = this._editor;
      this.focus();
      editor.trigger(null, actionName);
    },
    // to be called after widget initializtion and when the language changes
    _configureCustomSuggestionProvider: function() {
      let self = this, editor = self._editor, o = self.options, language = editorLangToMonacoLang(o.language), suggestions = o.suggestions, finalSuggestions, word;
      if (suggestions) {
        if (Array.isArray(suggestions)) {
          finalSuggestions = suggestions;
        } else if (typeof suggestions === "function") {
          finalSuggestions = suggestions(language);
        } else {
          debugError("Suggestions type not supported");
          return;
        }
        finalSuggestions = finalSuggestions.map((suggestion) => {
          suggestion.insertText = suggestion.insertText || suggestion.label;
          return suggestion;
        });
        self._registerDisposable("global-suggestions", monaco.languages.registerCompletionItemProvider(language, {
          provideCompletionItems: function(model, position) {
            if (editor.hasTextFocus()) {
              word = model.getWordUntilPosition(position);
              const toReturn = finalSuggestions.map((suggestion) => {
                suggestion.range = {
                  startLineNumber: position.lineNumber,
                  endLineNumber: position.lineNumber,
                  startColumn: word.startColumn,
                  endColumn: word.endColumn
                };
                suggestion.kind = monaco.languages.CompletionItemKind.Constructor;
                return suggestion;
              });
              if (toReturn.length) {
                return { suggestions: toReturn };
              } else {
                return;
              }
            } else {
              return;
            }
          }
        }));
        if (typeof o.pageInfo?.applicationMessages === "function") {
          const triggerCharacters = ["$", "{", "("];
          o.pageInfo.applicationMessages().then((res) => {
            self._registerDisposable("message-suggestions", monaco.languages.registerCompletionItemProvider(language, {
              triggerCharacters,
              provideCompletionItems: function(model, position, context) {
                let toReturn = [];
                if (!editor.hasTextFocus() || ![LANG_HTML, LANG_PLAINTEXT, LANG_JAVASCRIPT].includes(language) || context.triggerKind !== monaco.languages.CompletionTriggerKind.TriggerCharacter || !triggerCharacters.includes(context.triggerCharacter)) {
                  return void 0;
                }
                const messageSuggestion = res.map((s) => ({
                  ...s,
                  range: {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: position.column,
                    endColumn: position.column
                  },
                  kind: monaco.languages.CompletionItemKind.Keyword
                }));
                const lineContent = model.getLineContent(position.lineNumber);
                const currentWord = model.getWordUntilPosition({ column: position.column - 1, lineNumber: position.lineNumber });
                if (context.triggerCharacter === "$") {
                  if (language === LANG_JAVASCRIPT || currentWord.word !== "APP_TEXT" || lineContent.charAt(currentWord.startColumn - 2) !== "&") {
                    return void 0;
                  }
                  toReturn = messageSuggestion.map((suggestion) => {
                    if (suggestion.insertText.includes(".")) {
                      suggestion.additionalTextEdits = [{
                        text: '&"APP_TEXT',
                        range: {
                          startLineNumber: position.lineNumber,
                          startColumn: currentWord.startColumn - 1,
                          endLineNumber: position.lineNumber,
                          endColumn: currentWord.endColumn
                        }
                      }];
                      suggestion.insertText = suggestion.insertText + '".';
                    } else {
                      suggestion.insertText = suggestion.insertText + ".";
                    }
                    return suggestion;
                  });
                } else if (o.pageInfo.shortMsgSyntaxSupported && context.triggerCharacter === "{") {
                  let prevChar = lineContent.charAt(currentWord.startColumn - 2);
                  if (language === LANG_JAVASCRIPT || prevChar !== "&") {
                    return void 0;
                  }
                  toReturn = messageSuggestion.map((suggestion) => {
                    suggestion.insertTextRules = monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet;
                    suggestion.placeholders?.forEach((p, idx) => {
                      suggestion.insertText = `${suggestion.insertText} ${p[1]}=\${${idx + 1}:""}`;
                    });
                    if (lineContent.charAt(currentWord.startColumn) === "}") {
                      suggestion.additionalTextEdits = [{
                        text: ".",
                        range: {
                          startLineNumber: position.lineNumber,
                          startColumn: currentWord.startColumn + suggestion.insertText.length + 1,
                          endLineNumber: position.lineNumber,
                          endColumn: currentWord.endColumn + suggestion.insertText.length + 1
                        }
                      }];
                    } else {
                      suggestion.insertText += "}.";
                    }
                    return suggestion;
                  });
                } else if (context.triggerCharacter === "(") {
                  let endOfLine = lineContent.substring(0, position.column - 2);
                  if (language !== LANG_JAVASCRIPT || !["apex.lang.getMessage", "apex.lang.formatMessage", "apex.lang.formatMessageNoEscape"].some((f) => endOfLine.endsWith(f))) {
                    return void 0;
                  }
                  toReturn = messageSuggestion.flatMap((suggestion) => {
                    if (!suggestion.isJS) {
                      return [];
                    }
                    suggestion.insertText = `"${suggestion.insertText}"`;
                    if (currentWord.word !== "getMessage") {
                      suggestion.insertTextRules = monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet;
                      suggestion.placeholders?.forEach((p, idx) => {
                        suggestion.insertText = `${suggestion.insertText}, "\${${idx + 1}:${p[0]}}"`;
                      });
                    }
                    return [suggestion];
                  });
                }
                if (toReturn.length) {
                  return {
                    suggestions: toReturn
                  };
                } else {
                  return void 0;
                }
              }
            }));
          });
        }
        if (o.language === LANG_JAVASCRIPT_MLE_SNIPPET) {
          self._registerDisposable(DISP_MLE_ENV, monaco.languages.registerCompletionItemProvider(MONACO_LANG_JAVASCRIPT, {
            triggerCharacters: ["."],
            provideCompletionItems: function(model, position, context) {
              if (
                // only if this is the editor in question
                editor.hasTextFocus() && // only if "." was pressed
                context.triggerKind === monaco.languages.CompletionTriggerKind.TriggerCharacter && context.triggerCharacter === "." && // only if the dot follows apex.env
                model.getLineContent(position.lineNumber).substr(0, position.column - 2).endsWith("apex.env")
              ) {
                word = model.getWordUntilPosition(position);
                const toReturn = finalSuggestions.map((suggestion) => {
                  suggestion.range = {
                    startLineNumber: position.lineNumber,
                    endLineNumber: position.lineNumber,
                    startColumn: word.startColumn,
                    endColumn: word.endColumn
                  };
                  suggestion.kind = monaco.languages.CompletionItemKind.Constructor;
                  return suggestion;
                });
                if (toReturn.length) {
                  return {
                    suggestions: toReturn
                  };
                } else {
                  return;
                }
              } else {
                return;
              }
            }
          }));
        }
      }
    },
    // start of minimap logic
    _setupMinimap: function() {
      const self = this, o = self.options, editor = self._editor, model = self._model;
      if (self._disposableExists(DISP_MINIMAP)) {
        self._disposeDisposable(DISP_MINIMAP);
      }
      function showHideMinimap() {
        if (editor && model && !model.isDisposed()) {
          editor.updateOptions({
            minimap: {
              enabled: o.minimap === MINIMAP_ON || o.minimap === MINIMAP_CONDITIONAL && model.getLineCount() >= 100
            }
          });
        }
      }
      if (o.minimap === MINIMAP_CONDITIONAL) {
        self._registerDisposable(DISP_MINIMAP, model.onDidChangeContent(util2.debounce(showHideMinimap, 1e3)));
      }
      showHideMinimap();
    },
    // end of minimap logic
    _normalizeNotificationObject: function(obj) {
      if (typeof obj === "object") {
        return obj;
      } else if (typeof obj === "string") {
        const newObject = {
          message: obj
        };
        const index = newObject.message.indexOf("ORA-06550");
        if (index > -1) {
          const str = newObject.message.slice(index), parsedError = str.match(/\d{1,}/g), lineNumber = parseInt(parsedError[1], 10), columnNumber = parseInt(parsedError[2], 10);
          if (!isNaN(lineNumber)) {
            newObject.lineNumber = lineNumber;
          }
          if (!isNaN(columnNumber)) {
            newObject.columnNumber = columnNumber;
          }
        }
        return newObject;
      } else {
        throw new Error("error/warning must be an object or a string");
      }
    },
    // reveals line in center and sets the cursor at the given position
    // line and column must be 1-based
    // pass focus = false, if the editor should not be focused after the position was set
    //      this can avoid console errors in cases where the focus is trapped somewhere else,
    //      like alert dialogs. see bug #33264302
    gotoPosition: function(line, column, focus = true) {
      let self = this, editor = self._editor;
      if (editor) {
        editor.revealLineInCenter(line);
        editor.setPosition({
          lineNumber: line,
          column
        });
        if (focus) {
          setTimeout(function() {
            if (editor) {
              editor.focus();
            }
          }, 100);
        }
      }
    },
    _updateNotifications: function() {
      let self = this, options = self.options, list$ = $2("<ul/>");
      function pushItem(notificationObject, cls) {
        const obj = self._normalizeNotificationObject(notificationObject), listItem$ = $2(`<li role="alert" class="${cls}"></li>`);
        listItem$.css("cursor", "pointer");
        if (obj.lineNumber && obj.columnNumber) {
          listItem$.append($2(`<a data-line="${obj.lineNumber}" data-column="${obj.columnNumber}"></a>`).text(obj.message));
        } else {
          listItem$.text(obj.message);
        }
        list$.append(listItem$);
      }
      options.errors.forEach((errorObject) => {
        pushItem(errorObject, "is-error");
      });
      options.warnings.forEach((warningObject) => {
        pushItem(warningObject, "is-warning");
      });
      if (list$.children().length) {
        self.showNotification(list$);
        $2("a[data-line]", list$).on("click", function() {
          self.gotoPosition($2(this).data("line"), $2(this).data("column"));
        });
      } else {
        self.resetNotification();
      }
      self._updateInlineMessages();
    },
    _updateInlineMessages: function() {
      let self = this, options = self.options, model = self._model, lineMessages = [];
      function cleanMessageForInline(message2) {
        return util2.stripHTML(message2.match(/.*(ORA|PLS)-\d+:(?<msg>.*)/s)?.groups?.msg || message2).trim();
      }
      function pushItem(notificationObject, severity) {
        const obj = self._normalizeNotificationObject(notificationObject);
        if (obj.lineNumber && obj.columnNumber) {
          lineMessages.push({
            startLineNumber: obj.lineNumber,
            endLineNumber: obj.lineNumber,
            startColumn: obj.columnNumber,
            endColumn: 1e3,
            message: cleanMessageForInline(obj.message),
            severity
          });
        }
      }
      options.errors.forEach((errorObject) => {
        pushItem(errorObject, monaco.MarkerSeverity.Error);
      });
      options.warnings.forEach((warningObject) => {
        pushItem(warningObject, monaco.MarkerSeverity.Warning);
      });
      monaco.editor.setModelMarkers(model, "lineMessages", lineMessages);
      if (lineMessages.length) {
        self.gotoPosition(lineMessages[0].startLineNumber, lineMessages[0].startColumn);
      }
    },
    _queryBuilder: function() {
      let fn = this.options.queryBuilder;
      if (fn) {
        fn(this, this.getValue());
      }
    },
    _codeComplete: function() {
      if (!(this.options.codeComplete && [LANG_SQL, LANG_PLSQL, LANG_JAVASCRIPT_MLE_SNIPPET].includes(this.options.language))) {
        return;
      }
      let self = this, language = self.options.language, editor = self._editor, model = self._model, currentPosition = editor.getPosition(), lineValue = model.getLineContent(currentPosition.lineNumber), word, parts, search, parent, grantParent, isItem = false, $spinner, elem = self.element[0];
      function getWordAround(s, pos) {
        while (s[pos] === " ") {
          pos = pos - 1;
        }
        pos = s.lastIndexOf(" ", pos) + 1;
        let end = s.indexOf(" ", pos);
        if (end === -1) {
          end = s.length;
        }
        return s.substring(pos, end);
      }
      word = getWordAround(lineValue, currentPosition.column - 1);
      parts = word.split(".");
      if ([LANG_SQL, LANG_PLSQL].includes(language)) {
        if (parts.length === 1 && [":", "&"].includes(word.charAt(0))) {
          isItem = true;
          search = word.slice(1);
        } else {
          parent = parts[parts.length - 2];
          grantParent = parts[parts.length - 3];
        }
      } else if (language === LANG_JAVASCRIPT_MLE_SNIPPET) {
        if (parts.length === 3 && parts[0] === "apex" && parts[1] === "env") {
          isItem = true;
          search = parts[2];
          parent = void 0;
          grantParent = void 0;
        } else {
          self._triggerMonacoAction("editor.action.triggerSuggest");
          return;
        }
      }
      function _success(pData) {
        apex.util.delayLinger.finish("autocompleteSpinner", function() {
          if ($spinner) {
            $spinner.remove();
            $spinner = null;
          }
        });
        let kinds = monaco.languages.CompletionItemKind;
        let monacoTypes = {
          template: kinds.Constructor,
          application_item: kinds.Constructor,
          page_item: kinds.Constructor,
          package: kinds.Constructor,
          procedure: kinds.Method,
          function: kinds.Function,
          constant: kinds.Constructor,
          variable: kinds.Constructor,
          type: kinds.Constructor,
          table: kinds.Constructor,
          view: kinds.Constructor,
          keyword: kinds.Constructor,
          sequence: kinds.Constructor
        };
        let type, completion, completions = [];
        for (let i = 0; i < pData.length; i++) {
          type = pData[i];
          for (let j = 0; j < type.completions.length; j++) {
            completion = type.completions[j];
            let text = completion.r || completion;
            completions.push({
              label: completion.d || completion,
              insertText: text,
              detail: type.title,
              kind: monacoTypes[type.type]
            });
          }
        }
        let alreadyShown = false;
        self._registerDisposable("ajax-suggestions", monaco.languages.registerCompletionItemProvider(model.getLanguageId(), {
          provideCompletionItems: function() {
            if (self.element.hasClass(C_ACTIVE) && !alreadyShown) {
              alreadyShown = true;
              if (completions.length) {
                return {
                  suggestions: completions
                };
              } else {
                return;
              }
            } else {
              return;
            }
          }
        }));
        self._triggerMonacoAction("editor.action.triggerSuggest");
      }
      util2.delayLinger.start("autocompleteSpinner", function() {
        $spinner = util2.showSpinner(elem);
      });
      self.options.codeComplete({
        type: isItem ? "item" : "",
        search: isItem ? search : parts[parts.length - 1],
        parent,
        grantParent
      }, _success);
    },
    validateCode: function() {
      if (!this.options.validateCode) {
        return;
      }
      let self = this;
      self.options.validateCode(self.getValue(), function(results) {
        results = $2.extend({}, { errors: [], warnings: [] }, results);
        self._setOption("errors", results.errors);
        self._setOption("warnings", results.warnings);
        if (!isSave && results.errors.length === 0 && results.warnings.length === 0) {
          self.showSuccessNotification(util2.escapeHTML(MSG_VALIDATION_SUCCESS));
        }
      });
      isSave = false;
    },
    _notifyPreferenceChange: function() {
      let self = this, element = self.element[0];
      self._trigger("preferencesChanged", $2.Event("click", { target: element }));
    },
    _populateContext: function() {
      let self = this, o = self.options, language = o.language, editor = self._editor, model = self._model, context = self._context;
      function updateIndentation() {
        model.updateOptions({
          insertSpaces: o.tabsInsertSpaces,
          tabSize: o.tabSize,
          indentSize: o.indentSize
        });
      }
      context.add([
        {
          name: "undo",
          action: function() {
            self._triggerMonacoAction("undo");
          }
        },
        {
          name: "redo",
          action: function() {
            self._triggerMonacoAction("redo");
          }
        },
        {
          name: "find",
          action: function() {
            self._triggerMonacoAction(o.readOnly ? "actions.find" : "editor.action.startFindReplaceAction");
          }
        },
        {
          name: "font-size",
          get: function() {
            return o.fontSize;
          },
          set: function(v) {
            self._setOption("fontSize", v);
            self._notifyPreferenceChange();
          },
          choices: OPTIONS_FONT_SIZE
        },
        {
          name: "theme",
          get: function() {
            return o.theme;
          },
          set: function(v) {
            o.theme = v;
            setTheme(v);
            self._notifyPreferenceChange();
          },
          choices: OPTIONS_THEME
        },
        {
          name: "minimap",
          get: function() {
            return o.minimap;
          },
          set: function(v) {
            o.minimap = v;
            self._setupMinimap();
            self._notifyPreferenceChange();
          },
          choices: OPTIONS_MINIMAP
        },
        {
          name: "tabs-insert-spaces",
          label: MSG_INDENT_WITH_TABS,
          get: function() {
            return o.tabsInsertSpaces;
          },
          set: function(v) {
            o.tabsInsertSpaces = v;
            updateIndentation();
            self._notifyPreferenceChange();
          }
        },
        {
          name: "tab-size",
          get: function() {
            return o.tabSize;
          },
          set: function(v) {
            o.tabSize = v;
            updateIndentation();
            self._notifyPreferenceChange();
          },
          choices: OPTIONS_TAB_SIZE
        },
        {
          name: "indent-size",
          get: function() {
            return o.indentSize;
          },
          set: function(v) {
            o.indentSize = v;
            updateIndentation();
            self._notifyPreferenceChange();
          },
          choices: OPTIONS_INDENT_SIZE
        },
        {
          name: "show-ruler",
          label: MSG_SHOW_RULER,
          get: function() {
            return o.ruler;
          },
          set: function(v) {
            self._setOption("ruler", v);
            self._notifyPreferenceChange();
          }
        },
        {
          name: "line-numbers",
          label: MSG_SHOW_LINE_NUMBERS,
          get: function() {
            return o.lineNumbers;
          },
          set: function(v) {
            self._setOption("lineNumbers", v);
            self._notifyPreferenceChange();
          }
        },
        {
          name: "whitespace",
          label: MSG_WHITESPACE,
          get: function() {
            return o.whitespace;
          },
          set: function(v) {
            self._setOption("whitespace", v);
            self._notifyPreferenceChange();
          }
        },
        {
          name: "show-suggestions",
          label: MSG_SUGGESTIONS,
          get: function() {
            return o.showSuggestions;
          },
          set: function(v) {
            self._setOption("showSuggestions", v);
            self._notifyPreferenceChange();
          }
        },
        {
          name: "bracket-pair-colorization",
          label: MSG_BRACKET_PAIR_COLORIZATION,
          get: function() {
            return o.bracketPairColorization;
          },
          set: function(v) {
            self._setOption("bracketPairColorization", v);
            self._notifyPreferenceChange();
          }
        }
        /* {
            name: "semantic-highlighting",
            label: "Semantic Highlighting", // TODO localize
            get: function() {
                return o.semanticHighlighting;
            },
            set: function( v ) {
                self._setOption( "semanticHighlighting", v );
                self._notifyPreferenceChange();
            }
        } */
      ]);
      if (o.queryBuilder) {
        context.add({
          name: "query-builder",
          hide: ![LANG_SQL, LANG_PLSQL].includes(language),
          // initial hidden state
          action: function() {
            self._queryBuilder();
          }
        });
      }
      if (o.codeComplete) {
        context.add({
          name: "code-complete",
          hide: ![LANG_SQL, LANG_PLSQL, LANG_JAVASCRIPT_MLE_SNIPPET].includes(language),
          // initial hidden state
          action: function() {
            self._codeComplete();
          }
        });
        editor.addAction({
          id: "apex-code-complete",
          label: MSG_HINT,
          keybindings: [getUniversalCtrlKey() | monaco.KeyCode.Space],
          precondition: CONTEXT_KEY_DBHINT,
          run: function() {
            self._codeComplete();
          }
        });
      }
      if (o.validateCode) {
        context.add({
          name: "validate",
          hide: !this._hasValidate(),
          // initial hidden state
          action: function() {
            self.validateCode();
          }
        });
        editor.addAction({
          id: "apex-code-validate",
          label: MSG_VALIDATE,
          keybindings: [getUniversalCtrlKey() | monaco.KeyMod.Alt | monaco.KeyCode.KeyV],
          precondition: CONTEXT_KEY_VALIDATE,
          run: function() {
            self.validateCode();
          }
        });
      }
      if (o.diffEditor) {
        context.add([{
          name: "diff-previous",
          action: function() {
            self.diffPrevious();
          },
          title: MSG_PREVIOUS_CHANGE,
          label: MSG_PREVIOUS_CHANGE,
          shortcut: "Alt+Shift+F5"
        }, {
          name: "diff-next",
          action: function() {
            self.diffNext();
          },
          title: MSG_NEXT_CHANGE,
          label: MSG_NEXT_CHANGE,
          shortcut: "Alt+F5"
        }]);
      }
      if (o.dialogSave) {
        if (o.pageInfo.isPageDesigner) {
          context.add({
            name: ACTION_SAVE_AND_RUN_PAGE,
            action: function(event, element) {
              isSave = true;
              o.dialogSave(event, element, true);
            }
          });
          editor.addAction({
            id: "apex-" + ACTION_SAVE_AND_RUN_PAGE,
            label: lang2.format(MSG_SAVE_AND_RUN_PAGE, []),
            keybindings: [monaco.KeyMod.Alt | monaco.KeyCode.F7, monaco.KeyMod.Alt | monaco.KeyCode.F8],
            run: function(editor2) {
              isSave = true;
              o.dialogSave({}, editor2.getDomNode(), true);
            }
          });
        } else {
          context.add({
            name: ACTION_SAVE_PAGE,
            action: function(event, element) {
              isSave = true;
              o.dialogSave(event, element);
            }
          });
          editor.addAction({
            id: "apex-" + ACTION_SAVE_PAGE,
            label: lang2.format(MSG_SAVE_PAGE, []),
            keybindings: [monaco.KeyMod.Alt | monaco.KeyCode.F8, monaco.KeyMod.Alt | monaco.KeyCode.F7],
            run: function(editor2) {
              isSave = true;
              o.dialogSave({}, editor2.getDomNode());
            }
          });
        }
      }
      if (o.ai) {
        context.add({
          name: ACTION_AI,
          label: MSG_APEX_ASSISTANT,
          ariaControls: self._rightPanelId,
          get: () => {
            return self._aiEnabled;
          },
          set: (value) => {
            self._aiEnabled = value;
            if (value) {
              if (!self._chat) {
                this._aiCallback();
              } else {
                self._chatView.show();
                self.resize();
                self._chatToolbar$.css("visibility", "visible");
                self._toggleQuickActions();
                self._context.enable(ACTION_AI_SEND_SELECTION);
              }
            } else {
              if (self._chat) {
                self._chatView.hide();
                self._rightPanel$.width(0);
                self._chatToolbar$.css("visibility", "hidden");
                self.resize();
                self._editor.focus();
                self._context.disable(ACTION_AI_SEND_SELECTION);
                self._chat.quickActions = [];
              }
            }
          }
        });
        context.add({
          name: ACTION_AI_SEND_SELECTION,
          action: async (event, focusElement, { showAiMessage = true, isNewConversation = true } = {}) => {
            hasSelection = this._hasSelection();
            if (hasSelection) {
              isConversation = false;
              if (isNewConversation) {
                const messages = self._chat.getMessages();
                if (messages.length > 2 || messages.length === 2 && !messages[1].excludeFromCommits) {
                  await self._expireConversation();
                }
              }
              self._chatContext.invoke(ACTION_AI_SEND_CODE_MESSAGE, null, null, self.getSelection());
              if (showAiMessage) {
                self._chat.addAiMessage(MSG_AI_QUICK_ACTION_QUESTION);
              }
              if (self._currentAssistant === ACTION_AI_GENERAL) {
                self._chat.quickActions = [{
                  title: MSG_IMPROVE_TITLE,
                  message: MSG_IMPROVE_MSG
                }, {
                  title: MSG_EXPLAIN_TITLE,
                  message: MSG_EXPLAIN_MSG
                }];
              }
              self._toggleQuickActions();
              isConversation = true;
            } else {
              self._chat.addAiMessage(MSG_AI_USE_THIS_WARNING);
            }
            return true;
          }
        });
        context.add({
          name: ACTION_SWITCH_PANE_FOCUS,
          shortcut: "F6",
          action: () => {
            if (self._aiEnabled) {
              if (!self._editor.hasTextFocus()) {
                self.focus();
              } else {
                self._chatView.el.querySelector("textarea").focus();
              }
              return true;
            }
          }
        });
      }
    },
    async _expireConversation() {
      await this._chat.expire();
      this._chat.addAiMessage(MSG_NEW_CONVERSATION, {
        excludeFromCommits: true,
        cssClasses: "a-ChatItem-row--context"
      });
      const messageViews = this._chatView.getMessageViews();
      messageViews[messageViews.length - 1].el.classList.remove("a-ChatItem-row--inbound");
    },
    _toggleQuickActions() {
      if (!this._aiEnabled || chatLocked || suppressCursorPositionChange) {
        suppressCursorPositionChange = false;
        return;
      }
      if (isConversation) {
        isConversation = false;
        this._addSelectionQuickActions();
        return;
      }
      const quickActions = this._chat.quickActions;
      if (quickActions?.length) {
        if (!this._hasSelection()) {
          quickActions.forEach((actionCfg) => actionCfg.disabled = true);
          this._chat.quickActions = quickActions;
        } else {
          if (quickActions[0].disabled) {
            this._scrollToBottom = this._chatView.isTranscriptScrolledToBottom();
            quickActions.forEach((actionCfg) => actionCfg.disabled = false);
            this._chat.quickActions = quickActions;
          }
        }
      }
    },
    _addSelectionQuickActions() {
      const self = this;
      const disabled = !this._hasSelection();
      const quickActions = [{
        title: MSG_USE_SELECTION,
        disabled,
        action: function() {
          self._context.invoke(ACTION_AI_SEND_SELECTION, null, null, {
            showAiMessage: self._currentAssistant === ACTION_AI_GENERAL
          });
        }
      }];
      if (self._currentAssistant === ACTION_AI_GENERAL) {
        quickActions.push({
          title: MSG_IMPROVE_SEL_TITLE,
          disabled,
          action: function() {
            self._context.invoke(ACTION_AI_SEND_SELECTION, null, null, {
              showAiMessage: false
            });
            if (hasSelection) {
              self._chat.quickActions = [];
              self._chat.addUserMessage(MSG_IMPROVE_MSG);
              self._chat.commit();
            }
          }
        }, {
          title: MSG_EXPLAIN_SEL_TITLE,
          disabled,
          action: function() {
            self._context.invoke(ACTION_AI_SEND_SELECTION, null, null, {
              showAiMessage: false
            });
            if (hasSelection) {
              self._chat.quickActions = [];
              self._chat.addUserMessage(MSG_EXPLAIN_MSG);
              self._chat.commit();
            }
          }
        });
      }
      self._chat.quickActions = quickActions;
    },
    _hasSQLErrors() {
      let { errors, warnings } = this.options;
      errors = errors.filter((error) => error !== lang2.getMessage("PD.PE.IS_REQUIRED"));
      return !!errors.length || !!warnings.length;
    },
    _hasSelection() {
      return this.getSelection().trim() !== "";
    },
    _getChatInitMessage(mode) {
      return mode === ACTION_AI_GENERAL ? MSG_AI_GENERAL_WELCOME : MSG_AI_QUERY_BUILDER_WELCOME;
    },
    _aiCallback: function() {
      const self = this, content = this.getValue(), ai = apex.ai;
      let hasSelection2 = this._hasSelection();
      let hasErrorOrWarning;
      self._currentAssistant = self.options.language === LANG_SQL ? ACTION_AI_NL2SQL : ACTION_AI_GENERAL;
      const getChatLanguage = () => {
        const language = this.options.language;
        return AI_LANGS.includes(language) ? language : LANG_PLAINTEXT;
      };
      const getFormattedCodeMessage = (code, codeLanguage) => {
        let language = codeLanguage || getChatLanguage();
        if (language !== LANG_PLSQL) {
          language = editorLangToMonacoLang(language);
        }
        return lang2.formatNoEscape("```%0\n%1\n```", language, code);
      };
      const sendCodeMessage = (code, hidden = false) => {
        self._chat.addUserMessage(getFormattedCodeMessage(code), {
          type: self._chat.constructor.messageTypes.MARKDOWN,
          cssClasses: "a-ChatItem-row--context",
          hidden
        });
        const messageViews = self._chatView.getMessageViews();
        messageViews[messageViews.length - 1].el.classList.remove("a-ChatItem-row--outbound");
      };
      const sendNotificationMessage = () => {
        let { errors, warnings } = self.options;
        errors = errors.filter((error) => error !== lang2.getMessage("PD.PE.IS_REQUIRED"));
        let code, message2;
        if (errors.length > 0) {
          code = errors.join(", ");
          message2 = MSG_AI_ERROR_MESSAGE;
        } else {
          code = warnings.join(", ");
          message2 = MSG_AI_WARNING_MESSAGE;
        }
        const content2 = lang2.format(message2, getFormattedCodeMessage(code, LANG_PLAINTEXT));
        self._chat.addUserMessage(content2, {
          type: self._chat.constructor.messageTypes.MARKDOWN,
          hidden: true
        });
      };
      const processMessage = (model, messageModel) => {
        if (model.getCurrentUser() === messageModel.user) {
          return {};
        }
        const codeBlockQuickActions = [ai.ChatView.actions.COPY];
        if (!self._editor.getOption(monaco.editor.EditorOption.readOnly)) {
          codeBlockQuickActions.push({
            label: MSG_INSERT,
            iconClasses: "icon-clipboard",
            action: (view, messageView, actionObj, buttonEl, codeBlockEl) => {
              const cls = "is-inserted";
              const newIconClasses = "ui-icon-check";
              const datasetName = "insertTimeoutId";
              const { iconClasses } = actionObj;
              const labelEl = buttonEl.querySelector(".a-ChatItem-buttonLabel");
              const iconEl = buttonEl.querySelector(".a-ChatItem-buttonIcon");
              const runningTimeout = parseInt(buttonEl.dataset[datasetName], 10);
              if (runningTimeout) {
                return;
              }
              buttonEl.classList.add(cls);
              labelEl.innerText = MSG_INSERTED;
              suppressCursorPositionChange = true;
              self._editor.pushUndoStop();
              self._editor.executeEdits(
                "",
                [{
                  range: self._editor.getSelection(),
                  // either a selection or the cursor position
                  text: codeBlockEl.innerText.trim().replaceAll(/\u00A0/g, " ")
                }]
              );
              self._editor.pushUndoStop();
              if (iconEl) {
                if (iconClasses) {
                  iconEl.classList.toggle(...iconClasses.split(" "));
                }
                if (newIconClasses) {
                  iconEl.classList.toggle(...newIconClasses.split(" "));
                }
              }
              buttonEl.dataset[datasetName] = setTimeout(() => {
                delete buttonEl.dataset[datasetName];
                buttonEl.classList.remove(cls);
                if (labelEl) {
                  labelEl.innerText = MSG_INSERT;
                }
                if (iconEl) {
                  if (iconClasses) {
                    iconEl.classList.toggle(...iconClasses.split(" "));
                  }
                  if (newIconClasses) {
                    iconEl.classList.toggle(...newIconClasses.split(" "));
                  }
                }
              }, 3e3);
            }
          });
        }
        return { codeBlockQuickActions };
      };
      const initChatToolbar = () => {
        self._chatContext = actions.createContext("chatEditor", self.element[0]);
        self._chatContext.add([{
          name: ACTION_AI_MODE,
          get: () => {
            return self._currentAssistant;
          },
          set: (value, silent) => {
            if (![ACTION_AI_NL2SQL, ACTION_AI_GENERAL].includes(value)) {
              return;
            }
            self._currentAssistant = value;
            self._chatContext.invoke(ACTION_AI_CLEAR_CHAT);
            isConversation = false;
            if (!silent) {
              if (self._hasSelection()) {
                if (self._currentAssistant === ACTION_AI_NL2SQL) {
                  self._chat.quickActions = [];
                }
                self._context.invoke(ACTION_AI_SEND_SELECTION, null, null, { showAiMessage: false });
              } else {
                self._chat.addAiMessage(self._getChatInitMessage(value), {
                  excludeFromCommits: true
                });
              }
            }
            self._chatToolbar$.toolbar("option", "data", toolbarData());
            self._chatToolbar$.toolbar("findElement", "chatModeSelector").focus();
          },
          choices: [
            { label: MSG_AI_QUERY_BUILDER, value: ACTION_AI_NL2SQL },
            { label: MSG_AI_GENERAL_ASSISTANCE, value: ACTION_AI_GENERAL }
          ]
        }, {
          name: ACTION_AI_CLEAR_CHAT,
          action: async () => {
            await self._chat.clear();
            self._addSelectionQuickActions();
          }
        }, {
          name: ACTION_AI_SEND_CODE_MESSAGE,
          action: (event, focusElement, data) => {
            sendCodeMessage(data);
          }
        }]);
        self._chatToolbar$.toolbar({
          actionsContext: self._chatContext,
          simple: true,
          data: toolbarData()
        });
        self.resize();
      };
      const getCurrentModeName = () => {
        return self._currentAssistant === ACTION_AI_GENERAL ? MSG_AI_GENERAL_ASSISTANCE : MSG_AI_QUERY_BUILDER;
      };
      const toolbarData = () => {
        const data = [];
        if ([LANG_SQL, LANG_PLSQL].includes(self.options.language)) {
          data.push({
            id: "chatModeControls",
            align: "start",
            groupTogether: false,
            customCSS: C_TOOLBAR_GROUP,
            controls: [{
              type: "MENU",
              id: "chatModeSelector",
              title: getCurrentModeName(),
              label: getCurrentModeName(),
              menu: {
                items: [{
                  type: "radioGroup",
                  action: ACTION_AI_MODE
                }]
              }
            }]
          });
        }
        data.push({
          id: "chatControls",
          align: "end",
          groupTogether: false,
          customCSS: C_TOOLBAR_GROUP,
          controls: [{
            type: "BUTTON",
            title: MSG_CLEAR_CHAT,
            label: MSG_CLEAR_CHAT,
            iconOnly: false,
            iconBeforeLabel: true,
            action: ACTION_AI_CLEAR_CHAT
          }]
        });
        return data;
      };
      self._sendDebugMessage = () => {
        const selection = self.getSelection();
        const editorContent = self.getValue();
        const content2 = selection !== "" ? selection : editorContent;
        if (chatLocked) {
          return;
        }
        self._chatContext.set(ACTION_AI_MODE, ACTION_AI_GENERAL, true);
        self._chat.addAiMessage(MSG_AI_DEBUG_MESSAGE);
        sendNotificationMessage();
        sendCodeMessage(content2, true);
        self._chat.addUserMessage(MSG_DEBUG_MESSAGE, {
          type: self._chat.constructor.messageTypes.MARKDOWN,
          hidden: true
        });
        self._chat.quickActions = [];
        self._chat.commit();
      };
      if (hasErrorOrWarning && !hasSelection2 && content.length > 4e3) {
        message.alert(MSG_CONTENT_TOO_LONG);
        return;
      }
      ai.getUserConsent().then((granted) => {
        if (granted) {
          self._chat = new ai.ChatModel({
            ...self.options.ai.ajax,
            processMessage,
            requestHandler: () => {
              let chatLanguage = getChatLanguage();
              if (self._currentAssistant === ACTION_AI_NL2SQL) {
                chatLanguage = "sql-query";
              }
              return {
                serverData: JSON.stringify({
                  language: chatLanguage
                })
              };
            }
          });
          self._chatView = new ai.ChatView(self._chat, {
            mode: ai.ChatView.renderModes.INLINE,
            el: self._chatEl$[0],
            disclaimer: MSG_DISCLAIMER,
            highlightCode: (chatApp, mainView, messageView, el) => {
              if (el.getAttribute("data-lang") === LANG_PLSQL) {
                el.setAttribute("data-lang", LANG_SQL);
              }
              monaco.editor.colorizeElement(el, { theme: this._editor._themeService._theme.themeName });
            }
          });
          initChatToolbar();
          self._chat.on(ai.ChatModel.events.LOCK, () => {
            chatLocked = true;
            isConversation = true;
            lastSelection = self.getSelection();
            self._chatToolbar$.find("button").attr("disabled", true);
          });
          self._chat.on(ai.ChatModel.events.UNLOCK, () => {
            chatLocked = false;
            self._chatToolbar$.find("button").attr("disabled", false);
            setTimeout(() => {
              if (self.getSelection() !== lastSelection) {
                self._addSelectionQuickActions();
              }
            }, 1);
          });
          if (self._currentAssistant === ACTION_AI_NL2SQL) {
            hasErrorOrWarning = this._hasSQLErrors();
            if (hasErrorOrWarning) {
              self._sendDebugMessage();
            } else if (content !== "" && !hasSelection2) {
              const range = self._editor.getModel().getFullModelRange();
              self._editor.setSelection(range);
              hasSelection2 = true;
            }
          }
          self._editor.onDidChangeCursorSelection(util2.debounce(self._toggleQuickActions.bind(self)), 250);
          self._chatEl$[0].addEventListener("transitionend", (e) => {
            if (e.target.classList.contains("a-ChatActions-quickPicks")) {
              if (self._scrollToBottom) {
                self._chatView.scrollTranscriptToBottom();
                self._scrollToBottom = false;
              }
            }
          });
          if (!hasErrorOrWarning) {
            if (hasSelection2) {
              self._context.invoke(ACTION_AI_SEND_SELECTION, null, null, {
                showAiMessage: false,
                isNewConversation: false
              });
            } else {
              setTimeout(() => {
                self._chat.addAiMessage(self._getChatInitMessage(self._currentAssistant), {
                  excludeFromCommits: true
                });
                self._addSelectionQuickActions();
              }, 1);
            }
          }
        } else {
          debugWarn("The User has not consented to the use of AI.");
          self._context.set(ACTION_AI, false);
        }
      });
    },
    _initToolbar: function(container$) {
      let o = this.options, helper;
      let config = {
        actionsContext: this._context,
        simple: true,
        data: [],
        label: MSG_ROLE_DESC
        // "Editor"
      };
      function getKeyDisplay(str) {
        return isMac() ? str.replace("Alt", "Option").replace("Ctrl", "Control") : str;
      }
      let undoControls = [];
      undoControls.push({
        type: "BUTTON",
        title: MSG_UNDO,
        label: MSG_UNDO,
        iconOnly: true,
        icon: "icon-undo",
        action: "undo"
      });
      undoControls.push({
        type: "BUTTON",
        title: MSG_REDO,
        label: MSG_REDO,
        iconOnly: true,
        icon: "icon-redo",
        action: "redo"
      });
      config.data.push({
        id: "undoControls",
        align: "start",
        groupTogether: true,
        controls: undoControls
      });
      let searchControls = [];
      searchControls.push({
        type: "BUTTON",
        title: MSG_FIND,
        label: MSG_FIND,
        iconOnly: true,
        icon: "icon-cm-find",
        action: "find"
      });
      config.data.push({
        id: "searchControls",
        align: "start",
        groupTogether: true,
        controls: searchControls
      });
      if (o.queryBuilder || o.codeComplete || o.validateCode || o.ai) {
        let helperGroup = {
          id: "helperControls",
          align: "start",
          groupTogether: true,
          controls: []
        };
        if (o.queryBuilder) {
          helperGroup.controls.push({
            type: "BUTTON",
            title: MSG_QUERY_BUILDER,
            label: MSG_QUERY_BUILDER,
            iconOnly: true,
            icon: "icon-cm-query-builder",
            action: "query-builder"
          });
        }
        if (o.codeComplete) {
          helper = MSG_HINT + " - " + getKeyDisplay("Ctrl+Space");
          helperGroup.controls.push({
            type: "BUTTON",
            title: helper,
            label: helper,
            iconOnly: true,
            icon: "icon-cm-autocomplete",
            action: "code-complete"
          });
        }
        if (o.validateCode) {
          helper = MSG_VALIDATE + " - " + getKeyDisplay("Ctrl+Alt+V");
          helperGroup.controls.push({
            type: "BUTTON",
            title: helper,
            label: helper,
            iconOnly: true,
            icon: "icon-cm-validate",
            action: "validate"
          });
        }
        let aiGroup = {
          id: "aiControls",
          align: "start",
          groupTogether: true,
          controls: []
        };
        if (o.ai) {
          aiGroup.controls.push({
            type: "TOGGLE",
            title: MSG_APEX_ASSISTANT,
            label: MSG_APEX_ASSISTANT,
            iconOnly: false,
            iconBeforeLabel: true,
            icon: "icon-apex-assistant",
            action: ACTION_AI
          });
        }
        config.data.push(helperGroup);
        config.data.push(aiGroup);
      }
      if (o.diffEditor) {
        const helperGroup = {
          id: "diffControls",
          align: "end",
          groupTogether: true,
          controls: []
        };
        helperGroup.controls.push({
          type: "BUTTON",
          action: "diff-previous",
          icon: "icon-prev-change",
          iconOnly: true
        });
        helperGroup.controls.push({
          type: "BUTTON",
          action: "diff-next",
          icon: "icon-next-change",
          iconOnly: true
        });
        config.data.push(helperGroup);
      }
      if (o.dialogSave) {
        let saveControls = [];
        if (o.pageInfo.isPageDesigner) {
          helper = lang2.format(MSG_SAVE_AND_RUN_PAGE, "- " + getKeyDisplay("Alt+F8"));
          saveControls.push({
            type: "BUTTON",
            title: helper,
            label: lang2.format(MSG_SAVE_AND_RUN_PAGE, []),
            iconOnly: !!o.ai,
            // hide label if ai is enabled
            iconBeforeLabel: true,
            icon: "icon-run-page",
            action: ACTION_SAVE_AND_RUN_PAGE
          });
        } else {
          helper = lang2.format(MSG_SAVE_PAGE, "- " + getKeyDisplay("Alt+F7"));
          saveControls.push({
            type: "BUTTON",
            title: helper,
            label: lang2.format(MSG_SAVE_PAGE, []),
            ...o.ai && { icon: "icon-ig-save" },
            // icon only visible if ai is enabled
            iconOnly: !!o.ai,
            // hide label if ai is enabled
            action: ACTION_SAVE_PAGE
          });
        }
        config.data.push({
          id: "saveControls",
          align: "end",
          groupTogether: false,
          customCSS: C_TOOLBAR_GROUP,
          controls: saveControls
        });
      }
      config.data.push({
        id: "menuControls",
        align: "end",
        groupTogether: false,
        controls: [{
          type: "MENU",
          title: MSG_SETTINGS,
          label: MSG_SETTINGS,
          iconOnly: true,
          icon: "icon-gear",
          menu: {
            items: [
              /*{
                  type: "subMenu",
                  label: "Language Settings", // TODO localize
                  menu: {
                      items: [ {
                          type: "subMenu",
                          label: "JavaScript",
                          menu: {
                              items: [ {
                                  type: "toggle",
                                  action: "semantic-highlighting"
                              }, {
                                  type: "toggle",
                                  action: "inlay-hints"
                              } ]
                          }
                      } ]
                  }
              },*/
              {
                type: "subMenu",
                label: MSG_FONT_SIZE,
                menu: {
                  items: [{
                    type: "radioGroup",
                    action: "font-size"
                  }]
                }
              },
              {
                type: "subMenu",
                label: MSG_INDENTATION,
                menu: {
                  items: [
                    {
                      type: "toggle",
                      action: "tabs-insert-spaces"
                    },
                    {
                      type: "subMenu",
                      label: MSG_TAB_SIZE,
                      menu: {
                        items: [{
                          type: "radioGroup",
                          action: "tab-size"
                        }]
                      }
                    },
                    {
                      type: "subMenu",
                      label: MSG_INDENT_SIZE,
                      menu: {
                        items: [{
                          type: "radioGroup",
                          action: "indent-size"
                        }]
                      }
                    }
                  ]
                }
              },
              {
                type: "subMenu",
                label: MSG_THEMES,
                menu: {
                  items: [{
                    type: "radioGroup",
                    action: "theme"
                  }]
                }
              },
              {
                type: "subMenu",
                label: MSG_MINIMAP,
                menu: {
                  items: [{
                    type: "radioGroup",
                    action: "minimap"
                  }]
                }
              },
              {
                type: "toggle",
                action: "line-numbers"
              },
              {
                type: "toggle",
                action: "show-ruler"
              },
              {
                type: "toggle",
                action: "show-suggestions"
              },
              {
                type: "toggle",
                action: "whitespace"
              },
              {
                type: "toggle",
                action: "bracket-pair-colorization"
              }
            ]
          }
        }]
      });
      container$.toolbar(config);
      if (o.diffEditor) {
        container$.find("button[data-action*='diff']").removeAttr("data-no-update");
      }
    },
    // should be called on widget initialization and whenever the language changes
    // the language should not be sanatized. ie. we expect the mle- prefix in the case of mle-javascript
    _evaluateContextKeys: function(language) {
      if (!this._contextKeys) {
        this._contextKeys = {};
      }
      const keys = this._contextKeys, editor = this._editor;
      if (!keys[CONTEXT_KEY_VALIDATE]) {
        keys[CONTEXT_KEY_VALIDATE] = editor.createContextKey(CONTEXT_KEY_VALIDATE, true);
      }
      if (!keys[CONTEXT_KEY_DBHINT]) {
        keys[CONTEXT_KEY_DBHINT] = editor.createContextKey(CONTEXT_KEY_DBHINT, true);
      }
      keys[CONTEXT_KEY_VALIDATE].set(this._hasValidate());
      keys[CONTEXT_KEY_DBHINT].set([LANG_SQL, LANG_PLSQL, LANG_JAVASCRIPT_MLE_SNIPPET].includes(language));
    },
    _setLanguage: function(language) {
      let self = this, model = self._model, editor = self._editor, o = self.options, context = self._context, monacoLanguage = editorLangToMonacoLang(language);
      monaco.editor.setModelMarkers(model, "lineMessages", []);
      self.resetNotification();
      self._configureCustomSuggestionProvider();
      function hide(actionName) {
        if (context.lookup(actionName)) {
          context.hide(actionName);
        }
      }
      function show(actionName) {
        if (context.lookup(actionName)) {
          context.show(actionName);
        }
      }
      if ([LANG_SQL, LANG_PLSQL, LANG_JAVASCRIPT_MLE_SNIPPET].includes(language)) {
        show("code-complete");
      } else {
        hide("code-complete");
      }
      if ([LANG_SQL, LANG_PLSQL].includes(language)) {
        show("query-builder");
      } else {
        hide("query-builder");
      }
      if (this._hasValidate()) {
        show("validate");
      } else {
        hide("validate");
      }
      if (self._chatContext) {
        self._chatContext.set(ACTION_AI_MODE, ACTION_AI_GENERAL);
      }
      self._evaluateContextKeys(language);
      loadLanguageDependencies(language, o);
      monaco.editor.setModelLanguage(model, monacoLanguage);
      editor.updateOptions(self._getLanguageDependentMonacoOptions());
    },
    _hasValidate: function() {
      const o = this.options, lang3 = o.language;
      return [LANG_SQL, LANG_PLSQL, LANG_HTML, LANG_JAVASCRIPT_MLE_SNIPPET].includes(lang3) && o.validateCode !== void 0;
    },
    /*
        * Add warnings to page item references which don't exist
        * This only takes into account page items of the current page and the global page
        * as these are the only ones we currently know about
        * We assume the conventional Pnnn_[alphanum_]* name types
        */
    _initializeItemValidator: function() {
      let self = this, model = self._model, o = self.options, pageId = o.pageInfo.pageId, itemRegex = new RegExp("P(" + pageId + "|0)_[A-Z0-9_]*", "gi"), warnings = [];
      let pageItems = o.pageInfo.items.map((item) => item.name.toLowerCase());
      let verify = util2.debounce(function() {
        warnings = [];
        if (model && !model.isDisposed()) {
          const lineCount = model.getLineCount();
          for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
            const lineContent = model.getLineContent(lineNumber);
            const matches = lineContent.matchAll(itemRegex);
            for (let match of matches) {
              let foundItem = match[0].toLowerCase(), itemFoundAt = match.index + 1;
              if (!pageItems.includes(foundItem)) {
                warnings.push({
                  startLineNumber: lineNumber,
                  endLineNumber: lineNumber,
                  startColumn: itemFoundAt,
                  endColumn: itemFoundAt + foundItem.length,
                  message: lang2.formatMessage("CODE_EDITOR.ITEM_DOES_NOT_EXIST", foundItem.toUpperCase()),
                  severity: monaco.MarkerSeverity.Warning
                });
              }
            }
          }
          monaco.editor.setModelMarkers(model, "itemValidations", warnings);
        }
      }, 100);
      model.onDidChangeContent(verify);
      verify();
    },
    /*
        * Configuration of various shortcuts and extra editor actions
        */
    _initializeCustomActions: function() {
      let self = this, editor = self._editor, model = self._model, universalCtrlKey = getUniversalCtrlKey();
      function overrideActionKeybinding(actionId, newKeyBinding) {
        let action = editor.getAction(actionId);
        editor.addAction({
          id: actionId,
          label: action.label,
          alias: action.alias,
          keybindings: [newKeyBinding],
          run: function() {
            action.run();
          }
        });
      }
      overrideActionKeybinding("editor.action.transformToUppercase", universalCtrlKey | monaco.KeyMod.Alt | monaco.KeyCode.KeyU);
      overrideActionKeybinding("editor.action.transformToLowercase", universalCtrlKey | monaco.KeyMod.Alt | monaco.KeyCode.KeyL);
      if (self.options.diffEditor) {
        delete editor._actions["editor.action.diffReview.prev"];
        delete editor._actions["editor.action.diffReview.next"];
      }
      editor.addAction({
        id: "editor.action.toggleSmartCase",
        label: MSG_TRANSFORM_CODE_CASE,
        alias: MSG_TRANSFORM_CODE_CASE,
        keybindings: [universalCtrlKey | monaco.KeyMod.Alt | monaco.KeyCode.KeyC],
        run: function() {
          let selections = editor.getSelections();
          if (!selections.length) {
            return;
          }
          if (!model) {
            return;
          }
          let edits = [];
          for (let i = 0; i < selections.length; i++) {
            let selection = selections[i];
            if (!selection.isEmpty()) {
              let text = model.getValueInRange(selection);
              let transformedText = transformCodeCase(text);
              edits.push({
                range: selection,
                text: transformedText
              });
            }
          }
          editor.pushUndoStop();
          editor.executeEdits(null, edits);
          editor.pushUndoStop();
        }
      });
      editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyP, () => {
        self._triggerMonacoAction("editor.action.quickCommand");
      });
    },
    /*
        * Returns an object of Monaco editor options which are dependent on the current editor language.
        * To be used on the initial init, and on each subsequent language change.
        * See #35281964
        */
    _getLanguageDependentMonacoOptions: function() {
      const self = this, o = self.options, monacoLanguage = editorLangToMonacoLang(o.language);
      return {
        // when editing plaintext, enforce the wordWrap option
        // otherwise respect the passed in options
        wordWrap: o.language === LANG_PLAINTEXT ? true : o.wordWrap ? "on" : "off",
        // has side effect of not formatting multi-lines of SQL when indenting which is what we want
        useTabStops: [LANG_SQL, LANG_PLSQL].includes(o.language) ? false : true,
        // fixes the terrible word-based-suggestions coming from monaco-typescript
        // see github.com/microsoft/monaco-editor/issues/1980
        suggest: monacoLanguage === MONACO_LANG_JAVASCRIPT ? { showFiles: false } : void 0
      };
    },
    /* Mixins */
    ...mixins
  });
  $2.apex.codeEditor = {
    LANG_SQL,
    LANG_PLSQL,
    LANG_JAVASCRIPT,
    LANG_JAVASCRIPT_MLE_SNIPPET,
    LANG_JAVASCRIPT_MLE_MODULE,
    LANG_CSS,
    LANG_FILE_URLS_JAVASCRIPT: langId,
    LANG_FILE_URLS_CSS: langId2,
    LANG_HTML,
    LANG_XML,
    LANG_QUICKSQL: langId4,
    LANG_PLAINTEXT,
    LANG_YAML,
    LANG_JSON,
    LANG_TD_PLAINTEXT: langIdTdPlainText,
    LANG_TD_HTML: langIdTdHtml,
    LANG_APEXLANG: LANG_ID,
    LANG_MARKDOWN,
    registerJavaScriptContextCode: JAVASCRIPT_MANAGER.setContext,
    deregisterJavaScriptContextCode: JAVASCRIPT_MANAGER.dropContext,
    preferencesObjectFromString: (optionsString) => {
      let rawOptions, finalOptions = {};
      if (!optionsString) {
        return {};
      }
      try {
        rawOptions = JSON.parse(optionsString);
      } catch (e) {
        debugWarn("Could not parse optionsString");
        return {};
      }
      Object.values(PREF).forEach((item) => {
        let value = rawOptions[item], key = item;
        if (key === PREF.FONT_SIZE) {
          if (!OPTIONS_FONT_SIZE.map((option) => option.value).includes(value)) {
            debugWarn("Bad number ignored: " + value);
            return;
          }
        } else if (key === PREF.THEME) {
          if (!OPTIONS_THEME.map((option) => option.value).includes(value)) {
            debugWarn("Bad theme ignored: " + value);
            return;
          }
        } else if ([PREF.INDENT_SIZE, PREF.TAB_SIZE].includes(key)) {
          if (!["2", "3", "4", "8"].includes(value)) {
            debugWarn("Bad number ignored: " + value);
            return;
          }
        } else if (key === "minimap") {
          if (!OPTIONS_MINIMAP.map((option) => option.value).includes(value)) {
            debugWarn("Bad minimap ignored: " + value);
            return;
          }
        } else if ([
          // boolean preferences
          PREF.TABS_INSERT_SPACES,
          PREF.RULER,
          PREF.LINE_NUMBERS,
          PREF.WHITESPACE,
          PREF.SHOW_SUGGESTIONS,
          PREF.BRACKET_PAIR_COLORIZATION
          /*,
          PREF.SEMANTIC_HIGHLIGHTING,
          PREF.INLAY_HINTS */
        ].includes(key)) {
          value = !!value;
        } else {
          debugWarn("Unknown preference: " + key);
          return;
        }
        finalOptions[key] = value;
      });
      return finalOptions;
    }
  };
})();
/*!
 * Copyright (c) 2013, 2026, Oracle and/or its affiliates.
 */
/*!
 * Copyright (c) 2025, Oracle and/or its affiliates.
 */

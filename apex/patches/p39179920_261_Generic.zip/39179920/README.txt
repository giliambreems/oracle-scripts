# Oracle APEX Product Version #  : 26.1.4
#
# Patch Set Exception : Bug 39179920 - PSE BUNDLE FOR APEX 26.1 (PSES ON TOP OF 26.1.x)
#
# Platform Patch for  : Generic - Platform independent
#
# DATE : Aug 13, 2026
#
# This document describes how you can install the Patch Set Exception on your Oracle APEX 26.1.x instance.
#
#
# (I) Requirements
# ----------------
# Before you install the patch, ensure that you meet the following requirement:
#
#    - You must be using Oracle APEX Product Version #  : 26.1.x
#
# If you do NOT meet this requirement, or are not certain that you meet
# the requirement, please log a Service Request and Oracle Support will make
# a determination about whether you should apply this patch.
#
#
# (II) Bugs Fixed by this patch
# -----------------------------
# ----- PATCH_VERSION: 1 -----
# 39393807 - APEXLANG IMPORT FAILS FOR WORKFLOWS HAVING PARALLEL FLOW ACTIVITY
# 39253802 - INTERACTIVE REPORT: GROUP BY AND PIVOT DIALOGS CONTAIN POOR ACC LABELS
# 39370733 - PAGE DESIGNER: TEMPLATE COMPONENT GROUP ATTRIBUTES NOT VISIBLE
# 39314519 - REGRESSION : HUMAN TASK CREATION FAILS IF TASK PARAMETER VALUE IS LONGER THAN 255 CHARACTERS
# 39402028 - INVALID PROPERTY ERROR ON APEXLANG IMPORT WHEN IG COLUMN GROUPS ARE PRESENT IN REGIONS OTHER THAN INTERACTIVE GRID
# 39335842 - OBJECT BROWSER DATA TAB INSERT ROW FAILS FOR ANY TABLE WITH A CLOB COLUMN
# 39348655 - OCI GEMINI AI CHAT REQUESTS FAIL WHEN TOOL CALLS ARE PRESENT
# 39351143 - AI ASSISTANT UI/COLOR ISSUES
# 39289752 - COPY AND SUBSCRIBE REST DATA SOURCE LEADS TO SUBSCRIPTION STATUS NEEDS REFRESH
# 39344085 - IMPORTING REST SOURCE CATALOG THROWS UNIQUE CONSTRAINT ERROR (WWV_FLOW_COLLECTIONS_UK), BUT IMPORTS SUCCESSFULLY
# 39322631 - APEXLANG VIEW IN PAGE DESIGNER FAILS TO SHOW SOME APEXLANG SLOT NAMES
# 39370209 - Fix for bug 39370209
# 39377187 - Fix for bug 39377187
# 39377430 - Fix for bug 39377430
# 39393826 - WHEN P_INCLUDE_SESSION_STATE IS SET TO 'N' THEN SESSION STATE SHOULD BE CLEARED IN IMPORT
# 39409232 - FIX FOR BUG 39409232
# 39411363 - MONACO EDITOR CANNOT LOAD WORKERS VIA CDN
# 39377463 - Fix for bug 39377463
# 39390907 - REGRESSION - PAGE DESIGNER: JS ERROR IS THROWN WHEN UPDATING BACKGROUND PAGE PROCESS
# 39344241 - CORRECT MASTER/DETAIL WIZARD REMEMBER_SELECTION RDS PROPERTY VALUE
# 39411937 - NEXT LINK IS NOT WORKING ON THE MAIL QUEUE REPORT
# 39344501 - APEXLANG IMPORT DOES NOT PRESERVE WORKING COPY LINK
# 39378321 - REGRESSION: ERROR USING MAP LAYER WITH POINT CLUSTERING ENABLED
# 39288075 - ADMIN DIGEST > SUMMARY DASHBOARD SHOWS 0 COUNTS
# 39427432 - SQL SCRIPT IMPORT NULLS OUT THE CONTENT AND RAISES ORA-06502 IF EDIT CLICKED
# 36767291 - SELECT ONE/MANY VALUE HTML EXPR SUBSTS FAIL IF LOV ADDL COL NAMES CLASH W/ CLASSIC REPORT COLS
# 39383767 - REGRESSION: MAP REGION USING "ICON" STYLE W SUBSTITUTION FOR POINT LAYER FAILS WITH JS ERROR
# 39377425 - Fix for bug 39377425
# 39370202 - Fix for bug 39370202
# 39377223 - Fix for bug 39377223
# 39368814 - Fix for bug 39368814
# 39377297 - Fix for bug 39377297
# 39377263 - Fix for bug 39377263
# 39377881 - Fix for bug 39377881
# 39325666 - UNABLE TO SET ROWS PER PAGE FROM ACTION MENU WHEN SET USING AN EARLIER NATURAL LANGUAGE REQUEST
# 39427696 - REGRESSION: ERROR IMPORTING WORKSPACE FILES EXPORT FROM APEX VERSION BEFORE 26.1
# 39406656 - Fix for bug 39406656
# 39420516 - MASTER COMPONENT CHECKSUM NOT CALCULATED ON APP IMPORT
# 39409312 - Fix for bug 39409312
# 39359834 - APEXLANG UI IMPORT | DURING IMPORT EXPORTED FROM ORACLE APEX VERSION FIELD HAS NO VALUE
# 39378662 - Fix for bug 39378662
# 39385135 - Fix for bug 39385135
# 39385197 - Fix for bug 39385197
# 39385277 - Fix for bug 39385277
# 39409291 - Fix for bug 39409291
# 39465239 - EXPOSE APEX AUTHENTICATION AS DATA REPORTER AUTHENTICATION SCHEME
# 39409270 - Fix for bug 39409270
# 39474195 - APEXLANG EXPORT: F?P URL PARSING MISHANDLES QUOTED UNALIASED SQL COLUMN EXPRESSION WITH COMMAS
# 39397271 - APEX 26.1 INSTALLATION FAILS ON 19C SE2 DATABASE - ORA-439: FEATURE NOT ENABLED: BASIC COMPRESSION
# 39359824 - APEXLANG UI IMPORT ERROR - UNABLE TO FIND APEX CONTENT INSTALL.SQL OR APPLICATION.APX
# ----- PATCH_VERSION: 2 -----
# 39416789 - APEX DAILY JOB ORACLE_APEX_DAILY_METRICS FAILED WITH ORA-01555 AFTER UPGRADE TO APEX 26.1
# 39467407 - IN TEXT MSG TRANSLATION APP, ALT IR SAVED RPT SHOWS &{NAME}. UNEXPECTEDLY
# 39538497 - Fix for bug 39538497
# 39483916 - REGRESSION: DATA LOAD CREATE WIZARD DOES NOT ALLOW TAB AS COLUMN DELIMITER
# 39401806 - APP IMPORT FAILS WITH "ORA-20111: FOR PROCESS AND ITEM TYPE PLUGINS..." ERROR
# 39571361 - Fix for bug 39571361
# 39552100 - REGRESSION: WORKSPACE IMPORT IN APP 4050 ALWAYS RAISES "SCHEMA IS RESTRICTED" WHEN SCHEMA ALREADY EXISTS
# 39540365 - WORKFLOW COMPONENT: ASYNC WORKFLOW ACTIVITY CAN BE RESET TO WAITING AFTER IT FAULTS DURING EXECUTION
# 39548318 - CSP NONCE VIOLATION DURING CLASSIC REPORT AJAX REFRESH DUE TO SERVER-GENERATED STYLE
# 39622909 - Fix for bug 39622909
# 39587362 - ADMIN DIGEST - SYSTEM SCHEDULER JOBS REPORT INCLUDES USER-GENERATED APEX SCHEDULER JOBS
# 39426028 - SUBSCRIPTION IS LOST WHEN REFRESHING AN APPLICATION COMPUTATION
# 39539076 - REGRESSION: IR COLUMN TYPE LIST INCLUDE UNSUPPORTED TEMPLATE COMPONENTS
# 39575309 - REGRESSION: FILE BROWSE W/ SUPPORTED FILE EXTENSIONS IN UPPERCASE FAILS IN 26.1
# 39411057 - FULL EXPORT GENERATES INVALID SQL FOR WORKFLOW LINKED TASK INSTANCES
# 39552165 - APEX SHIPS JET LIBRARY CONTAINING (OUTDATED) DEVELOPMENT ARTIFACTS
# 39493465 - LONG URLS CAUSE DEBUG ERROR: ORA-06502: PL/SQL: VALUE OR CONVERSION ERROR: CHARACTER STRING BUFFER TOO SMALL
# 39537216 - AI AGENT SYSTEM PROMPT TEMPLATE DIRECTIVES NOT WORKING AS DOCUMENTED
# 39563236 - CSP NONCE VIOLATION DURING USE OF RICH TEXT EDITOR
# 39406703 - APEX_AUTHENTICATION.LOGOUT RETURNS BLANK PAGE AND DOES NOT REDIRECT FOR SOCIAL SIGN-IN OAUTH2 AFTER 26.1 UPGRADE
# 39595332 - REGRESSION: DYNAMIC ACTIONS GENERATED IN WORKFLOW CONSOLE AND TASK DETAILS PAGES ARE INCOMPLETE
# 39683227 - APEX 26.1 - REGRESSION UNGUARDED CLIPBOARDITEM.SUPPORTS() CALL IN DESKTOP_ALL.MIN.JS THROWS UNCAUGHT TYPEERROR ON SAFARI <18.4
# 39574632 - Fix for Bug 39574632
# ----- PATCH_VERSION: 3 -----
# 39716106 - APEXLANG EXPORT SKIPS FORMAT MASK FOR FACETS AND HAS SPARTIAL INDEX FOR MAPS
# 39718475 - CREATE A LEGACY PAGE FORM ENDS WITH ERROR-ORA-20001
# 39623051 - CREATE PAGE WIZ CAN CREATE EDITABLE GRID W/ MORE SELECT LISTS THAN EXPECTED
# 39735488 - ORA-6502 CONVERTING APPLICATION TEXT WITH OVER 1000 MESSAGES
# 39699404 - THEME ROLLER SAVE FAILS WITH ORA-28461 ON FIPS-ENABLED DATABASES
# 39700366 - REGRESSION: STAR RATING COL IN INTERACTIVE GRID ALWAYS SHOWS ONE STAR IN 26.1
# 39659750 - REGRESSION: SEARCH CONFIG ON DBMS_SEARCH RAISES NULL INDEX TABLE KEY VALUE
# 39689808 - APEX REGION PLUG-IN: INCONSISTENT HANDLING OF DEPRECATED STATIC IDS AFFECTING MULTI-VERSION BACKWARD COMPATIBILITY
# 39779736 - CANNOT USE AGENT WITH TOOLS AND GPT-5.6
# 39547705 - AVOID TRAILING ^M CHARACTER IN CSS AND JS URL STRING ARRAYS IN APEXLANG
# 39664657 - ADB: CREATED DATA REPORTER ADMIN OR EDITOR CANNOT SIGN IN TO WORKSPACE
# 39664718 - ADB: IN DATA REPORTER, SWITCHING ROLE TYPE FROM VIEWER TO EDITOR THROWS "ERROR PROCESSING VALIDATION" ERROR
# 39664758 - ADB: IN DATA REPORTER, SWITCHING USER ROLE THROWS ERROR "REQUIRE CHANGE OF PASSWORD ON FIRST USE MUST MATCH THE VALUES Y AND N"
# 39781640 - REGRESSION IN 24.2: PAGE DESIGNER DOES NOT CREATE "PARAMETERS" NODE FOR MAP LAYERS / CHART SERIES ON REST SOURCE
# 39722171 - BUTTON OF TYPE MENU ON GLOBAL PAGE DOES NOT SHOW THE MENU ON CLICK
# 39804519 - REGRESSION IN 26.1.2: RICH TEXT EDITOR IN MARKDOWN MODE ESCAPES VARIOUS SPECIAL CHARACTERS
# 39792845 - IT TAKES LONGER TO IMPORT TEXT MESSAGES IN APEX 26.1 THAN BEFORE
# 39803148 - APP UNAVAILABLE MESSAGE CANNOT BE SET FOR STATUS UNAVAILABLE (REDIRECT TO URL)
# 39749091 - MERGING CHANGED WORKFLOW FROM WORKING COPY TO MAIN DELETES EXISTING INSTANCES
# 39768927 - REGRESSION: RICH TEXT EDITOR UNEXPECTEDLY SAVES UNESCAPED SPACES IN MARKDOWN URLS
# 39557252 - APEX IMPORT DOES NOT PRESERVE APPLICATION LOCKS
# 39800372 - LEGACY DATA LOAD - UNABLE TO NAVIGATE TO ADDITIONAL TRANSFORMATION RULES PAGES
# 39741741 - ORA-6502 DURING TRANSLATE AND SYNC MESSAGES
# 39772421 - PLUGIN ATTRIBUTE STATIC IDS ARE INCORRECT AFTER UPGRADE FROM PRE-23.2 APEX
# 39790911 - Fix for bug 39790911
# 39818972 - Fix for bug 39818972
# 39816636 - REGRESSION: ORA-1426 NUMERIC OVERFLOW ON GETPAGEDATA IF APPID > 2147483647
# ----- NEW IN PATCH_VERSION: 4 -----
# 39847677 - ORA-1400 CONVERTING APP TEXT TO MESSAGES WITH TRANSLATABLE REPORT TEMPLATES
# 39834991 - IR FILTERS ON DATE COLUMN LOSE CONDITION DISPLAY UNEXPECTEDLY ON APEXLANG IMPORT
# 39863901 - Fix for bug 39863901
# 39830923 - REGRESSION: ORA-6502 OPENING PAGE DESIGNER IF PLUGIN HAS LONG ATTR GROUP APEXLANG NAME
# 39872578 - UNABLE TO INSTALL APEX 26.1.3 PATCH ON SE2 DATABASE - ORA-00439: FEATURE NOT ENABLED: ONLINE INDEX BUILD
# 39832528 - PROPERTY VALUE OF SINGLE LEFT SQUARE BRACKET CAN CONFUSE APEXLANG COMPILER
#
# (III) Patch Installation Instructions
# -------------------------------------
# To apply the patch:
#
#  1. Download the p39179920_261_GENERIC.zip patch set installation archive to a directory that is not the Oracle home directory or under the Oracle home directory.
#
#  2. Unzip and extract the installation files by double-clicking p39179920_261_GENERIC.zip in a Microsoft Windows based system, or entering the following command to unzip on a UNIX or Linux based system:
#
#   $ unzip p39179920_261_GENERIC.zip
#
#  3. Preventing Access to Oracle REST Data Services
#
#     It is important that no developers or end users access Oracle APEX while you are applying the patch. This section describes how to prevent access to Oracle APEX.
#
#     Stopping Oracle REST Data Services:
#
#        To learn more about stopping the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#        https://docs.oracle.com/en/database/oracle/oracle-rest-data-services/index.html
#
#  4. Set your current directory to the "39179920" directory where you unzipped the p39179920_261_GENERIC.zip file.
#
#  5. Set the NLS_LANG environment variable, making sure that the character set is AL32UTF8. For example:
#
#     Bourne or Korn shell:
#
#       NLS_LANG=American_America.AL32UTF8
#       export NLS_LANG
#
#     C shell:
#
#       setenv NLS_LANG American_America.AL32UTF8
#
#     For Windows based systems:
#
#       set NLS_LANG=American_America.AL32UTF8
#
#  6. Connect to the database where Oracle APEX is installed as the SYS user and run catpatch.sql or catpatch_con.sql as in the following examples:
#
#     sql "sys/ as sysdba" @catpatch.sql        -- for non-CDB and for CDB where Oracle APEX is not installed in the root, and for PDB where APEX is not installed in the root
#     sql "sys/ as sysdba" @catpatch_con.sql    -- for CDB where Oracle APEX is installed in the root
#     sql "sys/ as sysdba" @catpatch_appcon.sql -- for installations where Oracle APEX is installed in an application container
#
#  7. Install the Patch Set Exception's changes in the images directory
#
#       Copy the images directory of the patch to the /images folder of the Oracle APEX installation directory images sub directory.
#
#       Assuming the p39179920_261_GENERIC.zip file was unzipped to c:\temp on Windows and /tmp on Linux
#
#       On a Windows system, run a command from a command prompt similar to the following example:
#
#           xcopy /E /I c:\temp\images ORACLE_APEX_HOME\apex\images
#
#       On UNIX or Linux based systems, run a command similar to the following example:
#
#           cp -rf /tmp/images ORACLE_APEX_HOME/apex
#
#       In the preceding syntax examples, ORACLE_APEX_HOME is the existing Oracle APEX installation location. For example, c:\oracle\apex_26.1 on Windows and /oracle/apex_26.1 on Linux.
#
#  8. Starting Oracle APEX
#
#    - Starting Oracle REST Data Services
#
#       To learn more about starting the Oracle REST Data Services server, see Oracle REST Data Services Installation and Configuration Guide:
#
#           https://docs.oracle.com/en/database/oracle/oracle-rest-data-services/index.html
#
#
# (IV) New APEX 26.1 Content Delivery Network (CDN)
# -------------------------------------------------
# APEX 26.1 static resources are available on a CDN, https://static.oracle.com/cdn/apex/26.1.4/.
#   - The CDN contains the production APEX 26.1.0 static resources and the updated static resources included in 26.1.1, 26.1.2, 26.1.3 and 26.1.4.
#
#    I. Instance using the APEX CDN
#
#       If your instance is currently using the APEX CDN, this patch automatically updates the CDN reference to the 26.1.4 version. No further action needed.
#
#   II. Instance not yet using the APEX CDN
#
#       If you wish to convert your instance to use the static resources from the 26.1.4 CDN, you will need to reset the APEX images prefix for your instance. This change can be performed on a live system.
#
#       To convert an instance to use the CDN:
#
#       - Set your current directory to the directory where the production APEX 26.1 zipfile was extracted. For example, c:\temp\apex_ on Windows and /tmp/apex_ on Linux.
#
#       - Navigate to the apex/utilities subdirectory of the production APEX 26.1 directory. For example, /tmp/apex_/apex/utilities
#
#       - Connect to the database where Oracle APEX is installed as SYS and run reset_image_prefix.sql, as in the following example:
#
#         sql "sys/ as sysdba" @reset_image_prefix.sql
#
#       - When prompted for the image prefix, enter the CDN path, as follows:
#
#         https://static.oracle.com/cdn/apex/26.1.4/
#
#  III. Use the APEX CDN in a single APEX application
#
#       If you wish to use the APEX CDN in a single APEX application:
#
#       - In App Builder, edit your application and click "Shared Components"
#
#       - Click "User Interface Attributes"
#
#       - Under Advanced, in the #APEX_FILES# Path enter as follows:
#
#         https://static.oracle.com/cdn/apex/26.1.4/
#
#       - Click "Apply Changes"
#
#
# (V) To confirm the patch has been applied
# -----------------------------------------
#
#    I. Review the Product Build number on your instance
#
#       - Log into your workspace.
#
#       - Review the Product Build number displayed in the lower right corner.
#
#         If your instance has been patched, the build number will be 26.1.x, where x is the PATCH_VERSION. For example, 26.1.4.
#         In your instance has not been patched, the build number will be 26.1.x.
#
#   II. Review the About dialog on your instance
#
#       - Log into your workspace.
#
#       - Click 'Help' > 'About'.
#
#       - Review the Details section:
#
#         'Patch Version' will display the version of the patch installed.
#         'Last Patch Time' will display the patch installation date and time.
#         These values will only be visible on a patched instance.
#
#  III. Start SQLcl and connect to the database where Oracle APEX is installed as SYS. For example:
#
#         - On Windows:
#
#                 SYSTEM_DRIVE:\> sql /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password:
#
#         - On UNIX and Linux:
#
#                 $ sql /nolog
#                 SQL> CONNECT SYS as SYSDBA
#                 Enter password:
#
#            Enter the following statement to verify the patch with patch_number 39179920 has been installed:
#
#                 select patch_version, installed_on
#                   from apex_patches
#                  where patch_number = 39179920
#                  order by installed_on;
#
#            Multiple rows will be returned if earlier versions of this patch have been installed.
#
#            Enter the following statement to verify the APEXlang version for this patch:
#
#                 select apexlang_version
#                   from apex_release;
#
#
# EOF README.txt

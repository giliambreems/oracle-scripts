set define '^' verify off
set concat on
set concat .
prompt ...devpatch.sql

Rem  Copyright (c) 1999, 2026, Oracle and/or its affiliates.
Rem
Rem    NAME
Rem      devpatch.sql
Rem
Rem    DESCRIPTION
Rem      Oracle APEX patch for a full development installation.
Rem
Rem    MODIFIED   (MM/DD/YYYY)
Rem    hfarrell    10/13/2020 - Created

define APPUN  = 'APEX_260100'
define PREFIX = '^1'

alter session set current_schema = SYS;
--------------------------------------------------------------------------------
-- Grants
--------------------------------------------------------------------------------
grant select on sys.dba_external_tables to ^APPUN;

alter session set current_schema = ^APPUN;

---------------------------------------------------------------------------
-- Compilation of package specifications
-- @^PREFIX.foo.sql
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- Compilation of views
-- @^PREFIX.dev_views.sql
---------------------------------------------------------------------------

-------------------------------------------------------------------
-- Compilation of package bodies
-------------------------------------------------------------------
@^PREFIX.modules/catalog/wwv_web_src_catalog.plb
@^PREFIX.modules/data_reporter/wwv_dr_app_dev.plb
@^PREFIX.modules/data_reporter/wwv_dr_user_dev.plb
@^PREFIX.wwv_flow_ai_dev.plb
@^PREFIX.copy_metadata.plb
@^PREFIX.wwv_flow_dynamic_action_dev.plb
@^PREFIX.wwv_flow_file_editor_dev.plb
@^PREFIX.wwv_flow_map_region_dev.plb
@^PREFIX.wwv_flow_query_builder.plb
@^PREFIX.wizapi.plb
@^PREFIX.wwv_flow_property_dev.plb
@^PREFIX.wwv_flow_report_dev.plb
@^PREFIX.wwv_flow_web_src_dev.plb
@^PREFIX.wwv_flow_working_copy_dev.plb

--------------------------------------------------------------------------------
-- Grants and public synonyms
--------------------------------------------------------------------------------

-------------------------------------------------------------------
-- patch files
-- @^PREFIX.patch_123456.sql
-------------------------------------------------------------------
@^PREFIX.patch_39383200.sql
@^PREFIX.patch_39288075_dev.sql
@^PREFIX.patch_39370202_dev.sql
@^PREFIX.patch_39377223_dev.sql
@^PREFIX.patch_39368814_dev.sql
@^PREFIX.patch_39377297_dev.sql
@^PREFIX.patch_39377263_dev.sql
@^PREFIX.patch_39377881_dev.sql
@^PREFIX.patch_39406656_dev.sql
@^PREFIX.patch_39359834_dev.sql
@^PREFIX.patch_39378662_dev.sql
@^PREFIX.patch_39465239_dev.sql
@^PREFIX.patch_39483916_dev.sql
@^PREFIX.patch_39587362_dev.sql
@^PREFIX.patch_39735488_dev.sql
@^PREFIX.patch_39664718_dev.sql
@^PREFIX.patch_39664758_dev.sql
@^PREFIX.patch_39800372_dev.sql
@^PREFIX.patch_39803148_dev.sql

-- commit after dml changes to metadata
commit;
